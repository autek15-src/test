#!/usr/bin/env python3
from __future__ import annotations
import subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    tests=sorted((ROOT/'tests').glob('test_*.py'));fail=0
    for t in tests:
        print(f'== {t.name} ==');r=subprocess.run([sys.executable,str(t)],cwd=ROOT);fail=max(fail,r.returncode)
    if fail:return fail
    r=subprocess.run([sys.executable,str(ROOT/'evals/run_evals.py')],cwd=ROOT)
    if r.returncode:return r.returncode
    print(f'All {len(tests)} test files and evaluation scenarios passed.');return 0
if __name__=='__main__':raise SystemExit(main())
