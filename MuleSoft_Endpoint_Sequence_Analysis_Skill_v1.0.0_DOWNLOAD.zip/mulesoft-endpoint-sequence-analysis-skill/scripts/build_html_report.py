#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,html,json,re
from collections import defaultdict,Counter
from pathlib import Path

def esc(v):return html.escape('' if v is None else str(v),quote=True)
def slug(v):return re.sub(r'[^a-z0-9]+','-',str(v).lower()).strip('-') or 'item'
def read_csv(p):
    if not p.exists():return []
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def read_text(p):return p.read_text(encoding='utf-8',errors='replace') if p.exists() else ''
def simple_md(t):
    out=[]
    for line in t.splitlines():
        if line.startswith('# '):out.append(f'<h2>{esc(line[2:])}</h2>')
        elif line.startswith('## '):out.append(f'<h3>{esc(line[3:])}</h3>')
        elif line.startswith('### '):out.append(f'<h4>{esc(line[4:])}</h4>')
        elif line.startswith('- '):out.append(f'<li>{esc(line[2:])}</li>')
        elif line.strip():out.append(f'<p>{esc(line)}</p>')
    return '\n'.join(out)
def table(rows,cols=None,table_id=''):
    if not rows:return '<div class="empty">No records.</div>'
    cols=cols or list(rows[0].keys())
    out=[f'<div class="table-wrap"><table id="{esc(table_id)}"><thead><tr>']+[f'<th>{esc(c)}</th>' for c in cols]+['</tr></thead><tbody>']
    for r in rows:
        out.append('<tr>');out.extend(f'<td>{esc(r.get(c,""))}</td>' for c in cols);out.append('</tr>')
    out.append('</tbody></table></div>');return ''.join(out)
def svg_embed(root:Path,puml_rel:str):
    if not puml_rel:return '<div class="diagram-missing">Sequence diagram not available</div>'
    p=root/puml_rel; svg=p.with_suffix('.svg')
    if not svg.exists():return f'<div class="diagram-missing">Sequence diagram not available<br><code>{esc(svg.relative_to(root).as_posix())}</code></div>'
    text=read_text(svg)
    if re.search(r'(?i)(error occurred|IllegalStateException|syntax error\??|assumed diagram type)',text):return '<div class="diagram-missing">Sequence diagram not available: render error detected</div>'
    return f'<div class="diagram-wrap seq-diagram">{text}</div><div class="diagram-links"><a href="{esc(puml_rel)}">PlantUML source</a> · <a href="{esc(svg.relative_to(root).as_posix())}">SVG</a></div>'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('analysis',type=Path);ap.add_argument('--output',type=Path);a=ap.parse_args();root=a.analysis.resolve();out=a.output or root/'endpoint-sequence-analysis.html'
    endpoints=read_csv(root/'current-state/endpoint-inventory.csv');flows=read_csv(root/'current-state/endpoint-flow-inventory.csv');paths=read_csv(root/'current-state/endpoint-path-inventory.csv');steps=read_csv(root/'current-state/endpoint-flow-steps.csv');parts=read_csv(root/'current-state/endpoint-participants.csv');checks=read_csv(root/'current-state/endpoint-checklist.csv');evidence=read_csv(root/'current-state/endpoint-evidence.csv');gaps=read_csv(root/'current-state/gaps-unknowns.csv');cands=read_csv(root/'evidence/endpoint-candidates.csv');sources=read_csv(root/'evidence/source-inventory.csv');policies=read_csv(root/'current-state/policy-inventory.csv');traffic=read_csv(root/'current-state/traffic-evidence.csv')
    by_ep=defaultdict(list);by_flow=lambda rows: defaultdict(list)
    for r in flows:by_ep[r.get('endpoint_id','')].append(r)
    pbf=by_flow(paths);sbf=by_flow(steps);ptbf=by_flow(parts);cbf=by_flow(checks);ebf=by_flow(evidence);gbf=by_flow(gaps);tbf=by_flow(traffic)
    for coll,rows in [(pbf,paths),(sbf,steps),(ptbf,parts),(cbf,checks),(ebf,evidence),(gbf,gaps),(tbf,traffic)]:
        for r in rows:coll[r.get('flow_id','')].append(r)
    policies_ep=defaultdict(list)
    for r in policies:policies_ep[r.get('endpoint_id','')].append(r)
    status_counts=Counter(r.get('endpoint_status','UNKNOWN') for r in endpoints)
    multi=sum(1 for e,v in by_ep.items() if len(v)>1); checklist_total=len(checks); checklist_pass=sum(r.get('status') in {'PASS','NOT_APPLICABLE'} for r in checks)
    svg_clean=0
    for fl in flows:
        rel=fl.get('primary_sequence_diagram','');p=root/rel if rel else None
        if p and p.with_suffix('.svg').exists() and not re.search(r'(?i)(error occurred|IllegalStateException|syntax error\??|assumed diagram type)',read_text(p.with_suffix('.svg'))):svg_clean+=1
    nav=[];endpoint_sections=[]
    for ep in endpoints:
        eid=ep.get('endpoint_id',''); eid_slug=slug(eid); eflows=by_ep.get(eid,[])
        nav.append(f'<a href="#endpoint-{eid_slug}"><span>{esc(eid)}</span><small>{esc(ep.get("method_or_operation"))} {esc(ep.get("resource_or_source"))}</small></a>')
        buttons=[];panels=[]
        for idx,fl in enumerate(eflows):
            fid=fl.get('flow_id',''); rel=fl.get('primary_sequence_diagram','');stem=Path(rel).stem if rel else slug(fid); active=' active' if idx==0 else ''
            buttons.append(f'<button class="flow-tab{active}" data-panel="flow-{esc(stem)}">{esc(fid)} · {esc(fl.get("flow_name"))}</button>')
            pcols=['path_id','path_name','path_type','decision_condition','source_branch_or_location','terminal_outcome','diagram_coverage','gap_id','evidence_refs']
            scols=['step_number','actor_or_system','business_action','technical_action','source_component','target_component','protocol_method_operation','endpoint_or_event','data_or_transformation','authentication_authorization','timeout_retry','response_or_outcome','error_or_alternate_path','evidence_class','evidence_refs','source_locations']
            ecols=['evidence_id','evidence_role','fact_supported','source_type','source_location','evidence_class','observation_window','notes']
            ccols=['check_id','category','check_item','status','evidence_refs','notes'];gcols=['gap_id','severity','category','missing_information','potentially_missed_behavior','impact','attempted_sources','status','owner_or_followup']
            panels.append(f'''<article class="flow-panel{active}" id="flow-{esc(stem)}" data-flow-search="{esc((fid+' '+fl.get('flow_name','')+' '+fl.get('business_purpose','')+' '+fl.get('primary_actor','')).lower())}">
<div class="flow-head"><div><div class="eyebrow">{esc(fid)} · endpoint {esc(eid)}</div><h3>{esc(fl.get('flow_name'))}</h3><p>{esc(fl.get('business_purpose'))}</p></div><span class="confidence">{esc(fl.get('evidence_class'))} · {esc(fl.get('confidence'))}</span></div>
<div class="meta-grid"><div><b>Trigger</b><span>{esc(fl.get('trigger'))}</span></div><div><b>Actor / consumer</b><span>{esc(fl.get('primary_actor'))} / {esc(fl.get('user_type_or_consumer'))}</span></div><div><b>Entry condition</b><span>{esc(fl.get('entry_condition'))}</span></div><div><b>Outcome</b><span>{esc(fl.get('final_outcome'))}</span></div><div><b>Upstream</b><span>{esc(fl.get('upstream_components'))}</span></div><div><b>Downstream</b><span>{esc(fl.get('downstream_systems'))}</span></div></div>
<h4>End-to-end sequence</h4>{svg_embed(root,rel)}
<h4>Material paths and choices</h4>{table(pbf.get(fid,[]),pcols)}
<h4>Step-by-step business and technical behavior</h4>{table(sbf.get(fid,[]),scols)}
<details open><summary>Participants and systems</summary>{table(ptbf.get(fid,[]))}</details>
<details open><summary>Sources and evidence used</summary>{table(ebf.get(fid,[]),ecols)}</details>
<details><summary>Runtime observations</summary><div class="callout">Traffic values are observations from the stated evidence window, not configured system limits unless explicitly documented as such.</div>{table(tbf.get(fid,[]))}</details>
<details><summary>Completeness checklist</summary>{table(cbf.get(fid,[]),ccols)}</details>
<details open><summary>Unknowns and potentially missed behavior</summary>{table(gbf.get(fid,[]),gcols)}</details>
</article>''')
        if not eflows:
            panels=['<div class="diagram-missing">No flow rows documented for this endpoint.</div>']
        endpoint_sections.append(f'''<section class="endpoint-section" id="endpoint-{eid_slug}" data-search="{esc((' '.join(str(v) for v in ep.values())).lower())}">
<div class="section-head"><div class="eyebrow">Endpoint</div><h2>{esc(eid)} · {esc(ep.get('method_or_operation'))} {esc(ep.get('resource_or_source'))}</h2><p>{esc(ep.get('api_name'))} · {esc(ep.get('application'))}</p></div>
<div class="endpoint-summary">{table([ep],['endpoint_status','protocol','ingress_type','implementation_entrypoint','consumer_relationship','authentication','authorization','request_content_type','response_content_type','policy_refs','source_evidence_refs','runtime_evidence_refs','documentation_evidence_refs','notes'])}</div>
<h3>Policies / security attached to endpoint</h3>{table(policies_ep.get(eid,[]))}
<div class="flow-tabs">{''.join(buttons)}</div>{''.join(panels)}
</section>''')
    artifacts=[]
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p.name=='endpoint-sequence-analysis.html' or '.skill-run' in p.parts:continue
        rel=p.relative_to(root).as_posix();artifacts.append(rel)
    manifest={'schema':'1.0','endpoints':[r.get('endpoint_id') for r in endpoints],'flows':[r.get('flow_id') for r in flows],'artifacts':artifacts}
    css='''
:root{--bg:#f6f8fb;--panel:#fff;--text:#172033;--muted:#667085;--line:#dbe2ea;--accent:#155eef;--accent2:#eaf1ff;--warn:#a15c00;--bad:#b42318;--good:#067647}*{box-sizing:border-box}body{margin:0;font-family:Inter,Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--text);line-height:1.45}.layout{display:grid;grid-template-columns:300px minmax(0,1fr);min-height:100vh}.sidebar{position:sticky;top:0;height:100vh;overflow:auto;background:#101828;color:#fff;padding:22px}.sidebar h1{font-size:19px;margin:0 0 4px}.sidebar .sub{color:#98a2b3;font-size:12px;margin-bottom:16px}.sidebar input{width:100%;padding:10px;border-radius:8px;border:1px solid #344054;background:#1d2939;color:white;margin-bottom:12px}.nav-group{margin:14px 0 6px;color:#98a2b3;font-size:11px;text-transform:uppercase;letter-spacing:.08em}.sidebar a{display:block;color:#e4e7ec;text-decoration:none;padding:8px;border-radius:7px;font-size:13px}.sidebar a:hover{background:#1d2939}.sidebar a small{display:block;color:#98a2b3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.main{padding:30px;max-width:1600px;width:100%}.hero,.section,.endpoint-section{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:24px;margin-bottom:22px;box-shadow:0 1px 2px rgba(16,24,40,.04)}.hero h1{margin:0 0 8px;font-size:32px}.eyebrow{text-transform:uppercase;letter-spacing:.08em;font-size:11px;font-weight:700;color:var(--accent)}.metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:18px 0}.metric{background:#f9fafb;border:1px solid var(--line);border-radius:10px;padding:14px}.metric b{font-size:24px;display:block}.metric span{color:var(--muted);font-size:12px}.section-head h2{margin:.2rem 0}.flow-tabs{display:flex;gap:8px;flex-wrap:wrap;margin:20px 0}.flow-tab{border:1px solid #b2c5ee;background:white;color:#1849a9;border-radius:999px;padding:9px 13px;cursor:pointer}.flow-tab.active{background:var(--accent);color:white;border-color:var(--accent)}.flow-panel{display:none;border-top:1px solid var(--line);padding-top:20px}.flow-panel.active{display:block}.flow-head{display:flex;justify-content:space-between;gap:20px;align-items:flex-start}.flow-head h3{margin:3px 0;font-size:23px}.confidence{background:#f2f4f7;border-radius:999px;padding:6px 10px;font-size:12px;white-space:nowrap}.meta-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px;margin:16px 0}.meta-grid div{padding:11px;background:#f9fafb;border-radius:8px}.meta-grid b,.meta-grid span{display:block}.meta-grid span{color:#475467;font-size:13px;margin-top:3px}.table-wrap{overflow:auto;border:1px solid var(--line);border-radius:9px;margin:10px 0 20px}table{border-collapse:collapse;width:100%;font-size:12px}th{position:sticky;top:0;background:#f2f4f7;text-align:left;padding:9px;border-bottom:1px solid var(--line)}td{vertical-align:top;padding:9px;border-bottom:1px solid #eef2f6;min-width:100px}.seq-diagram{overflow:auto;border:1px solid var(--line);border-radius:10px;padding:10px;background:white}.seq-diagram svg{max-width:100%;height:auto;display:block;margin:0 auto}.diagram-missing{border:1px dashed #f79009;background:#fffaeb;color:#93370d;padding:18px;border-radius:9px}.diagram-links{text-align:right;font-size:12px;margin:5px 0 18px}.diagram-links a{color:var(--accent)}details{border-top:1px solid var(--line);padding:12px 0}summary{font-weight:700;cursor:pointer}.callout{padding:11px;background:#fffaeb;color:#7a2e0e;border-left:4px solid #f79009;margin:8px 0}.artifact-list{columns:2;column-gap:30px}.artifact-list a{display:block;color:var(--accent);font-size:12px;padding:2px 0;word-break:break-all}.empty{color:var(--muted);font-style:italic;padding:10px}.hidden-by-search{display:none!important}@media(max-width:900px){.layout{display:block}.sidebar{position:relative;height:auto}.main{padding:16px}.artifact-list{columns:1}}@media print{.sidebar,.flow-tabs{display:none}.layout{display:block}.main{max-width:none}.flow-panel{display:block!important}.hero,.section,.endpoint-section{box-shadow:none;break-inside:avoid}}
'''
    executive=simple_md(read_text(root/'executive-summary.md'));coverage=simple_md(read_text(root/'current-state/coverage-summary.md'))
    art_html=''.join(f'<a href="{esc(x)}">{esc(x)}</a>' for x in artifacts)
    html_doc=f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MuleSoft Endpoint Sequence Analysis</title><style>{css}</style></head><body><div class="layout">
<aside class="sidebar"><h1>Endpoint Sequence Analysis</h1><div class="sub">Evidence-driven MuleSoft behavior reconstruction</div><input id="search" placeholder="Search endpoints and flows…"><a href="#summary">Executive Summary</a><a href="#coverage">Coverage & Data Quality</a><a href="#universe">Endpoint Universe</a><div class="nav-group">Endpoints</div>{''.join(nav)}<div class="nav-group">Analysis</div><a href="#all-gaps">Gaps & Unknowns</a><a href="#sources">Evidence Sources</a><a href="#artifacts">Artifact Explorer</a></aside>
<main class="main"><section class="hero" id="summary"><div class="eyebrow">Primary review artifact</div><h1>MuleSoft Endpoint Sequence Analysis</h1><p>Every endpoint, every material path, and every distinct business flow reconstructed from available evidence.</p><div class="metrics"><div class="metric"><b>{len(cands)}</b><span>Candidates discovered</span></div><div class="metric"><b>{len(endpoints)}</b><span>Endpoints reconciled</span></div><div class="metric"><b>{len(flows)}</b><span>Business flows</span></div><div class="metric"><b>{multi}</b><span>Endpoints with multiple flows</span></div><div class="metric"><b>{len(paths)}</b><span>Material paths</span></div><div class="metric"><b>{svg_clean}/{len(flows)}</b><span>Clean rendered sequences</span></div><div class="metric"><b>{checklist_pass}/{checklist_total}</b><span>Checklist pass/N/A</span></div><div class="metric"><b>{len(gaps)}</b><span>Open/recorded gaps</span></div></div>{executive}</section>
<section class="section" id="coverage"><h2>Coverage & Data Quality</h2>{coverage}<h3>Endpoint status</h3>{table([{'status':k,'count':v} for k,v in sorted(status_counts.items())])}</section>
<section class="section" id="universe"><h2>Endpoint Universe</h2><p>Candidate declarations are reconciled against executable and observed behavior. Config/spec-only candidates are retained rather than silently dropped.</p>{table(endpoints)}</section>
{''.join(endpoint_sections)}
<section class="section" id="all-gaps"><h2>All Gaps & Unknowns</h2>{table(gaps)}</section>
<section class="section" id="sources"><h2>Evidence Sources</h2>{table(sources)}</section>
<section class="section" id="artifacts"><h2>Artifact Explorer</h2><p>Canonical analysis files and separate diagram sources/renders.</p><div class="artifact-list">{art_html}</div></section>
</main></div><script id="report-manifest" type="application/json">{json.dumps(manifest,separators=(',',':'))}</script><script>
document.querySelectorAll('.flow-tab').forEach(btn=>btn.addEventListener('click',()=>{{let section=btn.closest('.endpoint-section');section.querySelectorAll('.flow-tab').forEach(x=>x.classList.remove('active'));section.querySelectorAll('.flow-panel').forEach(x=>x.classList.remove('active'));btn.classList.add('active');let p=document.getElementById(btn.dataset.panel);if(p)p.classList.add('active');}}));
const search=document.getElementById('search');search.addEventListener('input',()=>{{const q=search.value.trim().toLowerCase();document.querySelectorAll('.endpoint-section').forEach(sec=>{{let matched=!q||sec.dataset.search.includes(q)||Array.from(sec.querySelectorAll('.flow-panel')).some(p=>p.dataset.flowSearch.includes(q));sec.classList.toggle('hidden-by-search',!matched);}});}});
</script></body></html>'''
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(html_doc,encoding='utf-8');print(f'Built {out}');return 0
if __name__=='__main__':raise SystemExit(main())
