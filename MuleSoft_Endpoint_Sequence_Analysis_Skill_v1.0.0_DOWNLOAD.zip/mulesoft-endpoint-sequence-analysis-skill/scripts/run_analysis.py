#!/usr/bin/env python3
"""Deterministic lifecycle controller. The agent owns semantic analysis; scripts own repeatable mechanics."""
from __future__ import annotations
import argparse,json,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];S=ROOT/'scripts'
def now():return datetime.now(timezone.utc).isoformat(timespec='seconds')
def run(cmd,required=True):
    print('+',' '.join(map(str,cmd)));r=subprocess.run(cmd,cwd=ROOT)
    if required and r.returncode:raise RuntimeError(f'Command failed ({r.returncode}): {cmd}')
    return r.returncode
def record(a,phase,status,**extra):
    p=a/'.skill-run/state.json';p.parent.mkdir(parents=True,exist_ok=True)
    try:d=json.loads(p.read_text()) if p.exists() else {'schema_version':1,'history':[]}
    except Exception:d={'schema_version':1,'history':[]}
    d.update({'last_phase':phase,'last_status':status,'updated_at':now(),**extra});d.setdefault('history',[]).append({'time':now(),'phase':phase,'status':status});p.write_text(json.dumps(d,indent=2)+'\n')
def prepare(x):
    a=x.analysis.resolve();run([sys.executable,str(S/'bootstrap_analysis.py'),str(a)]+(['--force'] if x.force_bootstrap else []))
    inp={'generated_at':now(),'source_repo':str(x.source_repo.resolve()) if x.source_repo else None,'supplementary_inputs':[str(p.resolve()) for p in x.inputs]};(a/'evidence/input-locations.json').write_text(json.dumps(inp,indent=2)+'\n')
    if x.source_repo:
        run([sys.executable,str(S/'scan_mule_project.py'),str(x.source_repo.resolve()),'--source-csv',str(a/'evidence/source-inventory.csv'),'--endpoint-csv',str(a/'evidence/endpoint-candidates.csv'),'--json',str(a/'evidence/mule-scan.json')])
    if x.inputs:
        run([sys.executable,str(S/'inventory_supporting_inputs.py'),str(a/'evidence/source-inventory.csv'),*[str(v.resolve()) for v in x.inputs]])
    if not x.source_repo and not (a/'evidence/endpoint-candidates.csv').exists():
        (a/'evidence/endpoint-candidates.csv').write_text('candidate_id,candidate_key,protocol,method_or_operation,resource_or_source,ingress_type,implementation_entrypoint,config_ref,declaration_source,notes\n')
    record(a,'prepare','complete');print('Prepared endpoint sequence analysis workspace.');return 0
def commit(x):
    a=x.analysis.resolve();run([sys.executable,str(S/'assign_sequence_names.py'),str(a)]);run([sys.executable,str(S/'seed_checklists.py'),str(a)])
    # Create endpoint diagram directories from committed flow rows.
    import csv
    p=a/'current-state/endpoint-flow-inventory.csv'
    if p.exists():
        for r in csv.DictReader(p.open(encoding='utf-8-sig',newline='')):
            rel=r.get('primary_sequence_diagram','').strip()
            if rel:(a/rel).parent.mkdir(parents=True,exist_ok=True);((a/rel).parent/'supporting').mkdir(exist_ok=True)
    record(a,'commit-flows','complete');return 0
def validate(x,require_html=False):
    a=x.analysis.resolve();out=a/'validation/analysis-validation.json';cmd=[sys.executable,str(S/'validate_analysis.py'),str(a),'--json',str(out)]
    if require_html:cmd.append('--require-html')
    if getattr(x,'strict_warnings',False):cmd.append('--strict-warnings')
    rc=run(cmd,required=False);record(a,'validate','passed' if rc==0 else 'failed',validation_report=str(out));return 0 if rc==0 else 1
def finalize(x):
    a=x.analysis.resolve();
    if validate(x):print('Finalization blocked: remediate validation findings first.');return 1
    render=[sys.executable,str(S/'render_diagrams.py'),str(a/'diagrams/endpoints'),'--format','svg']
    if x.plantuml_jar:render+=['--plantuml-jar',str(x.plantuml_jar)]
    rr=run(render,required=False)
    if rr:print('WARN: sequence rendering failed/unavailable. Final completeness validation will remain blocked until primary SVGs exist.')
    run([sys.executable,str(S/'build_html_report.py'),str(a),'--output',str(a/'endpoint-sequence-analysis.html')])
    rc=validate(x,require_html=True);record(a,'finalize','complete' if rc==0 else 'failed-after-build',html_report=str(a/'endpoint-sequence-analysis.html'));return rc
def status(x):
    p=x.analysis/'.skill-run/state.json';print(p.read_text() if p.exists() else '{}');return 0
def parser():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='command',required=True)
    p=sub.add_parser('prepare');p.add_argument('analysis',type=Path);p.add_argument('--source-repo',type=Path);p.add_argument('--inputs',type=Path,action='append',default=[]);p.add_argument('--force-bootstrap',action='store_true');p.set_defaults(func=prepare)
    p=sub.add_parser('commit-flows');p.add_argument('analysis',type=Path);p.set_defaults(func=commit)
    p=sub.add_parser('validate');p.add_argument('analysis',type=Path);p.add_argument('--strict-warnings',action='store_true');p.set_defaults(func=validate)
    p=sub.add_parser('finalize');p.add_argument('analysis',type=Path);p.add_argument('--strict-warnings',action='store_true');p.add_argument('--plantuml-jar',type=Path);p.set_defaults(func=finalize)
    p=sub.add_parser('status');p.add_argument('analysis',type=Path);p.set_defaults(func=status)
    return ap
def main():
    a=parser().parse_args()
    try:return int(a.func(a))
    except RuntimeError as e:print('ERROR:',e);return 2
if __name__=='__main__':raise SystemExit(main())
