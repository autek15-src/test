#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json,re
from collections import Counter,defaultdict
from pathlib import Path

CHECK_IDS={f'C{i:02d}' for i in range(1,21)}
ENDPOINT_STATUSES={'ACTIVE_CONFIRMED','ACTIVE_DOCUMENTED_FALLBACK','CONFIG_ONLY_UNCONFIRMED','DEAD_OR_UNREACHABLE','DUPLICATE_ALIAS'}
CHECK_STATUSES={'PASS','BLOCKED_GAP','NOT_APPLICABLE'}
ERROR_MARKERS=re.compile(r'(?i)(error occurred|IllegalStateException|syntax error\??|assumed diagram type)')
DIRECTION_RE=re.compile(r'(?im)^\s*(?:left\s+to\s+right|right\s+to\s+left|top\s+to\s+bottom|bottom\s+to\s+top)\s+direction\s*$')

def read_csv(p:Path):
    if not p.exists():return []
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def split_ids(v):return [x.strip() for x in re.split(r'[;,]',v or '') if x.strip() and x.strip().upper()!='N/A']
def slug(v):return re.sub(r'[^a-z0-9]+','-',(v or '').lower()).strip('-')
def add(findings,severity,code,msg):findings.append({'severity':severity,'code':code,'message':msg})

def validate(a:Path,require_html=False):
    f=[]
    req=['current-state/endpoint-inventory.csv','current-state/endpoint-flow-inventory.csv','current-state/endpoint-path-inventory.csv','current-state/endpoint-flow-steps.csv','current-state/endpoint-participants.csv','current-state/endpoint-checklist.csv','current-state/endpoint-evidence.csv','current-state/gaps-unknowns.csv','evidence/source-inventory.csv','evidence/evidence-register.csv','evidence/endpoint-candidates.csv']
    for r in req:
        if not (a/r).exists():add(f,'ERROR','FILE_MISSING',f'Missing required artifact: {r}')
    endpoints=read_csv(a/'current-state/endpoint-inventory.csv');flows=read_csv(a/'current-state/endpoint-flow-inventory.csv');paths=read_csv(a/'current-state/endpoint-path-inventory.csv');steps=read_csv(a/'current-state/endpoint-flow-steps.csv');parts=read_csv(a/'current-state/endpoint-participants.csv');checks=read_csv(a/'current-state/endpoint-checklist.csv');ev=read_csv(a/'current-state/endpoint-evidence.csv');gaps=read_csv(a/'current-state/gaps-unknowns.csv');cands=read_csv(a/'evidence/endpoint-candidates.csv');sources=read_csv(a/'evidence/source-inventory.csv')
    eids=[r.get('endpoint_id','').strip() for r in endpoints if r.get('endpoint_id','').strip()]
    if not endpoints:add(f,'ERROR','NO_ENDPOINTS','Endpoint inventory is empty.')
    for x,n in Counter(eids).items():
        if n>1:add(f,'ERROR','ENDPOINT_DUPLICATE_ID',f'Duplicate endpoint_id: {x}')
    cand_keys={r.get('candidate_key','').strip() for r in cands if r.get('candidate_key','').strip()}
    inv_keys={r.get('candidate_key','').strip() for r in endpoints if r.get('candidate_key','').strip()}
    for k in sorted(cand_keys-inv_keys):add(f,'ERROR','CANDIDATE_UNRECONCILED',f'Endpoint candidate not reconciled: {k}')
    flow_by_ep=defaultdict(list)
    flow_ids=[]
    for r in flows:
        fid=r.get('flow_id','').strip();eid=r.get('endpoint_id','').strip()
        if not fid:add(f,'ERROR','FLOW_ID_MISSING','Flow row missing flow_id.')
        else:flow_ids.append(fid)
        if eid not in eids:add(f,'ERROR','FLOW_ENDPOINT_UNKNOWN',f'Flow {fid or "[blank]"} references unknown endpoint {eid}.')
        flow_by_ep[eid].append(r)
    for x,n in Counter(flow_ids).items():
        if n>1:add(f,'ERROR','FLOW_DUPLICATE_ID',f'Duplicate flow_id: {x}')
    flow_id_set=set(flow_ids)
    for r in endpoints:
        eid=r.get('endpoint_id','').strip(); status=r.get('endpoint_status','').strip()
        if status not in ENDPOINT_STATUSES:add(f,'ERROR','ENDPOINT_STATUS_INVALID',f'{eid}: invalid endpoint_status {status!r}.')
        if not flow_by_ep.get(eid):add(f,'ERROR','ENDPOINT_NO_FLOW',f'{eid}: every endpoint must have at least one business/unresolved flow record.')
        declared=set(split_ids(r.get('business_flow_ids','')));actual={x.get('flow_id','').strip() for x in flow_by_ep.get(eid,[]) if x.get('flow_id','').strip()}
        if declared!=actual:add(f,'ERROR','ENDPOINT_FLOW_SET_MISMATCH',f'{eid}: business_flow_ids {sorted(declared)} do not match actual flow rows {sorted(actual)}.')
    path_by_flow=defaultdict(list)
    for r in paths:
        fid=r.get('flow_id','').strip();path_by_flow[fid].append(r)
        if fid not in flow_id_set:add(f,'ERROR','PATH_FLOW_UNKNOWN',f'Path {r.get("path_id")} references unknown flow {fid}.')
        cov=r.get('diagram_coverage','').strip()
        if cov not in {'PRIMARY','SUPPORTING','NOT_REPRESENTABLE_GAP'}:add(f,'ERROR','PATH_COVERAGE_INVALID',f'{r.get("path_id")}: invalid diagram_coverage {cov!r}.')
        if cov=='NOT_REPRESENTABLE_GAP' and not r.get('gap_id','').strip():add(f,'ERROR','PATH_GAP_MISSING',f'{r.get("path_id")}: non-representable path requires gap_id.')
    step_by_flow=defaultdict(list)
    for r in steps:
        fid=r.get('flow_id','').strip();step_by_flow[fid].append(r)
        if fid not in flow_id_set:add(f,'ERROR','STEP_FLOW_UNKNOWN',f'Step references unknown flow {fid}.')
        for col in ('step_number','actor_or_system','business_action','technical_action','evidence_class','evidence_refs','source_locations'):
            if not r.get(col,'').strip():add(f,'ERROR','STEP_FIELD_MISSING',f'{fid}: step missing required {col}.')
    ev_by_flow=defaultdict(list)
    for r in ev:ev_by_flow[r.get('flow_id','').strip()].append(r)
    part_by_flow=defaultdict(list)
    for r in parts:part_by_flow[r.get('flow_id','').strip()].append(r)
    check_by_flow=defaultdict(list)
    for r in checks:check_by_flow[r.get('flow_id','').strip()].append(r)
    gap_ids={r.get('gap_id','').strip() for r in gaps if r.get('gap_id','').strip()}
    for r in flows:
        fid=r.get('flow_id','').strip();eid=r.get('endpoint_id','').strip()
        if not path_by_flow.get(fid):add(f,'ERROR','FLOW_NO_PATHS',f'{fid}: no path inventory rows.')
        if not step_by_flow.get(fid):add(f,'ERROR','FLOW_NO_STEPS',f'{fid}: no step ledger rows.')
        if not ev_by_flow.get(fid):add(f,'ERROR','FLOW_NO_EVIDENCE',f'{fid}: no endpoint-evidence rows documenting sources used.')
        if not part_by_flow.get(fid):add(f,'WARN','FLOW_NO_PARTICIPANTS',f'{fid}: participant inventory is empty.')
        rows=check_by_flow.get(fid,[]); ids={x.get('check_id','').strip() for x in rows}
        for missing in sorted(CHECK_IDS-ids):add(f,'ERROR','CHECKLIST_ITEM_MISSING',f'{fid}: missing checklist {missing}.')
        for c in rows:
            st=c.get('status','').strip()
            if st not in CHECK_STATUSES:add(f,'ERROR','CHECKLIST_STATUS_INVALID',f'{fid}/{c.get("check_id")}: status must be PASS, BLOCKED_GAP, or NOT_APPLICABLE.')
            if st=='BLOCKED_GAP' and not re.search(r'GAP-[A-Za-z0-9_-]+',(c.get('notes','')+' '+c.get('evidence_refs',''))):add(f,'ERROR','CHECKLIST_BLOCKED_WITHOUT_GAP',f'{fid}/{c.get("check_id")}: BLOCKED_GAP must reference a GAP-* record.')
        puml_rel=r.get('primary_sequence_diagram','').strip()
        if not puml_rel:add(f,'ERROR','FLOW_DIAGRAM_PATH_MISSING',f'{fid}: primary_sequence_diagram is blank.');continue
        puml=a/puml_rel
        if not puml.exists():add(f,'ERROR','FLOW_DIAGRAM_MISSING',f'{fid}: missing sequence diagram {puml_rel}.');continue
        txt=puml.read_text(encoding='utf-8',errors='replace');stem=puml.stem
        if not re.search(rf'(?im)^\s*@startuml\s+{re.escape(stem)}\s*$',txt):add(f,'ERROR','FLOW_DIAGRAM_ID_MISMATCH',f'{fid}: @startuml ID must equal {stem}.')
        if 'autonumber' not in txt.lower():add(f,'WARN','FLOW_DIAGRAM_NO_AUTONUMBER',f'{fid}: sequence diagram missing autonumber.')
        if DIRECTION_RE.search(txt):add(f,'ERROR','FLOW_DIAGRAM_DIRECTION_INVALID',f'{fid}: sequence diagram contains structural direction directive.')
        if '->' not in txt:add(f,'ERROR','FLOW_DIAGRAM_NO_MESSAGES',f'{fid}: sequence diagram has no messages.')
        if '@enduml' not in txt:add(f,'ERROR','FLOW_DIAGRAM_INVALID',f'{fid}: sequence diagram missing @enduml.')
        if require_html:
            svg=puml.with_suffix('.svg')
            if not svg.exists():add(f,'ERROR','FLOW_SVG_MISSING',f'{fid}: rendered SVG missing: {svg.relative_to(a).as_posix()}')
            elif svg.stat().st_size==0 or ERROR_MARKERS.search(svg.read_text(encoding='utf-8',errors='replace')):add(f,'ERROR','FLOW_SVG_RENDER_ERROR',f'{fid}: SVG appears empty or contains PlantUML error output.')
    # source review: require relevant implementation sources to be dispositioned
    for r in sources:
        typ=r.get('source_type','');status=r.get('review_status','').strip().upper()
        if typ in {'XML/Mule candidate','DataWeave','RAML','WSDL','Java source','Properties/config'} and status in {'','UNREVIEWED'}:
            add(f,'WARN','SOURCE_UNREVIEWED',f'Relevant source not yet marked reviewed/not-relevant: {r.get("path_or_name")}')
    if require_html:
        htmlp=a/'endpoint-sequence-analysis.html'
        if not htmlp.exists():add(f,'ERROR','HTML_MISSING','Final HTML report is missing.')
        else:
            ht=htmlp.read_text(encoding='utf-8',errors='replace')
            if '"schema":"1.0"' not in ht.replace(' ',''):add(f,'ERROR','HTML_SCHEMA_INVALID','HTML report manifest schema 1.0 missing.')
            for eid in eids:
                if f'id="endpoint-{slug(eid)}"' not in ht:add(f,'ERROR','HTML_ENDPOINT_MISSING',f'HTML missing endpoint section {eid}.')
            for r in flows:
                rel=r.get('primary_sequence_diagram','').strip();stem=Path(rel).stem if rel else ''
                if stem and f'id="flow-{stem}"' not in ht:add(f,'ERROR','HTML_FLOW_MISSING',f'HTML missing flow panel for {r.get("flow_id")} / {stem}.')
    errors=sum(x['severity']=='ERROR' for x in f);warnings=sum(x['severity']=='WARN' for x in f)
    return {'schema_version':1,'errors':errors,'warnings':warnings,'findings':f,'metrics':{'endpoints':len(endpoints),'flows':len(flows),'paths':len(paths),'steps':len(steps),'gaps':len(gaps),'multi_flow_endpoints':sum(1 for e,v in flow_by_ep.items() if len(v)>1)}}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('analysis',type=Path);ap.add_argument('--json',type=Path);ap.add_argument('--require-html',action='store_true');ap.add_argument('--strict-warnings',action='store_true');a=ap.parse_args();res=validate(a.analysis.resolve(),a.require_html)
    for x in res['findings']:print(f"{x['severity']} {x['code']}: {x['message']}")
    print(f"Validation: {res['errors']} error(s), {res['warnings']} warning(s)")
    if a.json:a.json.parent.mkdir(parents=True,exist_ok=True);a.json.write_text(json.dumps(res,indent=2)+'\n',encoding='utf-8')
    return 1 if res['errors'] or (a.strict_warnings and res['warnings']) else 0
if __name__=='__main__':raise SystemExit(main())
