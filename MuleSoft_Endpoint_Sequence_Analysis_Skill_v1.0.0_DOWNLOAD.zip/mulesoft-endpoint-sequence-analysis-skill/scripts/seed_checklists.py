#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv
from pathlib import Path
CHECKS=[
('C01','Endpoint','Endpoint declaration/spec/config reconciled'),('C02','Endpoint','Executable entry flow identified or gap recorded'),('C03','Policies','Endpoint/gateway policies inspected'),('C04','Code paths','All reachable flow-ref/subflows recursively followed'),('C05','Code paths','Choice/router branches enumerated'),('C06','Transformations','DataWeave/custom transformation logic inspected'),('C07','Downstream','All reachable outbound calls/operations traced'),('C08','Reliability','Timeout/retry/reconnection/transaction behavior inspected'),('C09','Errors','Error handlers and caller-visible mappings inspected'),('C10','Security','Authentication/authorization behavior traced'),('C11','Upstream','Upstream consumer/user context investigated'),('C12','Runtime','Splunk/Anypoint/runtime evidence searched when supplied'),('C13','Supporting','Downstream source/Collibra/docs/diagrams investigated when supplied'),('C14','Multiplicity','Endpoint assessed for multiple business flows'),('C15','Paths','Every material path represented or linked to a gap'),('C16','Diagram','Primary sequence diagram authored and source-validated'),('C17','Diagram','Rendered SVG verified when PlantUML available'),('C18','Evidence','Material steps have evidence/source references'),('C19','Meaning','Business/functional meaning inferred as far as evidence allows'),('C20','Unknowns','Missing/unknown context explicitly recorded')]
def main():
    ap=argparse.ArgumentParser();ap.add_argument('analysis',type=Path);a=ap.parse_args();flows=a.analysis/'current-state/endpoint-flow-inventory.csv';out=a.analysis/'current-state/endpoint-checklist.csv'
    fr=list(csv.DictReader(flows.open(encoding='utf-8-sig',newline=''))); existing=[]
    if out.exists():existing=list(csv.DictReader(out.open(encoding='utf-8-sig',newline='')))
    keys={(r.get('endpoint_id'),r.get('flow_id'),r.get('check_id')) for r in existing}
    for f in fr:
        for cid,cat,item in CHECKS:
            k=(f.get('endpoint_id'),f.get('flow_id'),cid)
            if k not in keys:existing.append({'endpoint_id':k[0],'flow_id':k[1],'check_id':cid,'category':cat,'check_item':item,'status':'','evidence_refs':'','notes':''});keys.add(k)
    fields=['endpoint_id','flow_id','check_id','category','check_item','status','evidence_refs','notes']
    with out.open('w',encoding='utf-8',newline='') as fh:w=csv.DictWriter(fh,fieldnames=fields);w.writeheader();w.writerows(existing)
    print(f'Checklist rows: {len(existing)}');return 0
if __name__=='__main__':raise SystemExit(main())
