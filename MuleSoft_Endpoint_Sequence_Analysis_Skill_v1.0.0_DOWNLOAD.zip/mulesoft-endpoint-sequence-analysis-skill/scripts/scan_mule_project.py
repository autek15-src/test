#!/usr/bin/env python3
"""Seed source inventory, Mule structure, and endpoint candidate universe.

This scanner is intentionally heuristic. It establishes a broad candidate universe;
the agent must reconcile candidates against executable behavior and evidence.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, re
from pathlib import Path
import xml.etree.ElementTree as ET

INTERESTING_EXT={'.xml','.dwl','.raml','.yaml','.yml','.json','.java','.groovy','.properties','.conf','.md','.txt','.wsdl','.xsd','.feature'}
SPECIAL_NAMES={'pom.xml','mule-artifact.json','Dockerfile','Jenkinsfile','azure-pipelines.yml','buildspec.yml'}
IGNORE_DIRS={'.git','.idea','.vscode','target','node_modules','.mvn','dist','build'}
HTTP_METHODS={'get','post','put','patch','delete','head','options','trace'}

def lname(tag:str)->str:
    return tag.rsplit('}',1)[-1] if '}' in tag else tag.split(':')[-1]

def sha256(path:Path)->str:
    h=hashlib.sha256();
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def safe_text(path:Path,limit=5_000_000)->str:
    try:
        if path.stat().st_size>limit:return ''
        return path.read_text(encoding='utf-8',errors='replace')
    except OSError:return ''

def source_kind(path:Path)->str:
    n=path.name.lower(); s=path.suffix.lower()
    if n=='pom.xml': return 'Maven POM'
    if n=='mule-artifact.json': return 'Mule artifact descriptor'
    if s=='.dwl': return 'DataWeave'
    if s=='.raml': return 'RAML'
    if s in {'.yaml','.yml'}: return 'YAML/OpenAPI candidate'
    if s=='.wsdl': return 'WSDL'
    if s=='.java': return 'Java source'
    if s=='.properties': return 'Properties/config'
    if s=='.xml': return 'XML/Mule candidate'
    return 'Supporting source/document'

def candidate_key(protocol:str,method:str,resource:str,entry:str='')->str:
    vals=[protocol.strip().upper() or 'UNKNOWN',method.strip().upper() or 'UNKNOWN',resource.strip() or entry.strip() or 'UNKNOWN']
    return '|'.join(vals)

def add_candidate(store:dict[str,dict], **kw):
    key=kw.get('candidate_key') or candidate_key(kw.get('protocol',''),kw.get('method_or_operation',''),kw.get('resource_or_source',''),kw.get('implementation_entrypoint',''))
    if key in store:
        prev=store[key]
        for f in ('declaration_source','implementation_entrypoint','config_ref','notes'):
            v=str(kw.get(f,'')).strip()
            if v and v not in str(prev.get(f,'')):
                prev[f]=(str(prev.get(f,'')).strip()+'; '+v).strip('; ')
        return
    kw['candidate_key']=key
    store[key]=kw

def parse_mule_xml(path:Path, repo:Path, candidates:dict[str,dict], items:list[dict]):
    try:root=ET.parse(path).getroot()
    except Exception:return
    rel=path.relative_to(repo).as_posix()
    for flow in root.iter():
        fln=lname(flow.tag)
        if fln not in {'flow','sub-flow'}:continue
        fname=flow.attrib.get('name','')
        items.append({'type':fln,'name':fname,'file':rel})
        m=re.match(r'(?i)^(get|post|put|patch|delete|head|options|trace):([^:]+):',fname)
        if m:
            method=m.group(1).upper(); resource=m.group(2)
            add_candidate(candidates,protocol='HTTP',method_or_operation=method,resource_or_source=resource,ingress_type='APIKIT_ROUTE_FLOW',implementation_entrypoint=fname,config_ref='',declaration_source=rel,notes='Candidate inferred from APIkit-style flow name')
        for el in flow.iter():
            ln=lname(el.tag); a=el.attrib
            if ln=='listener':
                method=(a.get('allowedMethods') or a.get('method') or 'ANY').upper()
                resource=a.get('path','') or '[listener path unresolved]'
                add_candidate(candidates,protocol='HTTP',method_or_operation=method,resource_or_source=resource,ingress_type='HTTP_LISTENER',implementation_entrypoint=fname,config_ref=a.get('config-ref',''),declaration_source=rel,notes='Executable listener candidate')
                items.append({'type':'http-listener','flow':fname,'method':method,'path':resource,'config_ref':a.get('config-ref',''),'file':rel})
            elif ln in {'scheduler','fixed-frequency','cron'}:
                resource=f'scheduler:{fname}'
                add_candidate(candidates,protocol='SCHEDULE',method_or_operation='TRIGGER',resource_or_source=resource,ingress_type='SCHEDULER',implementation_entrypoint=fname,config_ref='',declaration_source=rel,notes='Scheduled integration entry point')
                items.append({'type':'scheduler','flow':fname,'file':rel})
            elif ln in {'listener-source','consume'} and any(x in el.tag.lower() for x in ('jms','amqp','mq')):
                dest=a.get('destination') or a.get('queueName') or a.get('topic') or a.get('source') or fname
                proto='JMS' if 'jms' in el.tag.lower() else 'MESSAGE'
                add_candidate(candidates,protocol=proto,method_or_operation='CONSUME',resource_or_source=dest,ingress_type='MESSAGE_CONSUMER',implementation_entrypoint=fname,config_ref=a.get('config-ref',''),declaration_source=rel,notes='Inbound message consumer candidate')
            elif ln=='flow-ref':
                items.append({'type':'flow-ref','flow':fname,'target':a.get('name',''),'file':rel})
            elif ln in {'request','publish','select','insert','update','delete','sftp','ftp','sap'}:
                items.append({'type':'outbound-operation','flow':fname,'operation':ln,'path':a.get('path',''),'config_ref':a.get('config-ref',''),'file':rel})
            elif ln in {'choice','when','otherwise','until-successful','scatter-gather','parallel-foreach','foreach','async','try','batch-job'}:
                items.append({'type':ln,'flow':fname,'file':rel})
            elif 'error-handler' in ln or ln.startswith('on-error'):
                items.append({'type':ln,'flow':fname,'error_type':a.get('type',''),'file':rel})

def parse_raml(path:Path,repo:Path,candidates:dict[str,dict]):
    text=safe_text(path); rel=path.relative_to(repo).as_posix(); stack=[]
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith('#'):continue
        indent=len(line)-len(line.lstrip()); s=line.strip()
        if s.startswith('/') and s.endswith(':'):
            resource=s[:-1]
            stack=[(indent,resource)]
        else:
            while stack and indent<=stack[-1][0]:stack.pop()
            if s.startswith('/') and s.endswith(':'):
                stack.append((indent,s[:-1])); continue
            mm=re.match(r'(?i)^(get|post|put|patch|delete|head|options):\s*$',s)
            if mm and stack:
                resource=''.join(x[1] for x in stack)
                add_candidate(candidates,protocol='HTTP',method_or_operation=mm.group(1).upper(),resource_or_source=resource,ingress_type='RAML_SPEC',implementation_entrypoint='',config_ref='',declaration_source=rel,notes='Specification candidate; must reconcile to executable implementation')

def parse_openapi_yaml(path:Path,repo:Path,candidates:dict[str,dict]):
    text=safe_text(path)
    if not re.search(r'(?im)^\s*(openapi|swagger)\s*:',text):return
    rel=path.relative_to(repo).as_posix(); current=None; current_indent=0
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith('#'):continue
        indent=len(line)-len(line.lstrip()); s=line.strip()
        pm=re.match(r'^(/[^:]+):\s*$',s)
        if pm:
            current=pm.group(1); current_indent=indent; continue
        mm=re.match(r'(?i)^(get|post|put|patch|delete|head|options|trace):\s*$',s)
        if current and mm and indent>current_indent:
            add_candidate(candidates,protocol='HTTP',method_or_operation=mm.group(1).upper(),resource_or_source=current,ingress_type='OPENAPI_SPEC',implementation_entrypoint='',config_ref='',declaration_source=rel,notes='Specification candidate; must reconcile to executable implementation')

def parse_wsdl(path:Path,repo:Path,candidates:dict[str,dict]):
    rel=path.relative_to(repo).as_posix()
    try:root=ET.parse(path).getroot()
    except Exception:return
    for el in root.iter():
        if lname(el.tag)=='operation' and el.attrib.get('name'):
            op=el.attrib['name']
            add_candidate(candidates,protocol='SOAP',method_or_operation=op,resource_or_source=f'operation:{op}',ingress_type='WSDL_SPEC',implementation_entrypoint='',config_ref='',declaration_source=rel,notes='WSDL operation candidate; must reconcile to executable implementation')

def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('repo',type=Path); ap.add_argument('--source-csv',type=Path); ap.add_argument('--endpoint-csv',type=Path); ap.add_argument('--json',type=Path); args=ap.parse_args()
    repo=args.repo.resolve(); sources=[]; items=[]; candidates={}
    for p in sorted(repo.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(repo)
        if any(part in IGNORE_DIRS for part in rel.parts):continue
        if p.suffix.lower() not in INTERESTING_EXT and p.name not in SPECIAL_NAMES:continue
        text=safe_text(p); low=text.lower(); relevance=[]
        for token,label in [('http:listener','HTTP listener'),('apikit','APIkit'),('dataweave','DataWeave'),('choice','branching'),('until-successful','retry'),('on-error','error handling'),('jms','JMS'),('scheduler','scheduler'),('munit','MUnit'),('autodiscovery','API policy/autodiscovery')]:
            if token in low: relevance.append(label)
        sources.append({'source_id':f'SRC-{len(sources)+1:04d}','source_type':source_kind(p),'path_or_name':rel.as_posix(),'scope':'repository','relevance':'; '.join(relevance),'modified_date':'','review_status':'UNREVIEWED','notes':f'size={p.stat().st_size}; sha256={sha256(p)[:16]}'})
        if p.suffix.lower()=='.xml':parse_mule_xml(p,repo,candidates,items)
        if p.suffix.lower()=='.raml':parse_raml(p,repo,candidates)
        if p.suffix.lower() in {'.yaml','.yml'}:parse_openapi_yaml(p,repo,candidates)
        if p.suffix.lower()=='.wsdl':parse_wsdl(p,repo,candidates)
    cand_rows=[]
    for i,key in enumerate(sorted(candidates),1):
        r=candidates[key].copy(); r['candidate_id']=f'CAND-{i:04d}'; cand_rows.append(r)
    if args.source_csv:
        args.source_csv.parent.mkdir(parents=True,exist_ok=True)
        with args.source_csv.open('w',newline='',encoding='utf-8') as f:
            fn=['source_id','source_type','path_or_name','scope','relevance','modified_date','review_status','notes']; w=csv.DictWriter(f,fieldnames=fn);w.writeheader();w.writerows(sources)
    if args.endpoint_csv:
        args.endpoint_csv.parent.mkdir(parents=True,exist_ok=True)
        fn=['candidate_id','candidate_key','protocol','method_or_operation','resource_or_source','ingress_type','implementation_entrypoint','config_ref','declaration_source','notes']
        with args.endpoint_csv.open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=fn);w.writeheader();w.writerows([{k:r.get(k,'') for k in fn} for r in cand_rows])
    result={'repository':str(repo),'source_count':len(sources),'endpoint_candidate_count':len(cand_rows),'endpoint_candidates':cand_rows,'mule_items':items}
    if args.json:
        args.json.parent.mkdir(parents=True,exist_ok=True);args.json.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    if not args.source_csv and not args.endpoint_csv and not args.json:print(json.dumps(result,indent=2))
    print(f'Scanned {len(sources)} relevant files; discovered {len(cand_rows)} endpoint/interface candidates.')
    return 0
if __name__=='__main__':raise SystemExit(main())
