#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,re
from collections import defaultdict
from pathlib import Path

def slug(v:str)->str:return re.sub(r'[^a-z0-9]+','-',v.lower()).strip('-') or 'flow'
def main():
    ap=argparse.ArgumentParser();ap.add_argument('analysis',type=Path);a=ap.parse_args();p=a.analysis/'current-state/endpoint-flow-inventory.csv'
    rows=list(csv.DictReader(p.open(encoding='utf-8-sig',newline=''))); counts=defaultdict(int); changed=0
    for r in rows:
        eid=r.get('endpoint_id','').strip();
        if not eid:continue
        counts[eid]+=1
        if not r.get('primary_sequence_diagram','').strip():
            stem=f"seq-{counts[eid]:02d}-{slug(r.get('flow_name') or r.get('flow_id') or 'flow')}"
            r['primary_sequence_diagram']=f'diagrams/endpoints/{eid}/{stem}.puml';changed+=1
    if rows:
        with p.open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    print(f'Committed sequence names; {changed} flow row(s) updated.');return 0
if __name__=='__main__':raise SystemExit(main())
