#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,hashlib
from pathlib import Path

def sha(p):
    h=hashlib.sha256()
    try:
        with p.open('rb') as f:
            for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
        return h.hexdigest()[:16]
    except Exception:return ''
def kind(p):
    s=p.suffix.lower();n=p.name.lower()
    if 'collibra' in n:return 'Collibra export'
    if 'splunk' in n:return 'Splunk export'
    if 'anypoint' in n or 'mulesoft' in n and 'metric' in n:return 'Anypoint export'
    if s in {'.vsdx','.drawio','.puml','.mmd','.svg','.png','.jpg','.jpeg'}:return 'Architecture/diagram evidence'
    if s in {'.csv','.xlsx','.xls'}:return 'Structured evidence export'
    if s in {'.md','.txt','.pdf','.doc','.docx','.ppt','.pptx'}:return 'Documentation'
    if s in {'.java','.ts','.tsx','.js','.jsx','.py','.cs','.go','.kt','.xml','.yaml','.yml','.json','.properties','.raml','.wsdl','.dwl'}:return 'Supporting source/config'
    return 'Supporting evidence'
def main():
    ap=argparse.ArgumentParser();ap.add_argument('source_inventory',type=Path);ap.add_argument('inputs',type=Path,nargs='+');a=ap.parse_args();p=a.source_inventory
    fields=['source_id','source_type','path_or_name','scope','relevance','modified_date','review_status','notes'];rows=[]
    if p.exists():
        with p.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    existing={r.get('path_or_name','') for r in rows};idx=len(rows)
    for base in a.inputs:
        base=base.resolve();items=[base] if base.is_file() else sorted(x for x in base.rglob('*') if x.is_file()) if base.exists() else []
        for x in items:
            key=str(x)
            if key in existing:continue
            idx+=1;rows.append({'source_id':f'SRC-{idx:04d}','source_type':kind(x),'path_or_name':key,'scope':'supplementary','relevance':'supporting evidence for endpoint/flow reconstruction','modified_date':'','review_status':'UNREVIEWED','notes':f'size={x.stat().st_size}; sha256={sha(x)}'});existing.add(key)
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    print(f'Source inventory now contains {len(rows)} item(s).');return 0
if __name__=='__main__':raise SystemExit(main())
