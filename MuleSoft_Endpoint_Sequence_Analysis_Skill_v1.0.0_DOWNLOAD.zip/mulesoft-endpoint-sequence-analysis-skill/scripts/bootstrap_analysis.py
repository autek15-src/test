#!/usr/bin/env python3
from __future__ import annotations
import argparse, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; T=ROOT/'templates'
COPY={
'executive-summary.md':'executive-summary.md','coverage-summary.md':'current-state/coverage-summary.md','evidence-register.csv':'evidence/evidence-register.csv','source-inventory.csv':'evidence/source-inventory.csv',
'endpoint-inventory.csv':'current-state/endpoint-inventory.csv','endpoint-flow-inventory.csv':'current-state/endpoint-flow-inventory.csv','endpoint-path-inventory.csv':'current-state/endpoint-path-inventory.csv','endpoint-flow-steps.csv':'current-state/endpoint-flow-steps.csv','endpoint-participants.csv':'current-state/endpoint-participants.csv','endpoint-checklist.csv':'current-state/endpoint-checklist.csv','endpoint-evidence.csv':'current-state/endpoint-evidence.csv','gaps-unknowns.csv':'current-state/gaps-unknowns.csv','policy-inventory.csv':'current-state/policy-inventory.csv','traffic-evidence.csv':'current-state/traffic-evidence.csv'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('analysis_dir',type=Path);ap.add_argument('--force',action='store_true');a=ap.parse_args();out=a.analysis_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    for s,d in COPY.items():
        dst=out/d;dst.parent.mkdir(parents=True,exist_ok=True)
        if dst.exists() and not a.force:continue
        shutil.copy2(T/s,dst)
    for d in ['diagrams/endpoints','validation','.skill-run','evidence']:(out/d).mkdir(parents=True,exist_ok=True)
    print(f'Analysis workspace ready: {out}');return 0
if __name__=='__main__':raise SystemExit(main())
