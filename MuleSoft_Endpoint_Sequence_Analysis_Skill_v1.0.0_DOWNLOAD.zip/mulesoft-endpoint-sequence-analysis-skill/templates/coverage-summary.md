# Coverage Summary

## Endpoint Universe

- Candidates discovered: [TBD]
- Candidates reconciled: [TBD]
- Active confirmed: [TBD]
- Documentation fallback: [TBD]
- Config-only/unconfirmed: [TBD]
- Dead/unreachable: [TBD]

## Business Flow Coverage

- Total endpoint/business-flow records: [TBD]
- Endpoints with multiple business flows: [TBD]
- Total material paths: [TBD]
- Primary sequence diagrams: [TBD]

Describe flow categories represented and any endpoints where multiplicity could not be established.

## Evidence Coverage

Summarize source code, runtime data, upstream/downstream code, Collibra, policies, tests, and documentation reviewed.

## Known Coverage Gaps

Summarize anything that may have been missed due to missing source code, unavailable production evidence, missing policy exports, unknown consumers, unknown downstream ownership, or undocumented dynamic routing.

## Cross-Endpoint Observations

Document recurring business functions, shared policies, repeated transformations, common backends, common error handling, and any endpoints that appear related or overlapping.
