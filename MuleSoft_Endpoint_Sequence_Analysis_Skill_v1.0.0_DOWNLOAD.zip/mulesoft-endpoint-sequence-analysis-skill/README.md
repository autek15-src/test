# MuleSoft Endpoint Sequence Analysis Skill

A reusable Codex/Claude-style skill for exhaustive current-state reconstruction of MuleSoft endpoint behavior.

## What it does

This skill discovers every MuleSoft endpoint/interface, traces every reachable path, determines all materially distinct business flows handled by each endpoint, and produces evidence-backed sequence diagrams plus a first-class offline HTML report.

It is intentionally separate from a MuleSoft-to-AWS target architecture skill. Use this skill when the immediate question is **"what exactly does every endpoint do today?"**

## Key guarantees

- endpoint universe established before deep analysis;
- one endpoint can map to multiple business flows and multiple diagrams;
- reachable source behavior and observed production evidence outrank stale documentation;
- config-only/dead placeholders are not silently treated as active behavior;
- every material branch/path is inventoried;
- every step records business meaning and technical behavior;
- every flow records exact source/evidence references;
- every flow has a standardized completeness checklist;
- unknowns are explicit artifacts, not hidden assumptions;
- rich self-contained HTML report plus separate PlantUML/SVG diagrams.

## Normal usage

The coding agent should read `SKILL.md` and orchestrate the included scripts itself. Users should not normally need to run scripts manually.

Manual/debug lifecycle:

```bash
python scripts/run_analysis.py prepare ./analysis --source-repo ./mule-app
python scripts/run_analysis.py commit-flows ./analysis
python scripts/run_analysis.py validate ./analysis
python scripts/run_analysis.py finalize ./analysis
```

See `INSTALL.md` for skill placement options.
