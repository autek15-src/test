# Installation

This package is self-contained and uses Python standard library utilities. PlantUML is optional for editable-source validation but required to render SVG sequence diagrams.

## Codex / agent skill use

Place the directory where your agent discovers skills, then invoke the skill by name or ask the agent to analyze a MuleSoft application endpoint-by-endpoint.

The agent should read `SKILL.md` and run the lifecycle automatically.

## Requirements

- Python 3.10+
- Local PlantUML command **or** Java + PlantUML JAR for SVG rendering
- Access to the Mule source repository and any supporting evidence

No Python pip dependencies are required.
