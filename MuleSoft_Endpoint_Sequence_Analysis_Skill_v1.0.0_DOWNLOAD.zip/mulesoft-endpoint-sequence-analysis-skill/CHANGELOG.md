# Changelog

## 1.0.0

- Initial specialized endpoint sequence-analysis release.
- Exhaustive endpoint candidate reconciliation.
- Explicit endpoint-to-many-business-flows model.
- Path/branch inventory per endpoint and flow.
- Standardized sequence-diagram authoring and rendering rules.
- Per-flow completeness checklist and evidence ledger.
- Explicit unknowns/gaps register.
- Rich self-contained HTML report with endpoint navigation and flow tabs.
- Automated prepare, flow-commit, validation, finalization, report, and package lifecycle.
