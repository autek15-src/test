# Evidence Discipline

## Source priority

When evidence conflicts, prefer:

1. reachable executable source behavior;
2. observed runtime/production behavior;
3. upstream/downstream source showing actual integration;
4. referenced configuration/specification;
5. Collibra/interface metadata;
6. current documentation/diagrams;
7. inference.

## Fact classes

- `OBSERVED_CODE`: directly established by reachable source code.
- `OBSERVED_RUNTIME`: directly measured in logs/monitoring/traces.
- `DOCUMENTED`: supported by supplied documentation but not independently confirmed.
- `INFERRED`: strongly inferred from multiple evidence sources.
- `ASSUMED`: necessary working assumption.
- `UNKNOWN`: evidence is insufficient.
- `CONTRADICTED`: evidence sources disagree.

Every material step should carry an evidence class and evidence IDs/source locations.

## Config is not automatically runtime truth

A configured host, HTTP request config, connector, WSDL, property, listener config, API specification resource, or policy declaration may be unused/dead. Confirm reachability from executable entry points before describing it as active behavior.

## Traffic observations are not system limits

Payload size, latency, TPS, request volume, and concurrency derived from Splunk/Anypoint represent what was **observed in the supplied evidence window**. They do not imply a configured or contractual system maximum.

Write:

`Observed 30-day max request payload: 11.7 MB; actual supported maximum is unknown.`

Do not write:

`Payload limit: 11.7 MB`

unless a real configured/specification limit establishes that value.

## Contradictions

When source/runtime contradict documentation, record both and explain which source governs the reconstructed current behavior and why.
