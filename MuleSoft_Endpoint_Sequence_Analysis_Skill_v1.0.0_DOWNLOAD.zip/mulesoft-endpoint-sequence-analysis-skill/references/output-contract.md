# Output Contract

## Endpoint inventory

`current-state/endpoint-inventory.csv` is the authoritative endpoint reconciliation table.

Every row from `evidence/endpoint-candidates.csv` must be represented by a matching `candidate_key` unless explicitly merged as a duplicate alias.

## Endpoint-flow inventory

`current-state/endpoint-flow-inventory.csv` contains one row per materially distinct business/functional flow handled by an endpoint.

Multiple rows with the same `endpoint_id` are expected and encouraged when evidence shows multiple business flows.

`primary_sequence_diagram` must point to the canonical `.puml` path.

## Path inventory

Every material reachable branch/path must be recorded in `endpoint-path-inventory.csv`.

`diagram_coverage` values:

- `PRIMARY`
- `SUPPORTING`
- `NOT_REPRESENTABLE_GAP`

The last value requires `gap_id`.

## Step ledger

Every flow must have numbered steps. Each step requires:

- business action/meaning;
- technical action;
- source and target participants;
- evidence class;
- evidence IDs/source locations.

Use `UNKNOWN` rather than inventing business meaning.

## Evidence references

Use evidence IDs from `evidence/evidence-register.csv` and exact source locations wherever possible, e.g.:

`SRC-0012 | src/main/mule/producer-api.xml | flow search-producers | http:request`

## Observed values

Traffic-derived maxima/percentiles are observations, not configured system limits. Every artifact must say `observed`, and include the measurement window when known.

## Sequence diagrams

The `.puml` source is canonical. Rendered `.svg` is required when local PlantUML is available.

Every primary flow diagram must use `autonumber`, exact stem-aligned `@startuml`, and valid sequence syntax.

## Gaps

Every potentially missed item due to missing evidence must be in `gaps-unknowns.csv` with impact and attempted evidence sources.
