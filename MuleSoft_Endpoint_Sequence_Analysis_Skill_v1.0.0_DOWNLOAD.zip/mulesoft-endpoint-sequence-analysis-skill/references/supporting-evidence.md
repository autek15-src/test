# Supporting Evidence Guidance

## Upstream source

Use upstream code to establish:

- actual caller and component;
- user action/user type when inferable from UI routes/components/permissions;
- exact URL/method/headers/query/body;
- timeout/retry expectations;
- response/error handling;
- whether the same endpoint is used for multiple business purposes.

## Downstream source

Use downstream code to establish:

- actual operation handling;
- business capability;
- accepted payload semantics;
- downstream validation/auth;
- side effects and persistence;
- response meanings.

## Splunk / Anypoint

Use runtime evidence for:

- confirmed route usage;
- consumers/client IDs;
- response codes;
- latency distributions;
- payload-size observations;
- error patterns;
- routing clues;
- seasonal/rare traffic.

Always record the observation window.

## Collibra

Use supplied Collibra data for lineage, definitions, ownership, schemas, system/domain relationships, and interface descriptions. Treat catalog metadata as supporting evidence, not executable truth.

## Documentation and diagrams

Use supplied current-state documentation when code/runtime cannot establish context. Mark the fact as `DOCUMENTED` and surface contradictions.
