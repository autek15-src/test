# HTML Report Standard

The HTML report is the primary human review artifact and must be usable offline.

## Navigation

Use a persistent sidebar with:

- Executive Summary
- Coverage & Data Quality
- Endpoint Universe
- Endpoints
  - one direct anchor per endpoint
- Gaps & Unknowns
- Evidence Sources
- Artifact Explorer

Provide global client-side search/filter.

## Coverage dashboard

Show at minimum:

- endpoint candidates discovered;
- endpoints reconciled;
- active vs config-only/dead/documented-fallback counts;
- total business flows;
- endpoints with multiple business flows;
- total material paths;
- flows with clean rendered SVGs;
- checklist completion;
- open gaps by severity.

## Endpoint section

Every endpoint gets a dedicated section containing:

1. endpoint identity/contract summary;
2. reconciliation/evidence status;
3. policy/security/runtime summary;
4. business-flow index;
5. one selectable flow panel per business flow.

## Flow panel

Each flow panel must show:

1. business purpose and trigger;
2. actor/user type/consumer;
3. upstream and downstream systems;
4. evidence/confidence summary;
5. embedded sequence SVG in `<div class="diagram-wrap seq-diagram">`;
6. visible fallback `Sequence diagram not available` when missing/broken;
7. path/branch inventory;
8. numbered business + technical step ledger;
9. participants;
10. exact evidence/source locations;
11. checklist status;
12. gaps/unknowns associated with the flow.

Required CSS:

```css
.seq-diagram svg { max-width:100%; height:auto; display:block; margin:0 auto; }
```

When an endpoint has multiple flows, use visible tabs/buttons; do not hide the multiplicity behind a dropdown.

## Artifact explorer

Embed or link every canonical CSV/MD/PUML/SVG artifact. The reviewer should not need filesystem browsing to understand the analysis.
