# Sequence Diagram Standards

## Naming

Primary diagrams live under:

`diagrams/endpoints/<endpoint-id>/seq-<NN>-<slug>.puml`

The rendered SVG uses the same stem. `NN` is a zero-padded sequence number within the endpoint.

The `@startuml` identifier MUST exactly equal the filename stem.

## Mandatory PlantUML conventions

- use `autonumber`;
- do **not** use structural direction directives;
- do **not** use `!pragma layout smetana` for sequence diagrams;
- define all participants before messages;
- group participants into logical `box` sections;
- use `activate`/`deactivate` where processing responsibility matters;
- use `alt`/`else`/`end` for material branches;
- use `loop` only for evidenced retry/redelivery behavior;
- use `par` only for actual concurrent work;
- include auth/authz/policy interactions when material to understanding behavior;
- label messages with protocol/method/event/operation and key business data;
- preserve response/error paths back to the initiating actor;
- use `note` for important transformations, business rules, unknowns, or evidence caveats.

## Participant grouping

Typical groups:

- User / External Actor
- Upstream Application
- MuleSoft / API Gateway / Policies
- Backend / Downstream Systems
- Async Messaging / External Services

Do not invent participants simply to make a diagram look complete.

## Readability

Target <=20 participants and <=40 message arrows for a primary diagram. Split at a natural boundary when larger.

Supporting diagrams go under:

`diagrams/endpoints/<endpoint-id>/supporting/`

## Business and technical fidelity

The diagram should make it possible to answer:

- Who initiates the action and why?
- Which consumer calls the endpoint?
- What authentication/authorization occurs?
- Which Mule flow/policies/transformations/choices are traversed?
- Which downstream endpoints/operations are called?
- What data is transformed or selected?
- What retries/timeouts/errors occur?
- What comes back to the actor?
- What is unknown or inferred?

## Render verification

After authoring each `.puml`, render it immediately. The SVG must be non-empty and must not contain PlantUML error markers such as `error occurred`, `IllegalStateException`, `syntax error`, or `assumed diagram type`.
