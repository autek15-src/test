# Endpoint-to-Business-Flow Multiplicity

One endpoint may serve zero, one, or many reconstructable business flows.

## Separate flow records are warranted when one or more differ materially

- primary actor/user type;
- upstream consumer application;
- business trigger;
- business purpose;
- input mode that selects a different operation;
- authorization context;
- downstream system or business capability;
- transaction semantics;
- externally visible business outcome;
- async continuation/callback behavior.

Implementation-level branches alone do not require separate business flows if they are merely error handling or small technical variations of the same business journey. Those belong in `alt`/`else` paths in one diagram.

## Diagram splitting

Use separate primary diagrams for the same endpoint when combining flow variants would:

- obscure the business story;
- require too many nested `alt` blocks;
- exceed roughly 20 participants or 40 messages;
- mix unrelated user journeys;
- mix synchronous and asynchronous processes that are easier to understand separately.

Each flow row must still reference the same `endpoint_id`.
