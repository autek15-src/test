# Endpoint Discovery and Trace Process

Apply this process to every endpoint candidate.

## Stage A - Establish endpoint identity

1. Locate the declaration: listener/APIkit/RAML/OpenAPI/WSDL/message source/scheduler/dynamic route.
2. Resolve method/operation/path/protocol.
3. Resolve listener/API configuration and base paths.
4. Reconcile spec declaration against executable implementation.
5. Determine whether the endpoint is reachable/active, documented-only, config-only, dead/unreachable, or a duplicate alias.

## Stage B - Trace complete executable behavior

6. Identify the endpoint's entry Mule flow.
7. Follow every `flow-ref` and subflow recursively.
8. Enumerate every `choice/when/otherwise`, router, try/error-handler, scatter-gather, foreach, parallel branch, async scope, batch branch, or custom-code decision that can materially change behavior.
9. Inspect DataWeave and inline transformations, including imported modules.
10. Trace all outbound connectors/requests actually reachable from each path.
11. Capture timeout/retry/reconnection/transaction/idempotency behavior.
12. Capture validation, authentication, authorization, gateway/API policies, and security side effects.
13. Trace response/error mapping back to the caller.
14. Record async side effects/events/callback continuations.

## Stage C - Add end-to-end context

15. Search upstream source for actual calls to the endpoint, including UI actions, user roles, services, scheduled jobs, headers, payload construction, retries, timeout expectations, and response handling.
16. Search downstream source for actual operation handling and business meaning.
17. Search Splunk/Anypoint for confirmed callers, paths, response codes, payload metadata, latency, routing clues, errors, and usage windows.
18. Search Collibra/interface catalogs for lineage, owner, domain, business descriptions, schemas, and consumers.
19. Review supplied architecture/network diagrams and documentation to fill remaining context, marking documentation-only facts.
20. Resolve contradictions among sources.

## Stage D - Determine business-flow multiplicity

21. Ask whether distinct actors/user types use the endpoint for different purposes.
22. Ask whether input flags/body/header/query values change the business operation.
23. Ask whether conditional routing sends the request to materially different backends.
24. Ask whether the same endpoint is used by multiple consumer applications for different outcomes.
25. Ask whether async side effects create distinct business journeys.
26. Create separate business-flow records when purpose/actor/trigger/material route/outcome differs.

## Stage E - Completeness proof

27. Ensure every material reachable path is in `endpoint-path-inventory.csv`.
28. Ensure every path maps to a flow and diagram or to an explicit unresolved gap.
29. Ensure every endpoint candidate is reconciled exactly once.
30. Complete the per-flow checklist.
31. Validate diagrams and HTML coverage.

Do not claim completeness based only on API specifications or endpoint names.
