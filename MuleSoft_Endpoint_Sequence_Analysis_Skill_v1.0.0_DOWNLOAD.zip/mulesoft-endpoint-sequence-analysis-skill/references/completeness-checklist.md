# Per-Flow Completeness Checklist

Every endpoint/business-flow pair must contain these checklist IDs in `endpoint-checklist.csv`.

| check_id | Category | Required check |
|---|---|---|
| C01 | Endpoint | Endpoint declaration/spec/config reconciled |
| C02 | Endpoint | Executable entry flow identified or gap recorded |
| C03 | Policies | Endpoint/gateway policies inspected |
| C04 | Code paths | All reachable flow-ref/subflows recursively followed |
| C05 | Code paths | Choice/router branches enumerated |
| C06 | Transformations | DataWeave/custom transformation logic inspected |
| C07 | Downstream | All reachable outbound calls/operations traced |
| C08 | Reliability | Timeout/retry/reconnection/transaction behavior inspected |
| C09 | Errors | Error handlers and caller-visible mappings inspected |
| C10 | Security | Authentication/authorization behavior traced |
| C11 | Upstream | Upstream consumer/user context investigated |
| C12 | Runtime | Splunk/Anypoint/runtime evidence searched when supplied |
| C13 | Supporting | Downstream source/Collibra/docs/diagrams investigated when supplied |
| C14 | Multiplicity | Endpoint assessed for multiple business flows |
| C15 | Paths | Every material path represented or linked to a gap |
| C16 | Diagram | Primary sequence diagram authored and source-validated |
| C17 | Diagram | Rendered SVG verified when PlantUML available |
| C18 | Evidence | Material steps have evidence/source references |
| C19 | Meaning | Business/functional meaning inferred as far as evidence allows |
| C20 | Unknowns | Missing/unknown context explicitly recorded |

Allowed statuses:

- `PASS`
- `BLOCKED_GAP`
- `NOT_APPLICABLE`

`BLOCKED_GAP` requires a gap ID in `notes` or evidence reference.
