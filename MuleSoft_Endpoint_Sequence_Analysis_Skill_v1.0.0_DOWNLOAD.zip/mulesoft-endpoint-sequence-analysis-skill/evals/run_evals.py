#!/usr/bin/env python3
from __future__ import annotations
import csv,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tests'))
from common import make_complete,write_csv

def set_checks(a):
    subprocess.check_call([sys.executable,str(ROOT/'scripts/seed_checklists.py'),str(a)],stdout=subprocess.DEVNULL);p=a/'current-state/endpoint-checklist.csv';r=list(csv.DictReader(p.open()));
    for x in r:x['status']='PASS'
    write_csv(p,r[0].keys(),r)
def run(extra=None,expect=0):
    with tempfile.TemporaryDirectory() as td:
        a=Path(td)/'a';subprocess.check_call([sys.executable,str(ROOT/'scripts/bootstrap_analysis.py'),str(a)],stdout=subprocess.DEVNULL);make_complete(a);set_checks(a)
        if extra:extra(a)
        r=subprocess.run([sys.executable,str(ROOT/'scripts/validate_analysis.py'),str(a)],stdout=subprocess.PIPE,text=True)
        assert r.returncode==expect,(r.returncode,r.stdout)

def unreconciled(a):
    p=a/'evidence/endpoint-candidates.csv';r=list(csv.DictReader(p.open()));r.append({**r[0],'candidate_id':'C2','candidate_key':'HTTP|GET|/ghost','method_or_operation':'GET','resource_or_source':'/ghost'});write_csv(p,r[0].keys(),r)
def no_paths(a):
    p=a/'current-state/endpoint-path-inventory.csv';write_csv(p,['path_id','endpoint_id','flow_id','path_name','path_type','decision_condition','source_branch_or_location','terminal_outcome','diagram_coverage','supporting_diagram','gap_id','evidence_refs','notes'],[])
def no_diagram(a):
    (a/'diagrams/endpoints/EP-001/seq-01-producer-search.puml').unlink()
def blocked_no_gap(a):
    p=a/'current-state/endpoint-checklist.csv';r=list(csv.DictReader(p.open()));r[0]['status']='BLOCKED_GAP';r[0]['notes']='missing';write_csv(p,r[0].keys(),r)
run(expect=0);run(unreconciled,1);run(no_paths,1);run(no_diagram,1);run(blocked_no_gap,1)
print('5 evaluation scenarios passed')
