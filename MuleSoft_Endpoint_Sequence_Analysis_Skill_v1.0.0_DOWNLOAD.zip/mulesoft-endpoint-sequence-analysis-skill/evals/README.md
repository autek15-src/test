# Evaluation Scenarios

`run_evals.py` exercises completion-gate behaviors that matter for exhaustive endpoint reconstruction:

- unreconciled endpoint candidate must fail;
- one endpoint with multiple business flows must pass;
- missing material path must fail;
- missing sequence source must fail;
- blocked checklist item without a GAP record must fail.
