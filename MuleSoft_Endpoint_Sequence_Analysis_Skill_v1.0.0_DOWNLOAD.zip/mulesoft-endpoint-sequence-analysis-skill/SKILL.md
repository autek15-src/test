---
name: mulesoft-endpoint-sequence-analysis
version: 1.0.0
description: Exhaustive evidence-driven reconstruction of every MuleSoft endpoint and every business/functional flow handled by each endpoint, with source-traced path inventories, per-flow completeness checklists, PlantUML sequence diagrams, gaps/unknowns tracking, and a first-class self-contained HTML review report.
---

# MuleSoft Endpoint Sequence Analysis Skill

Use this skill when the goal is to understand **exactly what every MuleSoft endpoint does today**, end to end, before migration, upgrade, refactoring, testing, or architecture review.

This skill does **not** design the AWS target architecture. Its job is behavioral reconstruction and evidence-backed documentation.

## Core objective

For every endpoint/interface identified in the MuleSoft application:

1. establish the complete endpoint universe before deep analysis;
2. trace the implementation from ingress through every reachable code path;
3. identify every distinct business/functional flow that can use that endpoint;
4. reconstruct upstream actors/consumers and downstream systems using all available evidence;
5. document business meaning, functional meaning, technical behavior, policies, transformations, branches, retries, errors, timeouts, and responses;
6. create one or more detailed sequence diagrams as needed;
7. cite the exact evidence used for every flow;
8. record unknowns and potentially missed behavior when evidence is unavailable;
9. prove completion with a per-endpoint/per-flow checklist and machine validation;
10. produce a rich self-contained HTML report plus separate editable/rendered sequence diagrams.

## Important multiplicity rule

A Mule endpoint is **not equivalent to one business flow**.

A single endpoint may support multiple materially different journeys, for example:

- different user types or consumer applications;
- different query/body modes;
- different business operations encoded by payload or headers;
- different routing conditions;
- different downstream systems;
- different authentication contexts;
- synchronous vs. asynchronous consequences;
- create/update/cancel semantics behind one generic endpoint;
- different success/error/exception paths that have distinct business meaning.

Every distinct business flow must be documented. If combining them in one sequence diagram would obscure the business meaning or exceed readability limits, create **separate primary sequence diagrams tied to the same endpoint**.

Do not force a one-endpoint/one-diagram model.

# Evidence priority

Use evidence in this order when sources conflict:

1. **reachable executable source behavior**: Mule XML, APIkit routing, DataWeave, custom Java/code, reachable config references, policies tied to the endpoint;
2. **observed production/runtime evidence**: Splunk, Anypoint Monitoring/API Manager analytics, traces, captured payload metadata, runtime logs;
3. **source code of upstream/downstream systems** demonstrating actual calls and behavior;
4. **configuration/specification evidence** that is referenced by reachable code;
5. **Collibra/interface catalog evidence**;
6. **current documentation and architecture/network diagrams**;
7. **inference**, explicitly labeled.

Configuration declarations that are never referenced by reachable code may be dead placeholders. Record them, but do not present them as active runtime behavior without corroboration.

When documentation conflicts with code/runtime evidence, prefer executable/observed behavior and record the contradiction.

Read `references/evidence-discipline.md` and `references/discovery-process.md` before analysis.

# Mandatory automated workflow

The user should not normally need to run scripts manually. The agent owns the lifecycle.

## Phase 0 - Preflight

1. Resolve the Mule repository root.
2. Resolve/create the analysis output directory.
3. Identify all supplementary inputs: upstream/downstream repositories, policies, Collibra exports, Splunk/Anypoint exports, Postman/SoapUI/MUnit, documents, diagrams, network data, logs, screenshots, API Manager exports.
4. Read all references in this skill relevant to the available evidence.
5. Record unavailable evidence categories instead of silently ignoring them.

## Phase 1 - Prepare and establish the endpoint universe

Run automatically:

```bash
python scripts/run_analysis.py prepare <analysis-dir> \
  --source-repo <mule-repo> \
  --inputs <supporting-input>
```

Repeat `--inputs` as needed.

The prepare phase seeds:

- source inventory;
- Mule structural scan;
- endpoint candidate universe;
- canonical analysis templates.

### Endpoint universe must be established before deep tracing

Search all of the following:

- HTTP listeners;
- APIkit route flows;
- RAML/OpenAPI resources and methods;
- SOAP/WSDL operations;
- message/JMS/MQ inbound consumers;
- schedulers/batch entry points where they act as externally meaningful integration interfaces;
- callback/webhook listeners;
- API Manager/policy registrations when supplied;
- source code/config that exposes routes dynamically.

Every discovered candidate must be reconciled in `current-state/endpoint-inventory.csv` as one of:

- `ACTIVE_CONFIRMED`
- `ACTIVE_DOCUMENTED_FALLBACK`
- `CONFIG_ONLY_UNCONFIRMED`
- `DEAD_OR_UNREACHABLE`
- `DUPLICATE_ALIAS`

Do not silently discard config-only/dead candidates. Their uncertainty is part of the analysis.

## Phase 2 - Exhaustively trace each endpoint

For **every endpoint candidate**, follow the checklist in `references/discovery-process.md`.

Trace:

- ingress/listener/APIkit mapping;
- endpoint-specific and gateway policies;
- flow references and subflows recursively;
- choice/when/otherwise branches;
- scatter-gather/parallel/foreach paths;
- transformations and DataWeave imports;
- variables/attributes that affect routing;
- custom Java/script logic;
- backend connector/request operations;
- transaction semantics;
- retry/reconnection/until-successful behavior;
- timeout configuration;
- error handlers and status/error mapping;
- async side effects/events;
- response transformation;
- logging/correlation/audit behavior.

### Enumerate every material code path

Populate `current-state/endpoint-path-inventory.csv` before claiming the endpoint is understood.

A path can be:

- success/default;
- conditional business branch;
- alternate backend route;
- validation rejection;
- authorization rejection;
- retry/transient failure;
- terminal error;
- async side effect;
- callback/event continuation;
- fallback/default behavior.

Every reachable material path must either be represented in a primary/supporting diagram or explicitly marked as not reconstructable with a linked gap record.

## Phase 3 - Reconstruct business-flow multiplicity

After technical paths are known, determine how many **business/functional flows** the endpoint actually serves.

Create one row per endpoint/business-flow pair in `current-state/endpoint-flow-inventory.csv`.

Examples that justify separate flow rows/diagrams for one endpoint:

- producer search initiated by an internal policy administrator vs. broker self-search;
- one endpoint routing to SAP for one product and Salesforce for another;
- same generic POST performing create vs. cancel based on payload action;
- UI interactive call vs. scheduled batch consumer using the same route;
- same endpoint used by two applications for different business purposes.

Do not create artificial flows merely because code has small implementation branches. Separate flows when the **actor, business purpose, trigger, material downstream route, or business outcome** is meaningfully different.

### Add upstream/downstream context

For each flow, inspect available:

- upstream UI/business-service/client source;
- downstream service/source;
- Collibra lineage/interface records;
- Splunk/Anypoint traffic and logs;
- documentation;
- architecture/network diagrams.

Infer as much business meaning as evidence supports. Label inference clearly.

If upstream or downstream context remains unknown, record the gap in `current-state/gaps-unknowns.csv`; do not invent participants.

## Phase 4 - Commit flow and diagram identities

Before diagram authoring, run automatically:

```bash
python scripts/run_analysis.py commit-flows <analysis-dir>
```

This assigns deterministic primary sequence names:

`diagrams/endpoints/<endpoint-id>/seq-<NN>-<slug>.puml`

where `NN` is the business-flow sequence within that endpoint.

The mapping in `endpoint-flow-inventory.csv` is the single source of truth. The `.puml`, `.svg`, HTML anchor, and manifest must share the same stem.

## Phase 5 - Author sequence diagrams

Read `references/sequence-diagram-standards.md`.

For every endpoint/business-flow row:

- create a primary PlantUML sequence diagram;
- include upstream actor/consumer when known;
- include every material Mule hop/policy/flow decision needed to understand behavior;
- include downstream systems and actual called endpoints/operations when known;
- include material auth/authz steps;
- use `alt` for conditional/error branches;
- use `loop` for evidenced retries/redelivery;
- use `par`/grouping where concurrency materially matters;
- use `activate`/`deactivate`;
- use `autonumber`;
- label arrows with method/protocol/event and key business data;
- cite evidence IDs in notes or accompanying step tables rather than cluttering every arrow.

If one business flow exceeds roughly 20 participants or 40 messages, split at a natural boundary. Keep one primary diagram and put supporting diagrams under the same endpoint directory `supporting/`.

Render immediately after writing each diagram. Broken PlantUML output is not acceptable.

## Phase 6 - Populate evidence, steps, checklists, and gaps

Populate:

- `current-state/endpoint-flow-steps.csv`
- `current-state/endpoint-participants.csv`
- `current-state/endpoint-checklist.csv`
- `current-state/endpoint-evidence.csv`
- `current-state/gaps-unknowns.csv`
- `current-state/coverage-summary.md`

Every step must contain both:

- **business/functional meaning**; and
- **technical behavior**.

Use `UNKNOWN` when business meaning cannot be established.

### Mandatory per-flow checklist

Every endpoint/business-flow pair must complete all checklist categories defined in `references/completeness-checklist.md`.

The skill should seed missing checklist rows automatically; the agent must change statuses based on evidence.

## Phase 7 - Validate and remediate

Run automatically:

```bash
python scripts/run_analysis.py validate <analysis-dir>
```

Read `validation/analysis-validation.json` and fix every correctable finding.

Repeat until:

- validation passes; or
- remaining failures reflect genuinely missing evidence and are explicitly represented as gaps/unknowns.

Never weaken validator rules merely to obtain a passing result.

## Phase 8 - Finalize report

Run automatically:

```bash
python scripts/run_analysis.py finalize <analysis-dir>
```

This renders diagrams, builds the self-contained HTML report, and reruns completion validation.

# Required outputs

The final analysis must include:

```text
endpoint-sequence-analysis/
├── endpoint-sequence-analysis.html
├── executive-summary.md
├── evidence/
│   ├── source-inventory.csv
│   ├── evidence-register.csv
│   ├── mule-scan.json
│   └── endpoint-candidates.csv
├── current-state/
│   ├── endpoint-inventory.csv
│   ├── endpoint-flow-inventory.csv
│   ├── endpoint-path-inventory.csv
│   ├── endpoint-flow-steps.csv
│   ├── endpoint-participants.csv
│   ├── endpoint-checklist.csv
│   ├── endpoint-evidence.csv
│   ├── policy-inventory.csv
│   ├── traffic-evidence.csv
│   ├── gaps-unknowns.csv
│   └── coverage-summary.md
├── diagrams/
│   └── endpoints/
│       └── <endpoint-id>/
│           ├── seq-01-<slug>.puml
│           ├── seq-01-<slug>.svg
│           └── supporting/
└── validation/
    └── analysis-validation.json
```

# HTML is the primary review artifact

`endpoint-sequence-analysis.html` must allow an architect/analyst to understand the complete reconstructed behavior without manually browsing the filesystem.

It must contain:

- coverage dashboard;
- endpoint universe/reconciliation status;
- searchable endpoint index;
- one endpoint section for every candidate;
- multiple business-flow tabs/cards under an endpoint when applicable;
- embedded sequence diagrams;
- business context and functional purpose;
- participant/upstream/downstream context;
- path/branch inventory;
- numbered step ledger;
- policies/security/timeouts/retries/errors;
- exact evidence/source locations;
- traffic observations, clearly labeled as observations;
- completeness checklist;
- unknowns/gaps;
- embedded artifact explorer and links/downloads for separate diagrams.

Read `references/html-report-standard.md` for the exact UX contract.

# Final quality bar

The analysis is not complete unless:

- every endpoint candidate is reconciled;
- every endpoint has at least one flow record, including an explicit unresolved flow for config-only/dead endpoints when behavior cannot be reconstructed;
- every materially distinct business flow per endpoint is represented;
- every material reachable code path is accounted for;
- every flow has a sequence diagram source;
- every primary diagram renders cleanly when PlantUML is available;
- every flow has business + technical step descriptions;
- every flow cites exact evidence;
- every flow checklist is complete or explicitly blocked by a recorded gap;
- every unknown upstream/downstream/branch/policy is visible in the gaps register;
- documentation conflicts are surfaced;
- observed traffic maxima are never mislabeled as configured/system limits;
- the HTML contains every endpoint and every business-flow diagram.
