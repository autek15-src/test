from pathlib import Path
import tempfile,subprocess,sys,csv
from common import make_complete
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
    a=Path(td)/'a';subprocess.check_call([sys.executable,str(ROOT/'scripts/bootstrap_analysis.py'),str(a)]);make_complete(a);subprocess.check_call([sys.executable,str(ROOT/'scripts/seed_checklists.py'),str(a)])
    p=a/'current-state/endpoint-checklist.csv';rows=list(csv.DictReader(p.open()));
    for r in rows:r['status']='PASS'
    with p.open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    subprocess.check_call([sys.executable,str(ROOT/'scripts/build_html_report.py'),str(a)])
    h=(a/'endpoint-sequence-analysis.html').read_text()
    assert 'id="endpoint-ep-001"' in h
    assert 'id="flow-seq-01-producer-search"' in h and 'id="flow-seq-02-agency-search"' in h
    assert h.count('class="flow-tab')>=2
    r=subprocess.run([sys.executable,str(ROOT/'scripts/validate_analysis.py'),str(a),'--require-html'])
    assert r.returncode==0
print('html ok')
