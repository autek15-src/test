from pathlib import Path
import tempfile,subprocess,sys,csv
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
    a=Path(td);p=a/'current-state/endpoint-flow-inventory.csv';p.parent.mkdir(parents=True)
    fields=['flow_id','endpoint_id','flow_name','flow_category','business_purpose','trigger','primary_actor','user_type_or_consumer','entry_condition','upstream_components','downstream_systems','final_outcome','primary_sequence_diagram','supporting_diagrams','evidence_class','evidence_refs','confidence','notes']
    rows=[dict.fromkeys(fields,'') for _ in range(2)];rows[0].update(flow_id='F1',endpoint_id='EP-009',flow_name='Producer Search');rows[1].update(flow_id='F2',endpoint_id='EP-009',flow_name='Agency Search')
    with p.open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    subprocess.check_call([sys.executable,str(ROOT/'scripts/assign_sequence_names.py'),str(a)])
    got=list(csv.DictReader(p.open()));assert got[0]['primary_sequence_diagram'].endswith('/seq-01-producer-search.puml');assert got[1]['primary_sequence_diagram'].endswith('/seq-02-agency-search.puml')
print('assign names ok')
