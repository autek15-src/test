from pathlib import Path
import tempfile,subprocess,sys,csv,json
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
    d=Path(td);repo=d/'repo';(repo/'src/main/mule').mkdir(parents=True)
    (repo/'src/main/mule/api.xml').write_text('''<mule xmlns:http="http://www.mulesoft.org/schema/mule/http"><flow name="search-flow"><http:listener config-ref="http" path="/search" allowedMethods="POST"/></flow><flow name="get:/items:api-config"/></mule>''')
    (repo/'api.raml').write_text('#%RAML 1.0\n/items:\n  post:\n')
    src=d/'sources.csv';ep=d/'eps.csv';js=d/'scan.json'
    r=subprocess.run([sys.executable,str(ROOT/'scripts/scan_mule_project.py'),str(repo),'--source-csv',str(src),'--endpoint-csv',str(ep),'--json',str(js)])
    assert r.returncode==0
    rows=list(csv.DictReader(ep.open()))
    keys={x['candidate_key'] for x in rows}
    assert 'HTTP|POST|/search' in keys
    assert any('/items' in k for k in keys)
print('scanner ok')
