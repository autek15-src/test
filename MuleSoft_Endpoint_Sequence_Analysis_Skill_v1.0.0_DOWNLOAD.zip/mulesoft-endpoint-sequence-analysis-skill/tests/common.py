from __future__ import annotations
import csv
from pathlib import Path

def write_csv(p:Path,fields,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def make_complete(root:Path):
    # Templates should already be bootstrapped.
    write_csv(root/'evidence/endpoint-candidates.csv',['candidate_id','candidate_key','protocol','method_or_operation','resource_or_source','ingress_type','implementation_entrypoint','config_ref','declaration_source','notes'],[
        {'candidate_id':'CAND-0001','candidate_key':'HTTP|POST|/search','protocol':'HTTP','method_or_operation':'POST','resource_or_source':'/search','ingress_type':'HTTP_LISTENER','implementation_entrypoint':'search-flow','config_ref':'http','declaration_source':'src/main/mule/api.xml','notes':''}
    ])
    write_csv(root/'current-state/endpoint-inventory.csv',['candidate_key','endpoint_id','application','api_name','protocol','method_or_operation','resource_or_source','ingress_type','implementation_entrypoint','spec_or_contract_source','endpoint_status','consumer_relationship','business_flow_ids','authentication','authorization','request_content_type','response_content_type','policy_refs','source_evidence_refs','runtime_evidence_refs','documentation_evidence_refs','notes'],[
        {'candidate_key':'HTTP|POST|/search','endpoint_id':'EP-001','application':'demo','api_name':'Search API','protocol':'HTTP','method_or_operation':'POST','resource_or_source':'/search','ingress_type':'HTTP_LISTENER','implementation_entrypoint':'search-flow','spec_or_contract_source':'api.raml','endpoint_status':'ACTIVE_CONFIRMED','consumer_relationship':'application UI','business_flow_ids':'FLOW-001,FLOW-002','authentication':'Okta JWT','authorization':'role check','request_content_type':'application/json','response_content_type':'application/json','policy_refs':'POL-1','source_evidence_refs':'EVID-1','runtime_evidence_refs':'EVID-2','documentation_evidence_refs':'','notes':''}
    ])
    flow_fields=['flow_id','endpoint_id','flow_name','flow_category','business_purpose','trigger','primary_actor','user_type_or_consumer','entry_condition','upstream_components','downstream_systems','final_outcome','primary_sequence_diagram','supporting_diagrams','evidence_class','evidence_refs','confidence','notes']
    flows=[
        {'flow_id':'FLOW-001','endpoint_id':'EP-001','flow_name':'Producer search','flow_category':'authenticated user journey','business_purpose':'Find producers','trigger':'User clicks Search','primary_actor':'Policy Admin','user_type_or_consumer':'Internal UI','entry_condition':'type=producer','upstream_components':'UI','downstream_systems':'Producer DB','final_outcome':'Results displayed','primary_sequence_diagram':'diagrams/endpoints/EP-001/seq-01-producer-search.puml','supporting_diagrams':'','evidence_class':'OBSERVED_CODE','evidence_refs':'EVID-1','confidence':'HIGH','notes':''},
        {'flow_id':'FLOW-002','endpoint_id':'EP-001','flow_name':'Agency search','flow_category':'authenticated user journey','business_purpose':'Find agencies','trigger':'User selects Agency','primary_actor':'Policy Admin','user_type_or_consumer':'Internal UI','entry_condition':'type=agency','upstream_components':'UI','downstream_systems':'Agency service','final_outcome':'Agency results displayed','primary_sequence_diagram':'diagrams/endpoints/EP-001/seq-02-agency-search.puml','supporting_diagrams':'','evidence_class':'OBSERVED_CODE','evidence_refs':'EVID-1','confidence':'HIGH','notes':''}
    ]
    write_csv(root/'current-state/endpoint-flow-inventory.csv',flow_fields,flows)
    path_fields=['path_id','endpoint_id','flow_id','path_name','path_type','decision_condition','source_branch_or_location','terminal_outcome','diagram_coverage','supporting_diagram','gap_id','evidence_refs','notes']
    write_csv(root/'current-state/endpoint-path-inventory.csv',path_fields,[
        {'path_id':'P1','endpoint_id':'EP-001','flow_id':'FLOW-001','path_name':'success','path_type':'SUCCESS','decision_condition':'type=producer','source_branch_or_location':'api.xml choice','terminal_outcome':'results','diagram_coverage':'PRIMARY','supporting_diagram':'','gap_id':'','evidence_refs':'EVID-1','notes':''},
        {'path_id':'P2','endpoint_id':'EP-001','flow_id':'FLOW-002','path_name':'success','path_type':'SUCCESS','decision_condition':'type=agency','source_branch_or_location':'api.xml choice','terminal_outcome':'results','diagram_coverage':'PRIMARY','supporting_diagram':'','gap_id':'','evidence_refs':'EVID-1','notes':''}
    ])
    step_fields=['flow_id','path_id','step_number','actor_or_system','business_action','technical_action','source_component','target_component','protocol_method_operation','endpoint_or_event','request_or_event','data_or_transformation','authentication_authorization','timeout_retry','response_or_outcome','error_or_alternate_path','evidence_class','evidence_refs','source_locations']
    rows=[]
    for fid,pid,purpose in [('FLOW-001','P1','Search producer'),('FLOW-002','P2','Search agency')]:
        rows.append({'flow_id':fid,'path_id':pid,'step_number':'1','actor_or_system':'Policy Admin','business_action':purpose,'technical_action':'UI calls Mule endpoint','source_component':'UI','target_component':'Mule','protocol_method_operation':'HTTPS POST','endpoint_or_event':'/search','request_or_event':'JSON criteria','data_or_transformation':'criteria mapped','authentication_authorization':'JWT + role','timeout_retry':'30s / none','response_or_outcome':'results','error_or_alternate_path':'mapped error','evidence_class':'OBSERVED_CODE','evidence_refs':'EVID-1','source_locations':'ui.ts; api.xml'})
    write_csv(root/'current-state/endpoint-flow-steps.csv',step_fields,rows)
    part_fields=['flow_id','participant_id','participant_name','participant_type','business_role','technical_role','system_or_application','evidence_class','evidence_refs','source_locations','notes']
    write_csv(root/'current-state/endpoint-participants.csv',part_fields,[{'flow_id':fid,'participant_id':'U','participant_name':'Policy Admin','participant_type':'actor','business_role':'searches','technical_role':'caller','system_or_application':'UI','evidence_class':'OBSERVED_CODE','evidence_refs':'EVID-1','source_locations':'ui.ts','notes':''} for fid in ['FLOW-001','FLOW-002']])
    evid_fields=['endpoint_id','flow_id','evidence_id','evidence_role','fact_supported','source_type','source_location','evidence_class','observation_window','notes']
    write_csv(root/'current-state/endpoint-evidence.csv',evid_fields,[{'endpoint_id':'EP-001','flow_id':fid,'evidence_id':'EVID-1','evidence_role':'implementation','fact_supported':'flow behavior','source_type':'Mule XML','source_location':'src/main/mule/api.xml','evidence_class':'OBSERVED_CODE','observation_window':'N/A','notes':''} for fid in ['FLOW-001','FLOW-002']])
    # no gaps required
    write_csv(root/'current-state/gaps-unknowns.csv',['gap_id','endpoint_id','flow_id','path_id','severity','category','missing_information','potentially_missed_behavior','impact','attempted_sources','status','owner_or_followup','evidence_refs','notes'],[])
    write_csv(root/'current-state/policy-inventory.csv',['policy_id','endpoint_id','policy_name','policy_type','scope','status','security_critical','behavior','evidence_refs','source_locations','notes'],[{'policy_id':'POL-1','endpoint_id':'EP-001','policy_name':'JWT','policy_type':'auth','scope':'endpoint','status':'CONFIRMED','security_critical':'yes','behavior':'validates token','evidence_refs':'EVID-1','source_locations':'policy export','notes':''}])
    write_csv(root/'current-state/traffic-evidence.csv',['endpoint_id','flow_id','metric','statistic','value','unit','observation_window','source','evidence_ref','notes'],[])
    write_csv(root/'evidence/evidence-register.csv',['evidence_id','evidence_class','source_type','path_or_name','specific_location','fact_or_use','observation_window','review_status','notes'],[{'evidence_id':'EVID-1','evidence_class':'OBSERVED_CODE','source_type':'Mule XML','path_or_name':'src/main/mule/api.xml','specific_location':'search-flow','fact_or_use':'implementation','observation_window':'N/A','review_status':'REVIEWED','notes':''}])
    write_csv(root/'evidence/source-inventory.csv',['source_id','source_type','path_or_name','scope','relevance','modified_date','review_status','notes'],[{'source_id':'SRC-1','source_type':'XML/Mule candidate','path_or_name':'src/main/mule/api.xml','scope':'repository','relevance':'endpoint','modified_date':'','review_status':'REVIEWED','notes':''}])
    # diagrams and SVGs
    for rel,title in [('diagrams/endpoints/EP-001/seq-01-producer-search.puml','producer'),('diagrams/endpoints/EP-001/seq-02-agency-search.puml','agency')]:
        p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);stem=p.stem;p.write_text(f'@startuml {stem}\nautonumber\nactor User\nparticipant Mule\nUser -> Mule: {title}\nMule --> User: result\n@enduml\n')
        p.with_suffix('.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="40"><text>ok</text></svg>')
