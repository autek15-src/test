from pathlib import Path
import tempfile,subprocess,sys,csv
from common import make_complete
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
    a=Path(td)/'a';subprocess.check_call([sys.executable,str(ROOT/'scripts/bootstrap_analysis.py'),str(a)]);make_complete(a)
    subprocess.check_call([sys.executable,str(ROOT/'scripts/seed_checklists.py'),str(a)])
    p=a/'current-state/endpoint-checklist.csv';rows=list(csv.DictReader(p.open()));
    for r in rows:r['status']='PASS'
    with p.open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    r=subprocess.run([sys.executable,str(ROOT/'scripts/validate_analysis.py'),str(a)])
    assert r.returncode==0
    flows=list(csv.DictReader((a/'current-state/endpoint-flow-inventory.csv').open()))
    assert len(flows)==2 and len({x['endpoint_id'] for x in flows})==1
print('multiplicity ok')
