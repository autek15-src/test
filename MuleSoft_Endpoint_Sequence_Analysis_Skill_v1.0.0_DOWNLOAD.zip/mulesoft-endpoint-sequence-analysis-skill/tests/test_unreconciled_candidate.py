from pathlib import Path
import tempfile,subprocess,sys,csv
from common import make_complete,write_csv
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
    a=Path(td)/'a';subprocess.check_call([sys.executable,str(ROOT/'scripts/bootstrap_analysis.py'),str(a)]);make_complete(a)
    p=a/'evidence/endpoint-candidates.csv';rows=list(csv.DictReader(p.open()));rows.append({'candidate_id':'CAND-0002','candidate_key':'HTTP|GET|/missing','protocol':'HTTP','method_or_operation':'GET','resource_or_source':'/missing','ingress_type':'RAML_SPEC','implementation_entrypoint':'','config_ref':'','declaration_source':'api.raml','notes':''});write_csv(p,rows[0].keys(),rows)
    r=subprocess.run([sys.executable,str(ROOT/'scripts/validate_analysis.py'),str(a)],capture_output=True,text=True)
    assert r.returncode==1 and 'CANDIDATE_UNRECONCILED' in r.stdout
print('unreconciled candidate check ok')
