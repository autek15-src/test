# Changelog

## 1.1.0

- Made assessment bootstrap, scan, validation, and finalization part of the mandatory skill workflow instead of manual user prerequisites.
- Added `scripts/run_assessment.py` as the deterministic lifecycle controller.
- Added `prepare`, `validate`, `finalize`, and `status` controller phases.
- Added machine-readable workflow state under `.skill-run/state.json`.
- Added machine-readable validation output under `validation/assessment-validation.json`.
- Added mandatory agent remediation loop for validator findings.
- Added automatic target OpenAPI validation when a populated REST target specification exists.
- Added automatic HTML report generation during finalization.
- Added best-effort PlantUML rendering during finalization while preserving `.puml` as canonical source.
- Updated `SKILL.md`, README, and installation instructions so end users are not expected to run bootstrap/validation scripts manually.
- Added orchestration unit tests and retained the modular lower-level scripts for CI/debugging.

## 1.0.0

- Initial complete MuleSoft-to-AWS architecture assessment skill package.
- Added repository scanner, traffic analyzer, OpenAPI validation, PlantUML rendering, HTML report generation, completion validator, package tests, and architecture evaluation scenarios.
