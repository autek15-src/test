# Traffic Analysis

Analyze per endpoint, not only per application.

## Volume
- requests/day/hour
- average TPS
- peak sustained TPS
- burst TPS
- concurrency
- peak periods/seasonality

## Latency
- p50/p90/p95/p99/max
- separate gateway/Mule/downstream time if evidence allows

## Payload
For request and response:
- p50/p95/p99/max
- content type
- binary/base64/compression implications

## Reliability
- 2xx/4xx/5xx
- timeouts
- retries
- downstream failures
- duplicates
- throttling

## Observation quality
Always record:
- start/end date
- environment
- filters/query used
- missing periods
- whether seasonal/scheduled traffic may be absent

Use `scripts/analyze_traffic.py` for normalized CSV exports when practical.
