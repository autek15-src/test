# Source Priority for Volatile Facts

For AWS quotas, features, networking behavior, pricing, and service semantics, prefer sources in this order:

1. Current official AWS service documentation (`docs.aws.amazon.com`).
2. Current AWS service/pricing pages (`aws.amazon.com`).
3. AWS Prescriptive Guidance / Well-Architected guidance.
4. Official vendor documentation for HashiCorp Vault, Splunk, MuleSoft, SAP, etc.
5. Current vendor blogs or engineering posts.
6. Community/blog/social sources only for implementation experience or caveats, never as the sole authority for a hard service limit.

Record the official source URL and verification date in the assessment whenever a volatile fact materially affects the architecture.

Do not hardcode remembered AWS limits into `SKILL.md`; the point of `aws-limit-validation.csv` is to force current verification.
