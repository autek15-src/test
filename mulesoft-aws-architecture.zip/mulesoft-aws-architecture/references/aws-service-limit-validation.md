# AWS Service Limit Validation

AWS limits change. Verify them from current official AWS documentation during every assessment.

For every proposed service record:
- AWS service
- feature/limit name
- official source URL
- verified date
- observed/current requirement
- unit
- hard/default/adjustable limit
- safety margin/headroom
- result: PASS/WARN/FAIL
- architectural consequence

## Validate when applicable

### API Gateway
- payload size
- integration timeout
- endpoint type/private support
- throttling/quotas
- header limits
- VPC Link/private integration
- auth/mTLS/WAF capabilities

### Lambda
- max duration
- request/response/event size
- response streaming rules
- memory/CPU
- ephemeral storage
- package/image/layer limits
- concurrency/scaling
- VPC/networking behavior

### Step Functions
- execution duration
- state payload
- history/throughput
- execution type semantics

### SQS/SNS/EventBridge
- message size
- ordering/deduplication
- throughput
- retry/DLQ/delivery semantics

### ECS/Fargate
- CPU/memory combinations
- ephemeral storage
- networking/ENI
- autoscaling/task behavior

## Headroom

Do not treat "barely under the hard limit" as healthy. Flag limited headroom as WARN and recommend load/extreme-value testing or a different architecture.
