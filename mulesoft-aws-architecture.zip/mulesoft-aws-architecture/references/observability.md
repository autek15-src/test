# Observability Design

Company baseline: CloudWatch + Splunk.

## Structured logs
Recommended fields:
- timestamp
- service/application
- environment
- request/correlation/trace ID
- endpoint/operation
- result/status
- duration
- downstream duration
- sanitized error classification

Never log secrets, authorization headers, access tokens, or sensitive PII without explicit approval.

## Metrics
Select service-appropriate metrics including:
- request count/latency/errors/throttles
- Lambda duration/concurrency/cold starts
- API Gateway latency/integration latency
- queue depth/oldest message/DLQ
- ECS CPU/memory/task count
- backend latency/errors

## Tracing
Preserve correlation across consumer -> ingress -> AWS service -> downstream. Use AWS-native telemetry where useful and route/bridge to Splunk according to enterprise tooling.
