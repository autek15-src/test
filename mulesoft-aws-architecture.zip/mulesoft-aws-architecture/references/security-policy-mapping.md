# Security and API Policy Mapping

Map both source-code security and externally managed API policies.

## Discover
- OAuth/OIDC/JWT
- Basic auth
- client ID/key enforcement
- mTLS/certificates
- IP allow/deny
- CORS
- rate limiting/spike control/SLA tiers
- validation/threat protection
- header transforms
- message logging
- custom policies

## Target requirements
- least-privilege IAM
- TLS and encryption at rest where applicable
- HashiCorp Vault for secrets
- input validation
- sensitive-log redaction
- auth/authz parity
- auditability
- rate limiting/throttling
- network/resource policies

If API Manager policy evidence is unavailable for a production API, mark the policy inventory UNKNOWN and create at least a P1 finding when security parity cannot otherwise be proven.
