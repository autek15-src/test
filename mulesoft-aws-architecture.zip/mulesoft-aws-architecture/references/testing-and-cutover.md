# Testing and Cutover

## Reuse evidence
- MUnit
- Postman
- SoapUI
- API specs
- production payload examples
- Splunk examples
- existing application tests

## Test layers

### Contract
Paths, methods, headers, schemas, content types, status/error contracts.

### Functional equivalence
Run equivalent inputs against Mule and target and compare body, headers, status, side effects, downstream calls, and error behavior.

### Negative
Malformed payload, invalid auth, missing headers, payload extremes, downstream timeout/4xx/5xx, duplicate request, retry conditions.

### Performance
Expected and burst TPS, p95/p99 latency, payload extremes, concurrency, downstream saturation, Lambda cold starts, Fargate scaling.

## Cutover
Consider strangler routing, consumer-by-consumer migration, canary, parallel run, shadow comparison, rollback, cert/credential rotation, monitoring window, and safe Mule decommission sequencing.
