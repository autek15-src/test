# Evidence Discipline

Use explicit evidence classifications throughout the assessment.

| Class | Meaning |
|---|---|
| OBSERVED | Directly supported by code, config, logs, metrics, or documentation |
| INFERRED | Strongly supported by multiple observations but not directly proven |
| ASSUMED | Needed to continue analysis but not confirmed |
| UNKNOWN | Required information is unavailable |
| RECOMMENDED | Target-state proposal |

## Minimum evidence record

Each evidence row should include:

- evidence ID
- classification
- subject
- fact/observation
- source artifact
- source location or query reference
- observation period when relevant
- confidence
- notes

## Rules

- Do not convert missing data into guessed facts.
- If code and documentation conflict, record the contradiction.
- Runtime behavior normally outweighs stale documentation, but production policy/configuration may exist outside the repo.
- A zero-traffic sample does not prove retirement unless the sample covers the relevant business cycle and consumer evidence agrees.
- Every material target decision should cite one or more evidence IDs.
