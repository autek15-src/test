# Output Contract

The assessment directory is the canonical system of record. Markdown/CSV/OpenAPI/PlantUML should be versioned. HTML/PDF/decks are derived review artifacts.

## Minimum files

See `SKILL.md` required outputs.

## Minimum row-level completeness

### Current API inventory
One row per current externally or internally callable endpoint/event interface. Method+path+API/app should form a stable key for HTTP APIs.

### Traceability
Every current endpoint must have exactly one disposition row and a non-empty rationale/evidence reference.

### Cloud component inventory
Every component must state purpose, what it replaces/supports, rationale, and relevant security/config/observability settings.

### AWS limits
Every recommended API Gateway/Lambda/Step Functions/SQS/SNS/EventBridge/Fargate component must have applicable limit checks. Not every theoretical quota is required, but every observed workload dimension that could invalidate the design must be covered.

### Readiness
The report must contain exactly one final readiness state:
- READY
- READY WITH CONDITIONS
- NOT READY

READY is prohibited when validator ERRORs remain.
