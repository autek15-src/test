# Discovery and Current-State Analysis

## Discovery principle

Analyze the Mule application as a system. API definitions are only one source of truth.

## Inspect recursively

### Mule/runtime
- `pom.xml`, Mule runtime/plugin versions, dependencies, shared libraries
- all Mule XML flows/subflows/global configs
- HTTP listeners/requests, APIkit, autodiscovery
- DataWeave `.dwl` and inline transformations
- Java/custom modules/scripts
- object stores, schedulers, batch jobs, VM/JMS/MQ
- SFTP/FTP/File/email/SAP/Salesforce/database connectors
- scatter-gather, async, foreach, until-successful, reconnection strategies
- transactions, error handlers, retry logic
- TLS/certs/secure properties/property files/logging
- MUnit/Postman/SoapUI and test payloads
- CI/CD/deployment/runtime configs

### API management
- API Manager policies and exports
- Exchange/API documentation
- Flex Gateway policies if applicable
- client/SLA registrations where available

### Related applications
Use upstream/downstream source only to establish actual calling behavior, payloads, authentication, retries, implicit contracts, and business ownership. Do not redesign those systems unless absorbing a Mule function is recommended.

### Runtime evidence
- Splunk
- Anypoint Monitoring/API Manager analytics
- CloudHub/runtime metrics
- incidents/load tests/transaction reports

### Documentation
- HLD/LLD
- architecture and network diagrams
- interface docs/runbooks/security reviews
- ownership/deployment/release documentation

## Endpoint trace procedure

For every ingress endpoint/event/schedule trace:

1. Listener/event entry point
2. APIkit routing and validation
3. gateway/API policies
4. authentication/authorization
5. transformations
6. routing/choice logic
7. downstream calls
8. parallelism
9. transaction semantics
10. retries/reconnection
11. error handling/error translation
12. response transformations
13. logs/metrics/correlation
14. state/object-store usage
15. config/secrets

Record file/line or artifact evidence wherever possible.
