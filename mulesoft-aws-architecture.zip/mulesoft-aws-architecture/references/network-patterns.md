# Network Architecture Analysis

Build the complete request path:

`Consumer -> Enterprise Network/Ingress -> AWS Entry Point -> Compute -> Downstream`

Show only known components. Unknown enterprise ingress should be labeled `Enterprise Ingress / Reverse Proxy [TBD]`.

Consider where applicable:
- DNS/Route 53
- corporate network
- Direct Connect/VPN/Transit Gateway
- VPC endpoints/PrivateLink
- API Gateway private/regional configuration
- VPC Link
- ALB/NLB
- VPC/AZ/subnets
- Lambda VPC attachment
- ECS services/tasks
- security groups
- NAT/egress
- on-prem/SAP/database/SaaS
- Vault
- Splunk/CloudWatch telemetry path

Identify:
- inbound/outbound paths
- TLS termination
- auth/authz point
- firewall dependencies
- cross-account/region paths
- single points of failure

Never invent CIDRs, subnet IDs, routes, or corporate appliances.
