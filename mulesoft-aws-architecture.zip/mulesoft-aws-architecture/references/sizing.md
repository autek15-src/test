# Initial Sizing Guidance

Sizing from static analysis is a starting point, not a production guarantee.

Classify each setting as:
- EVIDENCE-DERIVED
- AWS-REQUIRED
- ENGINEERING-STARTING-POINT
- REQUIRES-LOAD-TEST

## Lambda
Record:
- runtime/architecture
- memory
- timeout
- ephemeral storage
- reserved/provisioned concurrency
- VPC placement
- Vault integration
- observability integration

Approximate concurrency where appropriate as `requests/sec × execution duration`, using peak or percentile evidence rather than only averages. Check downstream capacity before enabling aggressive scale.

## Fargate
Record:
- task CPU/memory
- min/max tasks
- autoscaling metric
- health check
- ALB/NLB
- ephemeral storage
- deployment strategy

## API Gateway
Record:
- REST/HTTP/private/regional choice
- authorization
- timeout
- throttling
- validation
- logging
- VPC Link/private integration
