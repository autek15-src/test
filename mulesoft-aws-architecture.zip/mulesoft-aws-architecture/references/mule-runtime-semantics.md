# Mule Runtime Semantics to Preserve or Deliberately Change

Explicitly search for behavior that is easy to lose in a rewrite.

## Routing and validation
- APIkit routing
- schema/RAML validation
- choice routers
- scatter-gather
- foreach/parallel foreach

## Transformation
- DataWeave imports/functions
- MIME/content-type changes
- binary/base64 handling
- streaming/repeatable streams
- date/time/locale coercion

## Reliability
- until-successful
- reconnection strategies
- retry scopes
- connector-specific retries
- transactions
- idempotency/object store
- JMS acknowledgement/redelivery
- batch checkpoint behavior

## State and scheduling
- object stores
- caching
- schedulers
- batch jobs
- file/SFTP polling
- distributed lock-like behavior

## Errors
- global/local error handlers
- error type matching
- continue vs propagate
- status/header/body translation

For every material semantic answer:

1. Is it used?
2. What behavior does it create?
3. Must it remain?
4. What target mechanism replaces it?
5. Is target behavior equivalent?
6. If not, is the change intentional and documented?
