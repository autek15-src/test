# Diagram Standards

Preferred source: PlantUML. Use AWS official PlantUML icons when the rendering environment provides them; otherwise keep standard PlantUML components and explicit AWS service labels.

## Target context diagram
Show:
- consumers
- application boundary
- enterprise ingress
- target AWS API/compute components
- relevant existing app components
- upstream/downstream systems
- major protocols
- trust/system boundaries

Do not show subnet-level detail.

## Target network diagram
Show:
- consumer zones/corporate network
- enterprise ingress
- VPC/AZ/subnet boundaries where relevant
- private endpoints/VPC Link
- API Gateway/ALB/NLB
- Lambda/ECS placement
- NAT/Direct Connect/VPN/TGW/PrivateLink when known
- downstream paths
- Vault and observability path
- security boundaries

Do not fabricate addressing/routing.
