# Installation and Use

This bundle is intentionally agent-agnostic. `SKILL.md` is the entry point and the rest of the directory must remain beside it so relative references and scripts resolve.

## Repository-local use

The safest enterprise pattern is to keep the skill in source control beside the migration project or in an approved internal skills repository, then configure Codex/Claude Code to load that skill directory according to the version of the agent in use.

Do not copy only `SKILL.md`; the skill depends on `references/`, `constraints/`, `templates/`, and `scripts/`.

## Direct prompt fallback

If a particular agent runtime does not support skills directly, instruct the agent to read `SKILL.md` and execute it as the governing workflow. All supporting files are plain Markdown/CSV/YAML/Python and remain usable.

## Normal execution

Give the agent:

- the MuleSoft repository;
- the desired assessment output directory;
- all available supplementary evidence locations.

The skill itself should automatically run the deterministic lifecycle. The user should not normally bootstrap or validate the assessment by hand.

The agent will invoke approximately:

```bash
python scripts/run_assessment.py prepare ./assessment \
  --source-repo /path/to/mule/repository \
  --inputs /path/to/supporting/evidence
```

After architecture analysis and artifact generation it will invoke:

```bash
python scripts/run_assessment.py validate ./assessment
```

It must remediate correctable findings and rerun validation. Once blocking findings are resolved it will invoke:

```bash
python scripts/run_assessment.py finalize ./assessment
```

## Manual/debug use

Direct calls to `bootstrap_assessment.py`, `validate_assessment.py`, and other low-level scripts remain supported for CI, troubleshooting, or skill development. They are not required for normal user operation.

## Workflow state

The controller records deterministic state under:

```text
assessment/.skill-run/state.json
```

Validation findings are written to:

```text
assessment/validation/assessment-validation.json
```

## Package self-test

```bash
python scripts/run_quality_checks.py
```
