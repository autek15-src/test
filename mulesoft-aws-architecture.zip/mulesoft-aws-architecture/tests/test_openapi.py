import subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class OpenAPITest(unittest.TestCase):
    def test_valid_minimal(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'api.yaml'; p.write_text('''openapi: 3.0.3\ninfo:\n  title: T\n  version: 1.0.0\npaths:\n  /x:\n    get:\n      operationId: getX\n      responses:\n        "200":\n          description: OK\n''')
            rc=subprocess.call([sys.executable,str(ROOT/'scripts/validate_openapi.py'),str(p)])
            self.assertEqual(rc,0)
if __name__=='__main__': unittest.main()
