from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "scripts" / "run_assessment.py"
FIXTURE = ROOT / "evals" / "fixtures" / "mule-sample"


class OrchestratorTests(unittest.TestCase):
    def test_prepare_creates_state_and_scan(self):
        with tempfile.TemporaryDirectory(prefix="mule-skill-orchestrator-") as td:
            assessment = Path(td) / "assessment"
            proc = subprocess.run(
                [
                    sys.executable,
                    str(RUN),
                    "prepare",
                    str(assessment),
                    "--source-repo",
                    str(FIXTURE),
                    "--inputs",
                    str(FIXTURE),
                ],
                capture_output=True,
                text=True,
            )
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            self.assertTrue((assessment / ".skill-run" / "state.json").exists())
            self.assertTrue((assessment / "evidence" / "mule-scan.json").exists())
            self.assertTrue((assessment / "evidence" / "input-locations.json").exists())
            state = json.loads((assessment / ".skill-run" / "state.json").read_text())
            self.assertEqual(state["last_phase"], "prepare")
            self.assertEqual(state["last_status"], "complete")

    def test_prepare_preserves_existing_assessment_content(self):
        with tempfile.TemporaryDirectory(prefix="mule-skill-orchestrator-") as td:
            assessment = Path(td) / "assessment"
            first = subprocess.run([sys.executable, str(RUN), "prepare", str(assessment)], capture_output=True, text=True)
            self.assertEqual(first.returncode, 0, first.stdout + first.stderr)
            report = assessment / "architecture-assessment.md"
            report.write_text("CUSTOM-CONTENT\n", encoding="utf-8")
            second = subprocess.run([sys.executable, str(RUN), "prepare", str(assessment)], capture_output=True, text=True)
            self.assertEqual(second.returncode, 0, second.stdout + second.stderr)
            self.assertEqual(report.read_text(encoding="utf-8"), "CUSTOM-CONTENT\n")

    def test_validate_writes_machine_readable_findings(self):
        with tempfile.TemporaryDirectory(prefix="mule-skill-orchestrator-") as td:
            assessment = Path(td) / "assessment"
            subprocess.check_call([sys.executable, str(RUN), "prepare", str(assessment)])
            proc = subprocess.run([sys.executable, str(RUN), "validate", str(assessment)], capture_output=True, text=True)
            self.assertEqual(proc.returncode, 1)
            report = assessment / "validation" / "assessment-validation.json"
            self.assertTrue(report.exists())
            data = json.loads(report.read_text(encoding="utf-8"))
            self.assertGreater(data.get("errors", 0), 0)


if __name__ == "__main__":
    unittest.main()
