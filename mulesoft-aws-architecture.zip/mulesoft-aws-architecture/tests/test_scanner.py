import json, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class ScannerTest(unittest.TestCase):
    def test_discovers_listener_retry_scheduler(self):
        fixture=ROOT/'evals/fixtures/mule-sample'
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'scan.json'
            subprocess.check_call([sys.executable,str(ROOT/'scripts/scan_mule_project.py'),str(fixture),'--json',str(out)])
            data=json.loads(out.read_text())
            types={x['type'] for x in data['mule_items']}
            self.assertIn('flow',types)
            self.assertIn('http-listener',types)
            self.assertIn('until-successful',types)
            self.assertIn('scheduler',types)
if __name__=='__main__': unittest.main()
