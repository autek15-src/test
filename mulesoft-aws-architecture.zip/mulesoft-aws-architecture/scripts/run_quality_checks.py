#!/usr/bin/env python3
"""Run unit tests, then replace this process with the architecture eval suite.

Using exec for the eval phase avoids unnecessary nested process depth because the eval
suite itself intentionally launches validators in isolated subprocesses.
"""
from __future__ import annotations
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

unit = subprocess.run(
    [sys.executable, "-m", "unittest", "discover", "-s", str(ROOT / "tests"), "-p", "test_*.py"],
    cwd=ROOT,
)
if unit.returncode:
    raise SystemExit(unit.returncode)

# Replace rather than nest the process for the eval suite.
os.execv(sys.executable, [sys.executable, str(ROOT / "evals" / "run_evals.py")])
