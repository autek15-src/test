#!/usr/bin/env python3
"""Deterministic workflow controller for the MuleSoft-to-AWS assessment skill.

This script deliberately does not perform architecture reasoning. The coding agent owns
analysis and artifact authoring. This controller owns repeatable setup, scans, validation,
rendering, report generation, and machine-readable run state.

Normal users should not need to invoke it directly. SKILL.md instructs the agent to call:

  run_assessment.py prepare  ...  # before analysis
  run_assessment.py validate ...  # during remediation loops
  run_assessment.py finalize ...  # after analysis

Exit codes:
  0 = requested deterministic phase completed without blocking validation errors
  1 = assessment validation contains ERROR findings
  2 = controller/runtime/tooling error
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def run(cmd: list[str], cwd: Path | None = None, required: bool = True) -> int:
    print("+", " ".join(str(x) for x in cmd))
    proc = subprocess.run(cmd, cwd=cwd or ROOT)
    if required and proc.returncode:
        raise RuntimeError(f"Command failed with exit code {proc.returncode}: {' '.join(map(str, cmd))}")
    return proc.returncode


def state_path(assessment: Path) -> Path:
    return assessment / ".skill-run" / "state.json"


def load_state(assessment: Path) -> dict:
    p = state_path(assessment)
    if not p.exists():
        return {"schema_version": 1, "created_at": now_iso(), "history": []}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {"schema_version": 1, "created_at": now_iso(), "history": []}


def save_state(assessment: Path, state: dict) -> None:
    p = state_path(assessment)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")


def record(assessment: Path, phase: str, status: str, **extra) -> None:
    state = load_state(assessment)
    state["last_phase"] = phase
    state["last_status"] = status
    state["updated_at"] = now_iso()
    state.update({k: v for k, v in extra.items() if v is not None})
    state.setdefault("history", []).append({"time": now_iso(), "phase": phase, "status": status})
    save_state(assessment, state)


def inventory_inputs(assessment: Path, source_repo: Path | None, inputs: list[Path]) -> None:
    data = {
        "generated_at": now_iso(),
        "source_repo": str(source_repo.resolve()) if source_repo else None,
        "supplementary_inputs": [],
    }
    for p in inputs:
        item = {"path": str(p.resolve()), "exists": p.exists(), "kind": "directory" if p.is_dir() else "file"}
        if p.exists() and p.is_dir():
            try:
                item["file_count"] = sum(1 for x in p.rglob("*") if x.is_file())
            except Exception:
                pass
        data["supplementary_inputs"].append(item)
    out = assessment / "evidence" / "input-locations.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def prepare(args: argparse.Namespace) -> int:
    assessment = args.assessment.resolve()
    existed = assessment.exists() and any(assessment.iterdir()) if assessment.exists() else False

    # Bootstrap only fills missing templates unless --force-bootstrap is explicitly requested.
    cmd = [sys.executable, str(SCRIPTS / "bootstrap_assessment.py"), str(assessment)]
    if args.force_bootstrap:
        cmd.append("--force")
    run(cmd)

    (assessment / "validation").mkdir(parents=True, exist_ok=True)
    inventory_inputs(assessment, args.source_repo, args.inputs)

    if args.source_repo:
        scan_json = assessment / "evidence" / "mule-scan.json"
        source_csv = assessment / "evidence" / "source-inventory.csv"
        should_scan = args.rescan or not scan_json.exists() or not existed
        if should_scan:
            run([
                sys.executable,
                str(SCRIPTS / "scan_mule_project.py"),
                str(args.source_repo.resolve()),
                "--csv", str(source_csv),
                "--json", str(scan_json),
            ])
        else:
            print("Source scan already exists; preserving it. Use --rescan to refresh.")

    record(
        assessment,
        "prepare",
        "complete",
        source_repo=str(args.source_repo.resolve()) if args.source_repo else None,
        assessment_dir=str(assessment),
    )
    print(f"Prepared assessment workspace: {assessment}")
    print("Agent handoff: perform evidence-driven architecture analysis and populate canonical artifacts before validation.")
    return 0


def target_openapi_has_content(path: Path) -> bool:
    if not path.exists() or path.stat().st_size == 0:
        return False
    text = path.read_text(encoding="utf-8", errors="replace")
    # The bootstrap template can exist even when no REST API remains. Only validate when it appears populated.
    if "[TBD]" in text:
        return False
    import re
    return bool(re.search(r"(?m)^\s{2}/[^:]+:\s*$", text))


def validate_phase(args: argparse.Namespace) -> int:
    assessment = args.assessment.resolve()
    if not assessment.exists():
        print(f"ERROR: assessment directory does not exist: {assessment}")
        return 2

    openapi = assessment / "target-state" / "target-openapi.yaml"
    if target_openapi_has_content(openapi):
        rc = run([sys.executable, str(SCRIPTS / "validate_openapi.py"), str(openapi)], required=False)
        if rc:
            record(assessment, "validate", "openapi-failed")
            return 1
    else:
        print("OpenAPI validation skipped: no populated REST target OpenAPI detected.")

    validation_json = assessment / "validation" / "assessment-validation.json"
    cmd = [
        sys.executable,
        str(SCRIPTS / "validate_assessment.py"),
        str(assessment),
        "--json", str(validation_json),
    ]
    if args.strict_warnings:
        cmd.append("--strict-warnings")
    rc = run(cmd, required=False)
    record(assessment, "validate", "passed" if rc == 0 else "failed", validation_report=str(validation_json))
    return 0 if rc == 0 else 1


def finalize(args: argparse.Namespace) -> int:
    assessment = args.assessment.resolve()

    # Validate before generating derivative artifacts so obvious problems feed back to the agent first.
    rc = validate_phase(args)
    if rc:
        print("Finalization stopped because assessment validation has blocking findings.")
        print("Agent action: read validation/assessment-validation.json, remediate everything supported by available evidence, then validate again.")
        record(assessment, "finalize", "blocked-by-validation")
        return 1

    # Rendered diagrams are useful but not canonical. Missing local PlantUML is non-blocking.
    if not args.skip_render:
        render_cmd = [sys.executable, str(SCRIPTS / "render_diagrams.py"), str(assessment / "diagrams"), "--format", args.diagram_format]
        if args.plantuml_jar:
            render_cmd += ["--plantuml-jar", str(args.plantuml_jar)]
        render_rc = run(render_cmd, required=False)
        if render_rc:
            print("WARN: diagram rendering was unavailable or failed; editable .puml sources remain canonical.")

    html_out = assessment / "architecture-assessment.html"
    run([
        sys.executable,
        str(SCRIPTS / "build_html_report.py"),
        str(assessment),
        "--output", str(html_out),
    ])

    # Re-run the canonical gate after derivative artifact generation.
    rc = validate_phase(args)
    if rc:
        record(assessment, "finalize", "failed-after-build")
        return 1

    record(assessment, "finalize", "complete", html_report=str(html_out))
    print(f"Finalized assessment: {assessment}")
    print(f"Review report: {html_out}")
    return 0


def status(args: argparse.Namespace) -> int:
    assessment = args.assessment.resolve()
    state = load_state(assessment)
    print(json.dumps(state, indent=2))
    report = assessment / "validation" / "assessment-validation.json"
    if report.exists():
        try:
            v = json.loads(report.read_text(encoding="utf-8"))
            print(f"Validation: {v.get('errors', '?')} error(s), {v.get('warnings', '?')} warning(s)")
        except Exception:
            pass
    return 0


def parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="command", required=True)

    def common(p: argparse.ArgumentParser) -> None:
        p.add_argument("assessment", type=Path, help="Assessment output directory")

    p = sub.add_parser("prepare", help="Initialize/preserve workspace, record inputs, and seed source scan")
    common(p)
    p.add_argument("--source-repo", type=Path, help="MuleSoft source repository root")
    p.add_argument("--inputs", type=Path, action="append", default=[], help="Supplementary evidence file/directory; repeatable")
    p.add_argument("--rescan", action="store_true", help="Refresh Mule source scan even when one already exists")
    p.add_argument("--force-bootstrap", action="store_true", help="Overwrite canonical templates; normally avoid on continuation runs")
    p.set_defaults(func=prepare)

    p = sub.add_parser("validate", help="Run OpenAPI and assessment completion gates")
    common(p)
    p.add_argument("--strict-warnings", action="store_true")
    p.set_defaults(func=validate_phase)

    p = sub.add_parser("finalize", help="Validate, render optional diagrams, build HTML, and revalidate")
    common(p)
    p.add_argument("--strict-warnings", action="store_true")
    p.add_argument("--skip-render", action="store_true", help="Skip optional PlantUML rendering")
    p.add_argument("--diagram-format", choices=["svg", "png"], default="svg")
    p.add_argument("--plantuml-jar", type=Path)
    p.set_defaults(func=finalize)

    p = sub.add_parser("status", help="Show deterministic workflow/validation state")
    common(p)
    p.set_defaults(func=status)
    return ap


def main() -> int:
    args = parser().parse_args()
    try:
        return int(args.func(args))
    except RuntimeError as exc:
        print(f"ERROR: {exc}")
        try:
            record(args.assessment.resolve(), args.command, "runtime-error")
        except Exception:
            pass
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
