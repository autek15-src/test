#!/usr/bin/env python3
"""Heuristically inventory a Mule repository without external dependencies.

This seeds discovery; it does not replace human/agent semantic analysis.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, re
from pathlib import Path
import xml.etree.ElementTree as ET

INTERESTING_EXT = {'.xml','.dwl','.raml','.yaml','.yml','.json','.java','.groovy','.properties','.conf','.md','.txt','.wsdl','.xsd','.feature'}
SPECIAL_NAMES = {'pom.xml','mule-artifact.json','Dockerfile','Jenkinsfile','azure-pipelines.yml','buildspec.yml'}
IGNORE_DIRS = {'.git','.idea','.vscode','target','node_modules','.mvn/wrapper'}

def lname(tag: str) -> str:
    return tag.rsplit('}',1)[-1] if '}' in tag else tag.split(':')[-1]

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def kind(path: Path) -> str:
    n=path.name.lower(); s=path.suffix.lower()
    if n=='pom.xml': return 'Maven POM'
    if n=='mule-artifact.json': return 'Mule artifact descriptor'
    if s=='.dwl': return 'DataWeave'
    if s=='.raml': return 'RAML'
    if s in {'.yaml','.yml'} and ('openapi' in n or 'swagger' in n): return 'OpenAPI/YAML'
    if s=='.wsdl': return 'WSDL'
    if s=='.java': return 'Java source'
    if s=='.properties': return 'Properties/config'
    if s=='.xml': return 'XML/Mule candidate'
    return 'Supporting source/document'

def safe_text(path: Path, limit=4_000_000) -> str:
    try:
        if path.stat().st_size>limit: return ''
        return path.read_text(encoding='utf-8', errors='replace')
    except OSError: return ''

def parse_mule_xml(path: Path):
    items=[]
    try: root=ET.parse(path).getroot()
    except Exception: return items
    flow_stack=[]
    for el in root.iter():
        ln=lname(el.tag)
        if ln in {'flow','sub-flow'}:
            flow_stack.append(el.attrib.get('name',''))
            flow_name=el.attrib.get('name','')
            items.append({'type':ln,'name':flow_name,'file':str(path)})
            for child in el.iter():
                c=lname(child.tag)
                a=child.attrib
                if c in {'listener','request'}:
                    items.append({'type':f'http-{c}','flow':flow_name,'method':a.get('method',''), 'path':a.get('path',''), 'config_ref':a.get('config-ref',''), 'file':str(path)})
                elif c in {'scheduler','fixed-frequency','cron'}:
                    items.append({'type':'scheduler','flow':flow_name,'name':a.get('name',''), 'expression':a.get('expression',a.get('frequency','')), 'file':str(path)})
                elif c in {'flow-ref'}:
                    items.append({'type':'flow-ref','flow':flow_name,'target':a.get('name',''), 'file':str(path)})
                elif c in {'until-successful','scatter-gather','parallel-foreach','foreach','async','batch-job','try','choice'}:
                    items.append({'type':c,'flow':flow_name,'file':str(path)})
                elif 'error-handler' in c or c.startswith('on-error'):
                    items.append({'type':c,'flow':flow_name,'error_type':a.get('type',''), 'file':str(path)})
                elif c in {'transform','set-payload','set-variable'}:
                    items.append({'type':'transformation','subtype':c,'flow':flow_name,'file':str(path)})
                elif c in {'jms','publish','consume','listener-source','sftp','ftp','db','select','insert','update','delete','sap'}:
                    items.append({'type':'connector-operation','operation':c,'flow':flow_name,'file':str(path)})
        elif ln in {'apikit:config','config'} and ('raml' in str(el.attrib).lower() or 'api' in str(el.attrib).lower()):
            items.append({'type':'api-config','attributes':el.attrib,'file':str(path)})
    return items

def extract_runtime(text: str):
    vals={}
    m=re.search(r'<mule\.runtime\.version>([^<]+)', text)
    if m: vals['mule_runtime_version']=m.group(1).strip()
    deps=re.findall(r'<artifactId>([^<]+)</artifactId>', text)
    if deps: vals['artifact_ids']=sorted(set(d.strip() for d in deps))
    return vals

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument('repo', type=Path)
    ap.add_argument('--csv', type=Path)
    ap.add_argument('--json', type=Path)
    args=ap.parse_args()
    repo=args.repo.resolve()
    files=[]; mule_items=[]; metadata={}
    for p in sorted(repo.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(repo)
        if any(part in IGNORE_DIRS for part in rel.parts): continue
        if p.suffix.lower() not in INTERESTING_EXT and p.name not in SPECIAL_NAMES: continue
        text=safe_text(p)
        k=kind(p)
        relevance=[]
        low=text.lower()
        for token,label in [('apikit','APIkit'),('dataweave','DataWeave'),('http:listener','HTTP listener'),('until-successful','retry'),('scatter-gather','parallelism'),('object-store','object store'),('scheduler','scheduler'),('munit','MUnit'),('autodiscovery','API autodiscovery'),('sap','SAP'),('jms','JMS')]:
            if token in low: relevance.append(label)
        row={
            'source_id':f'SRC-{len(files)+1:04d}', 'source_type':k, 'path_or_name':str(rel), 'scope':'repository',
            'relevance':'; '.join(relevance), 'modified_date':'', 'review_status':'UNREVIEWED',
            'notes':f'size={p.stat().st_size}; sha256={sha256(p)[:16]}'
        }
        files.append(row)
        if p.name=='pom.xml': metadata.update(extract_runtime(text))
        if p.suffix.lower()=='.xml':
            mule_items.extend(parse_mule_xml(p))
    result={'repository':str(repo),'metadata':metadata,'file_count':len(files),'files':files,'mule_items':mule_items}
    if args.csv:
        args.csv.parent.mkdir(parents=True,exist_ok=True)
        with args.csv.open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=['source_id','source_type','path_or_name','scope','relevance','modified_date','review_status','notes']); w.writeheader(); w.writerows(files)
    if args.json:
        args.json.parent.mkdir(parents=True,exist_ok=True); args.json.write_text(json.dumps(result,indent=2),encoding='utf-8')
    if not args.csv and not args.json: print(json.dumps(result,indent=2))
    print(f"Scanned {len(files)} relevant files; discovered {len(mule_items)} Mule structural items.")
    return 0
if __name__=='__main__': raise SystemExit(main())
