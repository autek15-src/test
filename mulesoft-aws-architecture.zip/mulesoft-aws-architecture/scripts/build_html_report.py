#!/usr/bin/env python3
"""Build a self-contained architect-review HTML file from canonical assessment artifacts."""
from __future__ import annotations
import argparse, csv, html, re
from pathlib import Path

def md_to_html(text):
    out=[]; in_code=False; in_ul=False
    for line in text.splitlines():
        if line.startswith('```'):
            if in_ul: out.append('</ul>'); in_ul=False
            out.append('</code></pre>' if in_code else '<pre><code>'); in_code=not in_code; continue
        if in_code: out.append(html.escape(line)); continue
        m=re.match(r'^(#{1,6})\s+(.*)',line)
        if m:
            if in_ul: out.append('</ul>'); in_ul=False
            n=len(m.group(1)); out.append(f'<h{n}>{html.escape(m.group(2))}</h{n}>'); continue
        if line.startswith('- '):
            if not in_ul: out.append('<ul>'); in_ul=True
            out.append(f'<li>{html.escape(line[2:])}</li>'); continue
        if in_ul: out.append('</ul>'); in_ul=False
        if line.strip(): out.append(f'<p>{html.escape(line)}</p>')
    if in_ul: out.append('</ul>')
    if in_code: out.append('</code></pre>')
    return '\n'.join(out)

def csv_html(path):
    with path.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.reader(f))
    if not rows:return '<p>Empty CSV</p>'
    b=['<div class="table-wrap"><table><thead><tr>']+[f'<th>{html.escape(x)}</th>' for x in rows[0]]+['</tr></thead><tbody>']
    for row in rows[1:]: b+=['<tr>']+[f'<td>{html.escape(x)}</td>' for x in row]+['</tr>']
    b+=['</tbody></table></div>']; return ''.join(b)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('assessment',type=Path); ap.add_argument('--output',type=Path,required=True); args=ap.parse_args()
    root=args.assessment
    sections=[]
    priority=['executive-summary.md','architecture-assessment.md','assumptions-risks-open-questions.md','options/architecture-options.md','testing/migration-test-strategy.md','migration/migration-cutover-plan.md']
    for rel in priority:
        p=root/rel
        if p.exists(): sections.append(md_to_html(p.read_text(encoding='utf-8')))
    for p in sorted(root.rglob('*.csv')):
        sections.append(f'<h2>{html.escape(str(p.relative_to(root)))}</h2>'+csv_html(p))
    css='''body{font-family:Arial,sans-serif;max-width:1500px;margin:32px auto;padding:0 24px;color:#1f2937;line-height:1.45}h1,h2,h3{color:#111827}table{border-collapse:collapse;font-size:12px}th,td{border:1px solid #d1d5db;padding:6px;vertical-align:top}th{background:#f3f4f6;position:sticky;top:0}.table-wrap{overflow:auto;max-height:650px;margin-bottom:28px}pre{background:#f6f8fa;padding:12px;overflow:auto}'''
    doc='<!doctype html><html><head><meta charset="utf-8"><title>MuleSoft AWS Architecture Assessment</title><style>'+css+'</style></head><body>'+''.join(sections)+'</body></html>'
    args.output.write_text(doc,encoding='utf-8'); print(f'Wrote {args.output}')
if __name__=='__main__': main()
