#!/usr/bin/env python3
"""Run self-tests and create a distributable zip of the skill."""
from __future__ import annotations
import argparse, hashlib, subprocess, sys, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('--output',type=Path,default=ROOT.parent/(ROOT.name+'.zip')); ap.add_argument('--skip-tests',action='store_true'); args=ap.parse_args()
    if not args.skip_tests:
        rc=subprocess.call([sys.executable,str(ROOT/'scripts/run_quality_checks.py')],cwd=ROOT)
        if rc:return rc
    excluded={'__pycache__','.DS_Store'}
    files=[p for p in ROOT.rglob('*') if p.is_file() and not any(x in excluded for x in p.parts) and p.suffix!='.pyc']
    manifest=[]
    for p in files:
        h=hashlib.sha256(p.read_bytes()).hexdigest(); manifest.append(f'{h}  {p.relative_to(ROOT)}')
    (ROOT/'MANIFEST.sha256').write_text('\n'.join(manifest)+'\n',encoding='utf-8')
    files=[p for p in ROOT.rglob('*') if p.is_file() and not any(x in excluded for x in p.parts) and p.suffix!='.pyc']
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(args.output,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files:z.write(p,Path(ROOT.name)/p.relative_to(ROOT))
    print(f'Created {args.output} with {len(files)} files')
    return 0
if __name__=='__main__': raise SystemExit(main())
