#!/usr/bin/env python3
"""Lightweight OpenAPI structural validator; uses PyYAML when available."""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path
HTTP={'get','put','post','delete','options','head','patch','trace'}

def load(path:Path):
    txt=path.read_text(encoding='utf-8')
    if path.suffix.lower()=='.json': return json.loads(txt)
    try:
        import yaml  # type: ignore
        return yaml.safe_load(txt)
    except Exception:
        # Minimal line-oriented fallback for common OpenAPI files.
        data={'_raw':txt}
        m=re.search(r'^openapi:\s*([^\s#]+)',txt,re.M); data['openapi']=m.group(1) if m else None
        data['has_info']=bool(re.search(r'^info:\s*$',txt,re.M)); data['has_paths']=bool(re.search(r'^paths:\s*',txt,re.M))
        paths={}; current=None
        for line in txt.splitlines():
            m=re.match(r'^\s{2}(/[^:]+):\s*$',line)
            if m: current=m.group(1); paths[current]=set(); continue
            m=re.match(r'^\s{4}([a-zA-Z]+):\s*$',line)
            if current and m and m.group(1).lower() in HTTP: paths[current].add(m.group(1).lower())
        data['_paths_fallback']=paths
        return data

def main()->int:
    p=argparse.ArgumentParser(); p.add_argument('openapi',type=Path); args=p.parse_args()
    errors=[]; warns=[]
    try:data=load(args.openapi)
    except Exception as e: print(f'ERROR: cannot parse: {e}'); return 2
    ver=data.get('openapi') if isinstance(data,dict) else None
    if not ver or not str(ver).startswith('3.'): errors.append('Missing/unsupported openapi version; expected OpenAPI 3.x.')
    if '_raw' in data:
        if not data.get('has_info'): errors.append('Missing info section.')
        if not data.get('has_paths'): errors.append('Missing paths section.')
        paths=data.get('_paths_fallback',{})
        if not paths: warns.append('No HTTP operations detected in paths.')
    else:
        if not isinstance(data.get('info'),dict): errors.append('Missing info object.')
        paths=data.get('paths');
        if not isinstance(paths,dict): errors.append('Missing paths object.'); paths={}
        opids={}
        for path,item in paths.items():
            if not str(path).startswith('/'): errors.append(f'Path does not start with /: {path}')
            if not isinstance(item,dict): continue
            for method,op in item.items():
                if method.lower() not in HTTP: continue
                if not isinstance(op,dict): errors.append(f'{method.upper()} {path}: operation must be object'); continue
                oid=op.get('operationId')
                if not oid: warns.append(f'{method.upper()} {path}: missing operationId')
                elif oid in opids: errors.append(f'Duplicate operationId {oid}: {opids[oid]} and {method.upper()} {path}')
                else: opids[oid]=f'{method.upper()} {path}'
                responses=op.get('responses')
                if not isinstance(responses,dict) or not responses: errors.append(f'{method.upper()} {path}: missing responses')
    for e in errors: print('ERROR:',e)
    for w in warns: print('WARN:',w)
    print(f'OpenAPI validation: {len(errors)} error(s), {len(warns)} warning(s)')
    return 1 if errors else 0
if __name__=='__main__': raise SystemExit(main())
