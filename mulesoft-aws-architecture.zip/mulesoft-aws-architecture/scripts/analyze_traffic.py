#!/usr/bin/env python3
"""Create per-endpoint traffic statistics from a normalized CSV export."""
from __future__ import annotations
import argparse, csv, math
from collections import defaultdict
from datetime import datetime
from pathlib import Path

def num(v):
    try:return float(v)
    except:return None

def pct(vals,p):
    vals=sorted(v for v in vals if v is not None)
    if not vals:return ''
    if len(vals)==1:return vals[0]
    k=(len(vals)-1)*p; f=math.floor(k); c=math.ceil(k)
    return vals[f] if f==c else vals[f]*(c-k)+vals[c]*(k-f)

def main():
    a=argparse.ArgumentParser()
    a.add_argument('input',type=Path); a.add_argument('--output',type=Path,required=True)
    a.add_argument('--endpoint-col',default='endpoint_id'); a.add_argument('--timestamp-col',default='timestamp')
    a.add_argument('--latency-col',default='latency_ms'); a.add_argument('--request-bytes-col',default='request_bytes'); a.add_argument('--response-bytes-col',default='response_bytes')
    a.add_argument('--status-col',default='status'); a.add_argument('--timeout-col',default='timeout')
    args=a.parse_args()
    groups=defaultdict(list)
    with args.input.open(encoding='utf-8-sig',newline='') as f:
        for r in csv.DictReader(f): groups[r.get(args.endpoint_col,'UNKNOWN')].append(r)
    headers=['endpoint_id','observation_start','observation_end','request_count','calls_per_day','average_tps','peak_tps_1min','latency_p50_ms','latency_p90_ms','latency_p95_ms','latency_p99_ms','latency_max_ms','request_payload_p50_bytes','request_payload_p95_bytes','request_payload_p99_bytes','request_payload_max_bytes','response_payload_p50_bytes','response_payload_p95_bytes','response_payload_p99_bytes','response_payload_max_bytes','http_2xx','http_4xx','http_5xx','timeouts','error_rate_pct']
    out=[]
    for eid,rows in groups.items():
        timestamps=[]; minute=defaultdict(int)
        for r in rows:
            raw=r.get(args.timestamp_col,'')
            try:
                dt=datetime.fromisoformat(raw.replace('Z','+00:00')); timestamps.append(dt); minute[dt.replace(second=0,microsecond=0)]+=1
            except:pass
        start=min(timestamps).isoformat() if timestamps else ''; end=max(timestamps).isoformat() if timestamps else ''
        duration=(max(timestamps)-min(timestamps)).total_seconds() if len(timestamps)>1 else 0
        days=max(duration/86400,1) if duration else 1
        latency=[num(r.get(args.latency_col)) for r in rows]; req=[num(r.get(args.request_bytes_col)) for r in rows]; resp=[num(r.get(args.response_bytes_col)) for r in rows]
        statuses=[str(r.get(args.status_col,'')) for r in rows]
        c2=sum(s.startswith('2') for s in statuses); c4=sum(s.startswith('4') for s in statuses); c5=sum(s.startswith('5') for s in statuses)
        tout=sum(str(r.get(args.timeout_col,'')).lower() in {'1','true','yes','timeout'} for r in rows)
        errors=c4+c5+tout
        out.append({'endpoint_id':eid,'observation_start':start,'observation_end':end,'request_count':len(rows),'calls_per_day':round(len(rows)/days,3),'average_tps':round(len(rows)/duration,6) if duration else '', 'peak_tps_1min':round(max(minute.values())/60,6) if minute else '',
        'latency_p50_ms':pct(latency,.5),'latency_p90_ms':pct(latency,.9),'latency_p95_ms':pct(latency,.95),'latency_p99_ms':pct(latency,.99),'latency_max_ms':max([x for x in latency if x is not None],default=''),
        'request_payload_p50_bytes':pct(req,.5),'request_payload_p95_bytes':pct(req,.95),'request_payload_p99_bytes':pct(req,.99),'request_payload_max_bytes':max([x for x in req if x is not None],default=''),
        'response_payload_p50_bytes':pct(resp,.5),'response_payload_p95_bytes':pct(resp,.95),'response_payload_p99_bytes':pct(resp,.99),'response_payload_max_bytes':max([x for x in resp if x is not None],default=''),
        'http_2xx':c2,'http_4xx':c4,'http_5xx':c5,'timeouts':tout,'error_rate_pct':round(errors*100/len(rows),3) if rows else 0})
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=headers); w.writeheader(); w.writerows(out)
    print(f"Wrote {len(out)} endpoint profiles to {args.output}")
if __name__=='__main__': main()
