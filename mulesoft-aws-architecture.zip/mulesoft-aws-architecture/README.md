# MuleSoft to AWS Native Architecture Skill

Reusable Codex/Claude-compatible skill package for evidence-driven analysis of MuleSoft applications targeted for AWS-native migration.

## What it does

The skill analyzes the complete application boundary, not just RAML/OpenAPI. It is designed to inspect Mule XML, DataWeave, policies, Maven/configuration, tests, runtime evidence, traffic data, application/source dependencies, diagrams, and supporting documentation. It then rationalizes the Mule estate and proposes AWS-native replacement architecture only for Mule-owned capabilities.

Primary decision outcomes are RETIRE, CONSOLIDATE, ABSORB, or REIMPLEMENT.

## v1.1 automated lifecycle

The normal user does **not** need to run bootstrap or validation scripts by hand.

When the skill is invoked, the agent is instructed to automatically execute this lifecycle:

```text
preflight
  -> run_assessment.py prepare
  -> evidence discovery + architecture reasoning
  -> canonical artifact generation
  -> run_assessment.py validate
  -> agent remediation loop
  -> run_assessment.py finalize
  -> final validation
  -> READY / READY WITH CONDITIONS / NOT READY
```

The Python controller handles deterministic workflow mechanics. The coding agent still owns all architectural reasoning and must never bypass the validator to force a passing result.

## Package layout

```text
mulesoft-aws-architecture-skill/
├── SKILL.md
├── README.md
├── CHANGELOG.md
├── constraints/
├── references/
├── templates/
├── scripts/
│   ├── run_assessment.py        # normal deterministic lifecycle controller
│   ├── bootstrap_assessment.py # lower-level/manual/debug entry point
│   ├── scan_mule_project.py
│   ├── analyze_traffic.py
│   ├── validate_openapi.py
│   ├── validate_assessment.py
│   ├── render_diagrams.py
│   └── build_html_report.py
├── evals/
└── tests/
```

## Normal use with Codex/Claude

1. Install or reference the complete skill directory.
2. Give the agent the Mule repository and available supporting evidence.
3. Ask it to perform the MuleSoft-to-AWS architecture assessment.
4. The agent follows `SKILL.md`, automatically runs prepare/validation/finalization, remediates correctable findings, and returns the final readiness status.

Example user request:

```text
Analyze ./orders-mule for migration to AWS-native services.
Supporting Splunk exports, API Manager policy exports, network diagrams,
and downstream source are under ./migration-inputs.
Create the assessment under ./assessment.
```

The user should not need to invoke scripts manually for this normal flow.

## Deterministic controller

For developers, CI, debugging, or agent execution, the lifecycle controller provides:

```bash
python scripts/run_assessment.py prepare ./assessment \
  --source-repo ./orders-mule \
  --inputs ./migration-inputs

python scripts/run_assessment.py validate ./assessment

python scripts/run_assessment.py finalize ./assessment

python scripts/run_assessment.py status ./assessment
```

`validate` writes machine-readable findings to:

```text
assessment/validation/assessment-validation.json
```

The skill directs the agent to read these findings, repair everything supported by available evidence, and rerun validation until the assessment passes or remaining issues are genuine blockers.

## Lower-level/manual scripts

The original modular utilities remain intentionally available for development and CI. They are no longer the standard user-facing workflow.

## No required Python dependencies

The scripts use the Python standard library. YAML validation is intentionally lightweight. If PyYAML is installed, `validate_openapi.py` uses it; otherwise it performs structural checks using a built-in fallback.

PlantUML rendering is optional. Editable `.puml` source is canonical; `run_assessment.py finalize` warns rather than fails solely because a local PlantUML executable/JAR is unavailable.

## Important limitation

The scripts cannot prove architectural correctness. In particular, `aws-limit-validation.csv` must be populated from current official AWS documentation during each assessment. The validator checks that this evidence exists and that measured requirements fit the recorded limits.

## Optional derived artifacts

The package also includes templates for current-state diagrams, directional cost estimates, and a Permit-to-Build deck outline. These are derived/supporting artifacts; the Markdown/CSV/OpenAPI/PlantUML assessment remains the canonical engineering record.

## Package self-test

```bash
python scripts/run_quality_checks.py
```
