# Optional Permit-to-Build Deck Outline

This is a derived presentation, not the canonical system of record.

1. Title / decision requested
2. Executive summary and recommendation
3. Scope and migration boundary
4. Current-state context architecture
5. Current-state network architecture
6. Current-state API inventory summary
7. Traffic / latency / payload evidence
8. Current security and API policies
9. Rationalization: retire / consolidate / absorb / reimplement
10. Target-state context architecture
11. Target-state network architecture
12. Target API inventory
13. Target AWS cloud component inventory
14. Compute sizing and service settings
15. AWS hard-limit fit / headroom
16. Security and secrets design
17. Observability: CloudWatch + Splunk
18. Resilience / retries / idempotency
19. Architecture alternatives and recommendation
20. Cost considerations
21. Test and equivalence strategy
22. Migration / cutover / rollback
23. Risks, assumptions, open questions
24. ADR summary
25. Permit-to-Build readiness and conditions
