# ADR-XXX: Decision Title

- **Status:** Proposed
- **Date:** YYYY-MM-DD
- **Decision owner:** TBD

## Context

## Evidence

## Decision

## Alternatives Considered

## Consequences

### Positive

### Negative

## Risks

## Validation / Follow-up
