# Assumptions, Risks, and Open Questions

## Assumptions

| ID | Severity | Assumption | Evidence/Reason | Validation Owner | Due/Phase | Status |
|---|---|---|---|---|---|---|

## Risks

| ID | Severity | Risk | Impact | Evidence | Mitigation | Owner | Status |
|---|---|---|---|---|---|---|---|

## Open Questions

| ID | Severity | Question | Why It Matters | Evidence Needed | Owner | Status |
|---|---|---|---|---|---|---|
