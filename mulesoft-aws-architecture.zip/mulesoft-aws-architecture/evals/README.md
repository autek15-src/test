# Evaluation Scenarios

`run_evals.py` regression-tests the completion validator against representative migration assessment failure modes.

Scenarios include:

- complete private API Gateway + Lambda assessment passes
- current endpoint missing from traceability
- AWS hard-limit failure
- direct external/public API Gateway exposure
- prohibited Secrets Manager use
- unknown security-critical API policy
- empty target OpenAPI contract
- duplicate endpoint disposition

Run:

```bash
python evals/run_evals.py
```
