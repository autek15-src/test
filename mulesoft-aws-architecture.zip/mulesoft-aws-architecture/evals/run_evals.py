#!/usr/bin/env python3
from __future__ import annotations

import csv
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOOT = ROOT / 'scripts/bootstrap_assessment.py'
sys.path.insert(0, str(ROOT / 'scripts'))
import validate_assessment as validator  # type: ignore


def rows(path, headers, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        w.writerows(data)


def write_csv(path, data):
    with path.open(encoding='utf-8-sig', newline='') as f:
        headers = next(csv.reader(f))
    rows(path, headers, data)


def make_base(root: Path):
    subprocess.check_call([sys.executable, str(BOOT), str(root)])
    write_csv(root/'evidence/evidence-register.csv',[{'evidence_id':'EV-001','classification':'OBSERVED','subject':'GET /orders/{id}','observation':'Endpoint found in Mule flow','source_artifact':'orders.xml','source_location':'get-order-flow','confidence':'HIGH'}])
    write_csv(root/'current-state/api-inventory.csv',[{'endpoint_id':'EP-001','application':'orders-mule','api':'Orders','api_layer':'System','method':'GET','resource':'/orders/{id}','protocol':'REST','purpose':'Get order','authentication':'client credential','evidence_refs':'EV-001'}])
    write_csv(root/'current-state/policy-inventory.csv',[{'policy_id':'POL-001','api_or_endpoint':'EP-001','policy_type':'JWT','configuration_summary':'JWT validation','enforcement_location':'API Manager','security_critical':'true','status':'CONFIRMED','evidence_refs':'EV-001','target_mapping':'API authorizer'}])
    write_csv(root/'current-state/traffic-profile.csv',[{'endpoint_id':'EP-001','environment':'PROD','observation_start':'2026-07-01','observation_end':'2026-07-31','request_count':'1000','calls_per_day':'32','average_tps':'0.1','peak_tps':'2','latency_p50_ms':'300','latency_p95_ms':'700','latency_p99_ms':'900','latency_max_ms':'1000','request_payload_p95_bytes':'1000','request_payload_max_bytes':'2000','response_payload_p95_bytes':'5000','response_payload_max_bytes':'10000','http_2xx':'995','http_4xx':'4','http_5xx':'1','timeouts':'0','error_rate_pct':'0.5'}])
    write_csv(root/'target-state/traceability-matrix.csv',[{'current_endpoint_id':'EP-001','current_application':'orders-mule','current_api':'Orders','current_method':'GET','current_resource':'/orders/{id}','disposition':'REPLACED BY','target_component_or_endpoint':'TEP-001','rationale':'Independent low-latency API remains required','evidence_refs':'EV-001','approval_status':'PROPOSED'}])
    write_csv(root/'target-state/target-api-inventory.csv',[{'target_endpoint_id':'TEP-001','target_service':'orders-api','target_api':'Orders','method':'GET','path':'/orders/{id}','protocol':'REST','contract_disposition':'unchanged','authentication':'JWT','authorization':'claims','network_exposure':'Private via Enterprise Ingress','gateway':'Private API Gateway','compute':'Lambda','target_timeout_ms':'5000','current_endpoint_ids':'EP-001','rationale':'Measured workload fits request/response function pattern','evidence_refs':'EV-001'}])
    write_csv(root/'target-state/cloud-component-inventory.csv',[
        {'component_id':'CMP-API','aws_service':'API Gateway','logical_name':'orders-private-api','purpose':'Private API entry','replaces_or_supports':'Mule API listener/policy path','rationale':'API contract and enterprise ingress boundary','network_placement':'Private via Enterprise Ingress','secrets_mechanism':'HashiCorp Vault','logging':'CloudWatch -> Splunk','metrics':'CloudWatch/Splunk','validation_required':'yes'},
        {'component_id':'CMP-FN','aws_service':'Lambda','logical_name':'get-order','purpose':'Execute order integration','replaces_or_supports':'get-order-flow','rationale':'Short-lived stateless workload','memory_mb':'512','timeout_ms':'5000','secrets_mechanism':'HashiCorp Vault','logging':'CloudWatch -> Splunk','metrics':'CloudWatch/Splunk','validation_required':'yes'}])
    write_csv(root/'target-state/compute-sizing.csv',[
        {'component_id':'CMP-FN','setting':'memory','value':'512','unit':'MB','classification':'ENGINEERING-STARTING-POINT','evidence_or_reason':'Low-latency stateless API starting point','load_test_required':'yes'},
        {'component_id':'CMP-FN','setting':'timeout','value':'5000','unit':'ms','classification':'EVIDENCE-DERIVED','evidence_or_reason':'Above observed duration with bounded headroom','load_test_required':'yes'}])
    write_csv(root/'target-state/security-policy-mapping.csv',[{'current_policy_id':'POL-001','current_api_or_endpoint':'EP-001','current_control':'JWT validation','target_control':'JWT authorizer','target_component':'CMP-API','parity_status':'PLANNED','evidence_refs':'EV-001','validation_required':'yes'}])
    write_csv(root/'target-state/aws-limit-validation.csv',[
        {'check_id':'LIM-1','component_id':'CMP-API','aws_service':'API Gateway','limit_name':'Integration timeout','official_source_url':'https://docs.aws.amazon.com/apigateway/latest/developerguide/limits.html','verified_date':str(__import__('datetime').date.today()),'observed_requirement':'1000','unit':'ms','aws_limit':'30000','limit_type':'hard/default','headroom_pct':'96','result':'PASS','evidence_refs':'EV-001'},
        {'check_id':'LIM-2','component_id':'CMP-FN','aws_service':'Lambda','limit_name':'Execution timeout','official_source_url':'https://docs.aws.amazon.com/lambda/latest/dg/gettingstarted-limits.html','verified_date':str(__import__('datetime').date.today()),'observed_requirement':'1000','unit':'ms','aws_limit':'900000','limit_type':'hard','headroom_pct':'99','result':'PASS','evidence_refs':'EV-001'}])
    (root/'target-state/target-openapi.yaml').write_text('''openapi: 3.0.3\ninfo:\n  title: Orders\n  version: 1.0.0\npaths:\n  /orders/{id}:\n    get:\n      operationId: getOrder\n      responses:\n        "200":\n          description: OK\n''',encoding='utf-8')
    for name in ('target-context.puml','target-network.puml'):
        p=root/'diagrams'/name
        p.write_text(p.read_text().replace('[TBD]',''),encoding='utf-8')
    (root/'decisions/ADR-001-private-api-lambda.md').write_text('# ADR-001: Private API Gateway and Lambda\n\n## Decision\nUse private enterprise ingress, API Gateway, and Lambda.\n',encoding='utf-8')
    report=root/'architecture-assessment.md'
    report.write_text(report.read_text().replace('Readiness: NOT READY','Readiness: READY WITH CONDITIONS'),encoding='utf-8')


def mutate_csv(path, mutator):
    with path.open(encoding='utf-8-sig', newline='') as f:
        rd=csv.DictReader(f); headers=rd.fieldnames; data=list(rd)
    mutator(data)
    rows(path,headers,data)


def run_case(base: Path, work_parent: Path, name, mutate, expected_code=None, expected_pass=False):
    slug=''.join(c if c.isalnum() else '-' for c in name.lower()).strip('-')
    root=work_parent/slug
    shutil.copytree(base, root)
    mutate(root)
    result=validator.validate(root)
    codes={item['code'] for item in result.items}
    ok=(not result.errors) if expected_pass else (bool(result.errors) and expected_code in codes)
    print(('PASS' if ok else 'FAIL'),name)
    if not ok:
        for item in result.items:
            print(item)
    return ok


def main():
    with tempfile.TemporaryDirectory(prefix='mule-skill-evals-') as td:
        parent=Path(td)
        base=parent/'base'
        make_base(base)
        cases=[]
        cases.append(run_case(base,parent,'baseline complete assessment',lambda r:None,expected_pass=True))
        cases.append(run_case(base,parent,'missing traceability',lambda r:(r/'target-state/traceability-matrix.csv').write_text((r/'target-state/traceability-matrix.csv').read_text().splitlines()[0]+'\n'), 'TRACE_MISSING'))
        cases.append(run_case(base,parent,'AWS hard limit failure',lambda r:mutate_csv(r/'target-state/aws-limit-validation.csv',lambda d:d[1].update({'result':'FAIL'})), 'AWS_LIMIT_FAIL'))
        cases.append(run_case(base,parent,'direct public API Gateway',lambda r:mutate_csv(r/'target-state/target-api-inventory.csv',lambda d:d[0].update({'network_exposure':'Public Internet'})), 'API_GATEWAY_DIRECT_EXTERNAL'))
        cases.append(run_case(base,parent,'prohibited Secrets Manager',lambda r:mutate_csv(r/'target-state/cloud-component-inventory.csv',lambda d:d[1].update({'secrets_mechanism':'AWS Secrets Manager'})), 'CONSTRAINT_SECRETS_MANAGER'))
        cases.append(run_case(base,parent,'unknown critical policy',lambda r:mutate_csv(r/'current-state/policy-inventory.csv',lambda d:d[0].update({'status':'UNKNOWN'})), 'SECURITY_POLICY_UNKNOWN'))
        cases.append(run_case(base,parent,'empty OpenAPI',lambda r:(r/'target-state/target-openapi.yaml').write_text('openapi: 3.0.3\ninfo:\n  title: X\n  version: 1\npaths: {}\n'), 'OPENAPI_EMPTY'))
        cases.append(run_case(base,parent,'duplicate traceability',lambda r:mutate_csv(r/'target-state/traceability-matrix.csv',lambda d:d.append(dict(d[0]))), 'TRACE_DUPLICATE'))
        cases.append(run_case(base,parent,'legacy technology mention allowed',lambda r:(r/'architecture-assessment.md').write_text((r/'architecture-assessment.md').read_text()+"\nCurrent-state documentation references Spring Cloud Config. AWS Secrets Manager was considered and rejected for the target.\n"), expected_pass=True))
        cases.append(run_case(base,parent,'Spring Config prohibited in target mapping',lambda r:write_csv(r/'target-state/configuration-mapping.csv',[{'current_config_id':'CFG-1','current_source':'legacy config','current_key_or_purpose':'app settings','is_secret':'false','target_mechanism':'Spring Cloud Config','target_location':'Config Server','evidence_refs':'EV-001'}]), 'CONSTRAINT_SPRING_CONFIG'))
        return 0 if all(cases) else 1


if __name__=='__main__':
    raise SystemExit(main())
