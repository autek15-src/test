#!/usr/bin/env python3
"""Render PlantUML files using a locally available PlantUML executable/JAR."""
from __future__ import annotations
import argparse, shutil, subprocess, sys
from pathlib import Path

def main()->int:
    p=argparse.ArgumentParser(); p.add_argument('path',type=Path); p.add_argument('--format',choices=['svg','png'],default='svg'); p.add_argument('--plantuml-jar',type=Path); args=p.parse_args()
    files=[args.path] if args.path.is_file() else sorted(args.path.rglob('*.puml'))
    if not files: print('ERROR: no .puml files found'); return 2
    if args.plantuml_jar:
        cmd=['java','-jar',str(args.plantuml_jar)]
    elif shutil.which('plantuml'):
        cmd=['plantuml']
    else:
        print('ERROR: PlantUML not found. Install a local plantuml command or pass --plantuml-jar /path/to/plantuml.jar.')
        return 2
    rc=0
    for f in files:
        r=subprocess.run(cmd+[f'-t{args.format}',str(f)],text=True)
        rc=max(rc,r.returncode)
    return rc
if __name__=='__main__': raise SystemExit(main())
