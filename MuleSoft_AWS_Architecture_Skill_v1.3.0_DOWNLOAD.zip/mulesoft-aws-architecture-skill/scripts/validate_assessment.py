#!/usr/bin/env python3
"""Completion/quality gate for MuleSoft-to-AWS architecture assessments.

Exit codes:
  0 = no ERROR findings
  1 = one or more ERROR findings
  2 = validator/runtime error
"""
from __future__ import annotations
import argparse, csv, json, re, sys
from datetime import date, datetime
from pathlib import Path
from urllib.parse import urlparse

REQUIRED_FILES = [
    'architecture-assessment.md','executive-summary.md','assumptions-risks-open-questions.md',
    'evidence/evidence-register.csv','evidence/source-inventory.csv',
    'current-state/api-inventory.csv','current-state/api-flow-inventory.csv','current-state/api-flow-steps.csv','current-state/api-flows.md','current-state/dependency-inventory.csv','current-state/policy-inventory.csv','current-state/traffic-profile.csv',
    'target-state/target-api-inventory.csv','target-state/cloud-component-inventory.csv','target-state/compute-sizing.csv',
    'target-state/configuration-mapping.csv','target-state/security-policy-mapping.csv','target-state/aws-limit-validation.csv','target-state/traceability-matrix.csv',
    'options/architecture-options.md','diagrams/current-context.puml','diagrams/current-network.puml','diagrams/target-context.puml','diagrams/target-network.puml',
    'testing/migration-test-strategy.md','migration/migration-cutover-plan.md'
]
ALLOWED_DISPOSITIONS = {'RETIRED','CONSOLIDATED INTO','ABSORBED INTO','REPLACED BY'}
LIMIT_SERVICES = {'lambda','api gateway','step functions','sqs','sns','eventbridge','ecs','fargate'}
OFFICIAL_AWS_HOSTS = {'docs.aws.amazon.com','aws.amazon.com'}

class Result:
    def __init__(self): self.items=[]
    def add(self,severity,code,message,path=''):
        self.items.append({'severity':severity,'code':code,'message':message,'path':path})
    @property
    def errors(self): return [x for x in self.items if x['severity']=='ERROR']
    @property
    def warnings(self): return [x for x in self.items if x['severity']=='WARN']

def read_csv(path:Path):
    if not path.exists(): return []
    with path.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))

def all_text(root:Path):
    chunks=[]
    for ext in ('*.md','*.csv','*.yaml','*.yml','*.puml'):
        for p in root.rglob(ext):
            try: chunks.append(p.read_text(encoding='utf-8',errors='replace'))
            except: pass
    return '\n'.join(chunks)

def truthy(v): return str(v).strip().lower() in {'1','true','yes','y'}

def service_norm(v):
    s=str(v or '').lower().replace('aws ','').strip()
    if 'lambda' in s:return 'lambda'
    if 'api gateway' in s or 'apigateway' in s:return 'api gateway'
    if 'step function' in s:return 'step functions'
    if re.search(r'\bsqs\b',s):return 'sqs'
    if re.search(r'\bsns\b',s):return 'sns'
    if 'eventbridge' in s:return 'eventbridge'
    if 'fargate' in s:return 'fargate'
    if re.search(r'\becs\b',s):return 'ecs'
    return s

def parse_float(v):
    try:return float(str(v).replace(',','').strip())
    except:return None

def validate_html_report(root:Path, r:Result)->None:
    report=root/'architecture-assessment.html'
    manifest=root/'validation/html-report-manifest.json'
    if not report.exists():
        r.add('ERROR','HTML_REPORT_MISSING','Primary architect-facing HTML report is missing.','architecture-assessment.html'); return
    if report.stat().st_size < 5000:
        r.add('ERROR','HTML_REPORT_TOO_SMALL','HTML report is unexpectedly small and is unlikely to contain the complete assessment.','architecture-assessment.html')
    text=report.read_text(encoding='utf-8',errors='replace')
    required_markers=[
        'data-report-schema=\"2.1\"','id=\"overview\"','id=\"current-state\"','id=\"rationalization\"',
        'id=\"target-state\"','id=\"assurance\"','id=\"evidence\"','id=\"artifacts\"',
        'id=\"diagram-current-context\"','id=\"diagram-current-network\"',
        'id=\"diagram-target-context\"','id=\"diagram-target-network\"',
        'id=\"global-search\"','id=\"report-manifest\"'
    ]
    for marker in required_markers:
        if marker not in text:
            r.add('ERROR','HTML_REPORT_FEATURE_MISSING',f'Primary HTML report is missing required marker: {marker}.','architecture-assessment.html')
    if not manifest.exists():
        r.add('ERROR','HTML_MANIFEST_MISSING','HTML report manifest is missing.','validation/html-report-manifest.json'); return
    try:
        data=json.loads(manifest.read_text(encoding='utf-8'))
    except Exception as exc:
        r.add('ERROR','HTML_MANIFEST_INVALID',f'HTML report manifest is invalid JSON: {exc}.','validation/html-report-manifest.json'); return
    if str(data.get('schema_version'))!='2.1':
        r.add('ERROR','HTML_SCHEMA_INVALID','HTML report manifest does not use report schema 2.1.','validation/html-report-manifest.json')
    canonical=root/'architecture-assessment.md'
    if canonical.exists():
        m=re.search(r'(?im)^\s*(?:\*\*)?Readiness(?:\*\*)?\s*:\s*(READY WITH CONDITIONS|NOT READY|READY)\s*$',canonical.read_text(encoding='utf-8',errors='replace'))
        if m and str(data.get('readiness') or '').upper()!=m.group(1).upper():
            r.add('ERROR','HTML_READINESS_MISMATCH',f'HTML report readiness {data.get("readiness")} does not match canonical readiness {m.group(1)}.','architecture-assessment.html')
    included=set(data.get('embedded_artifacts') or [])
    # Every canonical required artifact must be viewable/downloadable from the report. The HTML itself is not in REQUIRED_FILES.
    for rel in REQUIRED_FILES:
        if rel not in included:
            r.add('ERROR','HTML_ARTIFACT_NOT_EMBEDDED',f'Required artifact is not embedded in the architect report: {rel}.','architecture-assessment.html')
    expected_diagrams={'current-context','current-network','target-context','target-network'}
    if not expected_diagrams.issubset(set(data.get('diagrams') or [])):
        r.add('ERROR','HTML_DIAGRAM_SET_INCOMPLETE','HTML report manifest does not declare all four current/target context/network diagrams.','validation/html-report-manifest.json')
    flow_rows=read_csv(root/'current-state/api-flow-inventory.csv')
    declared_flow_diagrams=set(data.get('flow_diagrams') or [])
    expected_flow_diagrams={(row.get('flow_id') or '').strip() for row in flow_rows if (row.get('flow_id') or '').strip()}
    if expected_flow_diagrams != declared_flow_diagrams:
        r.add('ERROR','HTML_FLOW_DIAGRAM_SET_INCOMPLETE','HTML report manifest flow_diagrams does not exactly match the current-state API interaction flow inventory.','validation/html-report-manifest.json')
    for row in flow_rows:
        fid=(row.get('flow_id') or '').strip()
        seq=(row.get('sequence_diagram') or '').strip()
        if not fid: continue
        if f'id="api-flow-{re.sub(r"[^a-zA-Z0-9]+", "-", fid.lower()).strip("-")}"' not in text:
            r.add('ERROR','HTML_FLOW_CARD_MISSING',f'HTML report does not contain a dedicated API interaction flow card for {fid}.','architecture-assessment.html')
        if seq and seq not in included:
            r.add('ERROR','HTML_FLOW_DIAGRAM_NOT_EMBEDDED',f'Flow sequence diagram is not embedded/downloadable from the architect report: {seq}.','architecture-assessment.html')

def validate(root:Path, require_html:bool=False)->Result:
    r=Result()
    for rel in REQUIRED_FILES:
        p=root/rel
        if not p.exists(): r.add('ERROR','FILE_MISSING',f'Required artifact missing: {rel}',rel)
        elif p.stat().st_size==0: r.add('ERROR','FILE_EMPTY',f'Required artifact empty: {rel}',rel)

    # Required diagrams should have meaningful content.
    for rel in ('diagrams/current-context.puml','diagrams/current-network.puml','diagrams/target-context.puml','diagrams/target-network.puml'):
        p=root/rel
        if p.exists():
            t=p.read_text(encoding='utf-8',errors='replace')
            if '@startuml' not in t or '@enduml' not in t: r.add('ERROR','DIAGRAM_INVALID',f'{rel} is not valid PlantUML source.',rel)
            if '[TBD]' in t: r.add('WARN','DIAGRAM_TBD',f'{rel} still contains [TBD] placeholders.',rel)

    current=read_csv(root/'current-state/api-inventory.csv')
    flows=read_csv(root/'current-state/api-flow-inventory.csv')
    flow_steps=read_csv(root/'current-state/api-flow-steps.csv')
    trace=read_csv(root/'target-state/traceability-matrix.csv')
    target=read_csv(root/'target-state/target-api-inventory.csv')
    comps=read_csv(root/'target-state/cloud-component-inventory.csv')
    limits=read_csv(root/'target-state/aws-limit-validation.csv')
    policies=read_csv(root/'current-state/policy-inventory.csv')
    evidence=read_csv(root/'evidence/evidence-register.csv')
    sizing=read_csv(root/'target-state/compute-sizing.csv')
    security_map=read_csv(root/'target-state/security-policy-mapping.csv')
    config_map=read_csv(root/'target-state/configuration-mapping.csv')
    traffic=read_csv(root/'current-state/traffic-profile.csv')

    if not current: r.add('ERROR','NO_CURRENT_ENDPOINTS','Current API inventory has no endpoint rows. If the app is truly non-API, document and adapt the inventory explicitly.','current-state/api-inventory.csv')
    if not evidence: r.add('WARN','NO_EVIDENCE_ROWS','Evidence register contains no evidence rows.','evidence/evidence-register.csv')
    if current and not policies: r.add('ERROR','POLICY_INVENTORY_EMPTY','Current endpoints exist but policy inventory is empty. Record confirmed policies, explicit NONE, or UNKNOWN/UNAVAILABLE evidence.','current-state/policy-inventory.csv')
    if current and not traffic: r.add('WARN','TRAFFIC_INVENTORY_EMPTY','No traffic profile rows exist. If runtime data was unavailable, record that gap and its architecture impact.','current-state/traffic-profile.csv')
    evidence_ids={(x.get('evidence_id') or '').strip() for x in evidence if (x.get('evidence_id') or '').strip()}
    def check_refs(ref_text, owner, path, severity='WARN'):
        refs=[x.strip() for x in re.split(r'[;,\s]+', ref_text or '') if x.strip()]
        for ref in refs:
            if ref not in evidence_ids:
                r.add(severity,'EVIDENCE_REF_UNKNOWN',f'{owner} references evidence ID {ref} not present in evidence register.',path)

    # Current-state application/business API interaction flows.
    if current and not flows:
        r.add('ERROR','API_FLOWS_EMPTY','Current endpoints exist but no API interaction flows were documented. Reconstruct the application/business flows that traverse Mule APIs.','current-state/api-flow-inventory.csv')
    flow_ids=[]
    steps_by_flow={}
    for row in flow_steps:
        fid=(row.get('flow_id') or '').strip()
        if fid: steps_by_flow.setdefault(fid,[]).append(row)
    for i,row in enumerate(flows,2):
        fid=(row.get('flow_id') or '').strip()
        if not fid:
            r.add('ERROR','FLOW_ID_MISSING',f'API flow row {i} has no flow_id.','current-state/api-flow-inventory.csv'); continue
        if fid in flow_ids:
            r.add('ERROR','FLOW_ID_DUP',f'Duplicate API interaction flow_id: {fid}.','current-state/api-flow-inventory.csv')
        flow_ids.append(fid)
        for col in ('flow_name','business_purpose','trigger','primary_actor','mule_endpoints','final_outcome','sequence_diagram','evidence_refs'):
            if not (row.get(col) or '').strip():
                r.add('ERROR','FLOW_FIELD_MISSING',f'{fid} missing required {col}.','current-state/api-flow-inventory.csv')
        if (row.get('evidence_refs') or '').strip(): check_refs(row.get('evidence_refs'), f'flow {fid}', 'current-state/api-flow-inventory.csv', 'ERROR')
        seq=(row.get('sequence_diagram') or '').strip()
        if seq:
            dp=(root/seq).resolve()
            try: dp.relative_to(root.resolve())
            except ValueError:
                r.add('ERROR','FLOW_DIAGRAM_PATH_INVALID',f'{fid} sequence diagram points outside the assessment: {seq}.','current-state/api-flow-inventory.csv'); dp=None
            if dp is not None:
                if not dp.exists():
                    r.add('ERROR','FLOW_DIAGRAM_MISSING',f'{fid} sequence diagram is missing: {seq}.',seq)
                else:
                    dt=dp.read_text(encoding='utf-8',errors='replace')
                    if '@startuml' not in dt or '@enduml' not in dt or '->' not in dt:
                        r.add('ERROR','FLOW_DIAGRAM_INVALID',f'{fid} sequence diagram must be valid PlantUML and contain sequence interactions.',seq)
        steps=steps_by_flow.get(fid,[])
        if not steps:
            r.add('ERROR','FLOW_STEPS_MISSING',f'{fid} has no step-by-step flow rows.','current-state/api-flow-steps.csv')
        else:
            for j,step in enumerate(steps,1):
                for col in ('step_number','actor_or_system','business_action','technical_action','evidence_refs'):
                    if not (step.get(col) or '').strip():
                        r.add('ERROR','FLOW_STEP_FIELD_MISSING',f'{fid} step row {j} missing {col}.','current-state/api-flow-steps.csv')
                if (step.get('evidence_refs') or '').strip(): check_refs(step.get('evidence_refs'), f'{fid} step {step.get("step_number")}', 'current-state/api-flow-steps.csv', 'ERROR')
    for fid in steps_by_flow:
        if fid not in flow_ids:
            r.add('ERROR','FLOW_STEP_ORPHAN',f'API flow steps reference unknown flow_id {fid}.','current-state/api-flow-steps.csv')

    current_ids=[]
    for i,row in enumerate(current,2):
        eid=(row.get('endpoint_id') or '').strip()
        if not eid: r.add('ERROR','CURRENT_ID_MISSING',f'Current API row {i} has no endpoint_id.','current-state/api-inventory.csv'); continue
        if eid in current_ids: r.add('ERROR','CURRENT_ID_DUP',f'Duplicate current endpoint_id: {eid}','current-state/api-inventory.csv')
        current_ids.append(eid)
        if not (row.get('method') or '').strip(): r.add('WARN','CURRENT_METHOD_MISSING',f'{eid} has no method/event type.','current-state/api-inventory.csv')
        if not (row.get('resource') or '').strip(): r.add('WARN','CURRENT_RESOURCE_MISSING',f'{eid} has no resource/interface.','current-state/api-inventory.csv')
        if not (row.get('evidence_refs') or '').strip(): r.add('WARN','CURRENT_EVIDENCE_MISSING',f'{eid} has no evidence_refs.','current-state/api-inventory.csv')
        else: check_refs(row.get('evidence_refs'), eid, 'current-state/api-inventory.csv')
        relationship=(row.get('consumer_relationship') or '').strip().upper()
        if relationship not in {'EXTERNAL_APPLICATION_CONSUMER','INTERNAL_APPLICATION_COMPONENT','MIXED','UNKNOWN'}:
            r.add('ERROR','CONSUMER_RELATIONSHIP_MISSING',f'{eid} must classify consumer_relationship as EXTERNAL_APPLICATION_CONSUMER, INTERNAL_APPLICATION_COMPONENT, MIXED, or UNKNOWN.','current-state/api-inventory.csv')
        if not (row.get('api_role') or '').strip():
            r.add('ERROR','API_ROLE_MISSING',f'{eid} has no api_role classification (for example GATEWAY_PROXY, ORCHESTRATION, DOMAIN_INTEGRATION).','current-state/api-inventory.csv')
        flow_refs=[x.strip() for x in re.split(r'[;,]',row.get('business_flow_ids') or '') if x.strip()]
        if not flow_refs:
            r.add('ERROR','ENDPOINT_FLOW_COVERAGE_MISSING',f'{eid} has no business_flow_ids coverage. Reference one or more flow IDs, or explicitly use N/A for a justified technical-only endpoint.','current-state/api-inventory.csv')
        else:
            for fid in flow_refs:
                if fid.upper() not in {'N/A','NA','TECHNICAL_ONLY'} and fid not in flow_ids:
                    r.add('ERROR','ENDPOINT_FLOW_UNKNOWN',f'{eid} references unknown business flow {fid}.','current-state/api-inventory.csv')

    trace_by={}
    for i,row in enumerate(trace,2):
        eid=(row.get('current_endpoint_id') or '').strip()
        if not eid: r.add('ERROR','TRACE_ID_MISSING',f'Traceability row {i} has no current_endpoint_id.','target-state/traceability-matrix.csv'); continue
        trace_by.setdefault(eid,[]).append(row)
        disp=(row.get('disposition') or '').strip().upper()
        if disp not in ALLOWED_DISPOSITIONS: r.add('ERROR','TRACE_DISPOSITION_INVALID',f'{eid} has invalid disposition: {disp or "<blank>"}.','target-state/traceability-matrix.csv')
        if not (row.get('rationale') or '').strip(): r.add('ERROR','TRACE_RATIONALE_MISSING',f'{eid} has no rationalization rationale.','target-state/traceability-matrix.csv')
        if not (row.get('evidence_refs') or '').strip(): r.add('ERROR','TRACE_EVIDENCE_MISSING',f'{eid} has no evidence reference.','target-state/traceability-matrix.csv')
        else: check_refs(row.get('evidence_refs'), f'traceability {eid}', 'target-state/traceability-matrix.csv', 'ERROR')
        target_ref=(row.get('target_component_or_endpoint') or '').strip()
        if disp!='RETIRED' and not target_ref: r.add('ERROR','TRACE_TARGET_MISSING',f'{eid} disposition {disp} has no target mapping.','target-state/traceability-matrix.csv')
    for eid in current_ids:
        n=len(trace_by.get(eid,[]))
        if n==0:r.add('ERROR','TRACE_MISSING',f'Current endpoint {eid} is missing from traceability.','target-state/traceability-matrix.csv')
        elif n>1:r.add('ERROR','TRACE_DUPLICATE',f'Current endpoint {eid} appears {n} times in traceability; exactly one disposition is required.','target-state/traceability-matrix.csv')
    for eid in trace_by:
        if eid not in current_ids:r.add('WARN','TRACE_ORPHAN',f'Traceability references unknown current endpoint {eid}.','target-state/traceability-matrix.csv')

    current_by_id={(row.get('endpoint_id') or '').strip(): row for row in current if (row.get('endpoint_id') or '').strip()}
    for eid,src in current_by_id.items():
        if re.search(r'GATEWAY|PROXY', (src.get('api_role') or '').upper()):
            rows=trace_by.get(eid,[])
            if rows:
                rationale=' '.join((rows[0].get('rationale') or '', rows[0].get('target_component_or_endpoint') or '')).lower()
                if not any(k in rationale for k in ('api gateway','direct integration','http proxy','retire','consolidat','absorb')):
                    r.add('ERROR','GATEWAY_RATIONALIZATION_MISSING',f'{eid} is classified as a gateway/proxy but its disposition does not explicitly evaluate direct API Gateway integration, retirement, consolidation, or absorption.','target-state/traceability-matrix.csv')

    # Target API references should resolve to current IDs and document compatibility intent.
    for i,row in enumerate(target,2):
        tid=(row.get('target_endpoint_id') or f'row-{i}').strip()
        refs=[x.strip() for x in re.split(r'[;,]',row.get('current_endpoint_ids') or '') if x.strip()]
        for eid in refs:
            if eid not in current_ids:r.add('ERROR','TARGET_SOURCE_UNKNOWN',f'{tid} references unknown current endpoint {eid}.','target-state/target-api-inventory.csv')
        if not (row.get('rationale') or '').strip():r.add('WARN','TARGET_RATIONALE_MISSING',f'{tid} has no rationale.','target-state/target-api-inventory.csv')
        preservation=(row.get('contract_preservation') or '').strip().upper()
        if preservation not in {'PRESERVED','PRESERVED_VIA_GATEWAY_MAPPING','CHANGED','N/A'}:
            r.add('ERROR','CONTRACT_PRESERVATION_MISSING',f'{tid} must state contract_preservation as PRESERVED, PRESERVED_VIA_GATEWAY_MAPPING, CHANGED, or N/A.','target-state/target-api-inventory.csv')
        if preservation=='CHANGED':
            if not (row.get('contract_change_justification') or '').strip():
                r.add('ERROR','CONTRACT_CHANGE_JUSTIFICATION_MISSING',f'{tid} changes the current contract without explicit architectural justification.','target-state/target-api-inventory.csv')
            if not (row.get('consumer_change_impact') or '').strip():
                r.add('ERROR','CONSUMER_CHANGE_IMPACT_MISSING',f'{tid} changes the current contract without documenting consumer impact.','target-state/target-api-inventory.csv')
            relationships={(current_by_id.get(eid,{}).get('consumer_relationship') or 'UNKNOWN').strip().upper() for eid in refs}
            if relationships & {'EXTERNAL_APPLICATION_CONSUMER','MIXED','UNKNOWN'}:
                r.add('WARN','EXTERNAL_CONTRACT_CHANGE',f'{tid} changes a contract used by external/mixed/unknown consumers; confirm the benefit outweighs coordinated consumer migration risk.','target-state/target-api-inventory.csv')
        if preservation=='PRESERVED' and len(refs)==1 and refs[0] in current_by_id:
            src=current_by_id[refs[0]]
            for src_col,tgt_col,label in [('method','method','method'),('resource','path','path'),('protocol','protocol','protocol')]:
                sv=(src.get(src_col) or '').strip().upper(); tv=(row.get(tgt_col) or '').strip().upper()
                if sv and tv and sv!=tv:
                    r.add('ERROR','CONTRACT_PRESERVATION_MISMATCH',f'{tid} is marked PRESERVED but {label} differs from current {refs[0]} ({src.get(src_col)} -> {row.get(tgt_col)}).','target-state/target-api-inventory.csv')
        gateway_sources=[eid for eid in refs if re.search(r'GATEWAY|PROXY', (current_by_id.get(eid,{}).get('api_role') or '').upper())]
        if gateway_sources and 'lambda' in (row.get('compute') or '').lower() and not (row.get('lambda_necessity_justification') or '').strip():
            r.add('ERROR','GATEWAY_LAMBDA_UNJUSTIFIED',f'{tid} uses Lambda to replace gateway/proxy source endpoint(s) {", ".join(gateway_sources)} without explaining why direct API Gateway integration, consolidation, retirement, or absorption is insufficient.','target-state/target-api-inventory.csv')

    # Cloud inventory completeness and company constraints.
    comp_services={}
    for i,row in enumerate(comps,2):
        cid=(row.get('component_id') or '').strip()
        if not cid:r.add('ERROR','COMPONENT_ID_MISSING',f'Cloud inventory row {i} has no component_id.','target-state/cloud-component-inventory.csv'); continue
        svc=service_norm(row.get('aws_service')); comp_services[cid]=svc
        for col in ('purpose','replaces_or_supports','rationale'):
            if not (row.get(col) or '').strip():r.add('ERROR','COMPONENT_FIELD_MISSING',f'{cid} missing required {col}.','target-state/cloud-component-inventory.csv')
        if svc=='lambda':
            runtime=(row.get('runtime') or '').strip()
            language=(row.get('implementation_language') or '').strip().lower()
            exception=(row.get('language_exception_justification') or '').strip()
            if not runtime:
                r.add('ERROR','LAMBDA_RUNTIME_MISSING',f'{cid} Lambda has no target runtime.','target-state/cloud-component-inventory.csv')
            if not language:
                r.add('ERROR','LAMBDA_LANGUAGE_MISSING',f'{cid} Lambda has no implementation_language; company default is TypeScript.','target-state/cloud-component-inventory.csv')
            elif 'typescript' in language:
                if runtime and 'node' not in runtime.lower():
                    r.add('ERROR','LAMBDA_TYPESCRIPT_RUNTIME_INVALID',f'{cid} is TypeScript but runtime does not identify Node.js: {runtime}.','target-state/cloud-component-inventory.csv')
            elif language=='java' or 'java' in language:
                if not exception:
                    r.add('ERROR','LAMBDA_JAVA_JUSTIFICATION_MISSING',f'{cid} targets Java instead of the company-default TypeScript but has no technical exception justification.','target-state/cloud-component-inventory.csv')
            else:
                r.add('ERROR','LAMBDA_LANGUAGE_NOT_ALLOWED',f'{cid} targets {row.get("implementation_language")} for Lambda; company default is TypeScript and only justified Java exceptions are currently allowed.','target-state/cloud-component-inventory.csv')
        secret=(row.get('secrets_mechanism') or '').lower()
        if 'secrets manager' in secret:r.add('ERROR','CONSTRAINT_SECRETS_MANAGER',f'{cid} uses AWS Secrets Manager, prohibited by company constraint.','target-state/cloud-component-inventory.csv')
        if secret and 'vault' not in secret:r.add('WARN','VAULT_NOT_EXPLICIT',f'{cid} has a secrets mechanism but does not mention Vault: {row.get("secrets_mechanism")}.','target-state/cloud-component-inventory.csv')

    # Compute sizing completeness.
    sizing_by={}
    for row in sizing:
        sizing_by.setdefault((row.get('component_id') or '').strip(), []).append(row)
    for cid,svc in comp_services.items():
        comp_row=next((x for x in comps if (x.get('component_id') or '').strip()==cid), {})
        if svc=='lambda':
            if not (comp_row.get('memory_mb') or '').strip(): r.add('ERROR','LAMBDA_MEMORY_MISSING',f'{cid} Lambda has no initial memory sizing.','target-state/cloud-component-inventory.csv')
            if not (comp_row.get('timeout_ms') or '').strip(): r.add('ERROR','LAMBDA_TIMEOUT_MISSING',f'{cid} Lambda has no target timeout.','target-state/cloud-component-inventory.csv')
            if not sizing_by.get(cid): r.add('ERROR','COMPUTE_SIZING_MISSING',f'{cid} Lambda has no compute-sizing evidence rows.','target-state/compute-sizing.csv')
        if svc in {'ecs','fargate'}:
            for col in ('cpu','memory_mb','min_capacity','max_capacity'):
                if not (comp_row.get(col) or '').strip(): r.add('ERROR','FARGATE_SIZING_MISSING',f'{cid} {svc} missing {col}.','target-state/cloud-component-inventory.csv')
            if not sizing_by.get(cid): r.add('ERROR','COMPUTE_SIZING_MISSING',f'{cid} {svc} has no compute-sizing evidence rows.','target-state/compute-sizing.csv')
        if svc=='api gateway' and not (comp_row.get('network_placement') or '').strip():
            r.add('ERROR','API_GATEWAY_NETWORK_MISSING',f'{cid} API Gateway has no network placement/exposure design.','target-state/cloud-component-inventory.csv')

    # Security mapping completeness for current policies.
    security_ids={(x.get('current_policy_id') or '').strip() for x in security_map}
    for row in policies:
        pid=(row.get('policy_id') or '').strip()
        if pid and (row.get('status') or '').strip().upper() in {'CONFIRMED','OBSERVED'} and pid not in security_ids:
            r.add('WARN','SECURITY_MAPPING_MISSING',f'Confirmed current policy {pid} has no target security-policy mapping row.','target-state/security-policy-mapping.csv')

    # Configuration target constraints. Current-source fields may legitimately name legacy technologies.
    for i,row in enumerate(config_map,2):
        target_fields=' '.join(str(row.get(k) or '') for k in ('target_mechanism','target_location','rotation_or_versioning','notes')).lower()
        is_secret=truthy(row.get('is_secret'))
        if 'spring cloud config' in target_fields or 'config server' in target_fields:
            r.add('ERROR','CONSTRAINT_SPRING_CONFIG',f'Configuration mapping row {i} retains Spring Cloud Config/Config Server in the target.','target-state/configuration-mapping.csv')
        if 'secrets manager' in target_fields:
            r.add('ERROR','CONSTRAINT_SECRETS_MANAGER',f'Configuration mapping row {i} uses AWS Secrets Manager in the target.','target-state/configuration-mapping.csv')
        if is_secret and 'vault' not in target_fields:
            r.add('ERROR','SECRET_TARGET_NOT_VAULT',f'Configuration mapping row {i} is secret but target mechanism/location does not identify Vault.','target-state/configuration-mapping.csv')

    # Limits per applicable component.
    limit_by_comp={}
    today=date.today()
    for i,row in enumerate(limits,2):
        cid=(row.get('component_id') or '').strip(); limit_by_comp.setdefault(cid,[]).append(row)
        result=(row.get('result') or '').strip().upper()
        if result=='FAIL':r.add('ERROR','AWS_LIMIT_FAIL',f'{cid or "limit row"}: {row.get("limit_name")} is marked FAIL.','target-state/aws-limit-validation.csv')
        elif result=='WARN':r.add('WARN','AWS_LIMIT_WARN',f'{cid or "limit row"}: {row.get("limit_name")} is marked WARN.','target-state/aws-limit-validation.csv')
        elif result not in {'PASS','N/A'}:r.add('ERROR','AWS_LIMIT_RESULT_MISSING',f'Limit row {i} result must be PASS/WARN/FAIL/N/A.','target-state/aws-limit-validation.csv')
        url=(row.get('official_source_url') or '').strip()
        if result!='N/A':
            if not url:r.add('ERROR','AWS_LIMIT_SOURCE_MISSING',f'Limit row {i} has no official source URL.','target-state/aws-limit-validation.csv')
            else:
                host=urlparse(url).hostname or ''
                if host not in OFFICIAL_AWS_HOSTS:r.add('WARN','AWS_LIMIT_SOURCE_NONOFFICIAL',f'Limit row {i} source is not an official AWS host: {host}.','target-state/aws-limit-validation.csv')
            vd=(row.get('verified_date') or '').strip()
            try:
                d=datetime.strptime(vd,'%Y-%m-%d').date()
                age=(today-d).days
                if age>90:r.add('WARN','AWS_LIMIT_STALE',f'Limit row {i} was verified {age} days ago. Recheck current AWS documentation.','target-state/aws-limit-validation.csv')
                if age<0:r.add('WARN','AWS_LIMIT_FUTURE_DATE',f'Limit row {i} has a future verified_date.','target-state/aws-limit-validation.csv')
            except:r.add('ERROR','AWS_LIMIT_DATE_INVALID',f'Limit row {i} has invalid verified_date; use YYYY-MM-DD.','target-state/aws-limit-validation.csv')
            if not (row.get('observed_requirement') or '').strip():r.add('ERROR','AWS_LIMIT_REQUIREMENT_MISSING',f'Limit row {i} has no observed requirement.','target-state/aws-limit-validation.csv')
            if not (row.get('aws_limit') or '').strip():r.add('ERROR','AWS_LIMIT_VALUE_MISSING',f'Limit row {i} has no recorded AWS limit.','target-state/aws-limit-validation.csv')
            hp=parse_float(row.get('headroom_pct'))
            if hp is not None and hp<10 and result=='PASS':r.add('WARN','AWS_LIMIT_LOW_HEADROOM',f'Limit row {i} has only {hp}% headroom but is marked PASS.','target-state/aws-limit-validation.csv')
    for cid,svc in comp_services.items():
        if svc in LIMIT_SERVICES and not limit_by_comp.get(cid):r.add('ERROR','AWS_LIMIT_COMPONENT_MISSING',f'{cid} ({svc}) has no AWS limit validation rows.','target-state/aws-limit-validation.csv')

    # Security-critical unknown policies.
    for row in policies:
        if truthy(row.get('security_critical')) and (row.get('status') or '').strip().upper() in {'','UNKNOWN','UNAVAILABLE','NOT REVIEWED','UNREVIEWED'}:
            r.add('ERROR','SECURITY_POLICY_UNKNOWN',f'Security-critical policy {row.get("policy_id") or row.get("api_or_endpoint")} is not confirmed.','current-state/policy-inventory.csv')

    # Network exposure guard for target APIs.
    for row in target:
        gateway=(row.get('gateway') or '').lower(); exposure=(row.get('network_exposure') or '').lower()
        if 'api gateway' in gateway and any(x in exposure for x in ('public','internet','external')) and not any(x in exposure for x in ('enterprise ingress','corporate','private','company network')):
            r.add('ERROR','API_GATEWAY_DIRECT_EXTERNAL',f'{row.get("target_endpoint_id")} appears to expose API Gateway directly outside the company network.','target-state/target-api-inventory.csv')

    text=all_text(root)
    low=text.lower()
    if 'vault' not in low:r.add('ERROR','CONSTRAINT_VAULT_MISSING','HashiCorp Vault is not present in assessment artifacts.')
    if 'cloudwatch' not in low:r.add('ERROR','CONSTRAINT_CLOUDWATCH_MISSING','CloudWatch is not present in assessment artifacts.')
    if 'splunk' not in low:r.add('ERROR','CONSTRAINT_SPLUNK_MISSING','Splunk is not present in assessment artifacts.')

    # OpenAPI presence when REST target endpoints remain.
    rest_target=[x for x in target if (x.get('protocol') or '').strip().upper() in {'REST','HTTP','HTTPS'}]
    if rest_target:
        op=root/'target-state/target-openapi.yaml'
        if not op.exists():r.add('ERROR','OPENAPI_MISSING','REST target endpoints exist but target-state/target-openapi.yaml is missing.','target-state/target-openapi.yaml')
        elif re.search(r'^paths:\s*\{\}\s*$',op.read_text(encoding='utf-8',errors='replace'),re.M):r.add('ERROR','OPENAPI_EMPTY','REST target endpoints exist but OpenAPI paths are empty.','target-state/target-openapi.yaml')

    # ADR presence: at least one non-template ADR if architecture has cloud components.
    adr=[p for p in (root/'decisions').glob('ADR-*.md') if 'template' not in p.name.lower()] if (root/'decisions').exists() else []
    if comps and not adr:r.add('WARN','ADR_MISSING','Cloud target components exist but no material ADRs were created.','decisions/')

    # Readiness marker.
    readiness_state=''
    report=(root/'architecture-assessment.md')
    if report.exists():
        t=report.read_text(encoding='utf-8',errors='replace')
        states=re.findall(r'(?im)^\s*(?:\*\*)?Readiness(?:\*\*)?\s*:\s*(READY WITH CONDITIONS|NOT READY|READY)\s*$',t)
        if not states:r.add('ERROR','READINESS_MISSING','architecture-assessment.md has no explicit Readiness: READY / READY WITH CONDITIONS / NOT READY marker.','architecture-assessment.md')
        elif len(states)>1:r.add('ERROR','READINESS_MULTIPLE','Multiple readiness markers found; exactly one final readiness is required.','architecture-assessment.md')
        else:
            readiness_state=states[0]
            if readiness_state=='READY' and ('[TBD]' in t or 'unknown' in t.lower()):r.add('WARN','READY_WITH_UNKNOWNS','Report says READY but still contains TBD/unknown language; verify this is intentional.','architecture-assessment.md')

    # Unresolved P0/P1 findings cannot be hidden by a readiness label.
    risk_file=root/'assumptions-risks-open-questions.md'
    if risk_file.exists():
        for n,line in enumerate(risk_file.read_text(encoding='utf-8',errors='replace').splitlines(),1):
            if not line.lstrip().startswith('|'): continue
            cells=[c.strip() for c in line.strip().strip('|').split('|')]
            severity=next((c.upper() for c in cells if c.upper() in {'P0','P1','P2','P3'}), '')
            if severity not in {'P0','P1'}: continue
            lowcells=' '.join(cells).lower()
            resolved=any(x in lowcells for x in ('resolved','closed','mitigated','accepted'))
            if resolved: continue
            if severity=='P0': r.add('ERROR','UNRESOLVED_P0',f'Unresolved P0 item at line {n}.','assumptions-risks-open-questions.md')
            elif readiness_state=='READY': r.add('ERROR','UNRESOLVED_P1_READY',f'Readiness is READY with an unresolved P1 item at line {n}.','assumptions-risks-open-questions.md')
            else: r.add('WARN','UNRESOLVED_P1',f'Unresolved P1 item remains at line {n}; it must be an explicit condition/blocker.','assumptions-risks-open-questions.md')
    if require_html:
        validate_html_report(root,r)
    return r

def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('assessment',type=Path); ap.add_argument('--json',type=Path); ap.add_argument('--strict-warnings',action='store_true'); ap.add_argument('--require-html',action='store_true',help='Require and validate the first-class architect HTML report'); args=ap.parse_args()
    root=args.assessment.resolve()
    if not root.exists(): print('ERROR: assessment directory does not exist'); return 2
    try:r=validate(root, require_html=args.require_html)
    except Exception as e: print('ERROR: validator failed:',e); return 2
    # Prevent READY from coexisting with validation errors.
    report=root/'architecture-assessment.md'
    if report.exists() and r.errors:
        t=report.read_text(encoding='utf-8',errors='replace')
        if re.search(r'(?im)^\s*(?:\*\*)?Readiness(?:\*\*)?\s*:\s*READY\s*$',t):
            r.add('ERROR','READY_INVALID','Readiness is READY while validator ERROR findings remain.','architecture-assessment.md')
    order={'ERROR':0,'WARN':1,'INFO':2}
    for x in sorted(r.items,key=lambda z:(order.get(z['severity'],9),z['code'])):
        loc=f" [{x['path']}]" if x['path'] else ''
        print(f"{x['severity']} {x['code']}{loc}: {x['message']}")
    summary={'errors':len(r.errors),'warnings':len(r.warnings),'findings':r.items}
    print(f"\nAssessment validation: {len(r.errors)} error(s), {len(r.warnings)} warning(s)")
    if args.json:
        args.json.parent.mkdir(parents=True,exist_ok=True); args.json.write_text(json.dumps(summary,indent=2),encoding='utf-8')
    return 1 if r.errors or (args.strict_warnings and r.warnings) else 0
if __name__=='__main__': raise SystemExit(main())
