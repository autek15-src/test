# MuleSoft to AWS Native Architecture Skill

Reusable Codex/Claude-compatible skill package for evidence-driven analysis of MuleSoft applications targeted for AWS-native migration.

## What it does

The skill analyzes the complete application boundary, not just RAML/OpenAPI. It inspects Mule XML, DataWeave, policies, Maven/configuration, tests, runtime evidence, traffic data, related application/source dependencies, diagrams, and supporting documentation. It then rationalizes the Mule estate and proposes AWS-native replacement architecture only for Mule-owned capabilities.

Primary decision outcomes are RETIRE, CONSOLIDATE, ABSORB, or REIMPLEMENT.

## v1.3 architecture rules

The skill now explicitly enforces:

- **Lambda implementation default:** Node.js + TypeScript. Java is an exception requiring documented technical justification.
- **Consumer contract preservation:** existing consumer-facing interfaces are preserved by default to minimize coordinated consumer changes. Internal application components such as a UI/business-service layer may be changed when the benefit is explicitly compared with preserving compatibility.
- **Gateway/proxy simplification:** Mule gateway/proxy APIs should first be evaluated for direct API Gateway replacement without Lambda. Pass-through Lambda requires explicit justification. Purposeless pass-through proxies should be considered for retirement or consolidation.
- **Current-state API Interaction Flows:** every identified business/application flow that touches Mule is documented step-by-step with a detailed sequence diagram. Unrelated internal application flows are intentionally excluded.

See `references/gateway-contract-and-flow-modernization.md` for the detailed decision guidance and current official AWS source links.

## First-class architect report

`architecture-assessment.html` is the required **primary architect-facing deliverable**.

The report is self-contained and designed so an architect can understand the assessment without browsing the assessment filesystem. It includes:

- persistent hierarchical navigation and active-section tracking;
- global offline search;
- architect review snapshot and readiness status;
- current-state context and network diagrams;
- **API Interaction Flows** with direct flow navigation, business purpose, detailed steps, evidence, and per-flow sequence diagrams;
- current API, traffic, policy/security, and dependency inventories;
- source-to-target traceability and rationalization dispositions;
- migration-option comparison matrix plus interactive option tabs;
- target context and network diagrams;
- target API/cloud inventories, sizing, runtime/language, configuration/secrets, security parity, and AWS-limit headroom;
- consumer contract-preservation/change impact;
- ADRs, testing/equivalence, cutover/rollback, and risks/open questions;
- complete architecture assessment narrative;
- evidence register and completion-validation results;
- sortable/filterable large tables;
- click-to-expand architecture and sequence diagrams;
- an Embedded Artifact Explorer containing every canonical analysis artifact with in-report viewing and download actions;
- responsive and Print/PDF-friendly styling.

The Markdown/CSV/OpenAPI/PlantUML/JSON artifacts remain machine-readable and version-control friendly, but the HTML is the default file to give an architect for review.

## Automated lifecycle

The normal user does **not** need to run bootstrap or validation scripts by hand.

```text
preflight
  -> run_assessment.py prepare
  -> evidence discovery + architecture reasoning
  -> reconstruct API interaction flows + sequence diagrams
  -> rationalize gateways/proxies/contracts
  -> current + target architecture artifacts
  -> run_assessment.py validate
  -> agent remediation loop
  -> run_assessment.py finalize
       -> recursively render architecture + flow diagrams
       -> build first-class HTML report
       -> validate HTML completeness
  -> READY / READY WITH CONDITIONS / NOT READY
```

## Package layout

```text
mulesoft-aws-architecture-skill/
├── SKILL.md
├── README.md
├── CHANGELOG.md
├── constraints/
├── references/
│   ├── html-report-standard.md
│   └── gateway-contract-and-flow-modernization.md
├── templates/
│   └── diagrams/flows/FLOW-template.puml
├── scripts/
│   ├── run_assessment.py
│   ├── bootstrap_assessment.py
│   ├── scan_mule_project.py
│   ├── analyze_traffic.py
│   ├── validate_openapi.py
│   ├── validate_assessment.py
│   ├── render_diagrams.py
│   └── build_html_report.py
├── evals/
└── tests/
```

## Normal use with Codex/Claude

Give the agent the Mule repository and supporting evidence, then ask it to perform the assessment. Example:

```text
Analyze ./orders-mule for migration to AWS-native services.
Supporting Splunk exports, API Manager policy exports, network diagrams,
and downstream source are under ./migration-inputs.
Create the assessment under ./assessment.
```

The main human deliverable will be:

```text
./assessment/architecture-assessment.html
```

## Deterministic controller

For agent execution, CI, debugging, or skill development:

```bash
python scripts/run_assessment.py prepare ./assessment \
  --source-repo ./orders-mule \
  --inputs ./migration-inputs

python scripts/run_assessment.py validate ./assessment
python scripts/run_assessment.py finalize ./assessment
python scripts/run_assessment.py status ./assessment
```

## No required Python dependencies

The scripts use the Python standard library. The generated HTML has no external JavaScript/CSS/CDN dependency and can be opened offline.

PlantUML rendering is best-effort. Editable `.puml` source is always embedded in the report; rendered SVG/PNG is embedded when the environment can render PlantUML.

## Important limitation

The deterministic scripts cannot prove architectural correctness. AWS quotas/runtime support/pricing must be verified from current official sources during each assessment. The validator checks that required evidence exists and that measured requirements fit the recorded design.

## Package self-test

```bash
python scripts/run_quality_checks.py
```
