# Installation and Use

This bundle is intentionally agent-agnostic. `SKILL.md` is the entry point and the rest of the directory must remain beside it so relative references and scripts resolve.

## Repository-local use

Keep the complete skill directory in source control beside the migration project or in an approved internal skills repository, then configure Codex/Claude Code to load it.

Do not copy only `SKILL.md`; the skill depends on `references/`, `constraints/`, `templates/`, and `scripts/`.

## Direct prompt fallback

If an agent runtime does not support skills directly, instruct the agent to read `SKILL.md` and execute it as the governing workflow.

## Normal execution

Give the agent:

- MuleSoft repository;
- desired assessment output directory;
- all available supporting evidence locations.

The skill automatically performs prepare, evidence discovery, API interaction-flow reconstruction, gateway/contract rationalization, architecture analysis, validation, remediation, and finalization.

The final architect-facing deliverable is:

```text
assessment/architecture-assessment.html
```

Open this HTML directly in a modern browser. It is self-contained and works offline. It includes navigation, search, current/target diagrams, step-by-step API interaction flows and sequence diagrams, migration options, inventories, ADRs, evidence, validation, and the full embedded artifact explorer.

## Canonical API interaction-flow artifacts

The skill creates and validates:

```text
assessment/current-state/api-flow-inventory.csv
assessment/current-state/api-flow-steps.csv
assessment/current-state/api-flows.md
assessment/diagrams/flows/<flow-id>.puml
```

Only application/business flows traversing one or more Mule APIs belong here.

## Manual/debug use

For CI/troubleshooting/skill development:

```bash
python scripts/run_assessment.py prepare ./assessment \
  --source-repo /path/to/mule/repository \
  --inputs /path/to/supporting/evidence
python scripts/run_assessment.py validate ./assessment
python scripts/run_assessment.py finalize ./assessment
```

`finalize` validates the canonical artifacts, attempts to recursively render all PlantUML diagrams including API interaction-flow sequence diagrams, builds the HTML report, and reruns validation with HTML completeness checks enabled.

## Workflow state and validation

```text
assessment/.skill-run/state.json
assessment/validation/assessment-validation.json
assessment/validation/html-report-manifest.json
```

## Package self-test

```bash
python scripts/run_quality_checks.py
```
