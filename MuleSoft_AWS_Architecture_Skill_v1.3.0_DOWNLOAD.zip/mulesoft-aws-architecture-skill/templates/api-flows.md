# Current-State API Interaction Flows

This artifact documents only application/business flows that traverse one or more MuleSoft APIs. It does not document unrelated internal application workflows.

## Flow Coverage Summary

Describe how the identified business/API interaction flows were discovered and any known coverage gaps.

## Cross-Flow Observations

Document shared behaviors such as authentication, correlation IDs, repeated transformations, common downstreams, retry patterns, or duplicated Mule layers.

## Unknown or Unconfirmed Flows

List flows suggested by code, schedules, traffic, or documentation that could not be fully reconstructed.
