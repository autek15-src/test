# Flow record and project schema

`scripts/build_report.py` reads `project.json` plus one `flows/<id>.json` per endpoint and refuses to build on structural errors, so follow these shapes exactly. Fields marked (req) are required; everything else is optional but expected wherever you have the information. Strings may contain simple Markdown (`**bold**`, `` `code` ``, bullet lines starting with `- `); the builder renders it.

## Contents
1. `flows/<id>.json`
2. Checklist items (fixed ids)
3. Gap and conflict objects
4. `project.json`
5. Minimal example

---

## 1. `flows/<id>.json`

```jsonc
{
  "id": "EP-003-post-orders",                  // (req) stable id, same as file name and diagram name
  "app": "orders-exp-api",                     // (req) Mule application name
  "name": "Create order",                      // (req) short human title
  "type": "http",                              // (req) http | scheduler | jms | vm | anypoint-mq | db | sftp | file | salesforce | kafka | email | other
  "method": "POST",                            // http only
  "path": "/api/orders",                       // http: full path incl. listener basePath; others: queue/topic/schedule/dir
  "full_url": "https://orders-exp-api.prod.example.com/api/orders",   // for the documented env, if known
  "spec_ref": "src/main/resources/api/orders.raml#/orders:post",
  "implementing_flow": "post:\\/orders:orders-config",
  "entry_evidence": "src/main/mule/orders-impl.xml:40-44",
  "summary": "One paragraph: what this endpoint does end to end.",   // (req)

  "business": {                                // (req)
    "capability": "Order capture",
    "actor": "Customer via Web Portal",        // who performs the action (role via application)
    "trigger": "Customer clicks 'Place order' at checkout",
    "rules": [                                 // business rules visible in code
      {"rule": "Orders over 10,000 are held for manual review", "basis": "orders-impl.xml:132 choice `payload.total > 10000`"}
    ],
    "entities": ["Order", "Customer", "Product"],
    "outcomes": {
      "success": "Order persisted in SAP; confirmation event published; customer sees order number",
      "failures": ["Validation errors → 400 with field list", "SAP unavailable → 503, no order created, customer told to retry"]
    },
    "compliance": "Card data never reaches this API; customer email is masked in logs (mask-dw.dwl)",
    "sla": "responseTimeout 5s to SAP, 3 retries → worst case ~15s",
    "inference_notes": "Actor inferred from web-portal route guard requireRole('customer') (web-portal/src/routes.tsx:88)"
  },

  "participants": [                            // (req) must match aliases used in the diagram
    {"alias": "Customer", "name": "Customer (Web Portal)", "kind": "actor"},
    {"alias": "UI", "name": "Web Portal UI", "kind": "upstream", "evidence": "web-portal/src/api/orders.ts:41"},
    {"alias": "GW", "name": "API Manager policies", "kind": "gateway"},
    {"alias": "EXP", "name": "orders-exp-api", "kind": "mule-app"},
    {"alias": "SAP", "name": "SAP S/4HANA", "kind": "downstream", "resolved": "sap-prd.internal:8443", "evidence": "config-prod.yaml:sap.host"},
    {"alias": "MQ", "name": "Anypoint MQ orders.events", "kind": "async"}
  ],

  "policies": [
    {"name": "client-id-enforcement", "config": "headers client_id/client_secret", "effect": "401 if missing/invalid", "evidence": "API Manager screenshot 2026-08-30"}
  ],

  "diagram_files": ["EP-003-post-orders.mmd"],  // (req) files in report/diagrams/, main first (scenario diagrams are listed under scenarios[])

  "scenarios": [                               // (req) ≥1 — the business flows this endpoint carries; see mulesoft-tracing.md §12
    {"id": "S1", "name": "New order", "discriminator": "payload.type == 'NEW' (choice orders-impl.xml:130)", "actor": "Customer via Web Portal",
     "business": "Customer places a first-time order; created in SAP, event published", "steps": "1-11",            // step numbers in the MAIN diagram/table
     "outcome": "201 with orderId", "downstream": ["SAP S/4HANA", "Anypoint MQ"], "production_share": "91% of POST /orders (30d)",
     "evidence": ["orders-impl.xml:130-171", "splunk: … | stats count by payload.type"]},
    {"id": "S2", "name": "Reorder", "discriminator": "payload.type == 'REORDER'", "actor": "Customer via Web Portal (Order history → Reorder)",
     "business": "Copies a previous order's lines, re-prices them, then follows the new-order path",
     "diagram_file": "EP-003-S2-reorder.mmd",  // own diagram when the path diverges; then this scenario's own numbered steps go below
     "steps_own": [ {"n": 1, "from": "UI", "to": "EXP", "technical": "POST /api/orders {type: REORDER, sourceOrderId}", "functional": "…", "business": "…", "evidence": "…"} ],
     "outcome": "201 with new orderId", "downstream": ["SAP S/4HANA", "Pricing service", "Anypoint MQ"], "production_share": "7%",
     "evidence": ["orders-impl.xml:180-240", "web-portal/src/pages/OrderHistory.tsx:112"]},
    {"id": "S3", "name": "Unknown type value X7", "discriminator": "payload.type == 'X7'", "actor": "❓", "business": "❓ — GAP-4", "steps": "12-13", "outcome": "202", "evidence": ["orders-impl.xml:245"]}
  ],

  "steps": [                                   // (req) one row per numbered arrow in the MAIN diagram (n must match autonumber)
    {"n": 1, "from": "UI", "to": "EXP", "technical": "POST /api/orders, JSON body {items[], customerId}", "functional": "Submit new order", "business": "Customer commits to purchase", "evidence": "web-portal/src/api/orders.ts:41; orders-impl.xml:40", "scenarios": ["S1", "S2", "S3"]},   // optional: which scenarios pass through this step
    {"n": 2, "from": "EXP", "to": "EXP", "technical": "validate-order sub-flow: validation:is-not-null on customerId, foreach item is-number qty", "functional": "Reject malformed orders early", "business": "Only complete orders reach SAP", "evidence": "orders-impl.xml:60-78"}
  ],

  "branches": [
    {"location": "orders-impl.xml:130 choice", "condition_expr": "payload.total > 10000", "condition_business": "High-value order", "paths": ["when: set status HOLD, notify reviewers (steps 7-8)", "otherwise: submit to SAP (steps 9-11)"]}
  ],

  "error_paths": [
    {"trigger": "HTTP:TIMEOUT or HTTP:CONNECTIVITY from SAP", "handler": "orders-impl.xml:190 on-error-propagate type=HTTP:TIMEOUT,HTTP:CONNECTIVITY", "retries": "until-successful 3x / 2000ms", "logged": "ERROR 'SAP unavailable' with correlationId", "response": "503 {code: SAP_UNAVAILABLE}", "side_effects": "No order created; no event published", "evidence": "orders-impl.xml:190-203"}
  ],

  "async": [
    {"construct": "anypoint-mq:publish", "target": "orders.events", "consumer": "notif-prc-api (EP-014)", "failure": "logged only; caller already got 201", "evidence": "orders-impl.xml:170"}
  ],

  "upstream": [                                // (req; may be empty with a gap)
    {"consumer": "Web Portal", "user_type": "Customer", "action": "Checkout → Place order", "auth": "client_id portal-web-prod", "evidence": ["web-portal/src/api/orders.ts:41", "splunk: 97% of calls client_id=portal-web-prod (30d)"]}
  ],

  "downstream": [                              // (req; may be empty with a gap)
    {"system": "SAP S/4HANA Order Mgmt", "connector": "http:request", "target": "https://sap-prd.internal:8443/api/orders", "resolved_from": "config-prod.yaml:sap.host", "purpose": "Create sales order", "linked_endpoint": null, "evidence": ["orders-impl.xml:150", "Architecture-Overview-v7.pdf p.3"]}
  ],

  "data": [
    {"entity": "Order", "fields": "orderId, customerId, items[sku, qty, price], total", "collibra": "Business Term 'Sales Order' (id 0a1b…)", "classification": "Confidential", "mapping": "sku ← MATNR, total ← NETWR"}
  ],

  "production": {
    "volume": "≈12k req/day (30d avg)",
    "callers": "portal-web-prod 97%, batch-reconcile 3%",
    "latency": "p50 310ms, p95 1.2s",
    "errors": "0.6% 4xx (mostly 400 validation), 0.1% 503",
    "observed_paths": "manual-review branch hit in 1.8% of requests (log 'ORDER_HOLD')",
    "evidence": ["splunk: index=mule app=orders-exp-api path=/api/orders earliest=-30d | stats ..."]
  },

  "sources": [                                 // (req) everything used
    {"type": "code", "ref": "orders-exp-api/src/main/mule/orders-impl.xml:40-210"},
    {"type": "config", "ref": "orders-exp-api/src/main/resources/config-prod.yaml", "note": "sap.host, sap.timeout"},
    {"type": "spec", "ref": "orders-exp-api/src/main/resources/api/orders.raml"},
    {"type": "upstream-code", "ref": "web-portal/src/api/orders.ts:41"},
    {"type": "diagram", "ref": "Architecture-Overview-v7.pdf p.3"},
    {"type": "splunk", "ref": "index=mule app=orders-exp-api earliest=-30d | stats count by client_id"}
  ],

  "conflicts": [ /* see §3 */ ],
  "checklist": [ /* see §2 — all 15 ids required */ ],
  "gaps": [ /* see §3 */ ],
  "confidence": "high",                         // (req) high | medium | low
  "confidence_basis": "Fully traced; upstream and SAP confirmed by code and Splunk; policy list from screenshot."
}
```

Source `type` values: `code`, `config`, `spec`, `policy`, `upstream-code`, `downstream-code`, `diagram`, `collibra`, `splunk`, `anypoint`, `doc`, `user`, `other`.

## 2. Checklist items

Include all 16 with these ids; `status` ∈ `done | partial | blocked`; `note` explains (required for partial/blocked).

| id | item |
|---|---|
| C01 | Entry point identified from code/spec/policy with file:line |
| C02 | API Manager policies applied (or gap recorded) |
| C03 | Every flow-ref / sub-flow followed to its definition |
| C04 | Every choice branch incl. otherwise covered |
| C05 | Every error handler covered (try, flow, global, APIkit defaults, connector types) |
| C06 | Every async / parallel / retry / loop construct covered |
| C07 | Every outbound call resolved to a target for the documented environment |
| C08 | Every DataWeave transform described in business terms |
| C09 | Response shape and status codes documented per path |
| C10 | Upstream consumer(s) and user type identified with evidence |
| C11 | Downstream systems named with evidence |
| C12 | Business meaning stated with basis for each inference |
| C13 | Production evidence attached (or gap recorded) |
| C14 | Diagram and narrative match step-for-step |
| C15 | Sources list complete |
| C16 | All business scenarios behind the endpoint identified (discriminators, upstream call sites, production data); each has business meaning, step range and own diagram where paths diverge |

```json
{"id": "C05", "status": "partial", "note": "Global error handler found (global-errors.xml:10); connector-specific DB:* mappings not exercised — see GAP-7"}
```

## 3. Gap and conflict objects

```json
{"id": "GAP-3", "what": "Payments host `${payments.host}` is a secure property; plaintext not available", "why": "Cannot name the downstream payment system with certainty", "resolve": "Provide decrypted config-prod.yaml or Runtime Manager properties, or Splunk dest host for flow 'charge-card'", "severity": "major", "affects": ["EP-003-post-orders"]}
```

`severity`: `blocking` (flow cannot be trusted), `major` (a participant/branch unnamed or unverified), `minor` (cosmetic/naming).

```json
{"topic": "SAP timeout", "code_says": "5000ms (config-prod.yaml:sap.timeout)", "prod_says": "p99 4.8s", "doc_says": "2s (Design v3 §4.2)", "resolution": "Code wins", "impact": "Callers may wait up to 15s incl. retries"}
```

## 4. `project.json`

```jsonc
{
  "title": "Orders Integration — End-to-End Sequence Documentation",   // (req)
  "environment": "prod",                                               // (req)
  "generated": "2026-09-03",
  "author": "Claude (mulesoft-sequence-docs skill) for D",
  "applications": [                                                    // (req)
    {"name": "orders-exp-api", "layer": "experience", "repo": "git@…/orders-exp-api", "version": "1.4.2 (Runtime Manager, tag v1.4.2)", "description": "Customer-facing orders API"}
  ],
  "overview": "Executive summary in a few paragraphs: purpose, scope, headline findings, biggest gaps.",   // (req)
  "actors": [{"name": "Customer", "via": "Web Portal", "description": "Registered customer placing and tracking orders"}],
  "systems": [{"name": "SAP S/4HANA", "role": "System of record for orders", "hosts": "sap-prd.internal"}],
  "context_diagram": "SYS-context.mmd",                                // flowchart in report/diagrams/
  "endpoint_count_expected": 23,                                       // from work/endpoints.md; builder checks it
  "inputs_received": ["Mule repos: orders-exp-api, orders-prc-api", "web-portal repo", "Architecture-Overview-v7.pdf", "Splunk export 30d", "Collibra glossary CSV"],
  "inputs_missing": ["API Manager policy export (screenshot used)", "sap-sys-api repo"],
  "methodology_notes": "Optional additions to the standard methodology section.",
  "sources": [ /* bibliography, same shape as flow sources */ ],
  "conflicts": [ /* project-level; flow-level ones are rolled up automatically */ ],
  "gaps": [ /* project-level; flow-level ones are rolled up automatically */ ]
}
```

## 5. Minimal example

The builder will build (with warnings) from a record that has only the required fields, but the report will show empty sections and the checklist will be marked missing — use that only while iterating. A finished record has every section either filled or backed by a gap.
