# Sequence diagram conventions (Mermaid)

One `sequenceDiagram` per endpoint in `report/diagrams/<id>.mmd`. The builder embeds it in the HTML and renders `.svg` with `mmdc` when available. Diagrams must render in Mermaid 10/11 — keep to the syntax below.

## Participants

Order left to right: actor → upstream application → gateway/policies (if any) → the Mule app (one lane per app in scope) → downstream systems in first-call order → async consumers last.

```
sequenceDiagram
    autonumber
    actor Customer as Customer<br/>(Web Portal)
    participant UI as Web Portal UI
    participant GW as API Manager<br/>(client-id, rate-limit)
    participant EXP as orders-exp-api
    participant PRC as orders-prc-api
    participant SAP as SAP S/4HANA<br/>(sap-prd.internal)
    participant MQ as Anypoint MQ<br/>orders.events
```

- Use short aliases and put the resolved host/queue/table in the display name — that is what makes the diagram evidence rather than a picture.
- Use `actor` for humans and scheduled/system actors; `participant` for systems.
- `autonumber` on, so the step table in the report can reference step numbers. Keep the numbers stable between diagram and narrative: the step table's `n` must match.

## Arrows

- `->>` synchronous request, `-->>` response, `-)` asynchronous (fire-and-forget), `-x` lost/failed message.
- Label every arrow with method + path/operation and the meaningful data, e.g. `GET /orders/{id}` , `SELECT ORDERS by ORDER_ID`, `upsert Account (ExternalId__c)`, `publish OrderCreated`.
- Responses show status + shape: `200 Order JSON`, `404 APP:ORDER_NOT_FOUND`, `429 rate limited`.

## Control flow

| Mule | Mermaid |
|---|---|
| `choice when/otherwise` | `alt <business condition>` / `else <other>` / `end` |
| optional step (validation passes, cache hit) | `opt <condition>` … `end` |
| `foreach`, `until-successful` | `loop for each line item` / `loop retry ≤3, 2s backoff` |
| `scatter-gather`, `async` | `par SAP lookup` / `and Pricing lookup` / `end` |
| error path that ends the sequence | `alt` block, or `break <error>` … `end` when supported; prefer `alt` for portability |
| critical section / transaction | `critical` … `option` … `end` (Mermaid ≥ 9.x) |
| business meaning at a step | `Note over EXP,SAP: Orders over 10,000 require manual review (choice at orders-impl.xml:132)` |
| sub-flow reused elsewhere | `EXP->>EXP: sub-flow validate-order (see SF-validate-order)` and a separate diagram file `SF-validate-order.mmd` |

Write conditions in business language first with the technical expression in the step table, not in the diagram: `alt customer is VIP` not `alt vars.tier == "VIP"`.

## Error paths

Every error handler that produces a distinct outcome for the caller gets its own `alt`/`else` branch showing: where it originates (arrow from the downstream with the error), the handler action (log, compensate, map), and the response to the caller with status code. Group connector errors that map to the same outcome into one branch labelled with the error types.

```
    EXP->>SAP: GET /orders/{id}
    alt 200
        SAP-->>EXP: order
        EXP-->>UI: 200 Order JSON
    else 404 (HTTP:NOT_FOUND)
        SAP-->>EXP: 404
        EXP-->>UI: 404 {code: ORDER_NOT_FOUND}
    else timeout / connectivity (HTTP:TIMEOUT, HTTP:CONNECTIVITY) — retried 3x
        SAP--xEXP: no response
        EXP-->>UI: 504 {code: UPSTREAM_TIMEOUT}
    end
```

## Async

```
    EXP-)MQ: publish OrderCreated {orderId, customerId}
    Note right of MQ: async — response to caller does not wait
    MQ-)NOTIF: deliver (consumer notif-prc-api EP-014)
```

## Multiple business scenarios on one endpoint

The endpoint's main diagram (`EP-<nnn>-….mmd`) shows the shared trunk and one `alt`/`else` block per scenario, labelled with the scenario id and business name:

```
    alt S1 — New order (payload.type == "NEW")
        EXP->>SAP: POST SalesOrderSet
        ...
    else S2 — Reorder (payload.type == "REORDER", copies a previous order)
        Note over EXP: see EP-003-S2-reorder.mmd
        EXP->>EXP: (scenario S2 — 11 steps, separate diagram)
    else S3 — Quote conversion (payload.quoteId present)
        ...
    end
```

When a scenario diverges materially (different actor or downstream chain, or more than ~8 scenario-specific steps), it gets its own full diagram `EP-<nnn>-S<k>-<slug>.mmd` with `autonumber` restarting at 1 and its own step table in the record's `scenarios[k].steps`. The main diagram keeps only the entry, the discriminator and a reference note. Every scenario diagram declares the same participant aliases as the main one for the participants it uses.

## Size and splitting

- Target ≤ 60 arrows per diagram. If longer, split: `<id>.mmd` (main, with self-calls referencing sub-diagrams) and `<id>-<part>.mmd`. List every file in the flow record `diagram_files`.
- Never collapse branches to fit — split instead.

## Gaps inside diagrams

Unknowns are drawn, not hidden:

```
    participant UNK as ❓ Unknown system<br/>(${payments.host} unresolved — GAP-3)
```

## Legibility

- No participant names longer than ~28 characters per line; use `<br/>`.
- Escape special characters (`#`, `;`) as `#35;` `#59;` in labels; avoid `:` inside `alt` labels when possible or wrap the text.
- Do not use `%%` comments to carry evidence — evidence goes in the flow record.

## Naming files

`EP-<nnn>-<method>-<path-slug>.mmd` for endpoints (`EP-003-post-orders.mmd`), `EP-<nnn>-S<k>-<slug>.mmd` for a scenario with its own diagram (`EP-003-S2-reorder.mmd`), `SF-<slug>.mmd` for reusable sub-flows, `SYS-context.mmd` for the system context (a `flowchart LR` of applications, actors and systems — the only non-sequence diagram).
