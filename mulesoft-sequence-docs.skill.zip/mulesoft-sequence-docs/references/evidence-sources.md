# Evidence sources: how to mine them and how to cite them

Use in Phase 3 (enrichment) and Phase 4 (verification). Every claim in the report should be traceable to one of the source types below. The precedence is: code/config → observed production behaviour → documentation (see SKILL.md).

## Contents
1. Citation format
2. Upstream source code (UI, other apps)
3. Downstream source code
4. Architecture and network diagrams
5. Collibra
6. Splunk
7. Anypoint (API Manager, Runtime Manager, Monitoring, Exchange, MQ)
8. Written documentation
9. Handling conflicts
10. Confidence ratings

---

## 1. Citation format

Every `sources` entry in a flow record uses this shape (see `flow-record-schema.md`):

```json
{"type": "code", "ref": "orders-api/src/main/mule/orders-impl.xml:112-158", "note": "get:\\/orders\\/(id):orders-config flow"}
{"type": "config", "ref": "orders-api/src/main/resources/config-prod.yaml:sap.host", "note": "resolved to sap-prd.internal:8443"}
{"type": "spec", "ref": "orders-api/src/main/resources/api/orders.raml#/orders/{id}:get"}
{"type": "policy", "ref": "API Manager apiId 18223344 — client-id-enforcement, rate-limiting(100/min)", "note": "screenshot 2026-08-30"}
{"type": "upstream-code", "ref": "web-portal/src/api/orders.ts:41", "note": "fetchOrder() called from OrderDetailPage (customer role)"}
{"type": "downstream-code", "ref": "sap-sys-api/src/main/mule/sap-orders.xml:77"}
{"type": "diagram", "ref": "Architecture-Overview-v7.pdf p.3", "note": "names sap-prd.internal as 'SAP S/4HANA Order Mgmt'"}
{"type": "collibra", "ref": "asset 0a1b2c3d Order (Business Term); lineage Orders API -> SAP ORDERS table"}
{"type": "splunk", "ref": "index=mule app=orders-api path=\"/api/orders/*\" earliest=-30d | stats count by client_id", "note": "97% portal-web-prod, 3% batch-reconcile"}
{"type": "anypoint", "ref": "API Manager > orders-api > Analytics, 2026-08 — p95 420ms, 0.4% 5xx"}
{"type": "doc", "ref": "Confluence: Orders Integration Design v3 §4.2", "note": "says SLA 2s; code timeout is 5s (conflict logged)"}
{"type": "user", "ref": "User statement 2026-09-03: 'the mobile app also calls this'", "note": "unverified"}
```

Precision matters: a file path without a line range is acceptable for short files; for anything over ~100 lines give the range. For Splunk give the full query and time window so it can be re-run. For diagrams give page/sheet.

## 2. Upstream source code

Goal: name each consumer, the user type, and the business action that triggers the call.

Search strategies (adapt to language):
- Grep for the endpoint path segments and the base path: `grep -rn "orders" --include=*.ts --include=*.js --include=*.java --include=*.xml --include=*.cs --include=*.py`. Paths are often built from constants (`API_BASE + '/orders/' + id`) — search for the constant too.
- Look for API client layers (`services/`, `api/`, `clients/`, generated SDKs from RAML/OAS, `HttpClient`, `axios.create`, `fetch(`, `RestTemplate`, `WebClient`, Mule `http:request` with the host of the app under study, Salesforce Named Credentials + Apex callouts, Boomi/Informatica connections).
- Trace from the API call up to the UI component / route / controller: what screen, what button, what role. Role evidence: route guards, `hasRole(...)`, permission constants, Okta/Azure AD group checks, feature flags. Express the actor as `<Role> via <Application>` (e.g. "Customer via Web Portal", "Claims Agent via Agent Desktop", "Nightly Reconciliation Job").
- For headers: which client_id/API key the upstream sends (often in its config) — that links to Anypoint contracts and Splunk fields.
- Note request payload construction: what the upstream fills in tells you the business context (e.g. `channel: "MOBILE"`).

If no upstream code is available, fall back to §6/§7 production callers, then §8 documentation, and record the gap.

## 3. Downstream source code

Goal: name the system and describe what it does with the call, to the depth needed to explain outcomes and error semantics for this endpoint.

- Match the resolved outbound host/path/queue/table/object to the downstream repo's listener/controller/handler/consumer.
- Capture: what the downstream validates (source of 4xx you will see), what it persists or triggers (business side effect), what it returns, its own downstream (one more hop if it is significant, e.g. the system of record). For another in-scope Mule app, link its endpoint id instead of re-documenting.
- Database targets: identify tables and key columns from the SQL; map to Collibra data assets when possible.

## 4. Architecture and network diagrams

- Extract text from PDFs / images (OCR if needed) and read the diagram visually. Record system names, zones (DMZ, internal, cloud), load balancers, gateways, and any labelled protocols/ports.
- Use them to translate hostnames into system names and to spot hops the code does not show (API proxy, WAF, API gateway, ESB, VPN). Those hops are participants in the sequence when they can alter or reject the call (policies, TLS termination, IP allowlists).
- Diagrams age. When a diagram shows a system that the code does not call (or vice versa), log it in the conflict log — it may be a decommissioned system or an undocumented dependency.

## 5. Collibra

Use Collibra (via connector/API export or user-provided CSV/JSON/screenshots) for:
- Business glossary: canonical names and definitions of entities the endpoint handles (Order, Customer, Policy). Use these names in the business-meaning text and map code fields to them.
- Data assets and lineage: which datasets/tables/APIs feed which; confirms downstream targets and reveals consumers you did not find in code.
- Data classification (PII, confidential) → note compliance handling in the sequence (masking, encryption, audit).
- Data owners / stewards → helpful for "who to ask" in gaps.

Record asset ids/names. Collibra is authoritative for business vocabulary, but for "what actually flows" the code and production data still win.

## 6. Splunk

Typical extraction (adapt index/fields to the customer's setup; Mule logs usually carry `correlationId`, `flowName`, `app`, `env`, `path`, `method`, `statusCode`, `client_id`, `responseTime`):

```
index=mule env=prod app=<app> earliest=-30d | stats count by method path          # observed endpoints
... | stats count by client_id, path                                             # upstream callers
... | stats p50(responseTime) p95(responseTime) count(eval(statusCode>=500)) by path
... path="<path>" statusCode>=400 | stats count by statusCode, errorType, errorMessage   # real error distribution
... flowName="<flow>" | head 20                                                  # sample transactions to follow a correlationId
index=* host=<downstream-host> ...                                               # confirm downstream received the call
```

Use production data to: confirm the endpoint list (reverse check), name callers, quantify volume/latency/error rates, discover which choice branches are actually exercised (log messages per branch), and detect targets that differ from config (e.g. a host override in Runtime Manager properties). Always cite query + time window. Do not treat 30 days of no traffic as proof an endpoint is dead — say "no traffic observed in window".

## 7. Anypoint Platform

- **API Manager**: policy list and configuration per API instance (order matters), contracts (client applications approved → upstream names and owners), proxy vs basic endpoint, SLA tiers, analytics (requests by client app, response codes, latency).
- **Runtime Manager**: deployed version (tag/commit — confirm you are reading the same code as prod), properties set at deploy time (override repo config — highest-precedence config source!), workers/vCores, alerts.
- **Anypoint Monitoring / Visualizer**: dependency map of which apps call which — strong evidence for upstream/downstream between Mule apps.
- **Exchange**: the published RAML/OAS (may be newer or older than the repo copy — compare versions), documentation pages, consumer list.
- **Anypoint MQ**: queue/exchange stats, dead-letter queues, which apps subscribe.

If an Anypoint connector/MCP is available, query it; otherwise ask for exports/screenshots and log gaps for whatever is missing.

## 8. Written documentation

Design documents, Confluence pages, runbooks, ticket descriptions and README files provide: business purpose, actor names, SLAs, known issues, and history. Extract these into the business-meaning text with citations, and check every technical claim (hosts, status codes, timeouts, retry counts, field names) against the code. Where documentation is the only source for something (e.g. the name of the user role), keep it but mark confidence as "doc-only".

## 9. Handling conflicts

Log every disagreement in the flow record's `conflicts` list and roll them up to `project.json`:

```json
{"topic": "Timeout to SAP", "code_says": "responseTimeout=5000 (config-prod.yaml:sap.timeout)", "prod_says": "p99 4.8s, 0.2% HTTP:TIMEOUT", "doc_says": "2s SLA (Design v3 §4.2)", "resolution": "Code wins: 5s. Doc is stale.", "impact": "Callers may wait up to 5s + retries (3x) = 15s worst case"}
```

Rules of thumb:
- Code vs doc → code wins; note that the doc is stale.
- Code vs production → investigate: usually a Runtime Manager property override, a different deployed version, a proxy, or feature-flag; report what you found; if unresolved, production wins for "what happens today" and the discrepancy is a gap with high importance.
- Doc vs doc → prefer the newer/owner-maintained one; note both.
- Never average or blend; state each source's claim.

## 10. Confidence ratings

Assign one per endpoint (and optionally per step) in the flow record:

- **high** — traced fully in code, targets resolved for the env, upstream and downstream confirmed by code or production data.
- **medium** — code fully traced, but upstream or downstream naming relies on documentation only, or production data unavailable.
- **low** — a referenced flow/config/spec was missing, or a secure property could not be resolved, or the path could not be exercised through to a response.

Confidence must be justified by the gap list: a `high` rating with open blocking gaps is a contradiction the builder will flag.
