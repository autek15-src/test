# Report structure

`scripts/build_report.py` produces `report/index.html` from `project.json` and `flows/*.json`. This file describes what it renders so you know what to fill in, and the writing standard for each section. Do not hand-edit the HTML — fix the records and rebuild.

## Output tree

```
report/
├── index.html                 # single-page report; Mermaid rendered client-side (CDN) or inlined with --inline-mermaid
├── diagrams/
│   ├── SYS-context.mmd        # system context flowchart
│   ├── EP-001-….mmd           # one per endpoint (+ SF-*.mmd sub-flows, EP-…-part.mmd splits)
│   └── *.svg                  # rendered with mmdc when --render-svg and mmdc are available
├── data/
│   ├── project.json           # copies of the inputs, for audit
│   └── flows/*.json
└── build-log.txt              # validation warnings and counts
```

## Sections rendered

1. **Cover & executive overview** — title, environment, generated date, applications table (name, layer, version), `overview` text, headline numbers (endpoints, high/medium/low confidence, open gaps by severity, conflicts).
2. **System context** — the `SYS-context.mmd` flowchart plus actors and systems tables.
3. **Endpoint index** — sortable table: id, app, method/type, path, actor, scenarios, downstream systems, async, confidence, open gaps, link.
4. **Endpoint sections** (one per flow record, ordered by id):
   - Header: id, name, app, method + path, full URL, spec ref, implementing flow, entry evidence, confidence badge.
   - Summary.
   - Business & functional meaning: capability, actor, trigger, rules (with basis), entities, outcomes, compliance, SLA, inference notes.
   - Business scenarios: table (id, name, discriminator, actor, outcome, downstream, production share, steps) followed by each scenario's own diagram and step table where it has one.
   - Policies.
   - Participants table (alias, name, kind, resolved target, evidence).
   - Sequence diagram(s) — embedded Mermaid with a "view source / download .mmd / .svg" strip.
   - Step table: `#`, from → to, technical, functional, business, evidence — the `#` matches the diagram's autonumber.
   - Branches & decisions.
   - Error paths.
   - Async / background work.
   - Upstream consumers.
   - Downstream systems (with cross-links when `linked_endpoint` is set).
   - Data elements (Collibra mapping, classification).
   - Production evidence.
   - Sources used.
   - Conflicts.
   - Verification checklist (16 items with status colouring).
   - Gaps.
5. **Gap register** — all gaps (project + rolled up), grouped by severity, with affected endpoints.
6. **Conflict log** — all conflicts with resolution.
7. **Coverage & verification** — counts check (expected vs documented endpoints), unreachable flows (from `work/inventory.json` if passed with `--inventory`), checklist completion heat-map.
8. **Methodology** — the phases, precedence rules, confidence definitions, plus `methodology_notes`.
9. **Bibliography** — deduplicated union of all sources, grouped by type.

## Writing standard

- **Summary**: 3–6 sentences, present tense, names the actor, the outcome and the systems touched. A reader who reads only this paragraph should be able to answer "what does this endpoint do and who uses it".
- **Technical column**: exact component and parameters (`http:request GET {sap.host}/api/orders/{id}, responseTimeout 5000`).
- **Functional column**: what the step accomplishes in the flow ("fetch the order from the system of record").
- **Business column**: why it matters to the business/user ("the customer sees live order status, not a cached copy"). Leave blank only with a reason (e.g. "plumbing – correlation id").
- **Evidence**: file:line or citation, never empty for a step that names a system, a rule or a status code.
- Be explicit about negatives when they matter: "no retry", "no authentication", "response body not validated".
- Prefer the customer's business vocabulary (Collibra glossary, doc names) over connector vocabulary in the business columns.

## Deliverable checklist (before handing over)

- [ ] `build-log.txt` has no errors and every warning is either fixed or acknowledged in a gap.
- [ ] Endpoint count in index == `endpoint_count_expected` == `work/endpoints.md`.
- [ ] Every endpoint has ≥1 scenario, and any `choice` on a request/message field maps to a scenario or is marked technical-only.
- [ ] Each diagram renders (open the HTML or check `.svg` files exist for each `.mmd`).
- [ ] At least three endpoints re-read side by side (diagram vs step table vs code).
- [ ] Gap register reviewed: each gap has a resolution path.
- [ ] `report/` and `work/` (audit trail) delivered.
