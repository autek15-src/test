# Tracing MuleSoft code into sequence steps

Use this while walking flows in Phase 2. It covers Mule 4 primarily, with Mule 3 equivalents where they differ. The goal is that every construct you meet in the XML becomes either a diagram step, a branch, a note, or an explicit "no observable effect" decision — never something you skip because it looked like plumbing.

## Contents
1. Where things live in a Mule project
2. Entry points (inbound sources) and what the inventory script may miss
3. Flow composition: flow-ref, sub-flow, private flows
4. Routers and branching
5. Error handling — the most commonly under-documented area
6. Asynchrony, retries and iteration
7. Outbound connectors and how to resolve targets
8. DataWeave — reading transforms for business meaning
9. Policies and API gateway behaviour
10. Mule 3 differences
11. Hidden-behaviour checklist
12. Discovering multiple business scenarios behind one endpoint

---

## 1. Where things live

```
src/main/mule/*.xml            flows, sub-flows, global configs (Mule 4)
src/main/app/*.xml             same, Mule 3
src/main/resources/api/        RAML / OAS spec + examples, traits, types, !includes
src/main/resources/*.dwl       external DataWeave scripts (referenced via resource="...")
src/main/resources/*.properties|yaml|yml   config-<env>.yaml, secure properties
src/main/resources/log4j2.xml  which loggers actually emit (Splunk searchability)
mule-artifact.json             configs list, secureProperties, minMuleVersion
pom.xml                        connectors, shared libs, exchange API dependencies (spec can come from Exchange, not the repo)
mule-domain-config.xml         (domain project) shared listener/connector configs used by several apps
```

Global elements sit at the top of a config file outside any flow: `http:listener-config`, `http:request-config`, `db:config`, `jms:config`, `salesforce:sfdc-config`, `sftp:config`, `anypoint-mq:config`, `os:object-store`, `ee:object-store-caching-strategy`, `apikit:config`, `api-gateway:autodiscovery`, `configuration-properties`, `secure-properties:config`, global `error-handler`, `configuration defaultErrorHandler-ref`.

Property resolution: `${key}` is looked up in every registered `configuration-properties` file, with environment selected by e.g. `file="config-${env}.yaml"` and `env` supplied at deploy time (Runtime Manager property). Secure properties (`![...]` values) cannot be decrypted from the repo — record the key name and mark the value as a gap unless the user gives the plain value or the production host is visible in Splunk/Anypoint.

## 2. Entry points

| Construct | What to capture |
|---|---|
| `http:listener path="..." allowedMethods="..." config-ref="..."` | Full path = listener-config `basePath` + listener `path`; wildcard `/*` usually feeds an APIkit router; `allowedMethods` absent means all |
| `apikit:router config-ref="X"` + `apikit:config api="api.raml"` | Each resource+method in the spec → endpoint. Implementing flow is named `get:\/orders\/(id):X` (Mule 4) or `get:/orders/{id}:X` (Mule 3). `get:\/orders:application\/json:X` when the spec has multiple request content types. Missing flow → APIkit returns the spec `example` (if `apikit:config` has `outboundHeadersMapName`/ mocking) or 404/501 — document either way |
| `apikit:console` | Non-business endpoint; list it, mark as tooling, note if exposed in prod |
| `scheduler` (`fixed-frequency`, `cron`) | Trigger = time; actor = system; include the schedule and timezone in the business meaning |
| `jms:listener`, `anypoint-mq:subscriber`, `vm:listener`, `kafka:message-listener` | Queue/exchange name resolved; the "caller" is whoever publishes — find the publisher in code or Anypoint MQ stats |
| `db:listener`, `sftp:listener`, `ftp:listener`, `file:listener`, `email:listener-*` | Polling frequency, watermark, directory/table, what happens to the source after processing (move/delete) |
| `salesforce:subscribe-topic-listener`, `replay-channel-listener`, `modified-object-listener` | Platform event / topic name; Salesforce is both upstream and downstream in these flows |
| `sockets:listener`, `wsc` inbound (rare), `mule:poll` (Mule 3) | Capture as-is |
| Batch jobs (`batch:job`) | Not an entry point themselves; triggered inside a flow — but they fork the sequence; see §6 |

**What the inventory script may miss** (check by hand): listeners defined in a domain project; flows added by shared libraries or `import` of another config; RAML pulled from Exchange (not in repo — check `pom.xml` for `<classifier>raml</classifier>` dependencies and ask the user for the spec); endpoints exposed only through an API proxy in API Manager (the proxy adds a base path and policies); resources defined by RAML `resourceTypes`/traits expansion; OAS `servers` base paths.

## 3. Flow composition

- `flow-ref name="X"` — follow into `X`. Sub-flows run inline on the same thread and share the event; `flow`s referenced via flow-ref run their own error handler first. In the diagram, show a sub-flow either inline (short) or as a self-call with a `Note` naming the sub-flow and a link to its sub-diagram (long or reused).
- Private flows (no source) are only reachable by flow-ref — the call graph tells you which endpoints share them. Reused sub-flows should be documented once as a sub-diagram and referenced, with the business meaning restated in each endpoint's context if it differs.
- `target="varName"` on a call stores the result in a variable instead of the payload — track this or you will misread what gets returned.
- `set-variable`, `set-payload`, `remove-variable` — usually not diagram arrows, but capture them when they carry business meaning (e.g. `set-variable name="customerTier"`).

## 4. Routers and branching

| Construct | Diagram mapping |
|---|---|
| `choice` / `when expression` / `otherwise` | `alt <condition in business words> ... else ... end`. Quote the DataWeave expression in the step table. If `otherwise` is absent, the event passes through unchanged — state that explicitly |
| `first-successful` | `alt` with fallthrough semantics: route 1 fails → route 2. Say what "fail" means (any error) |
| `round-robin` | Note: alternates; document each route |
| `scatter-gather` | `par ... and ... end`; result is an aggregated object keyed by route index; a failure in any route errors the whole scope unless wrapped in try |
| `foreach` / `parallel-foreach` | `loop for each <item>` ; note `batchSize`, collection expression, and that payload is restored after the loop |
| `validation:*` (`is-not-null`, `is-email`, custom) | Step that can raise `VALIDATION:*` errors → error path |
| `ee:cache` | `alt cache hit ... else ... end`; note key expression and TTL |
| `idempotent-message-validator` | Rejects duplicates with `DUPLICATE_MESSAGE`; business meaning: replay protection |
| `apikit:router` | Dispatch step; also the source of the 4xx default error mappings |

## 5. Error handling

Trace error paths in this order, because each level can change the outcome:

1. **`try` scope** around specific steps — `on-error-continue` swallows the error and continues with whatever payload the handler leaves (often a default value: business meaning!). `on-error-propagate` runs the handler then rethrows.
2. **Flow-level `error-handler`** — same two kinds. `on-error-continue` at flow level returns a *success* HTTP status (200 by default, unless `http:listener` `error-response` sets `statusCode`) — a classic hidden behaviour where the caller gets 200 with an error body.
3. **Global default error handler** (`<configuration defaultErrorHandler-ref>`) — applies to any flow without its own.
4. **APIkit error block** inside the main router flow — maps `APIKIT:BAD_REQUEST`, `NOT_FOUND`, `METHOD_NOT_ALLOWED`, `NOT_ACCEPTABLE`, `UNSUPPORTED_MEDIA_TYPE`, `NOT_IMPLEMENTED` to HTTP codes.
5. **`http:listener` `<http:response>` / `<http:error-response>`** — statusCode expressions like `#[vars.httpStatus default 500]` decide the actual status. Find where `vars.httpStatus` is set in each path.
6. **Connector error types** — `HTTP:TIMEOUT`, `HTTP:CONNECTIVITY`, `HTTP:NOT_FOUND`, `DB:QUERY_EXECUTION`, `SALESFORCE:INVALID_INPUT`, `JMS:*`, `SFTP:*`, `MULE:EXPRESSION`, `ANY`. Handlers keyed on type (`type="HTTP:NOT_FOUND"`) or `when` expressions create distinct paths.
7. **`raise-error type="APP:..."`** — custom business errors; find every handler that catches that type.
8. **`until-successful`** exhaustion → `MULE:RETRY_EXHAUSTED`.

For every error path record: trigger condition, handler location (file:line), what is logged (message + level — this is what support searches in Splunk), what is returned to the caller (status, body shape), whether downstream side effects already happened (partial-failure / compensation matters for business), and whether the message is dead-lettered or re-queued.

## 6. Asynchrony, retries and iteration

- `async` — fire-and-forget on another thread; the caller's response does not wait. Diagram: `par` or a `Note` "async — caller not blocked"; document what happens if it fails (usually only a log).
- `vm:publish` → `vm:listener` in the same app: transactional-ish handoff; document both halves in the same endpoint sequence, as a separate participant lane.
- `anypoint-mq:publish`, `jms:publish` — the sequence continues in another consumer; if that consumer is in scope, link to its endpoint id; if not, it is a downstream system.
- `until-successful maxRetries=".." millisBetweenRetries=".."` — `loop retry up to N times` with the delay; business meaning: resilience to transient downstream faults; note the total worst-case latency.
- `http:request` reconnection strategy (`reconnect`, `reconnect-forever`) and `responseTimeout` — capture timeouts; they define the failure envelope for the caller.
- `batch:job` — a fork: input phase, `batch:step`s with accept expressions, `batch:aggregator` (bulk downstream calls), on-complete. Document as its own sub-diagram; the triggering endpoint typically returns immediately.
- `foreach` with a downstream call inside → the number of downstream calls scales with input size; note it as a performance/business consideration.

## 7. Outbound connectors and targets

| Connector | Target to resolve | Details to capture |
|---|---|---|
| `http:request` | `request-config` → `http:request-connection host/port/basePath/protocol` (+ `path`/`url` on the request) | method, headers (auth type: client-id, OAuth token from `oauth2:*` grant, basic), query params, body transform, `responseTimeout`, `responseValidator`/`success-status-code-validator` |
| `db:select/insert/update/delete/bulk-insert/stored-procedure` | `db:config` → connection (host, db name) | SQL text (table names → data entities), input params, whether transactional (`transactionalAction`) |
| `salesforce:*` (query, create, update, upsert, invoke-apex-*) | `sfdc-config` (login URL, username → org) | sObject, SOQL, external id field |
| `jms:publish`, `anypoint-mq:publish`, `kafka:publish` | destination name | message shape, headers/properties, persistence |
| `sftp:*`, `ftp:*`, `file:*` | host + directory | file naming, overwrite/append |
| `wsc:consume` | WSDL service/port, address | operation name |
| `email:send` | SMTP host | recipients (business actors!) |
| `os:store/retrieve` | object store name | key expression, TTL — often implements caching or dedup |
| `ee:transform` with `output` to external file | — | see §8 |
| `http:request` to another Mule app in scope | its `http:listener` | link endpoint ids across apps |

Resolve hosts for the documented environment. If the host is a load-balancer or an alias, pair it with the network diagram / Splunk `dest` field to name the real system. Record `resolved_from` (which file and key) in the flow record's `downstream` entry.

## 8. DataWeave for business meaning

A transform is where the business rules hide. For each `ee:transform` / `.dwl`, write one to three sentences answering: what goes in, what comes out, what rules apply. Look for:

- Field mappings that rename or re-key entities (`sku: payload.MATNR`) — this gives you the vocabulary bridge between systems (feed it to the Collibra mapping).
- Filters (`filter $.status == "ACTIVE"`) and conditionals (`if (payload.amount > 10000) "MANUAL_REVIEW" else "AUTO"`) — business thresholds; quote them.
- Lookups (`lookup("flowName", ...)`, `p('key')`), `readUrl`, `Mule::p` — hidden dependencies and configuration-driven rules.
- Defaults (`default "UNKNOWN"`), null handling, `skipNullOn` — what the downstream receives when data is missing.
- Masking / removal of fields (`-` operator, `mapObject` dropping `ssn`) — compliance meaning.
- Error mapping transforms in handlers — how internal errors become customer-visible messages.
- Aggregations, groupBy, reduce — reporting/calculation logic.
- `output application/json skipNullOn="everywhere"` etc. — response contract details.

Do not paraphrase the code line by line; state the rule. "Orders over 10,000 are routed for manual review" beats "if payload.amount > 10000 then MANUAL_REVIEW".

## 9. Policies and the API gateway

If `api-gateway:autodiscovery apiId="..." flowRef="..."` is present, the flow is managed by API Manager and policies execute before the flow's source hands over the event. Typical policies and their sequence-diagram effect:

- Client ID enforcement → step "Validate client_id/secret", reject 401/403; the client_id identifies the upstream application — use it with Anypoint analytics to name real callers.
- OAuth 2.0 / JWT validation → token introspection call to the IdP (a downstream you would otherwise miss); claims may feed authorisation.
- Rate limiting / spike control → 429 path.
- IP allowlist/blocklist, CORS, header injection/removal, message logging (Splunk!), custom policies (ask for the source).
- Proxy vs. basic endpoint in API Manager: a proxy is a separate deployed app with its own base path and host — a step between the caller and your app.

Without an export you cannot know the policy list from code. Record the apiId and a gap; if Anypoint access (or a screenshot) is available, list each policy with its order and configuration.

## 10. Mule 3 differences (if the app is Mule 3)

`http:listener` under `http:listener-config`; `flow-ref`; `choice`; `catch-exception-strategy` / `rollback-exception-strategy` / `choice-exception-strategy` instead of error-handler (catch-exception-strategy swallows like on-error-continue); `apikit:mapping-exception-strategy` for HTTP code mapping; `dw:transform-message` (DataWeave 1.0, `%dw 1.0`); `enricher`; `message-properties-transformer`; `until-successful` (async by default unless `synchronous="true"`); `poll` as scheduler; `vm:inbound-endpoint`. The tracing logic is identical; only the element names differ. The inventory script recognises both.

## 11. Hidden-behaviour checklist

Before marking an endpoint's Phase 2 complete, confirm you looked for:

- [ ] Global error handler and `defaultErrorHandler-ref`
- [ ] `on-error-continue` anywhere on the path (changes status/payload)
- [ ] `http:error-response` status expression and every place `vars.httpStatus` is set
- [ ] `target=` on connector calls (payload vs variable)
- [ ] `flow-ref`s into flows defined in *other* config files or a domain
- [ ] Interceptors / `ee:cache` / Object Store use (caching changes what downstream is called)
- [ ] `async` blocks and `vm` handoffs
- [ ] `until-successful` and connector `reconnect` settings
- [ ] `foreach` wrapping a downstream call (N calls)
- [ ] `scatter-gather` failure semantics
- [ ] DataWeave `lookup()` calls (hidden flow invocations)
- [ ] `logger` steps with correlation ids / business ids (Splunk anchors)
- [ ] `secure-properties` values you could not resolve
- [ ] APIkit resources with no implementing flow
- [ ] Policies from `api-gateway:autodiscovery`

## 12. Discovering multiple business scenarios behind one endpoint

One entry point often carries several business flows. Miss one and the report is wrong for every request of that kind, so hunt for discriminators deliberately after the technical trace:

| Where to look | What it looks like | Example scenario split |
|---|---|---|
| `choice` on request fields | `payload.type`, `payload.action`, `attributes.queryParams.mode`, `attributes.headers.x-channel`, `attributes.uriParams.kind` | `POST /orders` → new order / reorder / quote-to-order |
| DataWeave conditionals | `if (payload.channel == "B2B") … else …`, `match payload.eventType { case "CREATED" -> … }` | different mapping → different downstream object |
| RAML/OAS | multiple request `type`s/`examples`, `oneOf` schemas, enum fields, optional query params that switch behaviour | documented variants the spec author knew about |
| Upstream call sites | the same path called from two UI actions or two apps with different payloads or roles | customer self-service vs agent-assisted |
| Message listeners | `eventType`, `operation`, JMS `JMSType`, MQ message properties, file-name patterns | one subscriber handling create/update/delete events |
| Schedulers | flags read from config or DB ("month-end", "full vs delta"), day-of-week logic | nightly delta sync vs monthly full reload |
| Feature flags / properties | `p('feature.newPricing') == "true"` | old vs new behaviour co-existing in prod |
| Error-handler outcomes with business meaning | `on-error-continue` that turns a downstream failure into "order accepted, pending" | degraded-mode scenario worth naming |
| Production logs | distinct log messages / branches firing in separate populations; different `client_id`s with different payload shapes | proves which scenarios are live and how often |

Rules for splitting:
- A scenario has a *business* difference: actor, trigger, outcome, downstream set, or rule applied. Retry loops, cache hits, pagination and content-type negotiation are technical branches, not scenarios — document them as branches inside the scenario they belong to.
- Give each scenario: id (`S1`…), name, discriminator (the exact condition and the field/source it reads), actor, business meaning, step range in the main diagram, own diagram file if the path diverges materially, evidence, and production share if known.
- The "default"/`otherwise` path is a scenario too; name it by what it does, not "otherwise".
- If a discriminator exists but you cannot determine the business meaning of a value (e.g. `payload.type == "X7"` with no doc), still list the scenario and log a gap asking the owner what `X7` is.
