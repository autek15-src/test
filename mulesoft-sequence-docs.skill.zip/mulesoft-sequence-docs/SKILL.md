---
name: mulesoft-sequence-docs
description: End-to-end sequence-diagram documentation for every API and endpoint in a MuleSoft (Mule 4 / Mule 3) application — discovers all entry points from code, config, RAML/OAS specs and API Manager policies, traces every path (choices, error handlers, scatter-gather, async, retries), adds upstream consumers (UI, user roles) and downstream systems from other repos, architecture/network diagrams, Collibra, Splunk and Anypoint data, infers business/functional meaning, records evidence, a per-flow checklist and a gap register, and produces a rich HTML report with embedded Mermaid sequence diagrams plus standalone .mmd/.svg files. Use this whenever the user mentions MuleSoft, Mule, Anypoint, APIkit, RAML, DataWeave, a "Mule app/API", "experience/process/system API", or wants API flows, integration flows, sequence diagrams, endpoint inventories, "what does this API do", or integration documentation for a Mule codebase — even if they don't say "sequence diagram" or "skill".
---

# MuleSoft Sequence Documentation

Produce a complete, evidence-backed, end-to-end description of every entry point in a MuleSoft application: one sequence diagram plus a narrative for each endpoint, covering who calls it (upstream), everything it does (every branch and error path), and what it touches (downstream). The output is an HTML report with embedded diagrams, a separate diagram file per endpoint, a checklist proving each flow was traced completely, and a gap register listing anything that could not be verified.

Read this whole file before starting. Then load the reference files at the phase where they are named.

## Why the process is strict

Integration documentation is usually wrong in the same predictable ways: an endpoint is missed because it lives in a RAML file rather than a flow; an error path is skipped because it sits in a global error handler; a downstream system is named from a stale Confluence page rather than the `http:request-config` that actually resolves in production. This skill exists to prevent exactly those failures. The multi-phase process, the evidence rules, the per-flow checklist and the gap register are not ceremony — they are how the report earns the right to be trusted as the source of truth by architects, auditors and the engineers who inherit the code.

## Source-of-truth precedence

When sources disagree, resolve in this order and say so in the report:

1. **Source code and configuration** (Mule XML, DataWeave, properties/YAML, RAML/OAS, `mule-artifact.json`, `pom.xml`, API Manager policy configuration, upstream/downstream repos).
2. **Observed production behaviour** (Splunk logs, Anypoint Monitoring/Runtime Manager/API Manager analytics, Collibra lineage). Production data can reveal real callers and real targets that code alone cannot (e.g. which UI actually hits an endpoint, which hostnames resolve in prod).
3. **User-provided documentation** (Confluence, design docs, architecture/network diagrams, runbooks). Use it to add business meaning and names, never to override what code or production data show. Flag every contradiction.

Never silently pick one. Record the conflict, the winner, and the reason.

## Inputs to collect before starting

Ask once, up front, for everything the user can provide — later phases will stall without it:

- Path(s) to the Mule project(s). Multiple apps (experience/process/system API layering) are common; document each and the calls between them.
- Environment to document (prod unless told otherwise) — this decides which `config-<env>.yaml` / properties file wins.
- Upstream/downstream source code (UI repos, other Mule apps, services) if available.
- API Manager policies (export, screenshot, or `api-gateway:autodiscovery` apiId + policy list).
- Architecture / network diagrams (PDF, PNG, Visio export, draw.io) and any written docs.
- Collibra exports (data assets, lineage, business glossary) — CSV/JSON/screenshot.
- Splunk / Anypoint Monitoring exports (request logs, transaction traces, top callers, error rates).
- Any connectors/MCP tools you have (Splunk, Collibra, Anypoint, GitHub, Confluence). Use them directly if present; ask for exports if not.

If something is unavailable, do not wait — proceed and log it in the gap register (Phase 4). Missing inputs are findings, not blockers.

## Workflow overview

| Phase | Goal | Output artefact |
|---|---|---|
| 0 | Inventory the project mechanically | `work/inventory.json`, `work/inventory.md`, `work/callgraph.mmd` |
| 1 | Confirm the **complete** endpoint list | `work/endpoints.md` (signed-off list) |
| 2 | Trace every path of every endpoint; split into business scenarios | one `flows/<id>.json` per endpoint (draft), main + per-scenario diagrams |
| 3 | Enrich with upstream, downstream, business meaning, production evidence | same files, enriched |
| 4 | Verify completeness; fill checklist; log gaps | checklist + gaps in each flow file, `project.json` |
| 5 | Generate diagrams and HTML report | `report/index.html`, `report/diagrams/*.mmd`, `*.svg` |

Work in a `work/` and `flows/` directory beside the report. Keep intermediate files — they are the audit trail.

---

## Phase 0 — Mechanical inventory

Run the bundled inventory script on every Mule project root. It parses the Mule XML, resolves property placeholders per environment, reads RAML/OAS specs, links APIkit routers to their resource flows, builds the `flow-ref` call graph and lists every inbound source and outbound connector:

```bash
python3 scripts/inventory_mule.py <mule-project-root> [<another-root> ...] \
  --env prod --out work/ --draft-diagrams
```

Read `work/inventory.md` completely. It tells you: every flow and sub-flow, every entry point (HTTP listeners, APIkit-routed RAML resources, schedulers, JMS/VM/MQ/DB/SFTP/Salesforce listeners), every outbound call with its resolved host, every `flow-ref` edge, unreachable flows, unresolved properties, and detected policy/autodiscovery references. `--draft-diagrams` writes a skeleton `.mmd` per entry point in `work/drafts/` that you will rewrite in Phase 2 — it is a starting point, not a deliverable.

The script is deterministic and fast but not omniscient. Treat its output as a first pass and expect to add things by reading the code yourself in Phase 1 (see `references/mulesoft-tracing.md` for the constructs it may miss).

## Phase 1 — Confirm the complete endpoint list

The single most expensive mistake is missing an endpoint, so this phase is separate and explicit. Build `work/endpoints.md` by cross-checking **all** of these sources against each other:

1. `http:listener` (and `https`/`http-listener` in Mule 3) elements — path, allowed methods, listener-config base path, port.
2. RAML / OAS files under `src/main/resources/api/` (and any `!include` / `$ref` fragments, exchange dependencies in `pom.xml`). Every `resource + method` in the spec is an endpoint whether or not a flow implements it — unimplemented ones return APIkit defaults and belong in the report as such.
3. APIkit router flows named `<method>:\<resource>:<config>` (and the `:<content-type>:` variant), APIkit console/`*` catch-all flows.
4. Non-HTTP entry points: `scheduler`, `jms:listener`, `vm:listener`, `anypoint-mq:subscriber`, `db:listener`, `sftp/ftp/file:listener`, `salesforce:*-listener`, `sockets`, `email:listener`, `kafka`, Object Store expiry, batch triggers. These are "endpoints" for the purposes of the report — they start business sequences.
5. API Manager policies and `api-gateway:autodiscovery`: policies (client-id enforcement, OAuth/JWT, rate limiting, IP allowlist, header injection, custom) add steps at the front of every HTTP sequence and can reject requests before the flow starts. Policies are configured outside the code, so if you have no export, record the apiId and a gap.
6. Upstream evidence: Splunk/Anypoint analytics listing paths actually called. Any path seen in production that is not in the code list is a finding (old version, another app, a proxy route).
7. `mule-artifact.json` (`secureProperties`, `configs`) and `pom.xml` (shared libraries, connectors) for hidden config files or domain projects (`mule-domain-config.xml` hosts shared listener configs).

Give each endpoint a stable id like `EP-007-get-orders-by-id`. Present the list to the user before Phase 2 with a count and ask whether anything is missing (e.g. endpoints exposed only through an API proxy). Do not proceed on an unconfirmed list if the user is available; if not, proceed and note it.

## Terminology: endpoint vs business scenario

One endpoint frequently serves several distinct business flows — `POST /orders` might be "new order", "reorder" and "quote conversion" depending on `payload.type`; a JMS listener switches on event type; a scheduler behaves differently on month-end. In this skill an **endpoint** is the technical entry point; a **business scenario** is one business-meaningful path through it (its own actor, trigger, outcome or downstream set). Every endpoint has at least one scenario; the report documents each scenario separately — with its own diagram where the paths diverge — and never collapses them into one "processes request" flow. "Flow" without qualifier means a Mule `flow` element.

## Phase 2 — Trace every path of every endpoint, then split into scenarios

Load `references/mulesoft-tracing.md` now. It explains how each Mule construct maps to sequence-diagram steps, where hidden behaviour lives, and (§12) how to discover the scenarios hiding behind one endpoint.

For each endpoint, walk the flow **from source to response**, following every `flow-ref` and sub-flow into its own definition, and record every step in `flows/<id>.json` using the schema in `references/flow-record-schema.md`. Every path means:

- Every `choice` branch including `otherwise`, and `first-successful` / `round-robin` / `scatter-gather` legs.
- Every error path: `try` scopes, `on-error-propagate` vs `on-error-continue` (the latter *changes the response*), flow-level and global error handlers, `raise-error`, APIkit's default exception mappings (400/404/405/406/415/500 in the `apikit:router` error block), and connector-specific error types (`HTTP:NOT_FOUND`, `DB:CONNECTIVITY`, `SALESFORCE:*`).
- Every asynchronous divergence: `async`, `vm:publish` with a listener in the same app, `anypoint-mq:publish`, batch jobs, `until-successful` retries (count, delay), and `foreach` / `parallel-foreach` iteration.
- Every outbound call: connector, resolved target host/queue/table/object, method, request payload shape (from the preceding DataWeave), timeout, and how the response is used.
- Every DataWeave transform: state what it does in business terms ("maps the SAP material to the customer-facing SKU and drops internal cost fields"), not just "Transform Message".
- Every discriminator on the request or message that selects a different business behaviour (see scenario identification below).
- Validation, enrichment (`enricher`, `target`/`targetValue`), caching (`ee:cache`, Object Store), idempotency, correlation-id and logging steps that a support engineer would need to find in Splunk.

**Identify the business scenarios** once the technical paths are traced. Look at the discriminators: choice conditions on request fields (`payload.type`, query params, headers, URI params), DataWeave conditionals, RAML/OAS request types and examples, distinct upstream call sites that hit the same endpoint for different user actions, event-type fields on queue listeners, scheduler mode flags, and log messages that Splunk shows firing in distinct populations. Give each scenario an id `S1`, `S2`… inside the endpoint, a business name, the discriminator (how a request is routed into it), the actor, and the step numbers it covers. Technical-only branches (retry loop, cache hit) are not scenarios; a path with a different business outcome, actor, or downstream set is. When in doubt, split — the reader can merge, but cannot un-merge.

Write the Mermaid `sequenceDiagram` for the endpoint into `report/diagrams/<id>.mmd` following `references/diagram-conventions.md`. This main diagram shows the shared trunk with `alt` blocks per scenario. When a scenario diverges enough that the main diagram becomes unreadable — roughly more than 8 scenario-specific steps, a different actor, or a different downstream chain — give it its own diagram `report/diagrams/<id>-S<n>-<slug>.mmd` and keep only a one-line reference to it in the main diagram. Record every scenario in the flow record's `scenarios` list with its diagram file. Use `alt/else` for choices, `opt` for optional steps, `loop` for iteration/retry, `par` for scatter-gather/async, `break` or a dedicated `alt` for error returns, and `Note` blocks for business meaning at key steps. If one diagram exceeds roughly 60 steps, split it into a main diagram plus sub-diagrams referenced from the main one, and list all files in the flow record.

Do not summarise multiple branches into one "processes request" arrow. The point of the exercise is that a reader can predict what the system will do for any input.

## Phase 3 — Enrich: upstream, downstream, business meaning, production evidence

Load `references/evidence-sources.md` for how to mine each source type and how to cite it.

**Upstream (who calls this and why).** Search upstream source code for the path/method (URL builders, API client classes, fetch/axios calls, Mule `http:request` in other apps, Salesforce callouts). Identify the user type performing the action (customer, agent, back-office user, batch job, partner system) from the UI code, route guards, RBAC configuration, or policy (client-id → application → owner). Confirm with production callers from Splunk/Anypoint (client_id, user-agent, source IP → network diagram). Represent the upstream as its own participant (e.g. `Customer (Web Portal UI)` → `Orders Experience API`).

**Downstream (what it depends on).** Resolve every outbound target to a named system: use the resolved host from the inventory, then the network/architecture diagram to give it a business name, then the downstream repo (if available) to describe what happens on the other side — to the depth needed for this endpoint's meaning, not a full second document. Where the downstream is another Mule app in scope, link to its endpoint id so the report chains experience → process → system → SoR end to end.

**Business and functional meaning.** For each endpoint *and each of its scenarios* state: the business capability it implements, the actor and trigger, the business rules visible in the code (choice conditions, DataWeave logic, validations), the data entities involved (map to Collibra assets and glossary terms when available), the outcome for the user on success and on each failure path, SLAs/timeouts/retries, and any compliance-relevant handling (PII, masking, audit logging). Infer boldly from names, comments, expressions and specs — but mark each inference with its basis so a reviewer can disagree.

**Production evidence.** Attach traffic volume, top callers, typical latency, error distribution and any observed paths or targets that differ from code. Observed behaviour that contradicts documentation is a headline finding.

## Phase 4 — Verify completeness and record gaps

This phase is what turns a good draft into a trustworthy document. For each endpoint, complete the checklist embedded in the flow record (full list in `references/flow-record-schema.md`). Each item is `done`, `partial` or `blocked`, with a one-line note. The core items:

1. Entry point identified from code/spec/policy, with file and line.
2. Policies applied (or gap recorded).
3. Every `flow-ref`/sub-flow followed to its definition.
4. Every `choice` branch and `otherwise` covered.
5. Every error handler covered (try, flow, global, APIkit defaults, connector error types).
6. Every async/parallel/retry construct covered.
7. Every outbound call resolved to a target for the documented environment.
8. Every DataWeave transform described in business terms.
9. Response shape and status codes documented per path.
10. Upstream consumer(s) and user type identified with evidence.
11. Downstream systems named with evidence.
12. Business meaning stated with basis.
13. Production evidence attached (or gap recorded).
14. Diagram matches the narrative step-for-step (re-read both side by side).
15. Sources list complete — every file, doc, query and dataset used.
16. All business scenarios behind the endpoint identified from discriminators, upstream call sites and production data; each has its own business meaning, step range and (where paths diverge) its own diagram.

Then run these whole-project checks:

- Count check: `endpoints.md` count == number of flow records; every scenario's `diagram_file` exists.
- Scenario check: every `choice` on a request/message field in the endpoint's path is either covered by a scenario or explicitly classified as technical-only in the record.
- Reachability: every flow/sub-flow in the inventory appears in at least one endpoint's path, or is listed as unreachable/dead code in the gap register.
- Reverse check from production: every path observed in Splunk/Anypoint maps to an endpoint id, and distinct log-message populations map to a scenario.
- Cross-app check: every `http:request` to another in-scope Mule app maps to that app's endpoint id.

Record every unknown in the flow record's `gaps` list and roll them up into `project.json` → `gaps`. Typical gaps: unknown upstream, downstream host resolves only in a vault/secure property you cannot read, policy list not provided, RAML `!include` missing, referenced flow not found in code (probably in a domain or shared library), no production data for the environment, contradiction between doc and code. Each gap needs: what is missing, why it matters, what would resolve it, and a confidence rating for the affected flow.

## Phase 5 — Generate the report

Write `project.json` (schema in `references/flow-record-schema.md`) with the application overview, system-context participants, sources bibliography, and the rolled-up gap register. Then:

```bash
python3 scripts/build_report.py --project project.json --flows flows/ \
  --diagrams report/diagrams/ --out report/ --render-svg
```

The builder validates every flow record (required fields, all 16 checklist ids, scenarios and their diagram files, step numbers vs diagram messages, participants vs diagram, confidence vs blocking gaps, endpoint count vs `endpoint_count_expected`), checks every diagram's syntax (built-in lint, plus the real Mermaid parser via `scripts/mermaid_check.mjs` when Node is available — it runs `npm install` in `scripts/` once), embeds each diagram in the HTML (client-side render), writes the standalone `.mmd` files, renders `.svg` when `mmdc` with a browser is available, and produces `report/index.html` with: executive overview, system context diagram, endpoint index (method, path, actor, scenario count, downstream, confidence, gap count), one section per endpoint (summary, business meaning, **scenarios with their own diagrams**, participants, main diagram, step table with technical/functional/business columns and evidence, branches, error paths, upstream, downstream, data elements, production evidence, sources, checklist, gaps), the global gap register, source-conflict log, methodology and bibliography. Report structure detail is in `references/report-template.md`.

Read `report/build-log.txt`: errors block delivery; every warning is either fixed or acknowledged in a gap. Then open the HTML (or the SVGs) if you can, and in any case re-read at least three endpoints end to end — diagram, step table, code — before handing over. Fix the flow records, not the HTML. Deliver `report/` (HTML + `diagrams/`) and the `work/` folder as the audit trail.

## Working style

- Read code, don't skim it. Open every referenced flow, every DataWeave file, every properties file for the target environment.
- Prefer exact evidence: file path plus line number, Splunk query plus time range, Collibra asset id, diagram file plus page.
- When the codebase is large, work endpoint by endpoint and save each flow record as you finish it, so partial progress survives context limits. Re-run Phase 4 checks at the end regardless.
- Keep narrative in the "technical / functional / business" triad so both engineers and business readers get what they need from the same table.
- Never invent a downstream system name, a user role or a business rule to fill a blank. A blank with a gap entry is correct; a plausible guess presented as fact is the failure mode this skill exists to prevent.

## Bundled resources

- `scripts/inventory_mule.py` — Phase 0 parser (Mule 4 & 3 XML, properties/YAML, RAML/OAS, APIkit mapping, call graph, drafts).
- `scripts/build_report.py` — Phase 5 report generator and validator.
- `scripts/mermaid_check.mjs` + `scripts/package.json` — optional headless Mermaid parser check used by the builder (needs Node; `npm install` runs automatically).
- `references/mulesoft-tracing.md` — how Mule constructs map to sequence steps; hidden-behaviour checklist.
- `references/evidence-sources.md` — mining upstream/downstream code, diagrams, Collibra, Splunk, Anypoint; citation format; conflict handling.
- `references/diagram-conventions.md` — Mermaid sequence-diagram rules and examples.
- `references/flow-record-schema.md` — JSON schema for `flows/<id>.json` and `project.json`, checklist items, gap format.
- `references/report-template.md` — report sections and per-endpoint template.
- `assets/report_template.html` — HTML/CSS shell used by the builder.
