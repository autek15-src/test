// Headless Mermaid syntax check (no browser needed). Used by build_report.py when node is available.
// Usage: node mermaid_check.mjs file1.mmd file2.mmd ...   → prints "OK <file> <type>" or "FAIL <file> <message>" per file.
import fs from 'fs';
let JSDOM;
try { ({ JSDOM } = await import('jsdom')); } catch (e) { console.log('UNAVAILABLE jsdom not installed (run: npm install in the scripts/ directory)'); process.exit(3); }
const dom = new JSDOM('<!DOCTYPE html><body></body>', { pretendToBeVisual: true });
globalThis.window = dom.window; globalThis.document = dom.window.document;
globalThis.HTMLElement = dom.window.HTMLElement; globalThis.SVGElement = dom.window.SVGElement;
let mermaid;
try { mermaid = (await import('mermaid')).default; } catch (e) { console.log('UNAVAILABLE mermaid not installed (run: npm install in the scripts/ directory)'); process.exit(3); }
let failures = 0;
for (const f of process.argv.slice(2)) {
  try { const r = await mermaid.parse(fs.readFileSync(f, 'utf8')); console.log('OK', f, r?.diagramType ?? ''); }
  catch (e) { failures++; console.log('FAIL', f, String(e.message || e).replace(/\n/g, ' | ').slice(0, 300)); }
}
process.exit(failures ? 1 : 0);
