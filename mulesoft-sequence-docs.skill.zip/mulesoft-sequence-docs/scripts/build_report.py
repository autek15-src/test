#!/usr/bin/env python3
"""
build_report.py — Phase 5: validate flow records + diagrams and build the HTML report.

Usage:
  python3 build_report.py --project project.json --flows flows/ --diagrams report/diagrams/ --out report/ \
      [--render-svg] [--inline-mermaid /path/to/mermaid.min.js] [--inventory work/inventory.json] [--strict]

Reads:
  project.json               (schema: references/flow-record-schema.md §4)
  flows/*.json               one record per endpoint (schema §1)
  diagrams/*.mmd             Mermaid sources referenced by the records' diagram_files (+ SYS-context.mmd)

Writes into --out:
  index.html                 the report (Mermaid rendered client-side)
  diagrams/*.mmd (+ .svg)    standalone diagrams; .svg only when --render-svg and `mmdc` + a browser are available
  data/project.json, data/flows/*.json   copies for audit
  build-log.txt              validation errors/warnings and coverage numbers

Exit status 1 on structural errors (or on warnings with --strict). Fix the records, not the HTML.
"""
import argparse
import datetime as dt
import glob
import html
import json
import os
import re
import shutil
import subprocess
import sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, "..", "assets", "report_template.html")
MERMAID_CDN = "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js"

CHECKLIST = [
    ("C01", "Entry point identified from code/spec/policy with file:line"),
    ("C02", "API Manager policies applied (or gap recorded)"),
    ("C03", "Every flow-ref / sub-flow followed to its definition"),
    ("C04", "Every choice branch incl. otherwise covered"),
    ("C05", "Every error handler covered (try, flow, global, APIkit defaults, connector types)"),
    ("C06", "Every async / parallel / retry / loop construct covered"),
    ("C07", "Every outbound call resolved to a target for the documented environment"),
    ("C08", "Every DataWeave transform described in business terms"),
    ("C09", "Response shape and status codes documented per path"),
    ("C10", "Upstream consumer(s) and user type identified with evidence"),
    ("C11", "Downstream systems named with evidence"),
    ("C12", "Business meaning stated with basis for each inference"),
    ("C13", "Production evidence attached (or gap recorded)"),
    ("C14", "Diagram and narrative match step-for-step"),
    ("C15", "Sources list complete"),
    ("C16", "All business scenarios behind the endpoint identified; each with business meaning, step range and own diagram where paths diverge"),
]
CHECK_IDS = [c[0] for c in CHECKLIST]
CHECK_TEXT = dict(CHECKLIST)
REQ_FLOW = ["id", "app", "name", "type", "summary", "business", "participants", "diagram_files", "scenarios", "steps", "upstream", "downstream", "sources", "checklist", "gaps", "confidence"]
REQ_PROJECT = ["title", "environment", "applications", "overview"]
SEVERITIES = ["blocking", "major", "minor"]


class Log:
    def __init__(self):
        self.errors, self.warnings, self.info = [], [], []

    def err(self, m): self.errors.append(m); print("ERROR:", m, file=sys.stderr)
    def warn(self, m): self.warnings.append(m); print("warn:", m, file=sys.stderr)
    def note(self, m): self.info.append(m)


# ----------------------------------------------------------------------------
# text helpers
# ----------------------------------------------------------------------------

def esc(s):
    return html.escape("" if s is None else str(s), quote=True)


def md(s):
    """Very small Markdown subset → HTML: paragraphs, '- ' bullets, **bold**, `code`, [[EP-id]] links."""
    if s is None or s == "":
        return ""
    if not isinstance(s, str):
        s = json.dumps(s, ensure_ascii=False)
    text = esc(s)
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(r"\b(EP-\d{3}[A-Za-z0-9\-]*)\b", r'<a href="#\1">\1</a>', text)
    text = re.sub(r"\b(GAP-\d+)\b", r'<a href="#\1">\1</a>', text)
    lines = text.split("\n")
    out, in_ul = [], False
    for ln in lines:
        if ln.strip().startswith("- "):
            if not in_ul:
                out.append("<ul class='tight'>"); in_ul = True
            out.append(f"<li>{ln.strip()[2:]}</li>")
        else:
            if in_ul:
                out.append("</ul>"); in_ul = False
            if ln.strip():
                out.append(ln)
            else:
                out.append("<br>")
    if in_ul:
        out.append("</ul>")
    return "<br>\n".join(x for x in out).replace("</ul><br>\n", "</ul>").replace("<br>\n<ul", "<ul")


def lst(v):
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def evid(v):
    return "; ".join(str(x) for x in lst(v))


def table(headers, rows, cls=""):
    if not rows:
        return "<p class='empty'>none recorded</p>"
    h = "".join(f"<th>{esc(x)}</th>" for x in headers)
    b = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows)
    return f"<table class='{cls}'><thead><tr>{h}</tr></thead><tbody>{b}</tbody></table>"


def badge(kind, text=None):
    k = (kind or "").lower()
    return f"<span class='badge {esc(k)}'>{esc(text or kind)}</span>"


def kv(pairs):
    return "<div class='facts'>" + "".join(f"<div>{esc(k)}</div><div>{v}</div>" for k, v in pairs if v) + "</div>"


# ----------------------------------------------------------------------------
# mermaid lint (no renderer needed)
# ----------------------------------------------------------------------------

OPEN_BLOCKS = {"alt", "opt", "loop", "par", "critical", "rect", "break", "box"}
MID_BLOCKS = {"else", "and", "option"}
ARROW_RE = re.compile(r"^\s*([A-Za-z0-9_]+)\s*(-->>|->>|-->|->|-\)|--\)|-x|--x)\s*([A-Za-z0-9_]+)\s*:")


def lint_mermaid(text, name, log):
    """Return (kind, message_count, participants). Adds errors/warnings to log."""
    lines = [l.rstrip() for l in text.splitlines()]
    body = [l for l in lines if l.strip() and not l.strip().startswith("%%")]
    if not body:
        log.err(f"{name}: empty diagram")
        return None, 0, set()
    head = body[0].strip()
    kind = head.split()[0]
    if kind not in ("sequenceDiagram", "flowchart", "graph"):
        log.err(f"{name}: first line must be 'sequenceDiagram' (or flowchart for SYS-context), got '{head}'")
    if kind != "sequenceDiagram":
        return kind, 0, set()
    declared, used, stack, msgs = set(), set(), [], 0
    for i, raw in enumerate(body[1:], start=2):
        l = raw.strip()
        first = l.split()[0] if l.split() else ""
        if first in ("participant", "actor"):
            m = re.match(r"(participant|actor)\s+([A-Za-z0-9_]+)", l)
            if m:
                declared.add(m.group(2))
            continue
        if first in OPEN_BLOCKS:
            stack.append((first, i)); continue
        if first in MID_BLOCKS:
            if not stack:
                log.err(f"{name}:{i}: '{first}' outside of a block")
            continue
        if first == "end":
            if not stack:
                log.err(f"{name}:{i}: 'end' without an open block")
            else:
                stack.pop()
            continue
        if first in ("Note", "note"):
            continue
        m = ARROW_RE.match(l)
        if m:
            msgs += 1
            used.add(m.group(1)); used.add(m.group(3))
            continue
        if first in ("autonumber", "activate", "deactivate", "title", "accTitle", "accDescr", "links", "link", "properties", "details", "create", "destroy"):
            continue
        log.warn(f"{name}:{i}: unrecognised line (may still be valid Mermaid): {l[:80]}")
    for b, i in stack:
        log.err(f"{name}:{i}: block '{b}' never closed with 'end'")
    undeclared = used - declared
    if undeclared:
        log.warn(f"{name}: participants used but not declared (Mermaid auto-creates them, but ordering/labels are lost): {sorted(undeclared)}")
    if "autonumber" not in {l.strip() for l in body[:6]}:
        log.warn(f"{name}: 'autonumber' missing — step numbers in the narrative will not match the diagram")
    return kind, msgs, declared | used


# ----------------------------------------------------------------------------
# validation
# ----------------------------------------------------------------------------

def load_json(path, log):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception as e:
        log.err(f"{path}: cannot parse JSON: {e}")
        return None


def validate_flow(f, path, diagrams_dir, log):
    fid = f.get("id") or os.path.splitext(os.path.basename(path))[0]
    for k in REQ_FLOW:
        if k not in f:
            log.err(f"{fid}: missing required field '{k}'")
    if f.get("id") and os.path.splitext(os.path.basename(path))[0] != f["id"]:
        log.err(f"{fid}: file name should equal id ({os.path.basename(path)})")
    if f.get("confidence") not in ("high", "medium", "low"):
        log.err(f"{fid}: confidence must be high|medium|low")
    # checklist
    cl = {c.get("id"): c for c in lst(f.get("checklist"))}
    fixed = []
    for cid in CHECK_IDS:
        c = cl.get(cid)
        if not c:
            log.warn(f"{fid}: checklist item {cid} missing → marked 'missing'")
            fixed.append({"id": cid, "status": "missing", "note": "not recorded"})
            continue
        if c.get("status") not in ("done", "partial", "blocked"):
            log.err(f"{fid}: checklist {cid} status must be done|partial|blocked")
        if c.get("status") in ("partial", "blocked") and not c.get("note"):
            log.warn(f"{fid}: checklist {cid} is {c.get('status')} without a note")
        fixed.append(c)
    extra = set(cl) - set(CHECK_IDS)
    if extra:
        log.warn(f"{fid}: unknown checklist ids ignored: {sorted(x for x in extra if x)}")
    f["checklist"] = fixed
    # gaps
    for g in lst(f.get("gaps")):
        if g.get("severity") not in SEVERITIES:
            log.warn(f"{fid}: gap {g.get('id')} severity should be blocking|major|minor")
        for k in ("id", "what", "why", "resolve"):
            if not g.get(k):
                log.warn(f"{fid}: gap {g.get('id') or '?'} missing '{k}'")
    if f.get("confidence") == "high" and any(g.get("severity") == "blocking" for g in lst(f.get("gaps"))):
        log.err(f"{fid}: confidence 'high' contradicts a blocking gap")
    if f.get("confidence") == "high" and any(c.get("status") == "blocked" for c in f["checklist"]):
        log.warn(f"{fid}: confidence 'high' with a blocked checklist item")
    if not lst(f.get("upstream")) and not any("upstream" in (g.get("what", "") + g.get("why", "")).lower() for g in lst(f.get("gaps"))):
        log.warn(f"{fid}: no upstream recorded and no gap mentioning upstream")
    if not lst(f.get("downstream")) and f.get("type") == "http" and not any("downstream" in (g.get("what", "") + g.get("why", "")).lower() for g in lst(f.get("gaps"))):
        log.warn(f"{fid}: no downstream recorded and no gap mentioning downstream (fine only for pure-local endpoints)")
    # steps
    ns = [s.get("n") for s in lst(f.get("steps"))]
    if ns and ns != list(range(1, len(ns) + 1)):
        log.warn(f"{fid}: step numbers are not 1..N contiguous: {ns[:12]}…")
    for s in lst(f.get("steps")):
        if not s.get("evidence"):
            log.warn(f"{fid}: step {s.get('n')} has no evidence")
    # scenarios
    scen = lst(f.get("scenarios"))
    if not scen:
        log.err(f"{fid}: no scenarios recorded — every endpoint carries at least one business scenario (see mulesoft-tracing.md §12)")
    sids = Counter(x.get("id") for x in scen)
    for sid, c in sids.items():
        if c > 1:
            log.err(f"{fid}: duplicate scenario id {sid}")
    max_n = max([x.get("n", 0) for x in lst(f.get("steps"))] or [0])
    for x in scen:
        for k in ("id", "name", "discriminator", "business"):
            if not x.get(k):
                log.warn(f"{fid}: scenario {x.get('id') or '?'} missing '{k}'")
        if not x.get("evidence"):
            log.warn(f"{fid}: scenario {x.get('id')} has no evidence")
        if x.get("diagram_file"):
            dp = os.path.join(diagrams_dir, x["diagram_file"])
            if not os.path.exists(dp):
                log.err(f"{fid}: scenario {x.get('id')} diagram file not found: {x['diagram_file']}")
            else:
                with open(dp, encoding="utf-8") as fh:
                    _, msgs, _ = lint_mermaid(fh.read(), x["diagram_file"], log)
                own = lst(x.get("steps_own"))
                if own and msgs and msgs != len(own):
                    log.warn(f"{fid}: scenario {x.get('id')} diagram has {msgs} messages but steps_own has {len(own)} rows")
                if not own:
                    log.warn(f"{fid}: scenario {x.get('id')} has its own diagram but no steps_own table")
        elif x.get("steps") and max_n:
            m = re.findall(r"\d+", str(x["steps"]))
            if m and max(int(v) for v in m) > max_n:
                log.warn(f"{fid}: scenario {x.get('id')} references step {max(int(v) for v in m)} but the main step table ends at {max_n}")
        elif not x.get("steps") and not x.get("diagram_file"):
            log.warn(f"{fid}: scenario {x.get('id')} has neither a step range nor its own diagram")
    if lst(f.get("branches")) and len(scen) == 1 and not any("technical" in str(b.get("condition_business", "")).lower() or "scenario" in str(b.get("condition_business", "")).lower() for b in lst(f.get("branches"))):
        log.warn(f"{fid}: {len(lst(f.get('branches')))} branch(es) recorded but only one scenario — confirm the branches are technical-only (say so in condition_business) or split scenarios")
    # participants vs diagram
    aliases = {p.get("alias") for p in lst(f.get("participants"))}
    total_msgs = 0
    for i, dfile in enumerate(lst(f.get("diagram_files"))):
        p = os.path.join(diagrams_dir, dfile)
        if not os.path.exists(p):
            log.err(f"{fid}: diagram file not found: {dfile}")
            continue
        with open(p, encoding="utf-8") as fh:
            text = fh.read()
        kind, msgs, parts = lint_mermaid(text, dfile, log)
        if i == 0:
            total_msgs = msgs
            missing = parts - aliases
            if missing:
                log.warn(f"{fid}: diagram participants not in record 'participants': {sorted(missing)}")
    if total_msgs and ns and total_msgs != len(ns):
        log.warn(f"{fid}: main diagram has {total_msgs} messages but the step table has {len(ns)} rows — autonumber and narrative will not line up")
    return f


# ----------------------------------------------------------------------------
# rendering
# ----------------------------------------------------------------------------

def render_diagram(dfile, diagrams_dir, svg_ok):
    p = os.path.join(diagrams_dir, dfile)
    if not os.path.exists(p):
        return f"<div class='callout bad'>Diagram file missing: {esc(dfile)}</div>"
    with open(p, encoding="utf-8") as fh:
        src = fh.read()
    svg = os.path.splitext(dfile)[0] + ".svg"
    tools = [f"<a href='diagrams/{esc(dfile)}' download>download .mmd</a>"]
    if svg_ok and os.path.exists(os.path.join(diagrams_dir, svg)):
        tools.append(f"<a href='diagrams/{esc(svg)}' target='_blank'>open .svg</a>")
    return (f"<div class='diagram-tools'><span>{esc(dfile)}</span>{''.join(' · ' + t for t in tools)}</div>"
            f"<div class='diagram'><pre class='mermaid'>{esc(src)}</pre></div>"
            f"<details class='src'><summary>Mermaid source</summary><pre>{esc(src)}</pre></details>")


def render_sources(sources):
    rows = [[esc(s.get("type")), md(s.get("ref")), md(s.get("note"))] for s in lst(sources)]
    return table(["type", "reference", "note"], rows)


def render_endpoint(f, diagrams_dir, svg_ok):
    fid = f["id"]
    b = f.get("business") or {}
    out = [f"<article class='endpoint' id='{esc(fid)}'>"]
    method = f.get("method") or f.get("type")
    out.append("<header>" + badge("method", method) + f"<h3>{esc(f.get('name'))}</h3>"
               + (f"<span class='path'>{esc(f.get('path'))}</span>" if f.get("path") else "")
               + badge(f.get("confidence"), f"confidence: {f.get('confidence')}")
               + f"<span class='legend'>{esc(fid)} · {esc(f.get('app'))}</span></header>")
    out.append(kv([("Full URL", esc(f.get("full_url"))), ("Spec", md(f.get("spec_ref"))), ("Implementing flow", f"<code>{esc(f.get('implementing_flow'))}</code>" if f.get("implementing_flow") else ""),
                   ("Entry evidence", md(f.get("entry_evidence"))), ("Confidence basis", md(f.get("confidence_basis")))]))
    out.append(f"<h4>Summary</h4><p>{md(f.get('summary'))}</p>")

    out.append("<h4>Business &amp; functional meaning</h4>")
    out.append(kv([("Capability", md(b.get("capability"))), ("Actor", md(b.get("actor"))), ("Trigger", md(b.get("trigger"))),
                   ("Entities", md(", ".join(lst(b.get("entities"))))), ("Compliance", md(b.get("compliance"))), ("SLA / timing", md(b.get("sla"))),
                   ("Inference notes", md(b.get("inference_notes")))]))
    if b.get("rules"):
        out.append(table(["Business rule", "Basis in code/doc"], [[md(r.get("rule")), md(r.get("basis"))] for r in lst(b.get("rules"))]))
    oc = b.get("outcomes") or {}
    if oc:
        out.append("<div class='grid2'><div><strong>On success</strong><p>" + md(oc.get("success")) + "</p></div><div><strong>On failure</strong>" + md("\n".join("- " + x for x in lst(oc.get("failures")))) + "</div></div>")

    scen = lst(f.get("scenarios"))
    out.append(f"<h4>Business scenarios ({len(scen)})</h4>")
    out.append(table(["id", "scenario", "discriminator (how a request lands here)", "actor", "business meaning", "outcome", "downstream", "prod share", "steps / diagram", "evidence"],
                     [[esc(x.get("id")), f"<strong>{esc(x.get('name'))}</strong>", md(x.get("discriminator")), md(x.get("actor")), md(x.get("business")), md(x.get("outcome")), md(", ".join(lst(x.get("downstream")))), md(x.get("production_share")),
                       (f"<a href='#{esc(fid)}-{esc(x.get('id'))}'>own diagram</a>" if x.get("diagram_file") else md(x.get("steps"))), md(evid(x.get("evidence")))] for x in scen]))
    for x in scen:
        if x.get("diagram_file"):
            out.append(f"<div id='{esc(fid)}-{esc(x.get('id'))}'><h4>Scenario {esc(x.get('id'))} — {esc(x.get('name'))}</h4>")
            out.append(render_diagram(x["diagram_file"], diagrams_dir, svg_ok))
            if x.get("steps_own"):
                out.append(table(["#", "from → to", "technical", "functional", "business", "evidence"],
                                 [[f"<span class='n'>{esc(st.get('n'))}</span>", f"<code>{esc(st.get('from'))}</code> → <code>{esc(st.get('to'))}</code>", md(st.get("technical")), md(st.get("functional")), md(st.get("business")), md(evid(st.get("evidence")))] for st in lst(x.get("steps_own"))]))
            out.append("</div>")

    if f.get("policies"):
        out.append("<h4>API Manager policies</h4>" + table(["policy", "config", "effect", "evidence"], [[esc(p.get("name")), md(p.get("config")), md(p.get("effect")), md(evid(p.get("evidence")))] for p in lst(f.get("policies"))]))

    out.append("<h4>Participants</h4>" + table(["alias", "name", "kind", "resolved target", "evidence"],
                                             [[f"<code>{esc(p.get('alias'))}</code>", esc(p.get("name")), esc(p.get("kind")), md(p.get("resolved")), md(evid(p.get("evidence")))] for p in lst(f.get("participants"))]))

    out.append("<h4>Sequence diagram (main — shared trunk and all scenarios)</h4>")
    for d in lst(f.get("diagram_files")):
        out.append(render_diagram(d, diagrams_dir, svg_ok))

    has_sc = any(st.get("scenarios") for st in lst(f.get("steps")))
    out.append("<h4>Steps (main diagram)</h4>" + table(["#", "from → to", "technical", "functional", "business"] + (["scenarios"] if has_sc else []) + ["evidence"],
                                       [[f"<span class='n'>{esc(st.get('n'))}</span>", f"<code>{esc(st.get('from'))}</code> → <code>{esc(st.get('to'))}</code>", md(st.get("technical")), md(st.get("functional")), md(st.get("business"))] + ([esc(", ".join(lst(st.get("scenarios"))))] if has_sc else []) + [md(evid(st.get("evidence")))] for st in lst(f.get("steps"))]))

    if f.get("branches"):
        out.append("<h4>Branches &amp; decisions</h4>" + table(["location", "condition (business)", "expression", "paths"],
                                                              [[md(x.get("location")), md(x.get("condition_business")), f"<code>{esc(x.get('condition_expr'))}</code>" if x.get("condition_expr") else "", md("\n".join("- " + p for p in lst(x.get("paths"))))] for x in lst(f.get("branches"))]))
    out.append("<h4>Error paths</h4>" + table(["trigger", "handler", "retries", "logged", "response to caller", "side effects", "evidence"],
                                             [[md(e.get("trigger")), md(e.get("handler")), md(e.get("retries")), md(e.get("logged")), md(e.get("response")), md(e.get("side_effects")), md(evid(e.get("evidence")))] for e in lst(f.get("error_paths"))]))
    if f.get("async"):
        out.append("<h4>Asynchronous / background work</h4>" + table(["construct", "target", "consumer", "on failure", "evidence"],
                                                                    [[esc(a.get("construct")), md(a.get("target")), md(a.get("consumer")), md(a.get("failure")), md(evid(a.get("evidence")))] for a in lst(f.get("async"))]))
    out.append("<h4>Upstream consumers</h4>" + table(["consumer", "user type", "action", "auth / identity", "evidence"],
                                                    [[md(u.get("consumer")), md(u.get("user_type")), md(u.get("action")), md(u.get("auth")), md(evid(u.get("evidence")))] for u in lst(f.get("upstream"))]))
    out.append("<h4>Downstream systems</h4>" + table(["system", "connector", "target", "resolved from", "purpose", "linked endpoint", "evidence"],
                                                    [[md(d.get("system")), esc(d.get("connector")), md(d.get("target")), md(d.get("resolved_from")), md(d.get("purpose")), md(d.get("linked_endpoint")), md(evid(d.get("evidence")))] for d in lst(f.get("downstream"))]))
    if f.get("data"):
        out.append("<h4>Data elements</h4>" + table(["entity", "fields", "Collibra", "classification", "mapping"],
                                                    [[md(d.get("entity")), md(d.get("fields")), md(d.get("collibra")), md(d.get("classification")), md(d.get("mapping"))] for d in lst(f.get("data"))]))
    pr = f.get("production") or {}
    if pr:
        out.append("<h4>Production evidence</h4>" + kv([("Volume", md(pr.get("volume"))), ("Callers", md(pr.get("callers"))), ("Latency", md(pr.get("latency"))), ("Errors", md(pr.get("errors"))), ("Observed paths", md(pr.get("observed_paths"))), ("Evidence", md(evid(pr.get("evidence"))))]))
    else:
        out.append("<h4>Production evidence</h4><p class='empty'>none recorded — see gaps</p>")
    out.append("<h4>Sources used</h4>" + render_sources(f.get("sources")))
    if f.get("conflicts"):
        out.append("<h4>Source conflicts</h4>" + render_conflicts(lst(f.get("conflicts"))))
    out.append("<h4>Verification checklist</h4>" + table(["", "item", "status", "note"],
                                                        [[esc(c.get("id")), esc(CHECK_TEXT.get(c.get("id"), c.get("item", ""))), badge(c.get("status")), md(c.get("note"))] for c in f["checklist"]]))
    out.append("<h4>Gaps</h4>" + render_gaps(lst(f.get("gaps")), with_affects=False))
    out.append("</article>")
    return "\n".join(out)


def render_gaps(gaps, with_affects=True):
    rows = []
    for g in sorted(gaps, key=lambda g: (SEVERITIES.index(g.get("severity")) if g.get("severity") in SEVERITIES else 9, str(g.get("id")))):
        rows.append([f"<span id='{esc(g.get('id'))}'>{esc(g.get('id'))}</span>", badge(g.get("severity")), md(g.get("what")), md(g.get("why")), md(g.get("resolve"))] + ([md(", ".join(lst(g.get("affects"))))] if with_affects else []))
    return table(["id", "severity", "what is missing", "why it matters", "how to resolve"] + (["affects"] if with_affects else []), rows)


def render_conflicts(conflicts):
    return table(["topic", "code says", "production says", "documentation says", "resolution", "impact", "endpoint"],
                 [[md(c.get("topic")), md(c.get("code_says")), md(c.get("prod_says")), md(c.get("doc_says")), md(c.get("resolution")), md(c.get("impact")), md(c.get("_endpoint"))] for c in conflicts])


def build(project, flows, diagrams_dir, svg_ok, inventory, log):
    apps = lst(project.get("applications"))
    conf = Counter(f.get("confidence") for f in flows)
    all_gaps = []
    for g in lst(project.get("gaps")):
        all_gaps.append(dict(g, affects=lst(g.get("affects")) or ["project"]))
    seen_gap = {g["id"] for g in all_gaps if g.get("id")}
    for f in flows:
        for g in lst(f.get("gaps")):
            g2 = dict(g)
            g2["affects"] = sorted(set(lst(g.get("affects")) + [f["id"]]))
            if g2.get("id") in seen_gap:
                for existing in all_gaps:
                    if existing.get("id") == g2["id"]:
                        existing["affects"] = sorted(set(existing["affects"] + g2["affects"]))
                continue
            seen_gap.add(g2.get("id"))
            all_gaps.append(g2)
    all_conflicts = [dict(c, _endpoint="project") for c in lst(project.get("conflicts"))]
    for f in flows:
        for c in lst(f.get("conflicts")):
            all_conflicts.append(dict(c, _endpoint=f["id"]))
    sev = Counter(g.get("severity") for g in all_gaps)
    expected = project.get("endpoint_count_expected")

    body = []
    body.append(f"<header class='cover'><h1>{esc(project['title'])}</h1><div class='meta'>Environment <strong>{esc(project['environment'])}</strong> · generated {esc(project.get('generated') or dt.date.today().isoformat())}" + (f" · {esc(project.get('author'))}" if project.get("author") else "") + "</div></header>")

    body.append("<section id='overview'><h2>1. Overview</h2>")
    body.append("<div class='kpis'>" + "".join(f"<div class='kpi'><div class='v'>{v}</div><div class='l'>{l}</div></div>" for v, l in [
        (len(flows), "endpoints documented"), (expected if expected is not None else "—", "endpoints expected"), (sum(len(lst(f.get("scenarios"))) for f in flows), "business scenarios"),
        (conf.get("high", 0), "high confidence"), (conf.get("medium", 0), "medium"), (conf.get("low", 0), "low"),
        (sev.get("blocking", 0), "blocking gaps"), (sev.get("major", 0), "major gaps"), (sev.get("minor", 0), "minor gaps"), (len(all_conflicts), "source conflicts")]) + "</div>")
    if expected is not None and expected != len(flows):
        body.append(f"<div class='callout bad'>Count check failed: {len(flows)} endpoint records but {expected} expected from Phase 1. Every entry point needs a record.</div>")
        log.err(f"endpoint count mismatch: {len(flows)} records vs endpoint_count_expected={expected}")
    body.append(table(["application", "layer", "version", "repo", "description"], [[esc(a.get("name")), esc(a.get("layer")), esc(a.get("version")), md(a.get("repo")), md(a.get("description"))] for a in apps]))
    body.append(f"<div>{md(project.get('overview'))}</div>")
    if project.get("inputs_received") or project.get("inputs_missing"):
        body.append("<div class='grid2'><div><h4>Inputs received</h4>" + md("\n".join("- " + x for x in lst(project.get("inputs_received")))) + "</div><div><h4>Inputs missing</h4>" + (md("\n".join("- " + x for x in lst(project.get("inputs_missing")))) or "<p class='empty'>none</p>") + "</div></div>")
    body.append("</section>")

    body.append("<section id='context'><h2>2. System context</h2>")
    if project.get("context_diagram"):
        body.append(render_diagram(project["context_diagram"], diagrams_dir, svg_ok))
    body.append("<div class='grid2'><div><h4>Actors</h4>" + table(["actor", "via", "description"], [[esc(a.get("name")), esc(a.get("via")), md(a.get("description"))] for a in lst(project.get("actors"))]) +
                "</div><div><h4>Systems</h4>" + table(["system", "role", "hosts / identifiers"], [[esc(s.get("name")), md(s.get("role")), md(s.get("hosts"))] for s in lst(project.get("systems"))]) + "</div></div></section>")

    body.append("<section id='index'><h2>3. Endpoint index</h2>")
    rows = []
    for f in flows:
        b = f.get("business") or {}
        ds = ", ".join(sorted({d.get("system") or "?" for d in lst(f.get("downstream"))}))
        rows.append([f"<a href='#{esc(f['id'])}'>{esc(f['id'])}</a>", esc(f.get("app")), badge("method", f.get("method") or f.get("type")), f"<code>{esc(f.get('path') or '')}</code>", esc(f.get("name")), md(b.get("actor")), str(len(lst(f.get("scenarios")))), md(ds),
                     "yes" if f.get("async") else "", badge(f.get("confidence")), str(len(lst(f.get("gaps")))), str(sum(1 for c in f["checklist"] if c.get("status") == "done")) + f"/{len(CHECKLIST)}"])
    body.append(table(["id", "app", "method", "path / trigger", "name", "actor", "scenarios", "downstream", "async", "confidence", "gaps", "checklist"], rows, cls="sortable"))
    body.append("</section>")

    body.append("<section id='endpoints'><h2>4. Endpoints</h2>")
    for f in flows:
        body.append(render_endpoint(f, diagrams_dir, svg_ok))
    body.append("</section>")

    body.append("<section id='gaps'><h2>5. Gap register</h2>" + (render_gaps(all_gaps) if all_gaps else "<p class='empty'>No gaps recorded. (Check that this is true rather than unrecorded.)</p>") + "</section>")
    body.append("<section id='conflicts'><h2>6. Source conflict log</h2>" + (render_conflicts(all_conflicts) if all_conflicts else "<p class='empty'>No conflicts recorded.</p>") + "</section>")

    body.append("<section id='coverage'><h2>7. Coverage &amp; verification</h2>")
    body.append(f"<p>Endpoint records: <strong>{len(flows)}</strong>" + (f" · expected: <strong>{expected}</strong>" if expected is not None else "") + f" · scenarios: <strong>{sum(len(lst(f.get('scenarios'))) for f in flows)}</strong> · diagrams referenced: <strong>{sum(len(lst(f.get('diagram_files'))) + sum(1 for x in lst(f.get('scenarios')) if x.get('diagram_file')) for f in flows)}</strong></p>")
    if inventory:
        unreachable, missing_targets, inv_eps = [], [], 0
        for p in inventory.get("projects", []):
            unreachable += [f"{p['project']}: {x}" for x in p.get("unreachable_flows", [])]
            missing_targets += [f"{p['project']}: {x}" for x in p.get("missing_flow_targets", [])]
            inv_eps += len(p.get("endpoints", []))
        body.append(f"<p>Phase 0 inventory found <strong>{inv_eps}</strong> mechanical entry points across {len(inventory.get('projects', []))} project(s).</p>")
        if inv_eps != len(flows):
            body.append(f"<div class='callout'>Inventory entry points ({inv_eps}) ≠ documented endpoints ({len(flows)}). This is expected if Phase 1 added/merged endpoints (proxy routes, spec-only resources, non-HTTP triggers) — the difference must be explained in the overview or gap register.</div>")
        body.append("<h4>Flows not reachable from any entry point</h4>" + (md("\n".join("- `" + x + "`" for x in unreachable)) if unreachable else "<p class='empty'>none</p>"))
        body.append("<h4>Referenced flows not found in code</h4>" + (md("\n".join("- `" + x + "`" for x in missing_targets)) if missing_targets else "<p class='empty'>none</p>"))
    body.append(f"<h4>Checklist completion</h4><p class='legend'>one row per endpoint, {len(CHECKLIST)} cells C01…C{len(CHECKLIST)} — green done, amber partial, red blocked/missing</p>")
    for f in flows:
        body.append(f"<div style='display:grid;grid-template-columns:220px 1fr;gap:.6rem;align-items:center;margin:.2rem 0'><a href='#{esc(f['id'])}'>{esc(f['id'])}</a><div class='heat'>" + "".join(f"<div class='{esc(c.get('status'))}' title='{esc(c.get('id'))}: {esc(c.get('status'))} {esc(c.get('note') or '')}'></div>" for c in f["checklist"]) + "</div></div>")
    body.append("</section>")

    body.append("<section id='method'><h2>8. Methodology</h2>" + md(
        "Phase 0 — mechanical inventory of Mule XML, properties (per environment), RAML/OAS, APIkit mappings and the flow-ref call graph.\n"
        "Phase 1 — endpoint list confirmed by cross-checking listeners, specs, APIkit flows, non-HTTP sources, API Manager policies, production traffic and build metadata.\n"
        "Phase 2 — every path of every endpoint traced from source to response: all choice branches, error handlers (try/flow/global/APIkit/connector), async, retries, loops, outbound calls and DataWeave transforms; paths with distinct business meaning split into named scenarios, each with its own diagram where they diverge.\n"
        "Phase 3 — enrichment with upstream consumers and user types, downstream systems, business meaning, Collibra vocabulary and production evidence.\n"
        "Phase 4 — 16-item verification checklist per endpoint, whole-project count/reachability/reverse checks, and a gap register.\n"
        "Phase 5 — this report.\n\n"
        "**Source precedence:** source code and configuration → observed production behaviour (Splunk, Anypoint) → written documentation. Conflicts are logged, never silently resolved.\n\n"
        "**Confidence:** high = fully traced, targets resolved, upstream/downstream confirmed by code or production data; medium = traced, but naming relies on documentation only or production data unavailable; low = missing code/spec/config or unresolved secure property on the path.\n"
        + ("\n" + project.get("methodology_notes", "") if project.get("methodology_notes") else "")) + "</section>")

    biblio = defaultdict(set)
    for s in lst(project.get("sources")) + [s for f in flows for s in lst(f.get("sources"))]:
        biblio[s.get("type") or "other"].add((s.get("ref") or "", s.get("note") or ""))
    body.append("<section id='biblio'><h2>9. Bibliography</h2>")
    for t in sorted(biblio):
        body.append(f"<h4>{esc(t)}</h4>" + md("\n".join("- " + r + (f" — {n}" if n else "") for r, n in sorted(biblio[t]))))
    body.append("</section>")

    nav = ["<ul>", "<li><a href='#overview'>1. Overview</a></li>", "<li><a href='#context'>2. System context</a></li>", "<li><a href='#index'>3. Endpoint index</a></li>", "<li><a href='#endpoints'>4. Endpoints</a></li>"]
    for f in flows:
        nav.append(f"<li class='sub'><a class='ep' href='#{esc(f['id'])}'><span class='m'>{esc((f.get('method') or f.get('type') or '')[:6])}</span><span>{esc(f.get('path') or f.get('name'))}</span></a></li>")
    nav += ["<li><a href='#gaps'>5. Gap register</a></li>", "<li><a href='#conflicts'>6. Conflict log</a></li>", "<li><a href='#coverage'>7. Coverage</a></li>", "<li><a href='#method'>8. Methodology</a></li>", "<li><a href='#biblio'>9. Bibliography</a></li>", "</ul>"]
    return "\n".join(body), "\n".join(nav)


def mermaid_parse_check(diagrams_dir, log):
    """Parse every .mmd with the real Mermaid parser (headless, via jsdom). Optional: needs node + `npm install` in scripts/."""
    node = shutil.which("node")
    if not node:
        log.note("node not found — using built-in regex lint only for Mermaid syntax")
        return
    if not os.path.isdir(os.path.join(HERE, "node_modules")):
        npm = shutil.which("npm")
        if not npm:
            log.note("npm not found — using built-in regex lint only for Mermaid syntax")
            return
        try:
            r = subprocess.run([npm, "install", "--silent", "--no-audit", "--no-fund"], cwd=HERE, capture_output=True, text=True, timeout=240)
            if r.returncode != 0:
                log.warn("npm install for mermaid_check failed (offline?) — using built-in regex lint only")
                return
        except Exception as e:
            log.warn(f"npm install for mermaid_check failed: {e} — using built-in regex lint only")
            return
    files = sorted(glob.glob(os.path.join(diagrams_dir, "*.mmd")))
    try:
        r = subprocess.run([node, os.path.join(HERE, "mermaid_check.mjs")] + files, capture_output=True, text=True, timeout=300)
    except Exception as e:
        log.warn(f"mermaid_check could not run: {e}")
        return
    ok = 0
    for line in r.stdout.splitlines():
        if line.startswith("OK "):
            ok += 1
        elif line.startswith("FAIL "):
            _, f, msg = line.split(" ", 2)
            log.err(f"Mermaid parse error in {os.path.basename(f)}: {msg}")
        elif line.startswith("UNAVAILABLE"):
            log.warn(line + " — using built-in regex lint only")
            return
    log.note(f"Mermaid parser: {ok}/{len(files)} diagrams parse cleanly")


def try_render_svg(diagrams_dir, log):
    exe = shutil.which("mmdc")
    if not exe:
        log.warn("mmdc not found — .svg files not rendered (npm i -g @mermaid-js/mermaid-cli); HTML still renders diagrams in the browser")
        return False
    ok = 0
    files = sorted(glob.glob(os.path.join(diagrams_dir, "*.mmd")))
    for i, m in enumerate(files):
        svg = os.path.splitext(m)[0] + ".svg"
        try:
            r = subprocess.run([exe, "-q", "-i", m, "-o", svg, "-b", "white"], capture_output=True, text=True, timeout=120)
        except Exception as e:
            log.warn(f"mmdc failed on {os.path.basename(m)}: {e}")
            if i == 0:
                return False
            continue
        if r.returncode != 0 or not os.path.exists(svg):
            msg = (r.stderr or r.stdout or "").strip().splitlines()
            log.warn(f"mmdc could not render {os.path.basename(m)}: {msg[0] if msg else 'unknown error'}")
            if i == 0 and any("Chrome" in x or "puppeteer" in x for x in msg):
                log.warn("mmdc has no browser available — skipping SVG rendering entirely")
                return False
            continue
        ok += 1
    log.note(f"rendered {ok}/{len(files)} diagrams to SVG")
    return ok > 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", required=True)
    ap.add_argument("--flows", required=True, help="directory of flow records")
    ap.add_argument("--diagrams", required=True, help="directory with .mmd files")
    ap.add_argument("--out", required=True, help="report output directory")
    ap.add_argument("--render-svg", action="store_true")
    ap.add_argument("--inline-mermaid", help="path to mermaid.min.js to inline (offline report)")
    ap.add_argument("--inventory", help="work/inventory.json for coverage cross-checks")
    ap.add_argument("--strict", action="store_true", help="exit 1 on warnings too")
    args = ap.parse_args()

    log = Log()
    project = load_json(args.project, log)
    if project is None:
        sys.exit(1)
    for k in REQ_PROJECT:
        if k not in project:
            log.err(f"project.json missing required field '{k}'")

    flow_files = sorted(glob.glob(os.path.join(args.flows, "*.json")))
    if not flow_files:
        log.err(f"no flow records in {args.flows}")
    flows = []
    for p in flow_files:
        f = load_json(p, log)
        if f is None:
            continue
        flows.append(validate_flow(f, p, args.diagrams, log))
    flows.sort(key=lambda f: f.get("id", ""))
    ids = Counter(f.get("id") for f in flows)
    for i, c in ids.items():
        if c > 1:
            log.err(f"duplicate endpoint id {i}")
    if project.get("context_diagram"):
        p = os.path.join(args.diagrams, project["context_diagram"])
        if not os.path.exists(p):
            log.warn(f"context diagram {project['context_diagram']} not found")
        else:
            with open(p, encoding="utf-8") as fh:
                lint_mermaid(fh.read(), project["context_diagram"], log)

    inventory = load_json(args.inventory, log) if args.inventory else None

    os.makedirs(args.out, exist_ok=True)
    out_diagrams = os.path.join(args.out, "diagrams")
    if os.path.abspath(out_diagrams) != os.path.abspath(args.diagrams):
        os.makedirs(out_diagrams, exist_ok=True)
        for m in glob.glob(os.path.join(args.diagrams, "*.mmd")):
            shutil.copy2(m, out_diagrams)
    mermaid_parse_check(out_diagrams, log)
    svg_ok = try_render_svg(out_diagrams, log) if args.render_svg else False

    body, nav = build(project, flows, out_diagrams, svg_ok, inventory, log)
    if args.inline_mermaid:
        with open(args.inline_mermaid, encoding="utf-8") as fh:
            mscript = "<script>" + fh.read() + "</script>"
    else:
        mscript = f"<script src='{MERMAID_CDN}'></script>"
    mscript += "<script>mermaid.initialize({startOnLoad:true,theme:'neutral',sequence:{useMaxWidth:false,wrap:true,mirrorActors:false},flowchart:{useMaxWidth:false}});</script>"
    with open(TEMPLATE, encoding="utf-8") as fh:
        tpl = fh.read()
    page = (tpl.replace("{{TITLE}}", esc(project["title"])).replace("{{NAV}}", nav).replace("{{BODY}}", body)
            .replace("{{MERMAID_SCRIPT}}", mscript).replace("{{GENERATED}}", esc(project.get("generated") or dt.date.today().isoformat())))
    with open(os.path.join(args.out, "index.html"), "w", encoding="utf-8") as fh:
        fh.write(page)

    data_dir = os.path.join(args.out, "data", "flows")
    os.makedirs(data_dir, exist_ok=True)
    shutil.copy2(args.project, os.path.join(args.out, "data", "project.json"))
    for p in flow_files:
        shutil.copy2(p, data_dir)

    with open(os.path.join(args.out, "build-log.txt"), "w", encoding="utf-8") as fh:
        fh.write(f"built {dt.datetime.now().isoformat(timespec='seconds')}\nendpoints: {len(flows)}  expected: {project.get('endpoint_count_expected')}\n")
        fh.write(f"confidence: {dict(Counter(f.get('confidence') for f in flows))}\n")
        fh.write("\nERRORS (%d)\n" % len(log.errors) + "\n".join(log.errors) + "\n\nWARNINGS (%d)\n" % len(log.warnings) + "\n".join(log.warnings) + "\n\nINFO\n" + "\n".join(log.info) + "\n")
    print(f"report: {os.path.join(args.out, 'index.html')}  ({len(flows)} endpoints, {len(log.errors)} errors, {len(log.warnings)} warnings) — see build-log.txt")
    if log.errors or (args.strict and log.warnings):
        sys.exit(1)


if __name__ == "__main__":
    main()
