#!/usr/bin/env python3
"""
inventory_mule.py — Phase 0 mechanical inventory of one or more MuleSoft projects.

Parses Mule 4 (and Mule 3) XML configs, resolves ${property} placeholders for a
chosen environment, reads RAML/OAS specs, maps APIkit routers to their resource
flows, builds the flow-ref call graph and lists every inbound source and
outbound connector call.

Usage:
  python3 inventory_mule.py <project-root> [<project-root> ...] --env prod --out work/ [--draft-diagrams]

Outputs (in --out):
  inventory.json   full machine-readable inventory
  inventory.md     human-readable summary to read in full
  callgraph.mmd    Mermaid flowchart of flow-ref edges
  drafts/*.mmd     (with --draft-diagrams) skeleton sequence diagrams per entry point

The script is deliberately conservative: anything it cannot resolve is listed
under "unresolved"/"gaps" rather than guessed.
"""
import argparse
import glob
import json
import os
import re
import sys
from collections import defaultdict

try:
    from lxml import etree as LET
    HAVE_LXML = True
except ImportError:  # pragma: no cover
    HAVE_LXML = False
    import xml.etree.ElementTree as ET

try:
    import yaml
    HAVE_YAML = True
except ImportError:  # pragma: no cover
    HAVE_YAML = False

# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------

HTTP_METHODS = {"get", "post", "put", "delete", "patch", "head", "options", "trace"}

# localnames that are inbound sources when they are the first child of a flow
SOURCE_LOCALNAMES = {
    "listener", "scheduler", "subscriber", "poll", "inbound-endpoint", "message-listener",
    "subscribe-topic-listener", "replay-channel-listener", "modified-object-listener",
    "deleted-object-listener", "new-object-listener", "replay-topic-listener",
    "listener-imap", "listener-pop3", "on-new-file", "on-new-object", "polling", "trigger",
}

CONNECTOR_PREFIXES = {
    "http", "https", "db", "jdbc", "jms", "vm", "salesforce", "sfdc", "sftp", "ftp", "ftps", "file",
    "anypoint-mq", "wsc", "email", "smtp", "os", "kafka", "sockets", "mongo", "amqp", "ldap",
    "redis", "cosmosdb", "azure-service-bus", "servicebus", "sap", "netsuite", "workday", "ibm-mq",
    "aws-sqs", "sqs", "s3", "aws-s3", "sns", "aws-sns", "dynamodb", "objectstore", "twilio", "slack",
    "sharepoint", "box", "servicenow", "jira", "veeva", "oracle-ebs", "peoplesoft", "msdynamics",
    "dynamics365", "marketo", "hubspot", "zendesk", "stripe", "elasticsearch", "cassandra",
    "hdfs", "neo4j", "graphql", "rest-connect", "smb", "ssh", "xml-module", "json-module",
}

# child elements of connector operations that are parameters, not operations
OP_PARAM_LOCALNAMES = {
    "body", "headers", "query-params", "uri-params", "sql", "input-parameters", "records",
    "message", "reconnect", "reconnect-forever", "response", "error-response", "content",
    "properties", "user-properties", "header", "attachments", "to-addresses", "cc-addresses",
    "in-parameters", "out-parameters", "parameters", "attributes", "key", "value", "fields",
    "response-validator", "success-status-code-validator", "failure-status-code-validator",
    "input-parameter", "message-properties", "on-message", "listener-connection", "connection",
    "target", "query", "ids", "objects", "sobjects", "headers-in", "default-headers",
}

# core scopes / routers we descend into
SCOPE_LOCALNAMES = {
    "choice", "when", "otherwise", "try", "error-handler", "on-error-propagate", "on-error-continue",
    "on-error", "scatter-gather", "route", "async", "until-successful", "foreach", "parallel-foreach",
    "first-successful", "round-robin", "cache", "batch", "job", "process-records", "step", "aggregator",
    "on-complete", "input", "catch-exception-strategy", "rollback-exception-strategy",
    "choice-exception-strategy", "exception-strategy", "enricher", "processor-chain", "transactional",
    "xa-transactional", "message-processor-chain", "flow", "sub-flow", "critical-section",
}

ENV_PATTERN = re.compile(r"[-_.](dev|develop|development|test|tst|qa|uat|sit|stage|staging|stg|prod|production|prd|perf|local|sandbox|sbx)\b", re.I)


# ----------------------------------------------------------------------------
# XML helpers
# ----------------------------------------------------------------------------

def localname(tag):
    if not isinstance(tag, str):
        return ""
    return tag.split("}", 1)[1] if "}" in tag else tag


def nsprefix(tag):
    """Derive a short prefix from the namespace URI (http://www.mulesoft.org/schema/mule/http -> http)."""
    if not isinstance(tag, str) or "}" not in tag:
        return "mule"
    uri = tag[1:].split("}", 1)[0]
    if uri.endswith("/mule/core") or uri.endswith("/mule/ee/core"):
        return "ee" if "/ee/" in uri else "mule"
    parts = uri.rstrip("/").split("/")
    last = parts[-1]
    if last in ("core",):
        return "mule"
    if last in ("mule-apikit", "apikit"):
        return "apikit"
    if last == "ee" and len(parts) > 1 and parts[-2] == "mule":
        return "ee"
    return last


def line_of(el):
    return getattr(el, "sourceline", None)


def parse_xml(path):
    if HAVE_LXML:
        parser = LET.XMLParser(remove_comments=True, recover=True, huge_tree=True)
        return LET.parse(path, parser).getroot()
    return ET.parse(path).getroot()


def is_mule_config(root):
    tag = root.tag if isinstance(root.tag, str) else ""
    return "mulesoft.org/schema/mule" in tag or localname(tag) in ("mule", "domain", "mule-domain")


def text_of(el, limit=600):
    t = (el.text or "").strip()
    if len(t) > limit:
        t = t[:limit] + " …[truncated]"
    return t


# ----------------------------------------------------------------------------
# Properties
# ----------------------------------------------------------------------------

def flatten_yaml(obj, prefix=""):
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            out.update(flatten_yaml(v, f"{prefix}{k}." if prefix else f"{k}."))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            out.update(flatten_yaml(v, f"{prefix}{i}."))
    else:
        out[prefix.rstrip(".")] = "" if obj is None else str(obj)
    return out


def load_property_files(root):
    files = []
    for pattern in ("**/*.properties", "**/*.yaml", "**/*.yml"):
        for p in glob.glob(os.path.join(root, "src", "main", "resources", pattern), recursive=True):
            files.append(p)
    # also top-level config dirs some teams use
    for pattern in ("config/**/*.properties", "config/**/*.yaml", "config/**/*.yml"):
        files.extend(glob.glob(os.path.join(root, pattern), recursive=True))
    result = []
    for p in sorted(set(files)):
        base = os.path.basename(p)
        if base in ("log4j2.xml",):
            continue
        env = None
        m = ENV_PATTERN.search(os.path.splitext(base)[0])
        if m:
            env = m.group(1).lower()
        props = {}
        try:
            if p.endswith(".properties"):
                with open(p, encoding="utf-8", errors="replace") as fh:
                    for line in fh:
                        s = line.strip()
                        if not s or s.startswith("#") or s.startswith("!"):
                            continue
                        if "=" in s:
                            k, v = s.split("=", 1)
                        elif ":" in s:
                            k, v = s.split(":", 1)
                        else:
                            continue
                        props[k.strip()] = v.strip()
            elif HAVE_YAML:
                with open(p, encoding="utf-8", errors="replace") as fh:
                    data = yaml.safe_load(fh)
                props = flatten_yaml(data) if data else {}
        except Exception as e:  # noqa
            props = {"__parse_error__": str(e)}
        result.append({"file": os.path.relpath(p, root), "env": env, "properties": props})
    return result


ENV_ALIASES = {
    "prod": {"prod", "production", "prd"}, "dev": {"dev", "develop", "development"},
    "test": {"test", "tst"}, "qa": {"qa"}, "uat": {"uat"}, "sit": {"sit"},
    "stage": {"stage", "staging", "stg"}, "perf": {"perf"}, "local": {"local"}, "sandbox": {"sandbox", "sbx"},
}


def env_matches(file_env, wanted):
    if not wanted:
        return file_env is None
    wanted = wanted.lower()
    for canon, aliases in ENV_ALIASES.items():
        if wanted in aliases:
            return file_env in aliases
    return file_env == wanted


class PropertyResolver:
    PLACEHOLDER = re.compile(r"\$\{([^}]+)\}")

    def __init__(self, prop_files, env):
        self.env = env
        self.values = defaultdict(list)  # key -> [(value, file, env)]
        for pf in prop_files:
            for k, v in pf["properties"].items():
                self.values[k].append((v, pf["file"], pf["env"]))
        self.unresolved = defaultdict(set)   # key -> set(where used)
        self.secure = defaultdict(set)
        self.ambiguous = {}
        # deploy-time environment selector keys (set in Runtime Manager, not in files)
        self.deploy_defaults = {k: env for k in ("env", "mule.env", "environment", "mule.environment", "ENV")} if env else {}

    def lookup(self, key):
        cands = self.values.get(key, [])
        if not cands:
            return None
        env_c = [c for c in cands if env_matches(c[2], self.env)]
        common_c = [c for c in cands if c[2] is None]
        chosen = env_c or common_c or cands
        if len({c[0] for c in chosen}) > 1:
            self.ambiguous[key] = [{"value": c[0], "file": c[1], "env": c[2]} for c in chosen]
        return chosen[0]

    def resolve(self, s, where="", depth=0):
        if not isinstance(s, str) or "${" not in s or depth > 8:
            return s

        def rep(m):
            key = m.group(1).strip()
            if ":" in key and not key.startswith("mule."):  # ${key:default}
                key, default = key.split(":", 1)
            else:
                default = None
            hit = self.lookup(key)
            if hit is None and key in self.deploy_defaults:
                return self.deploy_defaults[key]
            if hit is None:
                if default is not None:
                    return default
                self.unresolved[key].add(where)
                return "${" + key + "}"
            val = hit[0]
            if val.startswith("![") and val.endswith("]"):
                self.secure[key].add(where)
                return "${SECURE:" + key + "}"
            return self.resolve(val, where, depth + 1)

        return self.PLACEHOLDER.sub(rep, s)


# ----------------------------------------------------------------------------
# Spec parsing (RAML / OAS)
# ----------------------------------------------------------------------------

class RamlLoader(yaml.SafeLoader if HAVE_YAML else object):
    pass


if HAVE_YAML:
    def _include(loader, node):
        return {"!include": loader.construct_scalar(node)}
    RamlLoader.add_constructor("!include", _include)


def parse_spec(path, project_root):
    """Return {'kind','title','version','baseUri','resources':[{path,method,description,file}], 'includes':[...]}"""
    out = {"file": os.path.relpath(path, project_root), "kind": None, "title": None, "version": None,
           "baseUri": None, "resources": [], "includes": [], "errors": []}
    if not os.path.exists(path):
        out["errors"].append("spec file not found")
        return out
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            raw = fh.read()
    except Exception as e:
        out["errors"].append(str(e))
        return out
    if not HAVE_YAML:
        out["errors"].append("pyyaml not installed; spec not parsed")
        return out
    try:
        if path.endswith(".json"):
            data = json.loads(raw)
        else:
            data = yaml.load(raw, Loader=RamlLoader)
    except Exception as e:
        out["errors"].append(f"parse error: {e}")
        return out
    if not isinstance(data, dict):
        out["errors"].append("spec root is not a mapping")
        return out

    def collect_includes(obj):
        if isinstance(obj, dict):
            if "!include" in obj and len(obj) == 1:
                out["includes"].append(obj["!include"])
            for v in obj.values():
                collect_includes(v)
        elif isinstance(obj, list):
            for v in obj:
                collect_includes(v)
    collect_includes(data)

    if raw.lstrip().startswith("#%RAML") or any(k.startswith("/") for k in data.keys()):
        out["kind"] = "raml"
        out["title"] = data.get("title")
        out["version"] = data.get("version")
        out["baseUri"] = data.get("baseUri")

        def walk(node, prefix):
            if not isinstance(node, dict):
                return
            for k, v in node.items():
                if isinstance(k, str) and k.startswith("/"):
                    walk(v, prefix + k)
                elif isinstance(k, str) and k.lower() in HTTP_METHODS and prefix:
                    desc = v.get("description") if isinstance(v, dict) else None
                    out["resources"].append({"path": prefix, "method": k.upper(),
                                             "description": (desc or "").strip()[:300],
                                             "responses": sorted(str(x) for x in (v.get("responses") or {}).keys()) if isinstance(v, dict) and isinstance(v.get("responses"), dict) else []})
        walk(data, "")
    elif "openapi" in data or "swagger" in data:
        out["kind"] = "oas"
        info = data.get("info") or {}
        out["title"] = info.get("title")
        out["version"] = info.get("version")
        servers = data.get("servers") or []
        if servers and isinstance(servers, list) and isinstance(servers[0], dict):
            out["baseUri"] = servers[0].get("url")
        elif data.get("basePath"):
            out["baseUri"] = data.get("basePath")
        for p, methods in (data.get("paths") or {}).items():
            if not isinstance(methods, dict):
                continue
            for m, op in methods.items():
                if m.lower() in HTTP_METHODS:
                    out["resources"].append({"path": p, "method": m.upper(),
                                             "description": ((op or {}).get("summary") or (op or {}).get("description") or "").strip()[:300],
                                             "responses": sorted(str(x) for x in ((op or {}).get("responses") or {}).keys())})
    else:
        out["errors"].append("unrecognised spec format")
    return out


APIKIT_FLOW_RE = re.compile(r"^(get|post|put|delete|patch|head|options|trace):(.+)$", re.I)


def parse_apikit_flow_name(name):
    """Return (method, resource, content_type, config) or None."""
    m = APIKIT_FLOW_RE.match(name or "")
    if not m:
        return None
    method = m.group(1).upper()
    rest = m.group(2)
    parts = rest.split(":")
    if len(parts) < 2:
        return None
    resource = parts[0]
    config = parts[-1]
    ctype = ":".join(parts[1:-1]) if len(parts) > 2 else None
    resource = resource.replace("\\", "/")
    resource = re.sub(r"\(([^)]+)\)", r"{\1}", resource)
    if not resource.startswith("/"):
        resource = "/" + resource
    return method, resource, (ctype.replace("\\", "/") if ctype else None), config


def norm_resource(p):
    p = re.sub(r"\{[^}]+\}", "{}", p or "")
    return p.rstrip("/") or "/"


# ----------------------------------------------------------------------------
# Flow walking
# ----------------------------------------------------------------------------

class ProjectScanner:
    def __init__(self, root, env):
        self.root = os.path.abspath(root)
        self.name = os.path.basename(self.root.rstrip(os.sep))
        self.env = env
        self.files = []
        self.flows = {}          # name -> flow record
        self.globals = []        # global config elements
        self.configs = {}        # name -> global config record (with resolved host etc.)
        self.specs = {}          # spec file -> parsed
        self.apikit_configs = {}  # apikit config name -> {api, file, line}
        self.autodiscovery = []
        self.default_error_handler = None
        self.global_error_handlers = {}
        self.warnings = []
        self.prop_files = load_property_files(self.root)
        self.resolver = PropertyResolver(self.prop_files, env)
        self.pom = self.read_pom()
        self.artifact = self.read_artifact()

    # -- project metadata ----------------------------------------------------
    def read_pom(self):
        p = os.path.join(self.root, "pom.xml")
        if not os.path.exists(p):
            return None
        try:
            root = parse_xml(p)
        except Exception as e:
            self.warnings.append(f"pom.xml parse error: {e}")
            return None
        info = {"artifactId": None, "version": None, "dependencies": [], "spec_dependencies": [], "shared_libraries": []}
        for el in root.iter():
            ln = localname(el.tag)
            if ln == "artifactId" and info["artifactId"] is None and localname(el.getparent().tag if HAVE_LXML else "") == "project":
                info["artifactId"] = (el.text or "").strip()
            if ln == "version" and info["version"] is None and HAVE_LXML and localname(el.getparent().tag) == "project":
                info["version"] = (el.text or "").strip()
        for dep in root.iter():
            if localname(dep.tag) != "dependency":
                continue
            d = {localname(c.tag): (c.text or "").strip() for c in dep if isinstance(c.tag, str)}
            key = f"{d.get('groupId','')}:{d.get('artifactId','')}:{d.get('version','')}"
            if d.get("classifier") in ("raml", "oas", "raml-fragment", "oas-fragment"):
                info["spec_dependencies"].append(key + f" ({d.get('classifier')})")
            else:
                info["dependencies"].append(key)
        if HAVE_LXML:
            for sl in root.iter():
                if localname(sl.tag) == "sharedLibrary":
                    d = {localname(c.tag): (c.text or "").strip() for c in sl if isinstance(c.tag, str)}
                    info["shared_libraries"].append(f"{d.get('groupId','')}:{d.get('artifactId','')}")
        return info

    def read_artifact(self):
        p = os.path.join(self.root, "mule-artifact.json")
        if not os.path.exists(p):
            return None
        try:
            with open(p, encoding="utf-8") as fh:
                return json.load(fh)
        except Exception as e:
            self.warnings.append(f"mule-artifact.json parse error: {e}")
            return None

    # -- scanning ------------------------------------------------------------
    def find_config_files(self):
        candidates = []
        for sub in ("src/main/mule", "src/main/app", "src/main/resources", "."):
            base = os.path.join(self.root, sub)
            if os.path.isdir(base):
                candidates.extend(glob.glob(os.path.join(base, "**", "*.xml"), recursive=True))
        seen, out = set(), []
        for c in sorted(os.path.normpath(x) for x in candidates):
            if "/target/" in c or "/node_modules/" in c or "/.git/" in c:
                continue
            if c in seen:
                continue
            seen.add(c)
            try:
                root = parse_xml(c)
            except Exception as e:
                self.warnings.append(f"XML parse error {os.path.relpath(c, self.root)}: {e}")
                continue
            if is_mule_config(root):
                out.append((c, root))
        return out

    def rel(self, p):
        return os.path.relpath(p, self.root)

    def scan(self):
        for path, root in self.find_config_files():
            rp = self.rel(path)
            self.files.append(rp)
            for el in root:
                if not isinstance(el.tag, str):
                    continue
                ln = localname(el.tag)
                pfx = nsprefix(el.tag)
                if ln in ("flow", "sub-flow"):
                    self.add_flow(el, rp, ln)
                else:
                    self.add_global(el, rp, pfx, ln)
        self.link_specs()
        self.build_endpoints()
        self.build_callgraph()

    # -- globals -------------------------------------------------------------
    def add_global(self, el, file, pfx, ln):
        attrs = dict(el.attrib)
        rec = {"element": f"{pfx}:{ln}", "name": attrs.get("name"), "file": file, "line": line_of(el), "attrs": {}, "resolved": {}}
        interesting = {}
        for k, v in attrs.items():
            interesting[k] = v
        # connection child (host/port/basePath etc.)
        for child in el:
            if not isinstance(child.tag, str):
                continue
            cln = localname(child.tag)
            for k, v in child.attrib.items():
                interesting[f"{cln}.{k}"] = v
            for gc in child:
                if isinstance(gc.tag, str):
                    for k, v in gc.attrib.items():
                        interesting[f"{cln}.{localname(gc.tag)}.{k}"] = v
        rec["attrs"] = interesting
        where = f"{file}:{line_of(el)}"
        for k, v in interesting.items():
            if isinstance(v, str) and "${" in v:
                rec["resolved"][k] = self.resolver.resolve(v, where)
        # summarise a target for connector configs
        target = self.summarise_target(pfx, ln, interesting, rec["resolved"])
        if target:
            rec["target"] = target
        if ln == "configuration" and attrs.get("defaultErrorHandler-ref"):
            self.default_error_handler = attrs.get("defaultErrorHandler-ref")
        if ln == "error-handler":
            self.global_error_handlers[attrs.get("name")] = {"file": file, "line": line_of(el), "handlers": self.summarise_error_handlers(el)}
        if pfx == "api-gateway" and ln == "autodiscovery":
            self.autodiscovery.append({"apiId": self.resolver.resolve(attrs.get("apiId", ""), where), "flowRef": attrs.get("flowRef"), "file": file, "line": line_of(el)})
        if pfx == "apikit" and ln == "config":
            api = attrs.get("api") or attrs.get("raml")
            self.apikit_configs[attrs.get("name")] = {"api": api, "file": file, "line": line_of(el), "attrs": attrs}
        if ln == "configuration-properties" or (pfx == "secure-properties" and ln == "config"):
            rec["properties_file"] = self.resolver.resolve(attrs.get("file", ""), where)
        self.globals.append(rec)
        if rec["name"]:
            self.configs[rec["name"]] = rec

    def summarise_target(self, pfx, ln, attrs, resolved):
        g = lambda k: resolved.get(k, attrs.get(k))
        if pfx in ("http", "https") and ln in ("request-config", "listener-config"):
            for c in ("request-connection", "listener-connection"):
                host = g(f"{c}.host")
                if host:
                    proto = g(f"{c}.protocol") or ("HTTPS" if g(f"{c}.tls-context") or any(k.startswith(f"{c}.tls") for k in attrs) else "HTTP")
                    port = g(f"{c}.port")
                    base = g("basePath") or ""
                    return f"{proto.lower()}://{host}{(':' + str(port)) if port else ''}{base}"
            # mule 3 style
            if g("host"):
                return f"{(g('protocol') or 'http').lower()}://{g('host')}{(':' + str(g('port'))) if g('port') else ''}{g('basePath') or ''}"
        if pfx in ("db", "jdbc"):
            for k in ("url", "connection.url", "generic-connection.url", "my-sql-connection.host", "oracle-connection.host", "mssql-connection.host", "generic-connection.host"):
                if g(k):
                    return f"db {g(k)}"
            hosts = [f"{k}={v}" for k, v in {**attrs, **resolved}.items() if k.endswith(".host") or k.endswith(".database") or k.endswith(".instance")]
            return "db " + " ".join(hosts) if hosts else None
        if pfx in ("salesforce", "sfdc"):
            for k in ("basic-connection.url", "basic-connection.username", "oauth-connection.consumerKey", "username", "url"):
                if g(k):
                    return f"salesforce {k}={g(k)}"
        if pfx in ("jms", "anypoint-mq", "kafka", "amqp", "ibm-mq", "azure-service-bus", "aws-sqs", "sqs"):
            hosts = [f"{k}={v}" for k, v in {**attrs, **resolved}.items() if any(s in k.lower() for s in ("url", "host", "broker", "bootstrap", "namespace", "queuemanager", "region"))]
            return f"{pfx} " + " ".join(hosts) if hosts else None
        if pfx in ("sftp", "ftp", "ftps", "file", "smb"):
            hosts = [f"{k}={v}" for k, v in {**attrs, **resolved}.items() if any(s in k.lower() for s in ("host", "workingdir", "directory", "path"))]
            return f"{pfx} " + " ".join(hosts) if hosts else None
        if pfx == "wsc":
            for k in ("connection.wsdlLocation", "connection.address", "wsdlLocation", "address"):
                if g(k):
                    return f"soap {g(k)}"
        if pfx in ("email", "smtp"):
            hosts = [f"{k}={v}" for k, v in {**attrs, **resolved}.items() if "host" in k.lower()]
            return f"{pfx} " + " ".join(hosts) if hosts else None
        return None

    # -- flows ---------------------------------------------------------------
    def add_flow(self, el, file, kind):
        name = el.attrib.get("name")
        rec = {
            "name": name, "kind": kind, "file": file, "line": line_of(el), "line_end": None,
            "doc": el.attrib.get("{http://www.mulesoft.org/schema/mule/documentation}name") or el.attrib.get("doc:name"),
            "source": None, "steps": [], "flow_refs": [], "outbound": [], "lookups": [],
            "error_handlers": [], "loggers": [], "choices": [], "apikit_router": None,
            "constructs": defaultdict(int), "variables": [], "raise_errors": [],
        }
        children = [c for c in el if isinstance(c.tag, str)]
        # source = first child that looks like a source and has a connector prefix (or scheduler)
        if children:
            first = children[0]
            fln, fpfx = localname(first.tag), nsprefix(first.tag)
            if (fln in SOURCE_LOCALNAMES or fln.endswith("-listener") or fln.endswith("listener")) and (fpfx in CONNECTOR_PREFIXES or fpfx == "mule" or fpfx not in ("ee",)):
                rec["source"] = self.describe_source(first, file)
                children = children[1:]
        EH = ("error-handler", "catch-exception-strategy", "rollback-exception-strategy", "choice-exception-strategy", "exception-strategy")
        body = [c for c in children if localname(c.tag) not in EH]
        ehs = [c for c in children if localname(c.tag) in EH]
        rec["steps"] = [self.walk(c, rec, file, depth=0) for c in body]
        for eh in ehs:
            rec["error_handlers"].append({"file": file, "line": line_of(eh), "ref": eh.attrib.get("ref"), "handlers": self.summarise_error_handlers(eh)})
            for h in eh:
                if isinstance(h.tag, str):
                    for c in h:
                        if isinstance(c.tag, str):
                            self.walk(c, rec, file, depth=1, in_error_handler=True)
        rec["constructs"] = dict(rec["constructs"])
        if name in self.flows:
            self.warnings.append(f"duplicate flow name {name} ({file}:{line_of(el)} and {self.flows[name]['file']}:{self.flows[name]['line']})")
        self.flows[name] = rec

    def describe_source(self, el, file):
        pfx, ln = nsprefix(el.tag), localname(el.tag)
        where = f"{file}:{line_of(el)}"
        attrs = {k: self.resolver.resolve(v, where) for k, v in el.attrib.items()}
        src = {"element": f"{pfx}:{ln}", "file": file, "line": line_of(el), "attrs": attrs}
        for child in el:
            if isinstance(child.tag, str):
                cln = localname(child.tag)
                for k, v in child.attrib.items():
                    src["attrs"][f"{cln}.{k}"] = self.resolver.resolve(v, where)
        cfg = attrs.get("config-ref")
        if cfg:
            src["config"] = cfg
        return src

    def summarise_error_handlers(self, eh):
        out = []
        ln0 = localname(eh.tag)
        if ln0 in ("catch-exception-strategy", "rollback-exception-strategy", "exception-strategy"):  # Mule 3: the element is the handler
            a = eh.attrib
            return [{"kind": ln0, "type": a.get("exception-pattern") or a.get("when"), "when": a.get("when"), "enableNotifications": a.get("enableNotifications"),
                     "line": line_of(eh), "actions": [f"{nsprefix(c.tag)}:{localname(c.tag)}" for c in eh if isinstance(c.tag, str)]}]
        for h in eh:
            if not isinstance(h.tag, str):
                continue
            ln = localname(h.tag)
            a = h.attrib
            out.append({"kind": ln, "type": a.get("type") or a.get("exception-pattern"), "when": a.get("when"),
                        "enableNotifications": a.get("enableNotifications"), "line": line_of(h),
                        "actions": [f"{nsprefix(c.tag)}:{localname(c.tag)}" for c in h if isinstance(c.tag, str)]})
        return out

    def walk(self, el, flow, file, depth, in_error_handler=False):
        pfx, ln = nsprefix(el.tag), localname(el.tag)
        where = f"{file}:{line_of(el)}"
        a = dict(el.attrib)
        doc = a.get("{http://www.mulesoft.org/schema/mule/documentation}name") or a.get("doc:name")
        node = {"el": f"{pfx}:{ln}", "line": line_of(el), "doc": doc, "children": []}
        flow["constructs"][f"{pfx}:{ln}"] += 1

        if ln == "flow-ref" and pfx == "mule":
            node["ref"] = a.get("name")
            flow["flow_refs"].append({"name": a.get("name"), "line": line_of(el), "in_error_handler": in_error_handler})
            return node
        if ln == "logger":
            msg = a.get("message", "")
            node["message"] = msg
            node["level"] = a.get("level", "INFO")
            flow["loggers"].append({"level": node["level"], "message": msg[:300], "line": line_of(el)})
            return node
        if ln == "raise-error":
            node["type"] = a.get("type")
            node["description"] = a.get("description")
            flow["raise_errors"].append({"type": a.get("type"), "description": a.get("description"), "line": line_of(el)})
            return node
        if ln == "set-variable":
            node["variable"] = a.get("variableName")
            node["value"] = (a.get("value") or "")[:200]
            flow["variables"].append({"name": a.get("variableName"), "value": node["value"], "line": line_of(el)})
            return node
        if ln in ("set-payload", "remove-variable"):
            node["value"] = (a.get("value") or a.get("variableName") or "")[:200]
            return node
        if pfx == "ee" and ln == "transform":
            node["dw"] = self.extract_dw(el)
            for lk in re.findall(r"lookup\(\s*['\"]([^'\"]+)['\"]", node["dw"].get("script", "")):
                flow["lookups"].append({"flow": lk, "line": line_of(el)})
            return node
        if pfx == "mule" and ln == "transform-message" or (pfx == "dw" and ln == "transform-message"):
            node["dw"] = self.extract_dw(el)
            return node
        if pfx == "apikit" and ln == "router":
            node["config"] = a.get("config-ref")
            flow["apikit_router"] = a.get("config-ref")
            return node
        if ln in ("when", "route", "on-error-propagate", "on-error-continue", "catch-exception-strategy", "choice-exception-strategy", "rollback-exception-strategy"):
            node["expression"] = a.get("expression") or a.get("when")
            node["type"] = a.get("type") or a.get("exception-pattern")
        if ln == "choice":
            cond = [{"when": (c.attrib.get("expression") or "")[:300], "line": line_of(c)} for c in el if isinstance(c.tag, str) and localname(c.tag) == "when"]
            has_other = any(localname(c.tag) == "otherwise" for c in el if isinstance(c.tag, str))
            flow["choices"].append({"line": line_of(el), "whens": cond, "otherwise": has_other})
            node["otherwise"] = has_other
        if ln == "until-successful":
            node["maxRetries"] = a.get("maxRetries")
            node["millisBetweenRetries"] = a.get("millisBetweenRetries")
        if ln in ("foreach", "parallel-foreach"):
            node["collection"] = a.get("collection")
            node["batchSize"] = a.get("batchSize")
        if pfx == "ee" and ln == "cache":
            node["cachingStrategy"] = a.get("cachingStrategy-ref")
        if ln == "job" and pfx in ("batch", "ee"):
            node["jobName"] = a.get("jobName")

        # connector operation?
        if pfx in CONNECTOR_PREFIXES and ln not in OP_PARAM_LOCALNAMES and ln not in SCOPE_LOCALNAMES:
            op = self.describe_outbound(el, pfx, ln, file, where, in_error_handler)
            node["outbound"] = op
            flow["outbound"].append(op)
            return node

        # generic scope: descend
        if ln in SCOPE_LOCALNAMES or pfx == "mule" or pfx == "ee" or pfx == "batch":
            for c in el:
                if isinstance(c.tag, str) and localname(c.tag) not in OP_PARAM_LOCALNAMES:
                    node["children"].append(self.walk(c, flow, file, depth + 1, in_error_handler or ln in ("on-error-propagate", "on-error-continue", "error-handler")))
        return node

    def extract_dw(self, el):
        out = {"script": "", "resource": None, "target": el.attrib.get("target")}
        for sub in el.iter():
            if not isinstance(sub.tag, str):
                continue
            sln = localname(sub.tag)
            if sln in ("set-payload", "set-variable", "set-attributes", "set-session-variable", "set-property"):
                if sub.attrib.get("resource"):
                    out["resource"] = sub.attrib.get("resource")
                if sub.text and sub.text.strip():
                    out["script"] += (f"-- {sln} {sub.attrib.get('variableName','')}\n" if sln != "set-payload" else "") + sub.text.strip() + "\n"
        if not out["script"] and el.text and el.text.strip():
            out["script"] = el.text.strip()
        out["script"] = out["script"][:1500]
        return out

    def describe_outbound(self, el, pfx, ln, file, where, in_error_handler):
        a = {k: self.resolver.resolve(v, where) for k, v in el.attrib.items()}
        op = {"connector": pfx, "operation": ln, "line": line_of(el), "file": file,
              "doc": a.get("{http://www.mulesoft.org/schema/mule/documentation}name") or a.get("doc:name"),
              "config": a.get("config-ref") or a.get("connector-ref"), "attrs": {}, "in_error_handler": in_error_handler}
        for k in ("path", "url", "method", "target", "targetValue", "responseTimeout", "destination", "queue", "queueName", "topic",
                  "exchange", "type", "objectType", "key", "directory", "fileName", "operation", "service", "port", "address",
                  "transactionalAction", "objectStore", "sendCorrelationId", "toAddresses", "subject", "streamingStrategy"):
            if k in a and not k.startswith("{"):
                op["attrs"][k] = a[k][:300]
        for child in el:
            if not isinstance(child.tag, str):
                continue
            cln = localname(child.tag)
            if cln in ("sql", "body", "message", "records", "content", "query", "in-parameters", "fields", "headers", "query-params", "uri-params"):
                t = text_of(child, 400)
                if t:
                    op["attrs"][cln] = t
        cfg = self.configs.get(op["config"]) if op["config"] else None
        if cfg and cfg.get("target"):
            op["resolved_target"] = cfg["target"]
        elif op["config"]:
            op["resolved_target"] = None
        # http:request with explicit url
        if pfx in ("http", "https") and a.get("url"):
            op["resolved_target"] = a["url"]
        elif pfx in ("http", "https") and cfg and cfg.get("target") and a.get("path"):
            op["resolved_target"] = cfg["target"].rstrip("/") + "/" + a["path"].lstrip("/")
        return op

    # -- specs / apikit --------------------------------------------------------
    def link_specs(self):
        for name, cfg in self.apikit_configs.items():
            api = cfg.get("api")
            if not api:
                cfg["spec"] = None
                self.warnings.append(f"apikit:config {name} has no api/raml attribute")
                continue
            api = self.resolver.resolve(api, f"{cfg['file']}:{cfg['line']}")
            candidates = [os.path.join(self.root, "src/main/resources/api", api), os.path.join(self.root, "src/main/resources", api),
                          os.path.join(self.root, "src/main/api", api), os.path.join(self.root, api)]
            # exchange-style resource::group:artifact:version:classifier:zip:file.raml
            if "resource::" in api:
                fname = api.split(":")[-1]
                candidates += glob.glob(os.path.join(self.root, "**", fname), recursive=True)
                candidates += glob.glob(os.path.join(self.root, "target", "**", fname), recursive=True)
            found = next((c for c in candidates if os.path.exists(c)), None)
            if found:
                cfg["spec"] = parse_spec(found, self.root)
                self.specs[cfg["spec"]["file"]] = cfg["spec"]
            else:
                cfg["spec"] = {"file": api, "kind": None, "resources": [], "errors": ["spec file not found in repo (Exchange dependency? ask user for the RAML/OAS)"], "includes": []}
        # also parse any spec not referenced by apikit
        for p in glob.glob(os.path.join(self.root, "src/main/resources/api/**/*"), recursive=True):
            if p.endswith((".raml", ".yaml", ".yml", ".json")) and os.path.isfile(p):
                rp = self.rel(p)
                if rp in self.specs:
                    continue
                try:
                    with open(p, encoding="utf-8", errors="replace") as fh:
                        head = fh.read(400)
                except Exception:
                    continue
                if head.lstrip().startswith("#%RAML 1.0\n") or head.lstrip().startswith("#%RAML 0.8\n") or '"openapi"' in head or "openapi:" in head or '"swagger"' in head or "swagger:" in head:
                    if "#%RAML" in head and re.match(r"#%RAML \d\.\d\s+\w", head.lstrip()):
                        continue  # fragment (Trait/DataType/...)
                    sp = parse_spec(p, self.root)
                    if sp["resources"]:
                        sp["referenced_by_apikit"] = False
                        self.specs[rp] = sp

    def build_endpoints(self):
        self.endpoints = []
        apikit_flows = {}
        for fname, f in self.flows.items():
            parsed = parse_apikit_flow_name(fname)
            if parsed:
                method, resource, ctype, config = parsed
                apikit_flows[(method, norm_resource(resource), config)] = fname
        n = 0
        for fname, f in self.flows.items():
            src = f.get("source")
            if not src:
                continue
            el = src["element"]
            pfx = el.split(":")[0]
            if pfx in ("http", "https") and src["element"].endswith("listener"):
                lcfg = self.configs.get(src.get("config") or "")
                base = ""
                listen_target = None
                if lcfg:
                    base = (lcfg["resolved"].get("basePath") or lcfg["attrs"].get("basePath") or "").rstrip("/")
                    listen_target = lcfg.get("target")
                path = src["attrs"].get("path") or src["attrs"].get("address") or "/"
                methods = src["attrs"].get("allowedMethods")
                full = (base + ("/" + path.lstrip("/"))).replace("//", "/") if base else path
                if f.get("apikit_router"):
                    cfgname = f["apikit_router"]
                    cfg = self.apikit_configs.get(cfgname, {})
                    spec = cfg.get("spec") or {}
                    stem = full[:-2] if full.endswith("/*") else full.rstrip("/")
                    resources = spec.get("resources") or []
                    if not resources:
                        n += 1
                        self.endpoints.append({"id": f"EP-{n:03d}", "type": "http", "method": methods or "ANY", "path": full, "listener_flow": fname,
                                               "implementing_flow": fname, "apikit_config": cfgname, "spec": spec.get("file"),
                                               "note": "APIkit router present but spec resources could not be parsed — enumerate endpoints from the spec manually",
                                               "listener_target": listen_target, "file": src["file"], "line": src["line"]})
                    for r in resources:
                        n += 1
                        impl = apikit_flows.get((r["method"], norm_resource(r["path"]), cfgname))
                        self.endpoints.append({"id": f"EP-{n:03d}", "type": "http", "method": r["method"], "path": stem + r["path"],
                                               "listener_flow": fname, "implementing_flow": impl, "apikit_config": cfgname, "spec": spec.get("file"),
                                               "spec_description": r.get("description"), "spec_responses": r.get("responses"),
                                               "note": None if impl else "no implementing flow found — APIkit default/mocked response or 404/501; verify",
                                               "listener_target": listen_target, "file": src["file"], "line": src["line"]})
                else:
                    n += 1
                    self.endpoints.append({"id": f"EP-{n:03d}", "type": "http", "method": methods or "ANY", "path": full, "listener_flow": fname,
                                           "implementing_flow": fname, "apikit_config": None, "spec": None, "note": None,
                                           "listener_target": listen_target, "file": src["file"], "line": src["line"]})
            else:
                n += 1
                kind = pfx if pfx != "mule" else el.split(":")[1]
                desc_keys = ("frequency", "timeUnit", "expression", "timeZone", "destination", "queue", "queueName", "topic", "directory", "path",
                             "table", "watermarkColumn", "topicName", "objectType", "channelName", "folder", "config", "fixed-frequency.frequency",
                             "fixed-frequency.timeUnit", "cron.expression", "cron.timeZone", "scheduling-strategy.fixed-frequency.frequency",
                             "scheduling-strategy.cron.expression", "primaryNodeOnly", "sql")
                detail = {k: v for k, v in src["attrs"].items() if any(k.endswith(d) for d in desc_keys)}
                self.endpoints.append({"id": f"EP-{n:03d}", "type": kind, "method": None, "path": None, "listener_flow": fname, "implementing_flow": fname,
                                       "source": el, "detail": detail, "config": src.get("config"),
                                       "config_target": (self.configs.get(src.get("config") or "") or {}).get("target"),
                                       "note": None, "file": src["file"], "line": src["line"]})
        # apikit flows whose resource is not in the spec (stale flows)
        spec_keys = set()
        for cfgname, cfg in self.apikit_configs.items():
            for r in ((cfg.get("spec") or {}).get("resources") or []):
                spec_keys.add((r["method"], norm_resource(r["path"]), cfgname))
        self.stale_apikit_flows = [fn for key, fn in apikit_flows.items() if key not in spec_keys and key[2] in self.apikit_configs]

    def build_callgraph(self):
        self.edges = []
        for fname, f in self.flows.items():
            for r in f["flow_refs"]:
                self.edges.append((fname, r["name"], "flow-ref"))
            for lk in f["lookups"]:
                self.edges.append((fname, lk["flow"], "dw-lookup"))
        adj = defaultdict(set)
        for s, t, _ in self.edges:
            adj[s].add(t)
        entry_flows = {ep["listener_flow"] for ep in self.endpoints} | {ep["implementing_flow"] for ep in self.endpoints if ep.get("implementing_flow")}
        # apikit router dispatches to apikit flows implicitly
        for fname, f in self.flows.items():
            if f.get("apikit_router"):
                for other in self.flows:
                    p = parse_apikit_flow_name(other)
                    if p and p[3] == f["apikit_router"]:
                        adj[fname].add(other)
                        self.edges.append((fname, other, "apikit-dispatch"))
        for ad in self.autodiscovery:
            if ad.get("flowRef"):
                entry_flows.add(ad["flowRef"])
        reachable = set()
        stack = list(entry_flows)
        while stack:
            x = stack.pop()
            if x in reachable:
                continue
            reachable.add(x)
            stack.extend(adj.get(x, ()))
        self.reachable = reachable
        self.unreachable = sorted(fn for fn in self.flows if fn not in reachable)
        self.missing_targets = sorted({t for _, t, _ in self.edges if t not in self.flows})
        self.reachable_from = {}
        for ep in self.endpoints:
            start = ep.get("implementing_flow")
            if not start:  # unimplemented spec resource: only the listener flow runs (APIkit default)
                self.reachable_from[ep["id"]] = [ep["listener_flow"]]
                continue
            seen, st = [], [start]
            while st:
                x = st.pop()
                if x in seen:
                    continue
                seen.append(x)
                st.extend(sorted(adj.get(x, ())))
            self.reachable_from[ep["id"]] = seen
        self.discriminators = {}
        FIELD_RE = re.compile(r"(payload(?:\.[A-Za-z_][\w]*)+|attributes\.(?:queryParams|headers|uriParams)\.[\w-]+|vars\.[\w]+|p\('[^']+'\)|attributes\.(?:method|requestPath|properties)\.?[\w]*)")
        for ep in self.endpoints:
            found = []
            for fn in self.reachable_from.get(ep["id"], []):
                f = self.flows.get(fn)
                if not f:
                    continue
                for c in f["choices"]:
                    fields = sorted({m for w in c["whens"] for m in FIELD_RE.findall(w["when"])})
                    found.append({"flow": fn, "line": c["line"], "kind": "choice", "expressions": [w["when"] for w in c["whens"]], "fields": fields, "otherwise": c["otherwise"]})
                for st in self._iter_nodes(f["steps"]):
                    dw = st.get("dw") or {}
                    script = dw.get("script", "")
                    if script and re.search(r"\bif\s*\(|\bmatch\b|\bcase\b|\bunless\b", script):
                        conds = re.findall(r"(?:if|unless)\s*\(([^)]{1,120})\)|case\s+([^\n>]{1,80})->", script)
                        exprs = [a or b for a, b in conds][:8]
                        found.append({"flow": fn, "line": st["line"], "kind": "dataweave", "expressions": exprs, "fields": sorted({m for e in exprs for m in FIELD_RE.findall(e)}), "otherwise": None})
            self.discriminators[ep["id"]] = found

    def _iter_nodes(self, nodes):
        for n in nodes:
            yield n
            yield from self._iter_nodes(n.get("children", []))

    # -- summaries -------------------------------------------------------------
    def to_dict(self):
        def flow_out(f):
            return {k: v for k, v in f.items() if k != "steps"} | {"steps": f["steps"]}
        return {
            "project": self.name, "root": self.root, "env": self.env, "pom": self.pom, "mule_artifact": self.artifact,
            "config_files": self.files, "property_files": [{"file": p["file"], "env": p["env"], "keys": len(p["properties"])} for p in self.prop_files],
            "globals": self.globals, "apikit_configs": self.apikit_configs, "autodiscovery": self.autodiscovery,
            "default_error_handler": self.default_error_handler, "global_error_handlers": self.global_error_handlers,
            "specs": self.specs, "flows": {k: flow_out(v) for k, v in self.flows.items()}, "endpoints": self.endpoints,
            "stale_apikit_flows": self.stale_apikit_flows, "edges": [{"from": s, "to": t, "kind": k} for s, t, k in self.edges],
            "unreachable_flows": self.unreachable, "missing_flow_targets": self.missing_targets, "reachable_from": self.reachable_from,
            "scenario_discriminators": self.discriminators,
            "unresolved_properties": {k: sorted(v) for k, v in self.resolver.unresolved.items()},
            "secure_properties": {k: sorted(v) for k, v in self.resolver.secure.items()},
            "ambiguous_properties": self.resolver.ambiguous, "warnings": self.warnings,
        }


# ----------------------------------------------------------------------------
# Markdown + diagrams
# ----------------------------------------------------------------------------

def md_table(headers, rows):
    if not rows:
        return "_none_\n"
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c).replace("|", "\\|").replace("\n", " ") if c is not None else "" for c in r) + " |")
    return "\n".join(out) + "\n"


def write_markdown(scanners, out_dir):
    lines = ["# Mule inventory (Phase 0)\n", f"Environment: `{scanners[0].env or '(none — common properties only)'}`\n",
             "Read this file completely. Everything here came from code/config only; nothing is inferred.\n"]
    total_eps = sum(len(s.endpoints) for s in scanners)
    lines.append(f"**Projects:** {len(scanners)} · **Entry points found:** {total_eps} · **Flows:** {sum(len(s.flows) for s in scanners)}\n")
    for s in scanners:
        lines.append(f"\n---\n\n## Project `{s.name}`\n")
        if s.pom:
            lines.append(f"- pom: artifactId `{s.pom.get('artifactId')}` version `{s.pom.get('version')}`; {len(s.pom['dependencies'])} dependencies")
            if s.pom["spec_dependencies"]:
                lines.append(f"- **Spec dependencies from Exchange (RAML/OAS not in repo?):** {', '.join(s.pom['spec_dependencies'])}")
            if s.pom["shared_libraries"]:
                lines.append(f"- shared libraries: {', '.join(s.pom['shared_libraries'])}")
        if s.artifact:
            lines.append(f"- mule-artifact.json: minMuleVersion `{s.artifact.get('minMuleVersion')}`; secureProperties: {s.artifact.get('secureProperties')}; configs: {s.artifact.get('configs')}")
        lines.append(f"- config files ({len(s.files)}): " + ", ".join(f"`{f}`" for f in s.files))
        lines.append("- property files: " + (", ".join(f"`{p['file']}`{' [' + p['env'] + ']' if p['env'] else ''}" for p in s.prop_files) or "_none_"))
        if s.default_error_handler:
            lines.append(f"- **default error handler:** `{s.default_error_handler}`")
        if s.global_error_handlers:
            lines.append("- global error handlers: " + ", ".join(f"`{k}` ({v['file']}:{v['line']}, {len(v['handlers'])} handlers)" for k, v in s.global_error_handlers.items()))
        if s.autodiscovery:
            lines.append("- **API Manager autodiscovery (policies apply — export needed):** " + "; ".join(f"apiId `{a['apiId']}` flow `{a['flowRef']}` ({a['file']}:{a['line']})" for a in s.autodiscovery))
        else:
            lines.append("- no `api-gateway:autodiscovery` found (either unmanaged, or managed via an API proxy — ask)")

        lines.append("\n### Entry points\n")
        rows = []
        for ep in s.endpoints:
            if ep["type"] == "http":
                rows.append([ep["id"], ep["method"], f"`{ep['path']}`", ep["listener_flow"], ep.get("implementing_flow") or "**(none)**", ep.get("apikit_config") or "", (ep.get("spec_description") or "")[:80], ep.get("listener_target") or "", f"{ep['file']}:{ep['line']}", ep.get("note") or ""])
            else:
                rows.append([ep["id"], ep["type"], "; ".join(f"{k}={v}" for k, v in (ep.get("detail") or {}).items())[:120], ep["listener_flow"], ep["implementing_flow"], ep.get("config") or "", "", ep.get("config_target") or "", f"{ep['file']}:{ep['line']}", ep.get("note") or ""])
        lines.append(md_table(["id", "method/type", "path / trigger", "listener flow", "implementing flow", "apikit cfg", "spec description", "listener/config target", "where", "note"], rows))
        if s.stale_apikit_flows:
            lines.append("**APIkit-style flows with no matching spec resource (stale or spec missing):** " + ", ".join(f"`{f}`" for f in s.stale_apikit_flows) + "\n")

        lines.append("\n### Specs\n")
        for sp in s.specs.values():
            lines.append(f"- `{sp['file']}` kind={sp.get('kind')} title={sp.get('title')} version={sp.get('version')} baseUri={sp.get('baseUri')} resources={len(sp['resources'])}" + (f" **errors: {sp['errors']}**" if sp.get("errors") else "") + (f" includes: {len(sp['includes'])}" if sp.get("includes") else ""))
        if not s.specs:
            lines.append("_none found_")

        lines.append("\n### Global configurations (resolved for env)\n")
        rows = [[g["element"], g["name"] or "", g.get("target") or "", "; ".join(f"{k}={v}" for k, v in g["resolved"].items())[:160], g.get("properties_file") or "", f"{g['file']}:{g['line']}"] for g in s.globals]
        lines.append(md_table(["element", "name", "target", "resolved attrs", "properties file", "where"], rows))

        lines.append("\n### Flows\n")
        rows = []
        for fname, f in s.flows.items():
            src = f["source"]["element"] if f["source"] else ("(sub-flow)" if f["kind"] == "sub-flow" else "(private flow)")
            rows.append([fname, f["kind"], src, f"{f['file']}:{f['line']}", ", ".join(sorted({r['name'] for r in f['flow_refs']})), ", ".join(f"{o['connector']}:{o['operation']}" for o in f["outbound"]), len(f["choices"]), sum(len(e["handlers"]) for e in f["error_handlers"]), ", ".join(f"{k}×{v}" for k, v in f["constructs"].items() if k.split(':')[1] in ("async", "until-successful", "foreach", "parallel-foreach", "scatter-gather", "first-successful", "cache", "job", "try", "idempotent-message-validator")), "unreachable" if fname in s.unreachable else ""])
        lines.append(md_table(["flow", "kind", "source", "where", "flow-refs", "outbound", "#choice", "#err handlers", "notable constructs", "reach"], rows))

        lines.append("\n### Outbound calls\n")
        rows = []
        for fname, f in s.flows.items():
            for o in f["outbound"]:
                rows.append([fname, f"{o['connector']}:{o['operation']}", o.get("doc") or "", o.get("config") or "", o.get("resolved_target") or "**unresolved**" if o.get("config") or o["connector"] in ("http", "https") else "", "; ".join(f"{k}={v}" for k, v in o["attrs"].items())[:200], f"{o['file']}:{o['line']}", "in error handler" if o["in_error_handler"] else ""])
        lines.append(md_table(["flow", "operation", "doc:name", "config", "resolved target", "attrs", "where", ""], rows))

        lines.append("\n### Choices (branch conditions)\n")
        rows = [[fname, c["line"], " ‖ ".join(w["when"] for w in c["whens"]), "yes" if c["otherwise"] else "**NO — passthrough**"] for fname, f in s.flows.items() for c in f["choices"]]
        lines.append(md_table(["flow", "line", "when expressions", "otherwise?"], rows))

        lines.append("\n### Error handlers\n")
        rows = []
        for fname, f in s.flows.items():
            for eh in f["error_handlers"]:
                for h in eh["handlers"]:
                    rows.append([fname, f"{eh['file']}:{h['line']}", h["kind"], h.get("type") or "ANY", h.get("when") or "", ", ".join(h["actions"])])
        for gname, g in s.global_error_handlers.items():
            for h in g["handlers"]:
                rows.append([f"(global) {gname}", f"{g['file']}:{h['line']}", h["kind"], h.get("type") or "ANY", h.get("when") or "", ", ".join(h["actions"])])
        lines.append(md_table(["flow", "where", "kind", "type", "when", "actions"], rows))
        rows = [[fname, r["type"], r.get("description") or "", r["line"]] for fname, f in s.flows.items() for r in f["raise_errors"]]
        if rows:
            lines.append("**raise-error:**\n" + md_table(["flow", "type", "description", "line"], rows))

        lines.append("\n### Loggers (Splunk anchors)\n")
        rows = [[fname, l["level"], l["message"][:150], l["line"]] for fname, f in s.flows.items() for l in f["loggers"]]
        lines.append(md_table(["flow", "level", "message", "line"], rows))

        lines.append("\n### Reachability per entry point\n")
        for ep in s.endpoints:
            lines.append(f"- {ep['id']} ({ep.get('method') or ep['type']} {ep.get('path') or ''}): " + " → ".join(f"`{x}`" for x in s.reachable_from.get(ep["id"], [])))
        lines.append("\n### Scenario discriminator candidates per entry point\n")
        lines.append("Conditions on the request/message that may split one endpoint into several business scenarios (Phase 2 decides which are business vs technical):\n")
        for ep in s.endpoints:
            ds = s.discriminators.get(ep["id"], [])
            if not ds:
                lines.append(f"- {ep['id']}: _no request-dependent branching found in code — still check upstream call sites and prod logs_")
                continue
            lines.append(f"- {ep['id']} ({ep.get('method') or ep['type']} {ep.get('path') or ''}):")
            for d in ds:
                lines.append(f"  - {d['kind']} at `{d['flow']}`:{d['line']} on fields {', '.join('`' + x + '`' for x in d['fields']) or '(none extracted)'} — " + " ‖ ".join(e.replace('\n', ' ')[:100] for e in d['expressions']) + ("" if d['otherwise'] is None else ("; has otherwise" if d['otherwise'] else "; **no otherwise (passthrough)**")))
        lines.append("\n### Potential gaps detected mechanically\n")
        gaps = []
        if s.unreachable:
            gaps.append(f"- Flows not reachable from any entry point (dead code, invoked by a domain/other app, or missed source): {', '.join('`' + f + '`' for f in s.unreachable)}")
        if s.missing_targets:
            gaps.append(f"- flow-ref / lookup targets not defined in this project (domain, shared lib, other file?): {', '.join('`' + f + '`' for f in s.missing_targets)}")
        for ep in s.endpoints:
            if ep.get("note"):
                gaps.append(f"- {ep['id']}: {ep['note']}")
        if s.resolver.unresolved:
            gaps.append("- Unresolved properties (no value in any property file for this env): " + ", ".join(f"`{k}` ({', '.join(sorted(v))[:120]})" for k, v in s.resolver.unresolved.items()))
        if s.resolver.secure:
            gaps.append("- Secure/encrypted properties (plaintext needed to name targets): " + ", ".join(f"`{k}`" for k in s.resolver.secure))
        if s.resolver.ambiguous:
            gaps.append("- Ambiguous properties (several values for env): " + ", ".join(f"`{k}`" for k in s.resolver.ambiguous))
        for cfg, c in s.apikit_configs.items():
            if c.get("spec") and c["spec"].get("errors"):
                gaps.append(f"- apikit config `{cfg}` spec `{c['spec']['file']}`: {c['spec']['errors']}")
        if s.autodiscovery:
            gaps.append("- Policies are configured in API Manager, not in code — obtain the policy list for each apiId above")
        for w in s.warnings:
            gaps.append(f"- warning: {w}")
        lines.append("\n".join(gaps) if gaps else "_none detected — still verify by hand_")
        lines.append("")
    with open(os.path.join(out_dir, "inventory.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))


def write_callgraph(scanners, out_dir):
    lines = ["flowchart LR"]
    for s in scanners:
        lines.append(f"  subgraph {re.sub(r'[^A-Za-z0-9_]', '_', s.name)}[{s.name}]")
        ids = {}

        def nid(n):
            if n not in ids:
                ids[n] = f"n{len(ids)}_{re.sub(r'[^A-Za-z0-9_]', '_', s.name)[:8]}"
            return ids[n]
        for fname, f in s.flows.items():
            shape = ("([", "])") if f["source"] else (("[[", "]]") if f["kind"] == "sub-flow" else ("[", "]"))
            lines.append(f"    {nid(fname)}{shape[0]}\"{fname}\"{shape[1]}")
        for src, tgt, kind in s.edges:
            arrow = "-->" if kind == "flow-ref" else ("-.->" if kind == "dw-lookup" else "==>")
            lines.append(f"    {nid(src)} {arrow}|{kind}| {nid(tgt)}")
        lines.append("  end")
    with open(os.path.join(out_dir, "callgraph.mmd"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")


def draft_diagram(s, ep):
    """Skeleton sequence diagram for one entry point; Claude rewrites it in Phase 2."""
    app = re.sub(r"[^A-Za-z0-9]", "", s.name)[:20] or "APP"
    parts = ["sequenceDiagram", "    autonumber", "    actor Caller as ❓ Caller (upstream unknown)", f"    participant {app} as {s.name}"]
    participants = {}
    out = []
    visited = []

    def pname(o):
        key = o.get("config") or o["connector"]
        if key not in participants:
            alias = re.sub(r"[^A-Za-z0-9]", "", key)[:20] or f"P{len(participants)}"
            label = f"{key}<br/>{o.get('resolved_target') or '❓ target unresolved'}"
            participants[key] = alias
            parts.append(f"    participant {alias} as {label}")
        return participants[key]

    def emit(nodes, indent, depth):
        for n in nodes:
            el = n["el"]
            ln = el.split(":", 1)[1]
            pad = "    " * indent
            if "outbound" in n:
                o = n["outbound"]
                p = pname(o)
                label = f"{o['connector']}:{o['operation']} " + " ".join(f"{k}={v}" for k, v in o["attrs"].items() if k in ("method", "path", "url", "sql", "destination", "queue", "objectType", "key", "operation"))
                out.append(f"{pad}{app}->>{p}: {label[:110]}")
                out.append(f"{pad}{p}-->>{app}: response")
            elif ln == "flow-ref":
                ref = n.get("ref")
                if ref in s.flows and ref not in visited and depth < 8:
                    visited.append(ref)
                    out.append(f"{pad}Note over {app}: ▶ {ref} ({s.flows[ref]['file']}:{s.flows[ref]['line']})")
                    emit(s.flows[ref]["steps"], indent, depth + 1)
                    out.append(f"{pad}Note over {app}: ◀ end {ref}")
                    visited.remove(ref)
                else:
                    out.append(f"{pad}{app}->>{app}: flow-ref {ref}" + ("" if ref in s.flows else " (❓ not found)"))
            elif ln == "choice":
                first = True
                for c in n["children"]:
                    cl = c["el"].split(":")[1]
                    if cl == "when":
                        out.append(f"{pad}{'alt' if first else 'else'} {(c.get('expression') or '')[:80]}")
                        first = False
                        emit(c["children"], indent + 1, depth)
                    elif cl == "otherwise":
                        out.append(f"{pad}else otherwise")
                        emit(c["children"], indent + 1, depth)
                if not n.get("otherwise"):
                    out.append(f"{pad}else (no otherwise — passthrough)")
                out.append(f"{pad}end")
            elif ln in ("scatter-gather",):
                first = True
                for c in n["children"]:
                    out.append(f"{pad}{'par' if first else 'and'} route")
                    first = False
                    emit(c["children"], indent + 1, depth)
                out.append(f"{pad}end")
            elif ln == "async":
                out.append(f"{pad}par async (caller not blocked)")
                emit(n["children"], indent + 1, depth)
                out.append(f"{pad}end")
            elif ln == "until-successful":
                out.append(f"{pad}loop retry maxRetries={n.get('maxRetries')} every {n.get('millisBetweenRetries')}ms")
                emit(n["children"], indent + 1, depth)
                out.append(f"{pad}end")
            elif ln in ("foreach", "parallel-foreach"):
                out.append(f"{pad}loop {ln} {(n.get('collection') or 'payload')[:60]}")
                emit(n["children"], indent + 1, depth)
                out.append(f"{pad}end")
            elif ln == "first-successful":
                first = True
                for c in n["children"]:
                    out.append(f"{pad}{'alt' if first else 'else'} first-successful route")
                    first = False
                    emit(c["children"], indent + 1, depth)
                out.append(f"{pad}end")
            elif ln == "try":
                body = [c for c in n["children"] if c["el"].split(":")[1] != "error-handler"]
                ehs = [c for c in n["children"] if c["el"].split(":")[1] == "error-handler"]
                out.append(f"{pad}critical try scope")
                emit(body, indent + 1, depth)
                for eh in ehs:
                    for h in eh["children"]:
                        out.append(f"{pad}option {h['el'].split(':')[1]} {h.get('type') or 'ANY'}")
                        emit(h["children"], indent + 1, depth)
                out.append(f"{pad}end")
            elif ln == "transform" or ln == "transform-message":
                script = (n.get("dw") or {}).get("script", "").replace("\n", " ")[:70]
                out.append(f"{pad}{app}->>{app}: DataWeave {(n.get('doc') or '')} {script}".rstrip())
            elif ln == "logger":
                out.append(f"{pad}Note over {app}: log {n.get('level')} {(n.get('message') or '')[:70]}")
            elif ln == "raise-error":
                out.append(f"{pad}{app}->>{app}: raise-error {n.get('type')}")
            elif ln == "router" and el.startswith("apikit"):
                out.append(f"{pad}{app}->>{app}: apikit:router dispatch")
            elif ln in ("set-variable",):
                out.append(f"{pad}Note over {app}: set var {n.get('variable')}")
            elif ln in ("cache",):
                out.append(f"{pad}alt cache hit ({n.get('cachingStrategy')})")
                out.append(f"{pad}else cache miss")
                emit(n["children"], indent + 1, depth)
                out.append(f"{pad}end")
            elif n["children"]:
                out.append(f"{pad}Note over {app}: {el}")
                emit(n["children"], indent, depth)
            elif ln not in ("set-payload", "remove-variable", "validation"):
                out.append(f"{pad}{app}->>{app}: {el} {(n.get('doc') or '')}".rstrip())

    start = ep.get("implementing_flow") or ep["listener_flow"]
    f = s.flows.get(start)
    if not f:
        return None
    label = f"{ep.get('method') or ep['type']} {ep.get('path') or ''}".strip()
    out.append(f"    Caller->>{app}: {label}")
    if ep.get("listener_flow") != start and ep.get("listener_flow") in s.flows:
        out.append(f"    Note over {app}: listener flow {ep['listener_flow']} → apikit:router → {start}")
    emit(f["steps"], 1, 0)
    # error handlers
    for eh in f["error_handlers"]:
        for h in eh["handlers"]:
            out.append(f"    Note over {app}: error handler {h['kind']} {h.get('type') or 'ANY'} → {', '.join(h['actions'])[:60]}")
    if s.default_error_handler and not f["error_handlers"]:
        out.append(f"    Note over {app}: no flow error handler — global {s.default_error_handler} applies")
    out.append(f"    {app}-->>Caller: response (❓ status codes per path)")
    return "\n".join(parts + out) + "\n"


def write_drafts(scanners, out_dir):
    d = os.path.join(out_dir, "drafts")
    os.makedirs(d, exist_ok=True)
    for old in glob.glob(os.path.join(d, "*.mmd")):  # stale drafts from a previous run would mislead
        os.remove(old)
    count = 0
    for s in scanners:
        for ep in s.endpoints:
            txt = draft_diagram(s, ep)
            if not txt:
                continue
            slug = re.sub(r"[^A-Za-z0-9]+", "-", f"{ep.get('method') or ep['type']}-{ep.get('path') or ep['listener_flow']}").strip("-").lower()[:60]
            with open(os.path.join(d, f"{s.name}-{ep['id']}-{slug}.mmd"), "w", encoding="utf-8") as fh:
                fh.write(txt)
            count += 1
    return count


# ----------------------------------------------------------------------------
# main
# ----------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("roots", nargs="+", help="Mule project root(s) (directory containing pom.xml / src/main/mule)")
    ap.add_argument("--env", default=None, help="environment to resolve properties for (e.g. prod, dev)")
    ap.add_argument("--out", default="work", help="output directory")
    ap.add_argument("--draft-diagrams", action="store_true", help="write skeleton .mmd per entry point into <out>/drafts/")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    scanners = []
    for r in args.roots:
        if not os.path.isdir(r):
            print(f"ERROR: not a directory: {r}", file=sys.stderr)
            sys.exit(2)
        s = ProjectScanner(r, args.env)
        s.scan()
        scanners.append(s)
        print(f"[{s.name}] {len(s.flows)} flows, {len(s.endpoints)} entry points, {len(s.files)} config files, {len(s.warnings)} warnings")

    with open(os.path.join(args.out, "inventory.json"), "w", encoding="utf-8") as fh:
        json.dump({"env": args.env, "projects": [s.to_dict() for s in scanners]}, fh, indent=2, default=str)
    write_markdown(scanners, args.out)
    write_callgraph(scanners, args.out)
    if args.draft_diagrams:
        n = write_drafts(scanners, args.out)
        print(f"wrote {n} draft diagrams to {os.path.join(args.out, 'drafts')}")
    print(f"wrote {os.path.join(args.out, 'inventory.json')}, inventory.md, callgraph.mmd")
    if not HAVE_LXML:
        print("note: lxml not installed — line numbers unavailable (pip install lxml)")
    if not HAVE_YAML:
        print("note: pyyaml not installed — YAML properties and RAML/OAS specs not parsed (pip install pyyaml)")


if __name__ == "__main__":
    main()
