from __future__ import annotations

import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOOT = ROOT / "scripts" / "bootstrap_assessment.py"
BUILD = ROOT / "scripts" / "build_html_report.py"


class HtmlReportTests(unittest.TestCase):
    def test_builds_first_class_self_contained_report(self):
        with tempfile.TemporaryDirectory(prefix="mule-skill-html-") as td:
            assessment = Path(td) / "assessment"
            subprocess.check_call([sys.executable, str(BOOT), str(assessment)])
            flow_inventory = assessment / "current-state" / "api-flow-inventory.csv"
            with flow_inventory.open(encoding="utf-8-sig", newline="") as f:
                headers = next(csv.reader(f))
            with flow_inventory.open("w", encoding="utf-8", newline="") as f:
                w = csv.DictWriter(f, fieldnames=headers); w.writeheader(); w.writerow({
                    "flow_id":"FLOW-001","flow_name":"Producer search","business_purpose":"Search producers","trigger":"User searches in UI","primary_actor":"Policy admin","consumer_or_upstream_component":"Policy UI","mule_endpoints":"EP-001","downstream_systems":"Producer backend","final_outcome":"Search results displayed","sequence_diagram":"diagrams/flows/FLOW-001.puml","evidence_refs":"EV-001","confidence":"HIGH"})
            flow_steps = assessment / "current-state" / "api-flow-steps.csv"
            with flow_steps.open(encoding="utf-8-sig", newline="") as f:
                headers = next(csv.reader(f))
            with flow_steps.open("w", encoding="utf-8", newline="") as f:
                w = csv.DictWriter(f, fieldnames=headers); w.writeheader(); w.writerow({"flow_id":"FLOW-001","step_number":"1","actor_or_system":"Policy UI","business_action":"Search producers","technical_action":"Calls Mule API","mule_component_or_endpoint":"EP-001","evidence_refs":"EV-001"})
            flow_diagram = assessment / "diagrams" / "flows" / "FLOW-001.puml"
            flow_diagram.write_text("@startuml\nactor User\nparticipant Mule\nUser -> Mule: Search\nMule --> User: Results\n@enduml\n", encoding="utf-8")
            out = assessment / "architecture-assessment.html"
            proc = subprocess.run(
                [sys.executable, str(BUILD), str(assessment), "--output", str(out)],
                capture_output=True,
                text=True,
            )
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            text = out.read_text(encoding="utf-8")
            self.assertIn('data-report-schema="2.1"', text)
            self.assertIn('id="global-search"', text)
            self.assertIn('id="current-state"', text)
            self.assertIn('id="api-flows"', text)
            self.assertIn('id="api-flow-flow-001"', text)
            self.assertIn('id="diagram-flows-flow-001"', text)
            self.assertIn('id="target-state"', text)
            self.assertIn('id="diagram-current-context"', text)
            self.assertIn('id="diagram-current-network"', text)
            self.assertIn('id="diagram-target-context"', text)
            self.assertIn('id="diagram-target-network"', text)
            self.assertIn('id="artifacts"', text)
            manifest = assessment / "validation" / "html-report-manifest.json"
            self.assertTrue(manifest.exists())
            data = json.loads(manifest.read_text(encoding="utf-8"))
            self.assertEqual(data["schema_version"], "2.1")
            self.assertIn("current-state/api-inventory.csv", data["embedded_artifacts"])
            self.assertIn("diagrams/current-context.puml", data["embedded_artifacts"])
            self.assertIn("current-state/api-flow-inventory.csv", data["embedded_artifacts"])
            self.assertEqual(data["flow_diagrams"], ["FLOW-001"])


if __name__ == "__main__":
    unittest.main()
