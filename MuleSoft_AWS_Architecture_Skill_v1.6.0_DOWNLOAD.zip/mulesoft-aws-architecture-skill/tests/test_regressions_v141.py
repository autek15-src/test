from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class V141TrafficEvidenceRegressionTests(unittest.TestCase):
    def test_output_contract_requires_observation_qualifier(self):
        text = (ROOT / "references/output-contract.md").read_text(encoding="utf-8")
        self.assertIn("Traffic-derived measurements are observations, not system limits", text)
        self.assertIn("Observed 30-day max request payload: 11.7 MB", text)
        self.assertIn("Actual source-system maximum is unknown and may be higher", text)
        self.assertIn("Do **not** write `max 11.7 MB`", text)

    def test_evidence_discipline_preserves_observation_window_semantics(self):
        text = (ROOT / "references/evidence-discipline.md").read_text(encoding="utf-8")
        self.assertIn("OBSERVED traffic measurements", text)
        self.assertIn("do **not** establish a configured, contractual, or technically enforced system limit", text)
        self.assertIn("actual system maximum is unknown and may be higher", text)
        self.assertIn("Never rewrite the first statement as `payload limit = 11.7 MB`", text)

    def test_traffic_analysis_repeats_rule_near_measurement_guidance(self):
        text = (ROOT / "references/traffic-analysis.md").read_text(encoding="utf-8")
        self.assertIn("Measurement-labeling rule", text)
        self.assertIn("label them explicitly as observed", text)
        self.assertIn("Never use traffic `max` fields as an implied `payload limit`", text)


if __name__ == "__main__":
    unittest.main()
