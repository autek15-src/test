from __future__ import annotations

import csv
import importlib.util
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOOT = ROOT / "scripts" / "bootstrap_assessment.py"
BUILD = ROOT / "scripts" / "build_html_report.py"


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


validator = load_module("validate_assessment_v150", ROOT / "scripts" / "validate_assessment.py")
renderer = load_module("render_diagrams_v150", ROOT / "scripts" / "render_diagrams.py")
assigner = load_module("assign_flow_diagram_names_v150", ROOT / "scripts" / "assign_flow_diagram_names.py")


def csv_headers(path: Path) -> list[str]:
    with path.open(encoding="utf-8-sig", newline="") as f:
        return next(csv.reader(f))


def write_rows(path: Path, rows: list[dict[str, str]]) -> None:
    headers = csv_headers(path)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        for row in rows:
            out = {h: "" for h in headers}
            out.update(row)
            w.writerow(out)


class SequenceDiagramV150Tests(unittest.TestCase):
    def test_template_encodes_sequence_quality_standard(self):
        text=(ROOT / "templates/diagrams/flows/FLOW-template.puml").read_text(encoding="utf-8")
        for token in ("autonumber", "skinparam SequenceArrowThickness", "box \"MuleSoft\"", "activate", "deactivate", "alt Success path", "else Error / alternate path", "loop Actual retry/redelivery"):
            self.assertIn(token, text)
        self.assertNotIn("!pragma layout smetana", "\n".join(line for line in text.splitlines() if not line.lstrip().startswith("'")))

    def test_assigner_commits_deterministic_names_and_preserves_existing(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"api-flow-inventory.csv"
            path.write_text("flow_id,flow_name,sequence_diagram\nFLOW-001,Producer Search,\nFLOW-002,Policy Update,diagrams/flows/custom-existing.puml\n",encoding='utf-8')
            mapping=assigner.assign(path,force=False)
            with path.open(encoding='utf-8',newline='') as f:
                rows=list(csv.DictReader(f))
            self.assertEqual(rows[0]['sequence_diagram'],'diagrams/flows/seq-01-producer-search.puml')
            self.assertEqual(rows[1]['sequence_diagram'],'diagrams/flows/custom-existing.puml')
            self.assertEqual(mapping[0][0],'FLOW-001')

    def test_renderer_rejects_error_svg(self):
        with tempfile.TemporaryDirectory() as td:
            good=Path(td)/"good.svg"; bad=Path(td)/"bad.svg"
            good.write_text('<svg><text>ok</text></svg>',encoding='utf-8')
            bad.write_text('<svg><text>Syntax Error? (Assumed diagram type: component) IllegalStateException</text></svg>',encoding='utf-8')
            self.assertTrue(renderer.validate_rendered_output(good,"svg"))
            self.assertFalse(renderer.validate_rendered_output(bad,"svg"))

    def test_validator_warns_on_missing_autonumber_and_error_svg(self):
        with tempfile.TemporaryDirectory() as td:
            assessment=Path(td)/"assessment"
            subprocess.check_call([sys.executable,str(BOOT),str(assessment)])
            write_rows(assessment/"current-state/api-flow-inventory.csv", [{
                "flow_id":"FLOW-001","flow_name":"Producer search","business_purpose":"Search producers","trigger":"UI search","primary_actor":"Admin","mule_endpoints":"EP-001","final_outcome":"Results returned","sequence_diagram":"diagrams/flows/seq-01-producer-search.puml","evidence_refs":"EV-001"}])
            write_rows(assessment/"current-state/api-flow-steps.csv", [{"flow_id":"FLOW-001","step_number":"1","actor_or_system":"UI","business_action":"Search","technical_action":"Call API","evidence_refs":"EV-001"}])
            puml=assessment/"diagrams/flows/seq-01-producer-search.puml"
            puml.write_text("@startuml seq-01-producer-search\nactor User\nparticipant Mule\nUser -> Mule: GET /producers\nMule --> User: 200\n@enduml\n",encoding='utf-8')
            puml.with_suffix('.svg').write_text('<svg><text>error occurred IllegalStateException</text></svg>',encoding='utf-8')
            result=validator.validate(assessment)
            codes={x['code'] for x in result.warnings}
            self.assertIn('FLOW_DIAGRAM_NO_AUTONUMBER',codes)
            self.assertIn('FLOW_SVG_RENDER_ERROR',codes)

    def test_svg_count_mismatch_is_error_once_render_outputs_exist(self):
        with tempfile.TemporaryDirectory() as td:
            assessment=Path(td)/"assessment"
            subprocess.check_call([sys.executable,str(BOOT),str(assessment)])
            rows=[]
            steps=[]
            for n,name in [(1,"Producer search"),(2,"Policy update")]:
                fid=f"FLOW-{n:03d}"; stem=f"seq-{n:02d}-{'producer-search' if n==1 else 'policy-update'}"
                rows.append({"flow_id":fid,"flow_name":name,"business_purpose":name,"trigger":"Trigger","primary_actor":"Actor","mule_endpoints":f"EP-{n:03d}","final_outcome":"Done","sequence_diagram":f"diagrams/flows/{stem}.puml","evidence_refs":"EV-001"})
                steps.append({"flow_id":fid,"step_number":"1","actor_or_system":"Actor","business_action":"Act","technical_action":"Call","evidence_refs":"EV-001"})
                (assessment/f"diagrams/flows/{stem}.puml").write_text(f"@startuml {stem}\nautonumber\nactor A\nparticipant M\nA -> M: call\nM --> A: ok\n@enduml\n",encoding='utf-8')
            write_rows(assessment/"current-state/api-flow-inventory.csv",rows)
            write_rows(assessment/"current-state/api-flow-steps.csv",steps)
            (assessment/"diagrams/flows/seq-01-producer-search.svg").write_text('<svg/>',encoding='utf-8')
            result=validator.validate(assessment)
            self.assertIn('FLOW_SVG_COUNT_MISMATCH',{x['code'] for x in result.errors})

    def test_html_uses_sequence_stem_anchor_and_required_flow_structure(self):
        with tempfile.TemporaryDirectory() as td:
            assessment=Path(td)/"assessment"
            subprocess.check_call([sys.executable,str(BOOT),str(assessment)])
            write_rows(assessment/"current-state/api-flow-inventory.csv", [{
                "flow_id":"FLOW-001","flow_name":"Producer search","business_purpose":"Internal policy administrator searches for a producer.","trigger":"Search button selected","primary_actor":"Policy administrator","consumer_or_upstream_component":"Policy UI","mule_endpoints":"EP-001","downstream_systems":"Producer system","final_outcome":"Producer list displayed","sequence_diagram":"diagrams/flows/seq-01-producer-search.puml","evidence_refs":"EV-001","confidence":"HIGH"}])
            write_rows(assessment/"current-state/api-flow-steps.csv", [{
                "flow_id":"FLOW-001","step_number":"1","actor_or_system":"Policy UI","business_action":"Search producer","technical_action":"GET request to Mule","request_or_event":"GET /producers?name={query}","outcome_or_next_step":"HTTP 200 results returned to UI","error_or_alternate_path":"HTTP 4xx validation error","evidence_refs":"EV-001"}])
            puml=assessment/"diagrams/flows/seq-01-producer-search.puml"
            puml.write_text("@startuml seq-01-producer-search\nautonumber\nactor User\nparticipant Mule\nUser -> Mule: GET /producers\nMule --> User: HTTP 200 {producerList}\n@enduml\n",encoding='utf-8')
            puml.with_suffix('.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg"><text>Producer flow</text></svg>',encoding='utf-8')
            out=assessment/"architecture-assessment.html"
            subprocess.check_call([sys.executable,str(BUILD),str(assessment),"--output",str(out)])
            text=out.read_text(encoding='utf-8')
            self.assertIn('id="api-flow-seq-01-producer-search"',text)
            self.assertIn('data-sequence-stem="seq-01-producer-search"',text)
            self.assertIn('class="diagram-wrap seq-diagram"',text)
            self.assertIn('<strong>Initiated by:</strong>',text)
            self.assertIn('Request / Processing Path',text)
            self.assertIn('Response / Outcome Path',text)
            self.assertIn('AWS target note:',text)
            import json
            manifest=json.loads((assessment/"validation/html-report-manifest.json").read_text(encoding='utf-8'))
            self.assertEqual(manifest['flow_diagrams'],['seq-01-producer-search'])
            findings=validator.Result()
            validator.validate_html_report(assessment,findings)
            flow_codes={x['code'] for x in findings.items if x['code'].startswith('HTML_FLOW_')}
            self.assertNotIn('HTML_FLOW_SVG_EMBED_COUNT_MISMATCH',flow_codes)
            self.assertNotIn('HTML_FLOW_CARD_MISSING',flow_codes)

    def test_docs_define_coverage_and_slug_commitment(self):
        skill=(ROOT/"SKILL.md").read_text(encoding='utf-8')
        html=(ROOT/"references/html-report-standard.md").read_text(encoding='utf-8')
        flows=(ROOT/"templates/api-flows.md").read_text(encoding='utf-8')
        self.assertIn('Mandatory API interaction flow coverage',skill)
        self.assertIn('Commit API interaction flow diagram names before diagram authoring',skill)
        self.assertIn('seq-<NN>-<slug>',skill)
        self.assertIn('Sequence diagram format (mandatory)',skill)
        self.assertIn('Sequence diagram not available',html)
        self.assertIn('count/coverage by category',flows)


if __name__ == "__main__":
    unittest.main()
