from __future__ import annotations

import csv
import importlib.util
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
BOOT=ROOT/'scripts/bootstrap_assessment.py'
BUILD=ROOT/'scripts/build_html_report.py'

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); assert spec and spec.loader
    sys.modules[name]=mod; spec.loader.exec_module(mod); return mod

validator=load_module('validate_assessment_v160',ROOT/'scripts/validate_assessment.py')

def headers(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return next(csv.reader(f))

def write_rows(path, rows):
    hs=headers(path)
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=hs);w.writeheader()
        for row in rows:
            out={h:'' for h in hs};out.update(row);w.writerow(out)

class CurrentConnectionV160Tests(unittest.TestCase):
    def test_bootstrap_contains_connection_artifacts_and_templates_use_connection_ids(self):
        with tempfile.TemporaryDirectory() as td:
            a=Path(td)/'assessment'; subprocess.check_call([sys.executable,str(BOOT),str(a)])
            self.assertTrue((a/'current-state/connection-inventory.csv').exists())
            self.assertTrue((a/'current-state/connection-endpoints.csv').exists())
            for name in ('current-context.puml','current-network.puml'):
                text=(a/'diagrams'/name).read_text(encoding='utf-8')
                self.assertIn('[CONN-001]',text)

    def test_validator_rejects_config_only_connection_and_unlabeled_arrow(self):
        with tempfile.TemporaryDirectory() as td:
            a=Path(td)/'assessment'; subprocess.check_call([sys.executable,str(BOOT),str(a)])
            # Remove one edge evidence ID and create a config-only row.
            p=a/'diagrams/current-context.puml'; p.write_text(p.read_text().replace('[CONN-001] ',''),encoding='utf-8')
            write_rows(a/'current-state/connection-inventory.csv',[{
                'connection_id':'CONN-002','diagram_scope':'BOTH','source_component':'Mule','target_component_or_system':'Backend','direction':'OUTBOUND_FROM_MULE','business_or_functional_purpose':'Lookup','protocol':'HTTPS','validation_status':'UNCONFIRMED_CONFIG_ONLY','primary_evidence_type':'SOURCE_CODE','evidence_refs':'EV-001','source_locations':'global config only','endpoint_applicability':'N/A_NETWORK_ONLY'}])
            result=validator.validate(a)
            codes={x['code'] for x in result.errors}
            self.assertIn('DIAGRAM_CONNECTION_ID_MISSING',codes)
            self.assertIn('CONNECTION_NOT_AUTHORITATIVE',codes)

    def test_validator_requires_called_endpoint_details_for_application_connection(self):
        with tempfile.TemporaryDirectory() as td:
            a=Path(td)/'assessment'; subprocess.check_call([sys.executable,str(BOOT),str(a)])
            write_rows(a/'current-state/connection-inventory.csv',[{
                'connection_id':'CONN-001','diagram_scope':'BOTH','source_component':'UI','target_component_or_system':'Mule','direction':'INBOUND_TO_MULE','business_or_functional_purpose':'Search','protocol':'HTTPS','validation_status':'CONFIRMED_EXECUTABLE','primary_evidence_type':'SOURCE_CODE','evidence_refs':'EV-001','source_locations':'ui client + mule listener','endpoint_applicability':'REQUIRED'},
                {'connection_id':'CONN-002','diagram_scope':'BOTH','source_component':'Mule','target_component_or_system':'Backend','direction':'OUTBOUND_FROM_MULE','business_or_functional_purpose':'Search backend','protocol':'HTTPS','validation_status':'CONFIRMED_EXECUTABLE','primary_evidence_type':'SOURCE_CODE','evidence_refs':'EV-001','source_locations':'flow outbound request','endpoint_applicability':'REQUIRED'}])
            result=validator.validate(a)
            self.assertIn('CONNECTION_ENDPOINTS_MISSING',{x['code'] for x in result.errors})

    def test_html_places_connection_tables_after_current_diagrams(self):
        with tempfile.TemporaryDirectory() as td:
            a=Path(td)/'assessment'; subprocess.check_call([sys.executable,str(BOOT),str(a)])
            write_rows(a/'current-state/connection-inventory.csv',[{
                'connection_id':'CONN-001','diagram_scope':'BOTH','source_component':'Policy UI','target_component_or_system':'Mule Producer API','direction':'INBOUND_TO_MULE','business_or_functional_purpose':'Producer search','protocol':'HTTPS','connector_or_client':'Browser HTTP client','validation_status':'CONFIRMED_EXECUTABLE','primary_evidence_type':'SOURCE_CODE','evidence_refs':'EV-001','source_locations':'ui producer.service.ts; mule producer.xml','endpoint_applicability':'REQUIRED','network_path':'Corporate -> Mule'}])
            write_rows(a/'current-state/connection-endpoints.csv',[{
                'connection_endpoint_id':'CE-001','connection_id':'CONN-001','target_endpoint_or_operation':'GET /producers','business_or_functional_purpose':'Search producers','protocol':'HTTPS','method_or_operation':'GET','authentication':'Okta JWT','authorization':'producer.search scope','request_content_type':'application/json','response_content_type':'application/json','timeout_ms':'30000','retry_policy':'None','request_schema_or_event':'query params','response_schema_or_result':'producer list','call_condition':'User searches','call_confirmation':'CONFIRMED_EXECUTABLE_CALL','evidence_refs':'EV-001','source_locations':'producer.service.ts + producer.xml'}])
            out=a/'architecture-assessment.html'; subprocess.check_call([sys.executable,str(BUILD),str(a),'--output',str(out)])
            text=out.read_text(encoding='utf-8')
            self.assertIn('id="current-connections"',text)
            self.assertIn('Actually called target endpoints / operations',text)
            self.assertIn('CONFIRMED_EXECUTABLE_CALL',text)
            self.assertLess(text.index('diagram-current-network'), text.index('id="current-connections"'))
            self.assertLess(text.index('id="current-connections"'), text.index('id="api-flows"'))

    def test_docs_define_source_reachability_and_documentation_fallback(self):
        skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        discovery=(ROOT/'references/discovery.md').read_text(encoding='utf-8')
        contract=(ROOT/'references/output-contract.md').read_text(encoding='utf-8')
        self.assertIn('config-only/unconfirmed',skill)
        self.assertIn('reachable ingress',discovery)
        self.assertIn('DOCUMENTED_FALLBACK',contract)
        self.assertIn('connection-endpoints.csv',contract)

if __name__=='__main__':unittest.main()
