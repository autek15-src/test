from __future__ import annotations

import csv
import importlib.util
import json
import tempfile
import unittest
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


render = load_module("render_diagrams_v140", ROOT / "scripts" / "render_diagrams.py")
build = load_module("build_html_v140", ROOT / "scripts" / "build_html_report.py")
validator = load_module("validate_assessment_v140", ROOT / "scripts" / "validate_assessment.py")
bootstrap = ROOT / "scripts" / "bootstrap_assessment.py"


class V140RegressionTests(unittest.TestCase):
    def test_sequence_direction_directive_is_removed(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "FLOW-001.puml"
            p.write_text(
                "@startuml FLOW-001\nleft to right direction\nactor User\nparticipant Mule\nUser -> Mule: Call\nMule --> User: Result\n@enduml\n",
                encoding="utf-8",
            )
            changed = render.sanitize_sequence_directions(p)
            self.assertTrue(changed)
            text = p.read_text(encoding="utf-8")
            self.assertNotIn("left to right direction", text)
            self.assertIn("User -> Mule", text)


    def test_structural_actor_diagram_keeps_direction_directive(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "context.puml"
            p.write_text(
                "@startuml context\nleft to right direction\nactor User\ncomponent API\nUser --> API\n@enduml\n",
                encoding="utf-8",
            )
            changed = render.sanitize_sequence_directions(p)
            self.assertFalse(changed)
            self.assertIn("left to right direction", p.read_text(encoding="utf-8"))

    def test_custom_startuml_output_is_normalized_to_source_stem(self):
        with tempfile.TemporaryDirectory() as td:
            d = Path(td)
            src = d / "current-context.puml"
            src.write_text("@startuml current-context-pmp-7083\nA -> B\n@enduml\n", encoding="utf-8")
            before = render.output_snapshot(d, "svg")
            actual = d / "current-context-pmp-7083.svg"
            actual.write_text("<svg>ok</svg>", encoding="utf-8")
            out = render.normalize_rendered_output(src, "svg", before, 0)
            expected = d / "current-context.svg"
            self.assertEqual(out, expected)
            self.assertTrue(expected.exists())
            self.assertFalse(actual.exists())

    def test_manifest_path_normalizes_windows_backslashes(self):
        self.assertEqual(build.manifest_path(r"target-state\\cloud-component-inventory.csv"), "target-state/cloud-component-inventory.csv")

    def test_service_classifier_does_not_treat_vault_extension_as_lambda(self):
        self.assertNotEqual(validator.service_norm("HashiCorp Vault (Lambda Extension)"), "lambda")
        self.assertEqual(validator.service_norm("AWS Lambda"), "lambda")
        self.assertEqual(validator.service_norm("ECS Fargate"), "fargate")

    def test_spring_cloud_config_removal_note_does_not_trigger_constraint(self):
        with tempfile.TemporaryDirectory() as td:
            assessment = Path(td) / "assessment"
            # Import and call bootstrap's CLI through compile-free subprocess avoidance is unnecessary here.
            import subprocess, sys
            subprocess.check_call([sys.executable, str(bootstrap), str(assessment)])
            path = assessment / "target-state" / "configuration-mapping.csv"
            with path.open(encoding="utf-8-sig", newline="") as f:
                headers = next(csv.reader(f))
            row = {h: "" for h in headers}
            row.update({
                "current_config_id": "CFG-001",
                "current_source": "Spring Cloud Config",
                "target_mechanism": "Environment variables",
                "target_location": "Lambda environment",
                "notes": "External Spring Cloud Config server eliminated during migration",
            })
            with path.open("w", encoding="utf-8", newline="") as f:
                w = csv.DictWriter(f, fieldnames=headers); w.writeheader(); w.writerow(row)
            result = validator.validate(assessment)
            codes = {x["code"] for x in result.items}
            self.assertNotIn("CONSTRAINT_SPRING_CONFIG", codes)

    def test_missing_exact_recommendation_heading_warns(self):
        with tempfile.TemporaryDirectory() as td:
            assessment = Path(td) / "assessment"
            import subprocess, sys
            subprocess.check_call([sys.executable, str(bootstrap), str(assessment)])
            (assessment / "options" / "architecture-options.md").write_text(
                "# Options\n\n## Option A\nSomething\n\n## Selected Option\nOption A\n",
                encoding="utf-8",
            )
            result = validator.validate(assessment)
            warnings = {x["code"] for x in result.warnings}
            self.assertIn("OPTIONS_RECOMMENDATION_MISSING", warnings)

    def test_diagram_templates_use_filename_stem_ids(self):
        files = [
            ROOT / "templates/diagrams/current-context.puml",
            ROOT / "templates/diagrams/current-network.puml",
            ROOT / "templates/diagrams/target-context.puml",
            ROOT / "templates/diagrams/target-network.puml",
            ROOT / "templates/diagrams/flows/FLOW-template.puml",
        ]
        for p in files:
            first = p.read_text(encoding="utf-8").splitlines()[0].strip()
            self.assertEqual(first, f"@startuml {p.stem}")

    def test_output_contract_documents_reported_machine_rules(self):
        text = (ROOT / "references/output-contract.md").read_text(encoding="utf-8")
        self.assertIn("FLOW-001,FLOW-003", text)
        self.assertIn("## Recommendation", text)
        self.assertIn("must use an `@startuml` identifier equal to its filename", text)
        self.assertIn("SimpleQueueService.puml", text)
        self.assertIn("Containers/Fargate.puml", text)
        self.assertIn("security_critical = yes", text)

    def test_html_manifest_writes_schema_and_normalized_artifacts(self):
        with tempfile.TemporaryDirectory() as td:
            assessment = Path(td) / "assessment"
            import subprocess, sys
            subprocess.check_call([sys.executable, str(bootstrap), str(assessment)])
            out = assessment / "architecture-assessment.html"
            subprocess.check_call([sys.executable, str(ROOT / "scripts/build_html_report.py"), str(assessment), "--output", str(out)])
            manifest = json.loads((assessment / "validation/html-report-manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["schema"], "2.1")
            self.assertEqual(manifest["schema_version"], "2.1")
            self.assertTrue(all("\\" not in x for x in manifest["embedded_artifacts"]))
            self.assertTrue(all("\\" not in x for x in manifest["diagrams"]))
            self.assertTrue(all("\\" not in x for x in manifest["flow_diagrams"]))


if __name__ == "__main__":
    unittest.main()
