---
name: mulesoft-aws-architecture
version: 1.5.0
description: Evidence-driven analysis of MuleSoft applications and design of AWS-native replacement architecture, including automated workspace bootstrap, business/API interaction flow reconstruction, gateway/proxy rationalization, consumer-contract preservation, API/cloud inventories, AWS-limit validation, security/network mapping, current/target diagrams, ADRs, testing, cutover, remediation loops, completion validation, and a first-class interactive architect HTML review report.
---

# MuleSoft to AWS Native Architecture Skill

Use this skill when analyzing one MuleSoft application, including all APIs/flows it contains, for migration away from MuleSoft to AWS-native services.

## Core objective

Determine what the MuleSoft application actually does, which capabilities should remain, which should be retired/consolidated/absorbed, and what AWS-native design best replaces **only the Mule-owned functionality** while preserving required business behavior and contracts.

Do not perform a 1:1 Mule-to-AWS translation.

## Normal user experience

The user should provide the Mule repository plus any supporting evidence and ask for the migration assessment. The user should **not** normally be asked to run bootstrap, scan, validation, rendering, or report-generation scripts manually.

The agent owns orchestration of the deterministic scripts in this package.

Manual script invocation is a developer/debug/CI fallback, not the standard workflow.

## Hard scope boundary

In scope: Mule APIs, flows/subflows, orchestration, transformations, API policies, validation, retries, schedulers, messaging, object-store behavior, custom Mule-side Java/code, configuration, gateway behavior, and Mule-managed integrations.

Out of scope: redesigning or migrating upstream/downstream/non-Mule applications. Their code/docs may be inspected as evidence. A Mule capability may be recommended for absorption into an existing application when that application naturally owns the capability and absorption reduces unnecessary distributed architecture.

# Mandatory automated execution workflow

The following lifecycle is required. Do not skip it unless the environment prevents script execution; if that occurs, emulate the same steps manually and record the limitation.

## Phase 0: Preflight

Before analysis:

1. Resolve the Mule source repository root.
2. Resolve or create an assessment output directory.
3. Identify every user-supplied evidence location, including documentation, policies, diagrams, Splunk/Anypoint exports, tests, and non-Mule upstream/downstream source.
4. Determine whether this is a new assessment or a continuation.
5. Read `constraints/company-architecture-constraints.yaml` and treat enabled constraints as hard requirements.
6. Read `references/discovery.md`, `references/evidence-discipline.md`, and `references/mule-runtime-semantics.md`.
7. Read `references/html-report-standard.md`; the HTML report is a required first-class deliverable, not an optional summary.
8. Read `references/gateway-contract-and-flow-modernization.md` before rationalizing gateway/proxy APIs, consumer-facing contracts, or current-state interaction flows.
9. Read `references/diagram-standards.md` and `references/output-contract.md` before authoring PlantUML or machine-readable inventories.

Do not ask the user to initialize the workspace if the repository/output locations can be resolved from the task and filesystem.

## Phase 1: Automatically prepare the assessment

Before architecture reasoning, execute the deterministic prepare phase:

```bash
python scripts/run_assessment.py prepare <assessment-directory> \
  --source-repo <mule-source-repository> \
  --inputs <supporting-evidence-location>
```

Repeat `--inputs` for additional evidence locations.

The prepare phase:

- creates only missing canonical templates;
- preserves an existing assessment by default;
- records supplied input locations;
- seeds a recursive Mule source scan when needed;
- creates machine-readable workflow state.

Do not use `--force-bootstrap` during a continuation unless overwrite is explicitly intended.

Do not repeatedly rescan unchanged source. Use `--rescan` only when the repository changed materially or prior scan output is stale/incomplete.

## Phase 2: Perform evidence-driven analysis

The automated scanner is only a discovery accelerator. It does not replace direct inspection.

Recursively inspect the repository and all supplied evidence. Build an evidence register before making material architecture conclusions.

Build current-state inventories for:

### Current-state connection truth (mandatory)

Treat every connector/arrow in the current-state context and network diagrams as a claim that must be evidenced. Do not populate diagram edges merely because an HTTP Request config, connector global config, property, hostname, WSDL, database config, or architecture document mentions a possible target.

For each current-state connection:

1. Prefer executable source-path evidence: trace from a reachable listener/scheduler/message consumer through Mule `flow-ref`/subflows/routers to the actual outbound connector/request. Confirm which configured target is actually referenced by the reachable path.
2. Use runtime evidence (Splunk/Anypoint/logs/traces) to strengthen or, when source is incomplete, confirm that the connection is actually exercised.
3. Treat declarations that are never reached/referenced as `config-only/unconfirmed`; record them as findings if useful, but do **not** show them as authoritative current-state diagram edges.
4. When source/runtime cannot confirm a relationship, user-supplied documentation may be used as a fallback source of truth. Mark it `DOCUMENTED_FALLBACK`, state why code/runtime confirmation was not possible, and preserve that uncertainty in the report.
5. If source code contradicts documentation, prefer the executable behavior for the current-state diagram and explicitly record the contradiction.

Populate `current-state/connection-inventory.csv` with one row per authoritative diagram connection and `current-state/connection-endpoints.csv` with one row per target endpoint/operation that the connection actually invokes. Every current-state diagram edge must carry a stable `[CONN-###]` identifier matching `connection-inventory.csv`.

The called-endpoint detail must include, using `UNKNOWN`/`N/A` rather than blanks when evidence does not establish a value: business/functional purpose, protocol, method/operation, authentication, authorization, request/response content type, timeout, retry policy, call condition, evidence references, and source locations. Do not list endpoints merely discovered in config unless documentation is explicitly being used as the fallback authority.


- APIs/endpoints;
- **application/business API interaction flows that traverse one or more Mule APIs**, with detailed step-by-step business and technical descriptions and sequence diagrams;
- Mule flows/subflows;
- policies;
- dependencies/backends;
- traffic/latency/payload behavior;
- security/authentication/authorization;
- configuration/secrets;
- runtime semantics;
- deployment/network dependencies;
- tests and observed contracts.

Trace every endpoint from ingress to response, including API policies, DataWeave, validation, downstream calls, retries, transactions, error handling, and response mapping.

Separately reconstruct **API Interaction Flows** at the application/business level. A flow begins with a user, scheduler, upstream system, UI, or application component and must traverse one or more Mule APIs. For each flow:

- explain the business trigger and intended outcome;
- list the participating application components, Mule APIs, and downstream systems;
- enumerate each step in business language and technical language;
- show request/event transitions, transformations, policies/security, retries/errors, and responses where relevant;
- map the flow to current endpoint IDs and evidence references;
- create a detailed PlantUML sequence diagram under `diagrams/flows/`;
- ensure every `.puml` uses an `@startuml` ID exactly equal to the filename stem;
- never put structural direction directives (`left to right direction`, `top to bottom direction`, or reverse forms) in a sequence diagram;
- resolve PlantUML/AWS icon include paths to verified absolute filesystem paths rather than `$HOME`, `%USERPROFILE%`, `~`, or guessed AWS icon filenames/macros.

Do **not** document internal application workflows that never touch MuleSoft merely to make the application description complete.

### Mandatory API interaction flow coverage

Actively look for all of these flow categories rather than documenting only the obvious synchronous REST journeys:

- **Authenticated user journeys:** each materially distinct path from a user-facing actor through authentication/authorization, Mule, the final backend, and the response back to the caller.
- **Unauthenticated/open paths:** self-registration, health/open endpoints, bootstrap/login-support flows, or other intentionally unauthenticated consumer journeys that traverse Mule.
- **Async/event-driven flows:** AMQP/JMS/MQ consumers and producers, CometD/event subscriptions, scheduled jobs, file/SFTP polling, batch jobs, callbacks from queues/topics, and similar asynchronous paths.
- **Callback/webhook flows:** external or internal systems invoking Mule inbound after an earlier request or as an independent event.

For async flows, explicitly document acknowledgement/redelivery semantics, retry/DLQ behavior, ordering/idempotency, reconnect behavior, and timeout/idle behavior when supported by evidence. For CometD/WebSocket-style flows, include subscription establishment, event delivery, disconnect/idle handling, and reconnect behavior when present. For AMQP/MQ flows, include producer/broker/consumer transitions plus ACK/NACK/redelivery/DLQ behavior actually used by the current system; do not assume Amazon MQ, Lambda ESM, `x-death`, or any other target/runtime mechanism unless evidence or the target design establishes it.

As a coverage sanity check, an application with roughly 10 APIs often results in several distinct interaction flows and may plausibly have around 8–15. This is **not a quota**. Never invent flows to reach a count. If materially fewer flows are documented, explain why the API set collapses into fewer business/system journeys and record any coverage gaps.

### Commit API interaction flow diagram names before diagram authoring

After `current-state/api-flow-inventory.csv` is stable enough to enumerate the flows, commit the sequence-diagram mapping once before creating diagrams:

1. Order the flows in the same order they should appear in the architect HTML report.
2. Assign a zero-padded two-digit index starting at `01`.
3. Create a short lowercase-hyphenated slug from the flow name (use the flow ID as the fallback when the name is not usable).
4. Set `sequence_diagram` to `diagrams/flows/seq-<NN>-<slug>.puml`.
5. Treat that path as the single source of truth for the PlantUML filename, rendered SVG filename, and HTML flow-card anchor. Do not rename it later without updating the inventory first.

For a new assessment or blank `sequence_diagram` column, execute the deterministic helper after flow order/names are established:

```bash
python scripts/assign_flow_diagram_names.py <assessment-directory>
```

The helper preserves already committed names by default. Do not use `--force` after diagrams or report links have been authored unless intentionally re-baselining them.

Example: `FLOW-003` / `Producer Search` -> `diagrams/flows/seq-03-producer-search.puml` -> `seq-03-producer-search.svg` -> HTML anchor `api-flow-seq-03-producer-search`.

Use upstream/downstream code only as evidence unless recommending deliberate absorption of Mule-owned logic.

## Phase 3: Rationalize before choosing AWS services

Every current endpoint/API must receive an evidence-backed disposition:

- RETIRE
- CONSOLIDATE
- ABSORB
- REIMPLEMENT

Use `references/api-rationalization.md`.

Do not preserve Mule Experience/Process/System layers automatically.

Treat Mule gateway/proxy APIs as a special rationalization class:

- First evaluate whether API Gateway can replace gateway/proxy behavior directly **without Lambda** using HTTP/private proxy integration, supported request/response mappings, authentication/authorization, validation, throttling, routing, or direct AWS service integration.
- Do not introduce a pass-through Lambda solely to reproduce a Mule proxy hop.
- A Lambda behind API Gateway for a gateway/proxy replacement requires explicit evidence-backed justification such as complex data manipulation, multi-step orchestration, domain logic, conditional multi-backend behavior, non-trivial idempotency/state, protocol adaptation, or another documented need for compute.
- If the existing proxy has no meaningful routing, security/policy, contract abstraction, transformation, protocol adaptation, observability/governance, or ownership/lifecycle purpose, evaluate RETIRE or CONSOLIDATE rather than recreating it.
- Before deleting a pass-through API, verify whether it intentionally provides a stable compatibility/anti-corruption boundary for multiple consumers.

Do not default to Lambda.

When Lambda is selected, target **Node.js + TypeScript** by default. Java requires explicit technical justification recorded in the cloud component inventory. Do not select Java merely because Mule contains Java code or because of team familiarity.

Preserve existing **consumer-facing API contracts by default** to minimize coordinated consumer changes. Classify each consumer relationship. For consumers outside the application boundary, mixed consumers, or unknown consumers, any contract change requires explicit justification and migration impact. If the consumer is an internal application component such as its UI or business-service layer, contract changes may be recommended when the analysis demonstrates a material advantage over preserving compatibility.

Evaluate service boundaries around domain cohesion, ownership, security boundary, scaling, latency, failure isolation, deployment independence, operational burden, and cost.

## Phase 4: Design and populate canonical target artifacts

Evaluate Lambda, ECS Fargate, API Gateway, ALB, Step Functions, SQS, SNS, EventBridge, S3, DynamoDB/RDS, and other AWS services only where justified.

Use `references/aws-compute-decision-matrix.md` and all other relevant files in `references/`.

Populate the canonical assessment artifacts continuously as evidence and decisions are established. Do not wait until the end and produce prose without the structured inventories.

At minimum create/populate:

- `architecture-assessment.md`
- `executive-summary.md`
- `assumptions-risks-open-questions.md`
- `evidence/evidence-register.csv`
- `evidence/source-inventory.csv`
- `current-state/api-inventory.csv`
- `current-state/api-flow-inventory.csv`
- `current-state/api-flow-steps.csv`
- `current-state/api-flows.md`
- one detailed `diagrams/flows/seq-<NN>-<slug>.puml` sequence diagram for every identified API interaction flow
- `current-state/dependency-inventory.csv`
- `current-state/connection-inventory.csv`
- `current-state/connection-endpoints.csv`
- `current-state/policy-inventory.csv`
- `current-state/traffic-profile.csv`
- `target-state/target-api-inventory.csv`
- `target-state/cloud-component-inventory.csv`
- `target-state/compute-sizing.csv`
- `target-state/configuration-mapping.csv`
- `target-state/security-policy-mapping.csv`
- `target-state/aws-limit-validation.csv`
- `target-state/traceability-matrix.csv`
- `options/architecture-options.md`
- `diagrams/current-context.puml`
- `diagrams/current-network.puml`
- `diagrams/target-context.puml`
- `diagrams/target-network.puml`
- `testing/migration-test-strategy.md`
- `migration/migration-cutover-plan.md`
- ADRs for material decisions

Generate `target-state/target-openapi.yaml` when a REST API remains in the target state.

### Sequence diagram format (mandatory)

Every current-state API interaction sequence diagram must follow these rules:

1. **Deterministic name:** use `diagrams/flows/seq-<NN>-<slug>.puml`; rendered output is `seq-<NN>-<slug>.svg`. `NN` is zero-padded and `slug` is the committed lowercase-hyphenated flow slug. The `@startuml` identifier must equal the filename stem exactly.
2. **Autonumber:** include `autonumber` so every message is traceable to a numbered interaction.
3. **No Smetana / no structural direction directives:** do not use `!pragma layout smetana`, `left to right direction`, `top to bottom direction`, or related structural direction directives in a sequence diagram.
4. **Standard visual structure:** use the sequence skin parameters and logical `box` groupings from `templates/diagrams/flows/FLOW-template.puml` to distinguish external actors, application components, MuleSoft, and backends.
5. **Declare participants first:** declare all actors/participants before messages; group them in logical boxes.
6. **Show processing lifetimes:** use `activate`/`deactivate` on participants where processing duration/ownership materially improves understanding.
7. **Show branches:** use `alt` / `else` / `end` for material success/error or conditional behavior. Do not hide error behavior in prose when it changes the interaction.
8. **Show retries:** use `loop` for actual retry/redelivery logic when evidence shows it exists. Do not invent retry loops.
9. **Show authentication/security steps explicitly:** include material JWT/OIDC validation, Okta token acquisition/validation, HMAC signing/verification, mTLS/certificate steps, client-ID enforcement, or other security interactions when they occur in the flow. Security steps are migration-critical and must not be omitted merely to simplify the diagram.
10. **Label every message:** include protocol/method/event and the key business data or result when known, for example `GET /api/producers?name={query}` or `HTTP 200 {producerList, count}`. Preserve the observed-vs-system-limit distinction for any traffic measurements in labels/notes.
11. **Request then response:** make the forward request/event path and the response/outcome path visually understandable. Include callbacks or asynchronous completion paths explicitly.
12. **Keep diagrams readable:** target no more than roughly 20 participants and 40 message arrows. If the diagram exceeds this, split it at a natural boundary such as authentication vs. business retrieval, or submission vs. asynchronous processing. Keep one primary `seq-<NN>-<slug>` diagram in `diagrams/flows/`; place optional supporting sub-flow diagrams under `diagrams/flows/supporting/` and cross-reference them so primary SVG count remains one per business flow.

After writing each `.puml`, render it immediately using `scripts/render_diagrams.py <file> --format svg` when PlantUML is available. Verify that the SVG is non-empty and does not contain PlantUML error markers such as `error occurred` or `IllegalStateException`. Fix or split a broken diagram before proceeding.

See `references/output-contract.md` for schemas and completion expectations.

## Phase 5: Verify current AWS facts

For every recommended AWS service, verify relevant limits using current official AWS documentation at assessment time.

Never rely only on remembered quotas.

Record:

- service/limit;
- official AWS source URL;
- verification date;
- observed current-state requirement;
- AWS limit;
- headroom;
- pass/fail;
- evidence reference.

See `references/aws-service-limit-validation.md` and `references/official-source-priority.md`.

## Phase 6: Run automatic validation

When the assessment appears complete, do **not** report completion yet.

Execute:

```bash
python scripts/run_assessment.py validate <assessment-directory>
```

This automatically validates a populated target OpenAPI when applicable and runs the canonical assessment validator, writing machine-readable findings to:

`validation/assessment-validation.json`

## Phase 7: Mandatory remediation loop

If validation fails:

1. Read every finding in `validation/assessment-validation.json`.
2. Classify each finding as one of:
   - missing analysis;
   - missing generated artifact;
   - internally inconsistent information;
   - missing source evidence;
   - unresolved architecture decision;
   - genuine architecture blocker.
3. Correct everything that can be corrected using available evidence.
4. Do not weaken, bypass, delete, or edit validator rules merely to obtain a passing result.
5. Do not invent missing evidence.
6. Convert genuinely unavailable evidence into explicit assumptions, UNKNOWNs, P0-P3 findings, or approval conditions as appropriate.
7. Rerun:

```bash
python scripts/run_assessment.py validate <assessment-directory>
```

8. Repeat until either:
   - the validator passes; or
   - remaining blockers genuinely require evidence/decisions that are unavailable.

The validation loop is part of the skill's work, not work delegated to the user.

## Phase 8: Automatically finalize derivative outputs

After blocking canonical-artifact validation findings are resolved, execute:

```bash
python scripts/run_assessment.py finalize <assessment-directory>
```

The finalize phase:

1. runs canonical-artifact validation again;
2. renders current-state and target-state PlantUML diagrams when a local PlantUML runtime is available;
3. preserves `.puml` sources even when local rendering is unavailable;
4. builds `architecture-assessment.html` as the **primary architect-facing review artifact**;
5. embeds the current/target diagrams, inventories, decisions, testing/cutover material, evidence, validation results, and all canonical artifacts into that HTML;
6. provides hierarchical navigation, anchor tracking, search, sortable/filterable inventory tables, migration-option comparison/tabs, diagram expansion, print/PDF styling, and an embedded Artifact Explorer;
7. writes `validation/html-report-manifest.json`;
8. reruns completion validation with HTML-report checks enabled;
9. records final workflow state.

The architect should be able to obtain a full understanding from `architecture-assessment.html` without opening analysis files directly. The underlying files remain important for automation, source control, and exact traceability.

If finalization exposes new validation errors, return to the remediation loop rather than declaring completion.

## Phase 9: Final readiness status

Finish with exactly one assessment status:

- READY
- READY WITH CONDITIONS
- NOT READY

The status must agree with the validator and documented P0-P3 findings.

Summarize:

- endpoint traceability count;
- recommended architecture;
- major rationalization decisions;
- validation result;
- unresolved conditions/blockers;
- generated artifact locations.

# First-class architect HTML report

`architecture-assessment.html` is mandatory after finalization and is the default artifact to hand to an architect.

It must provide both a fast review path and full drill-down. At minimum it must contain:

- architect review snapshot and readiness;
- current-state context and network diagrams;
- current API, traffic, policy/security, and dependency views;
- endpoint rationalization and source-to-target traceability;
- visible migration option comparison with pros/cons and recommendation;
- target context and network diagrams;
- target APIs, cloud components, sizing, configuration/secrets, security parity, and AWS limit headroom;
- ADRs, testing, cutover/rollback, risks, assumptions, and open questions;
- the complete architecture-assessment narrative;
- evidence register and completion-validation results;
- an embedded Artifact Explorer from which every canonical analysis artifact can be viewed and downloaded.

Use `references/html-report-standard.md` as the mandatory UX/content contract. Do not replace structured report sections with a raw appendix dump.

# Evidence rules

Use these fact classes consistently:

- **OBSERVED**: directly supported by code/config/logs/metrics/documentation.
- **INFERRED**: strongly supported by multiple pieces of evidence.
- **ASSUMED**: necessary for analysis but unconfirmed.
- **UNKNOWN**: required information unavailable.
- **RECOMMENDED**: target-state proposal.

Never fabricate traffic, consumers, SLAs, network paths, payload sizes, AWS limits, pricing, or policy behavior.

# Architecture rules

Do not assume:

- one Mule app becomes one Lambda;
- one Mule API becomes one Lambda;
- Mule Experience/Process/System layering must survive;
- synchronous flows must stay synchronous;
- historical service boundaries are correct target boundaries.

Prefer the simplest architecture that meets measured requirements.

# Required target outcomes per current endpoint

Every current endpoint must appear exactly once in the traceability matrix as:

- RETIRED
- CONSOLIDATED INTO
- ABSORBED INTO
- REPLACED BY

No endpoint may silently disappear.

# Company defaults

The constraints file currently establishes these defaults:

- HashiCorp Vault remains the secret store; AWS Secrets Manager is not used.
- Spring Cloud Config is replaced with environment variables and/or S3-based non-secret configuration.
- CloudWatch and Splunk are both part of observability.
- API Gateway cannot be directly exposed to consumers outside the company network.
- Lambda implementation targets Node.js/TypeScript; Java is an exception requiring documented technical justification.
- Existing consumer-facing API contracts are preserved by default. Deliberate contract changes require explicit justification and consumer impact analysis, with greater flexibility when the consumer is another component within the same application boundary.

Do not bypass these with equivalent public exposure patterns unless the user explicitly changes the constraint.

# Diagram rules

Use separate editable diagrams for:

1. Current application/context architecture.
2. Current network architecture.
3. Target application/context architecture.
4. Target network architecture.

All four must be embedded in the first-class HTML report. Keep business/application relationships out of subnet-level clutter and keep network topology out of the context diagrams.

For both current-state diagrams, every rendered connection line must include a `[CONN-###]` evidence ID. The diagram is not the evidence source; it is a visual projection of `current-state/connection-inventory.csv`. Immediately after the current-state diagrams, the architect HTML report must show the connection evidence table and the detailed target-endpoint/operation table so reviewers can verify exactly why each arrow exists.

In addition, **every identified current-state API interaction flow must have a detailed sequence diagram**. These flow diagrams are mandatory, not optional complexity diagrams. Auth/async/failure diagrams beyond the per-flow sequence diagrams remain optional when they clarify material complexity.

# Readiness rule

Do not return READY if any of the following remain unresolved:

- current endpoints are missing from traceability;
- current production policy behavior is unknown for security-critical APIs;
- a recommended AWS service conflicts with measured payload/timeout/throughput requirements;
- external-consumer ingress violates company network constraints;
- required security parity is unproven;
- target architecture has a P0/P1 blocker;
- required current or target context/network diagrams are absent;
- identified API interaction flows lack step-by-step documentation or sequence diagrams;
- a gateway/proxy API is recreated as API Gateway + pass-through Lambda without an explicit compute justification;
- a Lambda is targeted to a language other than TypeScript without an allowed and justified exception;
- consumer-facing contract changes are proposed without documented justification and consumer impact;
- finalization cannot produce a structurally complete first-class HTML architect report.

# Script ownership model

The coding agent owns:

- interpretation of source behavior;
- evidence classification;
- API rationalization;
- architecture decisions;
- AWS service selection;
- target design;
- ADRs;
- risk classification;
- artifact authoring;
- remediation of validator findings.

The deterministic scripts own:

- workspace creation;
- repository scanning;
- traffic summarization;
- structural validation;
- omission/inconsistency checks;
- OpenAPI checks;
- diagram rendering;
- HTML generation;
- package self-tests.

Do not move architecture judgment into deterministic scripts merely to make the workflow appear automated.

# Manual/debug entry points

These remain available for skill developers, CI pipelines, or troubleshooting:

```bash
python scripts/bootstrap_assessment.py ...
python scripts/scan_mule_project.py ...
python scripts/analyze_traffic.py ...
python scripts/validate_openapi.py ...
python scripts/validate_assessment.py ...
python scripts/render_diagrams.py ...
python scripts/build_html_report.py ...
```

For normal skill execution, prefer `scripts/run_assessment.py` and let the skill invoke it automatically.
