# Changelog

## 1.6.0

- Made current-state context/network diagram connections evidence-backed claims rather than configuration projections. Every authoritative edge now uses a stable `[CONN-###]` identifier.
- Added `current-state/connection-inventory.csv` with from/to, purpose, protocol, validation status, primary evidence source, source locations, network path, and documentation-fallback rationale.
- Added `current-state/connection-endpoints.csv` with only actually invoked/documentation-backed target endpoints or operations, including business purpose, protocol, method, authentication, authorization, content types, timeout, retry policy, call condition, evidence, and source locations.
- Added source reachability rules that prevent unused/global Mule configs, property URLs, WSDLs, and other config-only placeholders from being rendered as active architecture connections.
- Added explicit documentation-fallback semantics when source/runtime cannot confirm a connection and contradiction handling when source disagrees with documentation.
- Added validator gates for connection IDs on every current-state diagram arrow, authoritative evidence status, source locations, called-endpoint completeness, orphan endpoints, and diagram/inventory scope alignment.
- Added a first-class Current-State Connection Evidence section immediately after the current diagrams in the architect HTML report, plus sidebar navigation and artifact embedding.

## 1.5.0

- Upgraded current-state API interaction sequence diagrams from a minimal stub to a fully specified PlantUML standard with autonumber, skin parameters, logical system boxes, activation lifetimes, conditional branches, retry loops when evidenced, explicit authentication/security interactions, and message-labeling rules.
- Added mandatory flow coverage categories for authenticated, unauthenticated/open, async/event-driven, scheduled/file, and callback/webhook journeys, with a non-quota coverage sanity check.
- Added a deterministic flow-diagram naming commitment: `seq-<NN>-<slug>` is established in `api-flow-inventory.csv` before authoring and reused for `.puml`, `.svg`, HTML anchors, and manifest entries.
- Added sequence readability limits (~20 participants/~40 arrows) and natural-boundary split guidance.
- Reworked architect HTML flow cards to emphasize business context, initiated-by trigger, embedded sequence diagram, request/processing path, response/outcome path, target-state mapping note, and expandable detailed evidence steps.
- Added explicit `.seq-diagram` responsive CSS and visible `Sequence diagram not available` fallback.
- Added validator gates for autonumber, render-error SVGs, final SVG/flow count alignment, and HTML flow-card/diagram alignment.
- Strengthened `api-flows.md` coverage, cross-flow observations, and unknown-flow guidance while preserving CSV canonical artifacts and evidence traceability.

## 1.4.1

- Added a mandatory distinction between runtime-observed maxima and configured/contractual system limits.
- Traffic-derived payload, latency, throughput, concurrency, and volume values must now be labeled as observations everywhere they are reused, including executive summaries, flow narratives/diagrams, ADRs, sizing, risks, options, and AWS-limit comparisons.
- Added explicit guidance that an observed maximum is bounded by the evidence window and may understate the true system ceiling.
- Added the required architecture-decision phrasing pattern: an observed value can invalidate an AWS option while the actual source-system maximum remains unknown and potentially higher.
- Reinforced the same rule in traffic-analysis guidance and added regression coverage for the documentation contract.

## 1.4.0

- Fixed PlantUML output-name mismatches caused by custom `@startuml` IDs by normalizing newly rendered SVG/PNG files back to the source filename stem.
- Added pre-render sequence-diagram sanitation that removes structural direction directives and logs a warning.
- Normalized all HTML report manifest artifact paths to forward slashes for Windows compatibility and added explicit manifest `schema` + `schema_version` = `2.1`.
- Narrowed the Spring Cloud Config constraint check to target mechanism/location fields so documentation of legacy removal does not trigger false positives.
- Added an architecture-options validation warning when the exact `## Recommendation` section required by the HTML report is missing.
- Hardened AWS service classification so non-AWS components such as Vault extensions are not classified as Lambda merely because their descriptive text contains an AWS-service keyword.
- Documented `business_flow_ids` separators, security-critical policy confirmation rules, categorical `aws_service` usage, deterministic `@startuml` IDs, and sequence-diagram restrictions.
- Added PlantUML/AWS icon guidance: absolute include paths only, no shell-variable paths, verify local include files/macros, and documented common Lambda/Fargate/API Gateway/SQS/EventBridge/Step Functions/ALB/WAF mappings.
- Updated diagram templates to use deterministic `@startuml` IDs matching filename stems.
- Added regression tests for the reported finalization/diagram/manifest/validator failures.

## 1.3.0

- Added company constraint requiring Lambda implementations to target Node.js/TypeScript by default, with Java allowed only through an explicit technical exception justification.
- Added consumer-relationship classification and a default goal of preserving existing consumer-facing interfaces to minimize coordinated consumer changes.
- Added explicit contract-preservation/change fields and validator gates for justification and consumer impact.
- Added Mule gateway/proxy rationalization guidance: prefer direct API Gateway HTTP/private/AWS service integration where no compute logic is required; avoid pass-through Lambda; retire/consolidate purposeless proxy layers.
- Added official AWS source-backed `references/gateway-contract-and-flow-modernization.md`.
- Added required current-state API Interaction Flows with flow inventory, step inventory, business/technical descriptions, evidence, and one detailed PlantUML sequence diagram per flow.
- Added API flow direct navigation and detailed sequence diagrams to the first-class HTML architect report.
- Added recursive PlantUML rendering so per-flow diagrams are rendered during finalization.
- Added validator gates for flow completeness/diagram coverage, endpoint-to-flow coverage, gateway-to-Lambda justification, Lambda language/runtime, and contract preservation.
- Expanded architecture-option templates with Consumer Contract Impact and Gateway / Proxy Simplification sections.
- Expanded regression/evaluation coverage for the new architecture gates.

## 1.2.0

- Promoted `architecture-assessment.html` to the mandatory first-class architect-facing deliverable.
- Rebuilt the HTML generator as a self-contained offline architecture review portal with hierarchical navigation, active-section tracking, global search, responsive layout, and Print/PDF styling.
- Added an Architect Review Snapshot with readiness, endpoint/traceability/component/limit metrics, and rationalization disposition counts.
- Made current-state context and current-state network diagrams mandatory alongside the target-state diagrams.
- Embedded current and target diagrams with click-to-expand behavior and downloadable PlantUML source.
- Added sortable/filterable inventory tables for detailed review.
- Added migration-option comparison matrix and visible interactive option tabs with recommendation treatment.
- Embedded ADRs, testing/cutover strategy, risks/open questions, the full narrative assessment, evidence register, source inventory, and validator results.
- Added an Embedded Artifact Explorer that contains every canonical analysis artifact and provides in-report download actions.
- Added `references/html-report-standard.md` as the report information-architecture and UX contract.
- Added `validation/html-report-manifest.json` and final HTML structural/completeness validation.
- Updated output contract, bootstrap, templates, lifecycle controller, README, and install guidance for the first-class HTML model.

## 1.1.0

- Made assessment bootstrap, scan, validation, and finalization part of the mandatory skill workflow instead of manual user prerequisites.
- Added `scripts/run_assessment.py` as the deterministic lifecycle controller.
- Added `prepare`, `validate`, `finalize`, and `status` controller phases.
- Added machine-readable workflow state under `.skill-run/state.json`.
- Added machine-readable validation output under `validation/assessment-validation.json`.
- Added mandatory agent remediation loop for validator findings.
- Added automatic target OpenAPI validation when a populated REST target specification exists.
- Added automatic HTML report generation during finalization.
- Added best-effort PlantUML rendering during finalization while preserving `.puml` as canonical source.
- Updated `SKILL.md`, README, and installation instructions so end users are not expected to run bootstrap/validation scripts manually.
- Added orchestration unit tests and retained the modular lower-level scripts for CI/debugging.

## 1.0.0

- Initial complete MuleSoft-to-AWS architecture assessment skill package.
- Added repository scanner, traffic analyzer, OpenAPI validation, PlantUML rendering, HTML report generation, completion validator, package tests, and architecture evaluation scenarios.
