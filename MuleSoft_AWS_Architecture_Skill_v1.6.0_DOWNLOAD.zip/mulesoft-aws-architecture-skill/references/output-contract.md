# Output Contract

The assessment has two complementary systems of record:

1. **Canonical engineering artifacts**: Markdown/CSV/OpenAPI/PlantUML/JSON are machine-readable, diffable, and version-controlled.
2. **Primary architect-facing artifact**: `architecture-assessment.html` is the complete interactive review surface and must embed or link every analysis result needed for architecture review.

An architect should not need to browse the assessment filesystem to understand the current state, target state, migration options, decisions, sizing, limits, risks, evidence, test/cutover strategy, or readiness.

Read `references/html-report-standard.md` for the mandatory HTML structure and interaction requirements.

## Minimum files

See `SKILL.md` required outputs.

The current-state API interaction flow artifacts are mandatory:

- `current-state/api-flow-inventory.csv`
- `current-state/api-flow-steps.csv`
- `current-state/api-flows.md`
- `current-state/connection-inventory.csv`
- `current-state/connection-endpoints.csv`
- one primary `diagrams/flows/seq-<NN>-<slug>.puml` sequence diagram per identified flow

The four architecture diagram sources are mandatory:

- `diagrams/current-context.puml`
- `diagrams/current-network.puml`
- `diagrams/target-context.puml`
- `diagrams/target-network.puml`

After finalization, these are also mandatory:

- `architecture-assessment.html`
- `validation/html-report-manifest.json`

## Minimum row-level completeness

### Current API inventory
One row per current externally or internally callable endpoint/event interface. Method+path+API/app should form a stable key for HTTP APIs. Classify `consumer_relationship`, `api_role`, and business-flow coverage.

### API interaction flows
One row per business/application interaction flow that touches one or more Mule APIs, plus one row per step in `api-flow-steps.csv`. Every flow must have a detailed PlantUML sequence diagram and evidence references. Internal application workflows that do not touch Mule are out of scope for this artifact.


### Current-state connection evidence

`current-state/connection-inventory.csv` contains one row per authoritative connection drawn on the current-state context/network diagrams. Every arrow in those diagrams must be labeled with `[CONN-###]` and resolve to exactly one inventory row.

Allowed `validation_status` values for authoritative diagram connections:

- `CONFIRMED_EXECUTABLE` — reachable source-code/Mule-flow path proves the call.
- `CONFIRMED_RUNTIME` — runtime/log/trace evidence proves the call when source evidence is incomplete.
- `DOCUMENTED_FALLBACK` — current-state documentation is being used because source/runtime could not confirm the connection; `documentation_fallback_reason` is mandatory.

`UNCONFIRMED_CONFIG_ONLY`, `UNKNOWN`, dead placeholders, unused global connector configs, and discovered-but-unreferenced URLs **must not** be represented as authoritative current-state diagram edges. They may be documented as findings/dependencies outside the connection inventory.

`primary_evidence_type` must be `SOURCE_CODE`, `RUNTIME`, or `DOCUMENTATION`. `evidence_refs` and `source_locations` are required for every row.

`endpoint_applicability` is `REQUIRED` when the connection targets a callable API/operation and `N/A_NETWORK_ONLY` only for pure network/infrastructure links that have no application endpoint.

### Current-state called target endpoints/operations

`current-state/connection-endpoints.csv` contains one row per endpoint/operation actually called by an authoritative connection. Do not populate it with every URL/operation found in configuration.

Allowed `call_confirmation` values:

- `CONFIRMED_EXECUTABLE_CALL`
- `CONFIRMED_RUNTIME_CALL`
- `DOCUMENTED_FALLBACK`

Every row must identify `connection_id`, `target_endpoint_or_operation`, business/functional purpose (or `UNKNOWN`), protocol, method/operation, authentication, authorization, request/response content type, timeout, retry policy, call condition, evidence refs, and source locations. Use `UNKNOWN` or `N/A` rather than silently leaving evidence-critical fields blank.

The architect HTML report must place the connection evidence and called-endpoint tables immediately after the current-state context/network diagrams and before API interaction flows.

### Traceability
Every current endpoint must have exactly one disposition row and a non-empty rationale/evidence reference.

### Cloud component inventory
Every component must state purpose, what it replaces/supports, rationale, and relevant security/config/observability settings. Every Lambda must state runtime and implementation language. TypeScript/Node.js is the default; Java requires a non-empty technical exception justification.

### Contract preservation
Every target API row must state whether the current consumer-facing contract is `PRESERVED`, `PRESERVED_VIA_GATEWAY_MAPPING`, `CHANGED`, or `N/A`. `CHANGED` requires explicit justification and consumer-impact documentation.

### Gateway/proxy replacement
For current APIs classified as `GATEWAY_PROXY` or equivalent, the target must explicitly consider direct API Gateway integration, consolidation, or retirement before adding Lambda. A target Lambda used for a gateway/proxy replacement requires a non-empty Lambda necessity justification.

### AWS limits
Every recommended API Gateway/Lambda/Step Functions/SQS/SNS/EventBridge/Fargate component must have applicable limit checks. Not every theoretical quota is required, but every observed workload dimension that could invalidate the design must be covered.

### Traffic-derived measurements are observations, not system limits
When a payload size, latency, throughput, concurrency, or volume figure originates from runtime monitoring or traffic evidence (for example Anypoint `max_req_bytes` / `max_resp_bytes`, Splunk percentiles, API Manager analytics, or sampled production logs), it **MUST** be labeled as an observation in every artifact where it appears.

Required phrasing should make both the measurement nature and evidence window clear when known, for example:

- `Observed 30-day max request payload: 11.7 MB`
- `Up to 11.7 MB observed in production (30-day window)`
- `Observed p99 latency: 8.2 s during 2026-07-01 through 2026-07-30`

Do **not** write `max 11.7 MB`, `payload limit: 11.7 MB`, `maximum supported payload: 11.7 MB`, or similar wording unless a configuration, API specification, product quota, or other authoritative source proves that value is a system-enforced ceiling.

This rule applies everywhere traffic-derived values are reused, including:

- executive summaries
- API/flow inventories
- API interaction-flow step descriptions
- sequence-diagram labels, notes, and titles
- architecture options
- ADRs
- AWS-limit comparison tables
- sizing recommendations
- risks/findings
- target-state rationale

When comparing an observation against an AWS hard limit, keep the two semantics explicit. Example:

`Observed 30-day max request payload: 11.7 MB; this already exceeds the Lambda synchronous request limit evaluated for this design. Actual source-system maximum is unknown and may be higher.`

If the system's configured or contractual maximum is unknown, record it as `UNKNOWN` rather than promoting the largest observed value into a presumed limit.

### HTML completeness
The final HTML report must contain all required canonical artifacts in its Embedded Artifact Explorer and expose the major information through purpose-built sections rather than only dumping files into an appendix.

### Readiness
The report must contain exactly one final readiness state:
- READY
- READY WITH CONDITIONS
- NOT READY

READY is prohibited when validator ERRORs remain.

## Machine-readable field conventions

These conventions are part of the contract. They are intentionally strict because the validators and HTML report consume these fields programmatically.

### `current-state/api-inventory.csv` — `business_flow_ids`

- Use a comma-separated or semicolon-separated list of flow IDs from `current-state/api-flow-inventory.csv`.
- Spaces are **not** separators; they are treated as part of the flow ID.
- Use `N/A` for a justified technical-only endpoint with no business/application interaction flow.
- Correct example: `FLOW-001,FLOW-003`
- Incorrect example: `FLOW-001 FLOW-003`

### `current-state/api-flow-inventory.csv` — `sequence_diagram`

For new assessments use `diagrams/flows/seq-<NN>-<slug>.puml`. Establish the mapping once after flow discovery and before diagram authoring. The same stem must be used by the `.puml`, rendered `.svg`, HTML card anchor, and report manifest. `scripts/assign_flow_diagram_names.py` can fill blank mappings deterministically.

### `target-state/cloud-component-inventory.csv` — `aws_service`

`aws_service` is a machine-readable **service category**, not a free-form component description.

For AWS components use the canonical category name, for example:

- `Lambda`
- `API Gateway`
- `Fargate`
- `ECS`
- `SQS`
- `SNS`
- `EventBridge`
- `Step Functions`

For non-AWS infrastructure integrated with the target, use a neutral category name that does not embed an unrelated AWS service keyword. For example use `Vault Extension`, not `Vault Lambda Extension`, and `Splunk Telemetry Extension`, not a label that makes the extension appear to be the compute service itself. Put implementation detail such as "deployed as a Lambda extension" in `purpose`, `rationale`, or `notes` rather than `aws_service`.

The validator also uses anchored service-category matching defensively, but authors must still keep this field categorical.

### `current-state/policy-inventory.csv` — security-critical policy status

If `security_critical = yes`, the policy must be directly confirmed before the assessment can become READY.

- Preferred final state: `security_critical = yes`, `status = CONFIRMED`.
- If evidence is unavailable, keep `security_critical = yes`, set `status = UNKNOWN` or `UNAVAILABLE`, and create a P1 open question/approval condition requiring confirmation. The completion validator intentionally blocks READY in this state.
- Change `security_critical` to `no` only when evidence establishes that the item is not security critical. Never downgrade the field merely to suppress a validator finding.

## `options/architecture-options.md` recommendation heading

The file **MUST** contain an H2 heading whose text is exactly:

```markdown
## Recommendation
```

Matching is case-insensitive, but the heading text itself must be `Recommendation`. Put the full selected recommendation below it. An optional `### Why` subsection may contain rationale.

The HTML architect report reads this exact section for its highlighted Recommendation panel. Headings such as `## Selected Option`, `## Decision`, or `## Conclusion` do not populate that panel.

## PlantUML source contract

### API interaction sequence diagram naming and flow-card alignment

For new assessments, each row in `current-state/api-flow-inventory.csv` must commit a deterministic sequence path before diagram authoring:

- `diagrams/flows/seq-<NN>-<slug>.puml`
- `NN`: zero-padded two-digit display order (`01`, `02`, ...).
- `slug`: lowercase hyphenated short name derived from the flow name; use the flow ID as a fallback if needed.
- The rendered sibling must be `seq-<NN>-<slug>.svg`.
- The HTML card anchor must be `api-flow-seq-<NN>-<slug>`.

`sequence_diagram` is the single source of truth. Legacy assessments using `<flow-id>.puml` remain readable, but new assessments should use the `seq-<NN>-<slug>` convention.

Sequence sources must include `autonumber`, logical participant `box` groupings, material auth/security steps, explicit branches/retries when they actually exist, and labeled messages. Readability target: roughly <=20 participants and <=40 message arrows. If a flow needs supporting sub-flow diagrams, keep exactly one primary sequence in `diagrams/flows/` and place additional diagrams under `diagrams/flows/supporting/` so primary flow/SVG count remains deterministic.


Read `references/diagram-standards.md` before authoring diagrams.

### `@startuml` identifier must equal the filename stem

Every `.puml` file must use an `@startuml` identifier equal to its filename without `.puml`.

Examples:

```text
# diagrams/current-context.puml
@startuml current-context

# diagrams/flows/seq-03-producer-search.puml
@startuml seq-03-producer-search
```

Do not use descriptive identifiers that diverge from the filename, such as `@startuml current-context-customer-app`. Some PlantUML versions use that identifier as the rendered output filename. The renderer contains a defensive normalization fallback, but compliant sources must still follow the stem convention.

### Sequence diagrams must not contain structural direction directives

Sequence diagrams containing sequence participants/messages (`participant`, `actor`, `->`, `-->`, `activate`, `deactivate`, etc.) must **not** contain:

- `left to right direction`
- `right to left direction`
- `top to bottom direction`
- `bottom to top direction`

These are structural-diagram directives and can cause PlantUML to infer the wrong diagram type and render a syntax-error page. Sequence participants are already arranged left-to-right by default.

### PlantUML include paths must be real absolute paths

PlantUML does not expand shell variables such as `$HOME`, `$USER`, `%USERPROFILE%`, or `~` inside `!define`/`!include` statements. Resolve the local icon-distribution directory first and write a real absolute path into the generated `.puml` file when local includes are used.

Do not copy an example user path literally. On Windows, for example, discover the actual directory and use a normalized absolute path such as `C:/Users/<user>/claude_tools/plantuml/aws-icons-for-plantuml/dist`.

Before relying on AWS icon includes, enumerate the local distribution and verify each `.puml` file exists. PowerShell example:

```powershell
Get-ChildItem -Recurse -Filter "*.puml" <absolute-dist-path>
```

Common AWS Icons for PlantUML mappings (verify against the installed distribution before use):

| AWS service | Include path under `dist/AWSPUML/` | Macro |
|---|---|---|
| Lambda | `Compute/Lambda.puml` | `Lambda(alias, label, techn)` |
| ECS Fargate | `Containers/Fargate.puml` | `Fargate(alias, label, techn)` |
| API Gateway | `NetworkingContentDelivery/APIGateway.puml` | `APIGateway(alias, label, techn)` |
| SQS | `ApplicationIntegration/SimpleQueueService.puml` | `SimpleQueueService(alias, label, techn)` |
| EventBridge | `ApplicationIntegration/EventBridge.puml` | `EventBridge(alias, label, techn)` |
| Step Functions | `ApplicationIntegration/StepFunctions.puml` | `StepFunctions(alias, label, techn)` |
| Application Load Balancer | `NetworkingContentDelivery/ElasticLoadBalancingApplicationLoadBalancer.puml` | `ElasticLoadBalancingApplicationLoadBalancer(alias, label, techn)` |
| WAF | `SecurityIdentityCompliance/WAF.puml` | `WAF(alias, label, techn)` |

If the locally installed AWS icon distribution differs, the local filesystem is authoritative. Never invent include paths or macro names.

