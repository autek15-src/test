# Diagram Standards

## Mandatory PlantUML authoring rules

1. **Identifier = filename stem.** `diagrams/current-context.puml` must begin with `@startuml current-context`; `diagrams/flows/seq-03-producer-search.puml` must begin with `@startuml seq-03-producer-search`. This keeps rendered filenames deterministic across PlantUML versions.
2. **No direction directives in sequence diagrams.** Never put `left to right direction`, `top to bottom direction`, or their reverse forms in sequence diagrams. Structural direction directives can make PlantUML infer a component diagram and produce syntax errors for sequence constructs.
3. **No shell-variable include paths.** PlantUML does not expand `$HOME`, `$USER`, `%USERPROFILE%`, or `~` in `!define`/`!include`. Resolve an absolute local path before writing the file.
4. **Verify AWS icon includes against the installed distribution.** Do not infer service file names from AWS product names. In the commonly used AWS Icons for PlantUML distribution, Fargate is `Containers/Fargate.puml` with macro `Fargate`, while SQS is `ApplicationIntegration/SimpleQueueService.puml` with macro `SimpleQueueService`. See `references/output-contract.md` for the reference table.
5. **Keep editable source canonical.** SVG/PNG is derivative. The `.puml` file must remain understandable and valid without relying on the rendered image.


Preferred source: PlantUML. Use AWS official PlantUML icons when the rendering environment provides them; otherwise keep standard PlantUML components and explicit AWS service labels.

## Target context diagram
Show:
- consumers
- application boundary
- enterprise ingress
- target AWS API/compute components
- relevant existing app components
- upstream/downstream systems
- major protocols
- trust/system boundaries

Do not show subnet-level detail.

## Target network diagram
Show:
- consumer zones/corporate network
- enterprise ingress
- VPC/AZ/subnet boundaries where relevant
- private endpoints/VPC Link
- API Gateway/ALB/NLB
- Lambda/ECS placement
- NAT/Direct Connect/VPN/TGW/PrivateLink when known
- downstream paths
- Vault and observability path
- security boundaries

Do not fabricate addressing/routing.
## Current-state API interaction sequence diagrams

Use `templates/diagrams/flows/FLOW-template.puml` as the authoring baseline. Mandatory conventions:

- `autonumber`;
- no `!pragma layout smetana`;
- no structural direction directives;
- logical colored `box` groupings for external actors, application components, MuleSoft, and backends;
- `activate`/`deactivate` where processing ownership is useful;
- `alt`/`else` for material conditional/success-error behavior;
- `loop` only for retries/redelivery actually supported by evidence;
- material authentication/security interactions shown explicitly;
- message labels include protocol/method/event and key business fields/results when known;
- split at a natural boundary around 20 participants or 40 messages rather than sacrificing readability. Keep one primary diagram directly under `diagrams/flows/`; put supporting sub-flow diagrams under `diagrams/flows/supporting/`.

Render each diagram as soon as it is authored. A rendered SVG is not healthy merely because the file exists: verify it is non-empty and does not contain PlantUML error markers such as `error occurred`, `IllegalStateException`, or obvious syntax-error text.



## Current-state connection evidence labels

Current-state diagrams are evidence-backed views, not configuration inventories.

- Label every current-state connection arrow with `[CONN-###]`.
- The ID must exist in `current-state/connection-inventory.csv`.
- Do not draw an edge solely because a global Mule config, property, WSDL, connector declaration, hostname, or old architecture diagram contains the destination.
- Prefer reachable Mule/source-code call-path evidence; runtime evidence can confirm actual use; documentation is a fallback only when source/runtime cannot establish the relationship.
- Do not draw `UNCONFIRMED_CONFIG_ONLY` or dead/unused placeholder connections as active edges.
- Reuse the same connection ID across context and network diagrams when both views represent the same logical communication path.

Example:

```plantuml
PolicyUI --> MuleProcess : [CONN-003] HTTPS GET /producers
MuleProcess --> ProducerAPI : [CONN-004] HTTPS GET /producer/search
```
