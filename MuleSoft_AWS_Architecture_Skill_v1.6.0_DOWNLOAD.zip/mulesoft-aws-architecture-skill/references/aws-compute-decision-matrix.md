# AWS Compute and Integration Decision Matrix

Do not default to Lambda.

| Dimension | Lambda tends to fit | ECS Fargate tends to fit |
|---|---|---|
| Workload | short-lived, event-driven, bursty | long-running, sustained, server-like |
| State | stateless | stateless or process-local state needs |
| Connections | short/managed | long-lived/persistent pools |
| Startup | cold starts acceptable | continuously warm tasks useful |
| Runtime/deps | modest | large/custom/container-centric |
| Payload | safely within service path limits | large/streaming/custom server paths |
| Protocol | request/event | long-lived connections/WebSocket/custom |
| Cost | intermittent/bursty | sustained utilization can be better |
| Scaling | rapid event scaling | controlled service/task scaling |
| Existing ownership | standalone capability | natural extension of existing container app |

## API ingress

Evaluate API Gateway REST vs HTTP API vs ALB based on:
- private exposure requirements
- timeout
- payload
- auth/policy capability
- VPC integration
- cost
- streaming
- request validation
- enterprise ingress pattern

## Orchestration

Use Step Functions when durable workflow state, branching, retry policy, wait states, or auditable orchestration are real requirements. Do not use it merely to replace a simple sequential function call.

## Messaging

Use SQS for buffering/work queues and backpressure, SNS for fan-out notification, EventBridge for event routing/integration, only when delivery semantics fit.


## Company Lambda implementation default
When Lambda is selected, target Node.js with TypeScript. Java is an exception and requires explicit evidence-backed technical justification. Runtime support must be verified against current AWS Lambda documentation at assessment time.
