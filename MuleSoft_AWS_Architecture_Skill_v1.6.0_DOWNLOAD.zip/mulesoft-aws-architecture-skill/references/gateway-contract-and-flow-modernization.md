# Gateway, Contract Preservation, and API Interaction Flow Guidance

Use this reference when rationalizing Mule gateway/proxy APIs and deciding how much of the existing consumer contract should survive migration.

Verified against official AWS documentation on 2026-08-21.

## 1. Preserve consumer contracts by default

The default migration posture is to preserve existing consumer-facing API contracts when doing so is technically viable and does not perpetuate a material architecture problem.

Why:
- incremental modernization should minimize disruption to dependent consumers;
- API Gateway can sit in front of old/new implementations during strangler migration;
- API Gateway request/response mappings can preserve a legacy contract when a new backend contract differs;
- consumer changes create coordination, regression, release, and rollback risk that should be justified explicitly.

Official references:
- AWS Prescriptive Guidance, REST-based modernization with API Gateway proxy and transformations: https://docs.aws.amazon.com/prescriptive-guidance/latest/modernization-aspnet-web-services/rest.html
- AWS Prescriptive Guidance, Strangler Fig pattern: https://docs.aws.amazon.com/prescriptive-guidance/latest/cloud-design-patterns/strangler-fig.html
- AWS Prescriptive Guidance, Branch by Abstraction: https://docs.aws.amazon.com/prescriptive-guidance/latest/modernization-decomposing-monoliths/branch-by-abstraction.html

### Consumer relationship rule

Classify each current interface as one of:
- `EXTERNAL_APPLICATION_CONSUMER`: another application/team/system depends on the contract;
- `INTERNAL_APPLICATION_COMPONENT`: UI, business-service layer, batch component, or other component inside the same application/product boundary;
- `MIXED`: both external and internal application consumers;
- `UNKNOWN`.

For `EXTERNAL_APPLICATION_CONSUMER`, `MIXED`, or `UNKNOWN`, preserve method, path, protocol, payload/response shapes, status/error semantics, and required headers/auth behavior by default.

For `INTERNAL_APPLICATION_COMPONENT`, contract changes may be recommended when the benefit is material and the assessment compares the change against retaining compatibility. Document consumer-code changes, deployment coupling, regression scope, rollback implications, and why the change is worth it.

Any intentional contract change must identify:
- what changes;
- affected consumers;
- why preservation is inferior;
- compatibility/migration strategy;
- rollout/cutover impact;
- required consumer testing.

## 2. Mule gateway/proxy APIs are not automatically compute services

A Mule API whose primary responsibility is gateway/proxy behavior should first be evaluated for replacement by API Gateway **without Lambda**.

Examples of functions API Gateway can often own directly:
- ingress and routing;
- HTTP proxying;
- private backend integration through VPC Link;
- authentication/authorization integrations;
- throttling and usage controls;
- request validation;
- selected header/path/query mappings;
- request/response mapping where appropriate;
- direct integration with supported AWS service actions.

Official references:
- API Gateway integration types: https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-api-integration-types.html
- HTTP proxy integration: https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-set-up-simple-proxy.html
- Private integrations and VPC Link V2: https://docs.aws.amazon.com/apigateway/latest/developerguide/private-integration.html
- REST API integration settings: https://docs.aws.amazon.com/apigateway/latest/developerguide/how-to-integration-settings.html
- Direct AWS service integration: https://docs.aws.amazon.com/apigateway/latest/developerguide/getting-started-aws-proxy.html
- API Gateway use cases: https://docs.aws.amazon.com/prescriptive-guidance/latest/choosing-the-right-aws-service-for-your-microservice-endpoints/api-gateway.html

## 3. Avoid pass-through Lambda

Do not add Lambda merely because the current Mule gateway/proxy is implemented as executable Mule code.

AWS Well-Architected Serverless guidance explicitly shows direct API Gateway service integration removing Lambda where no additional logic is necessary, reducing cost and unnecessary invocations.

Reference:
- https://docs.aws.amazon.com/wellarchitected/latest/serverless-applications-lens/direct-integrations.html

A Lambda behind API Gateway for a gateway/proxy migration requires evidence-backed justification such as:
- complex transformations that are unsafe/unmaintainable as API Gateway mappings;
- multi-step orchestration;
- domain/business logic;
- conditional calls to multiple backends;
- non-trivial state/idempotency logic;
- protocol adaptation not reasonably handled by API Gateway;
- custom validation/security logic that belongs in compute;
- other documented technical requirements.

If Lambda is used, explain why direct HTTP/AWS integration, API Gateway mapping, consolidation, retirement, or absorption are insufficient.

## 4. Retire or consolidate purposeless pass-through proxies

A proxy/gateway layer should not survive solely because it exists today.

If it contributes no material:
- routing;
- security/policy enforcement;
- contract abstraction;
- protocol adaptation;
- transformation;
- observability/governance boundary;
- independent lifecycle/ownership value;

then evaluate:
- retirement;
- consolidation into another API Gateway surface;
- direct consumer-to-existing-backend routing through the approved ingress architecture;
- absorption into an existing application when that application naturally owns the capability.

Do not remove a pass-through proxy before checking whether it is intentionally acting as a stable contract/anti-corruption boundary for multiple consumers.

## 5. Business/API interaction flows are separate from Mule technical flows

The assessment must model **application/business interaction flows that touch one or more Mule APIs**, not every internal application workflow and not merely every Mule `<flow>` element.

Examples:
- Internal policy administrator searches for producers in the UI.
- Nightly policy synchronization is initiated by a scheduler and passes through a Mule API.
- External billing application submits a payment request through a Mule-managed interface.

For each identified flow:
1. describe the user/business/system trigger;
2. list actors and systems;
3. identify every Mule endpoint/component traversed;
4. explain each step in business terms and technical terms;
5. identify transformations, security/policies, downstream calls, retries/errors, and response/outcome where relevant;
6. attach evidence references;
7. produce a detailed PlantUML sequence diagram.

Do not document internal application flows that never touch MuleSoft.

## 6. Current Mule-specific AWS transformation tooling is an accelerator, not architecture authority

AWS Transform currently documents an early-access `AWS/mulesoft-to-aws-native` managed transformation that converts Mule 3.x/4.x applications toward API Gateway, Lambda, and Step Functions and targets Java 17 Lambda/SnapStart.

Reference:
- https://docs.aws.amazon.com/transform/latest/userguide/transform-aws-customs.html

Treat this as potentially useful implementation/discovery automation, not as proof that:
- every Mule API should become Lambda;
- Java should be the target language under this company's standards;
- Mule API-led layers should remain intact;
- proxy/gateway APIs need compute;
- current service boundaries are optimal.

If such tooling is used, its generated architecture/code must still pass this skill's rationalization, company-constraint, contract-preservation, AWS-limit, security/network, and completion gates.
