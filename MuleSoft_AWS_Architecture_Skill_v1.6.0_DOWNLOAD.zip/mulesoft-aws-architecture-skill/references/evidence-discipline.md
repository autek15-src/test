# Evidence Discipline

Use explicit evidence classifications throughout the assessment.

| Class | Meaning |
|---|---|
| OBSERVED | Directly supported by code, config, logs, metrics, or documentation |
| INFERRED | Strongly supported by multiple observations but not directly proven |
| ASSUMED | Needed to continue analysis but not confirmed |
| UNKNOWN | Required information is unavailable |
| RECOMMENDED | Target-state proposal |

## Minimum evidence record

Each evidence row should include:

- evidence ID
- classification
- subject
- fact/observation
- source artifact
- source location or query reference
- observation period when relevant
- confidence
- notes

## OBSERVED traffic measurements

`OBSERVED` traffic measurements describe what was measured in the evidence window. They do **not** establish a configured, contractual, or technically enforced system limit unless separate evidence proves that limit.

This distinction is mandatory for payload sizes, latency, throughput, request volume, concurrency, error rates, and similar runtime measurements. The largest value seen in a monitoring window is an **observed maximum**, not automatically the maximum value the system can accept or produce.

When citing an observed maximum as justification for an architecture decision, state the evidence window and preserve the uncertainty about the true ceiling. For example:

`Observed 30-day max request payload: 11.7 MB - already exceeds the evaluated Lambda 6 MB synchronous request limit; actual system maximum is unknown and may be higher.`

If a configured/API-specification limit is also known, record the two facts separately, for example:

- `OBSERVED: 30-day max request payload = 11.7 MB.`
- `OBSERVED: API specification/configuration permits payloads up to 25 MB.`

Never rewrite the first statement as `payload limit = 11.7 MB`.

When the observed range already invalidates a candidate architecture, that is sufficient evidence to reject the candidate even though the true maximum may be higher. Carry the unknown upper bound into the risk/assumption record when it can affect sizing, buffering, gateway choice, testing scope, or operational headroom.

## Rules

- Do not convert missing data into guessed facts.
- If code and documentation conflict, record the contradiction.
- Runtime behavior normally outweighs stale documentation, but production policy/configuration may exist outside the repo.
- A zero-traffic sample does not prove retirement unless the sample covers the relevant business cycle and consumer evidence agrees.
- Every material target decision should cite one or more evidence IDs.
