# API Rationalization Decision Framework

Apply before selecting AWS services.

## RETIRE
Use when evidence shows the capability is obsolete or unused.

Required checks:
- production traffic over an adequate period
- consumer references/registrations
- scheduled/seasonal use
- owner/business confirmation when possible
- dependencies/failover/DR paths

## CONSOLIDATE
Use when multiple Mule APIs represent one cohesive capability and separate deployment/network hops add little value.

Consider:
- same consumers
- same domain/business capability
- same downstreams
- same security boundary
- same scaling profile
- same team/change cadence
- same resilience requirements

Do not consolidate unrelated domains solely to reduce resource count.

## ABSORB
Use when an existing non-Mule application naturally owns the capability and can implement it more cleanly than a new AWS service.

Good signals:
- Mule is a thin proxy/transformation layer
- almost all traffic comes from one application
- same team owns both
- app already runs on an appropriate platform such as ECS/Fargate
- no independent scaling/security/lifecycle requirement exists
- removing a network hop improves reliability/cost

Document the minimal change required in the existing app. Do not redesign the app.

## REIMPLEMENT
Use when the capability needs an independent AWS-native service boundary.

Possible patterns:
- API Gateway + Lambda
- API Gateway/ALB + ECS Fargate
- Step Functions orchestration
- SQS/SNS/EventBridge async patterns
- scheduled/event-driven functions/tasks

## ASYNC REDESIGN
Consider when synchronous behavior is not actually required and current duration/retries/backpressure conflict with gateway/compute limits.


## GATEWAY / PROXY SPECIAL CASE
Before mapping a Mule gateway/proxy API to compute, evaluate direct API Gateway HTTP/private proxy integration, request/response mapping, supported security/policy controls, and direct AWS service integration. Avoid pass-through Lambda. If the gateway/proxy provides no durable routing, security, contract abstraction, transformation, protocol adaptation, governance, or ownership purpose, evaluate RETIRE or CONSOLIDATE. See `gateway-contract-and-flow-modernization.md`.

## CONTRACT PRESERVATION
Preserve consumer-facing contracts by default. Contract changes for internal application components can be considered when the architectural benefit outweighs consumer-change cost/risk. Changes affecting external/mixed/unknown consumers require explicit justification and migration impact.
