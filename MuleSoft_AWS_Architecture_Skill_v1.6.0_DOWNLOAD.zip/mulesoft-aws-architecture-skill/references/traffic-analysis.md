# Traffic Analysis

Analyze per endpoint, not only per application.

## Volume
- requests/day/hour
- average TPS
- peak sustained TPS
- burst TPS
- concurrency
- peak periods/seasonality

## Latency
- p50/p90/p95/p99/max
- separate gateway/Mule/downstream time if evidence allows

## Payload
For request and response:
- p50/p95/p99/max
- content type
- binary/base64/compression implications

## Reliability
- 2xx/4xx/5xx
- timeouts
- retries
- downstream failures
- duplicates
- throttling

## Observation quality
Always record:
- start/end date
- environment
- filters/query used
- missing periods
- whether seasonal/scheduled traffic may be absent

Use `scripts/analyze_traffic.py` for normalized CSV exports when practical.

## Measurement-labeling rule
Traffic-derived maxima and percentiles are observations over the stated evidence window, not system-enforced limits. Whenever these values are carried into another artifact, label them explicitly as observed (for example, `Observed 30-day max response payload: 11.7 MB`). If the configured/contractual system maximum is unknown, state that it is unknown and may exceed the observed value. Never use traffic `max` fields as an implied `payload limit` or `maximum supported` value without separate authoritative evidence.
