# Current-State API Interaction Flows

This artifact documents only application/business flows that traverse one or more MuleSoft APIs. It does not document unrelated internal application workflows.

## Flow Coverage Summary

Document:

- total number of interaction flows identified;
- count/coverage by category: authenticated user journeys, unauthenticated/open or self-registration paths, async/event-driven flows, callback/webhook flows;
- evidence used to discover each flow category (for example UI/business-service source, Mule listener/scheduler configuration, MQ consumer/producer configuration, runtime traffic, API specs, documentation);
- known coverage gaps, including flows suggested by traffic or code that could not be reconstructed completely;
- why the identified flow count is credible for this application. Do not invent flows to meet a numeric target.

## Cross-Flow Observations

Document cross-cutting patterns that matter to migration, including as applicable:

- shared authentication/authorization patterns (Okta/OIDC/JWT, HMAC, mTLS, client-ID enforcement, etc.);
- common downstream systems and shared integration bottlenecks;
- repeated DataWeave mappings or transformations that may become shared TypeScript utilities or common libraries;
- recurring retry, timeout, redelivery, DLQ, correlation-ID, error-mapping, and idempotency patterns;
- flows that traverse multiple Mule APIs in sequence or reuse the same Mule API from different business journeys;
- recurring payload/latency/throughput observations, explicitly labeled as observations and not system-enforced limits.

## Unknown or Unconfirmed Flows

For every suspected but unconfirmed flow, document:

- what evidence suggests the flow exists;
- which steps/endpoints/consumers remain unknown;
- what evidence or owner confirmation would resolve the gap;
- whether confidence is **INFERRED** (strong supporting evidence) or **SUSPECTED** (weak/partial evidence);
- whether the gap should be escalated to the application owner before target architecture is finalized and at what severity/readiness impact.
