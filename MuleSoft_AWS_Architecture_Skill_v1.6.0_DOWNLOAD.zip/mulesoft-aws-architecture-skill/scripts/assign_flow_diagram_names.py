#!/usr/bin/env python3
"""Commit deterministic primary sequence-diagram names for API interaction flows.

The flow inventory remains canonical. This helper only fills sequence_diagram paths that
are blank by default. Use --force only when intentionally re-baselining all flow diagram
names before diagrams have been authored.
"""
from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path


def slugify(value: str) -> str:
    s=re.sub(r'[^a-z0-9]+','-',(value or '').lower()).strip('-')
    return s or 'flow'


def assign(path: Path, force: bool=False) -> list[tuple[str,str]]:
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f)
        headers=reader.fieldnames or []
        rows=list(reader)
    if 'sequence_diagram' not in headers:
        raise ValueError('api-flow-inventory.csv is missing sequence_diagram column')
    used=set()
    mapping=[]
    for idx,row in enumerate(rows,1):
        fid=(row.get('flow_id') or '').strip()
        name=(row.get('flow_name') or '').strip()
        current=(row.get('sequence_diagram') or '').strip()
        if current and not force:
            stem=Path(current).stem
            used.add(stem.lower())
            mapping.append((fid,current))
            continue
        base=slugify(name or fid)
        stem=f'seq-{idx:02d}-{base}'
        if stem.lower() in used:
            fallback=slugify(fid) or str(idx)
            stem=f'seq-{idx:02d}-{base}-{fallback}'
        used.add(stem.lower())
        value=f'diagrams/flows/{stem}.puml'
        row['sequence_diagram']=value
        mapping.append((fid,value))
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=headers)
        w.writeheader(); w.writerows(rows)
    tmp.replace(path)
    return mapping


def main()->int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('assessment',type=Path)
    ap.add_argument('--force',action='store_true',help='Reassign even non-empty sequence_diagram paths; use only before authored diagrams depend on them')
    args=ap.parse_args()
    path=args.assessment.resolve()/'current-state/api-flow-inventory.csv'
    try:
        mapping=assign(path,args.force)
    except Exception as exc:
        print(f'ERROR: {exc}')
        return 2
    for fid,seq in mapping:
        print(f'{fid or "<missing-flow-id>"}: {seq}')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
