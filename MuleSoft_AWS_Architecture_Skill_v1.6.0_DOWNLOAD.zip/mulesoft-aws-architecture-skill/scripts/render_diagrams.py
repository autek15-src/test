#!/usr/bin/env python3
"""Render PlantUML files using a locally available PlantUML executable/JAR.

The renderer also applies two defensive compatibility fixes:
- sequence diagrams are sanitized to remove structural direction directives that
  can make PlantUML misclassify the diagram type;
- if a custom @startuml identifier causes PlantUML to emit a filename that does
  not match the .puml stem, the generated file is normalized back to <stem>.<fmt>.
"""
from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

DIRECTION_RE = re.compile(r"(?im)^\s*(?:left\s+to\s+right|right\s+to\s+left|top\s+to\s+bottom|bottom\s+to\s+top)\s+direction\s*$")
STRONG_SEQUENCE_DECL_RE = re.compile(r"(?im)^\s*(?:participant|boundary|control|entity|collections)\b")
ACTOR_DECL_RE = re.compile(r"(?im)^\s*actor\b")
STRUCTURAL_DECL_RE = re.compile(r"(?im)^\s*(?:component|rectangle|cloud|node|package|frame|artifact|folder|card|usecase)\b")
SEQUENCE_ACTION_RE = re.compile(r"(?m)^\s*[^'\n]+?\s*(?:-+>|--+>|<-+|<--+)\s*[^\n:]+(?:\s*:|\s*$)")
SEQUENCE_CONTROL_RE = re.compile(r"(?im)^\s*(?:activate|deactivate|autonumber|group|alt|else|opt|loop|par|break|critical)\b")


def is_sequence_diagram(text: str) -> bool:
    """Return True when the source has strong sequence-diagram signals."""
    return bool(
        SEQUENCE_CONTROL_RE.search(text)
        or (STRONG_SEQUENCE_DECL_RE.search(text) and SEQUENCE_ACTION_RE.search(text))
        or (ACTOR_DECL_RE.search(text) and SEQUENCE_ACTION_RE.search(text) and not STRUCTURAL_DECL_RE.search(text))
    )


def sanitize_sequence_directions(path: Path) -> bool:
    """Remove structural direction directives from sequence diagrams in-place."""
    text = path.read_text(encoding='utf-8', errors='replace')
    if not is_sequence_diagram(text) or not DIRECTION_RE.search(text):
        return False
    cleaned = DIRECTION_RE.sub('', text)
    # Collapse only the blank line introduced by stripping the directive; keep author formatting otherwise.
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    path.write_text(cleaned, encoding='utf-8')
    print(f"WARN: removed structural direction directive from sequence diagram: {path}", file=sys.stderr)
    return True


def output_snapshot(directory: Path, fmt: str) -> dict[Path, tuple[int, int]]:
    result: dict[Path, tuple[int, int]] = {}
    for out in directory.glob(f'*.{fmt}'):
        try:
            st = out.stat()
            result[out] = (st.st_mtime_ns, st.st_size)
        except OSError:
            pass
    return result


def normalize_rendered_output(source: Path, fmt: str, before: dict[Path, tuple[int, int]], render_started_ns: int) -> Path | None:
    """Normalize PlantUML output to <source-stem>.<fmt> when @startuml ID changes the emitted name.

    PlantUML versions differ in how they name outputs when @startuml carries an ID.
    Rendering is sequential, so we detect files created/changed by this render rather
    than hard-coding any particular ID pattern.
    """
    expected = source.with_suffix(f'.{fmt}')
    after = output_snapshot(source.parent, fmt)

    expected_state = after.get(expected)
    before_expected = before.get(expected)
    if expected_state is not None and expected_state != before_expected:
        return expected

    changed: list[Path] = []
    for out, state in after.items():
        old = before.get(out)
        # A new file or a changed file is attributable to the just-completed sequential render.
        if old is None or state != old or state[0] >= render_started_ns:
            if out != expected:
                changed.append(out)

    if not changed:
        # If PlantUML reported success but timestamp precision prevented change detection,
        # prefer a unique output that begins with the source stem.
        changed = [x for x in after if x != expected and x.stem.startswith(source.stem)]

    if not changed:
        return expected if expected.exists() else None

    preferred = [x for x in changed if x.stem.startswith(source.stem)]
    candidates = preferred or changed
    if len(candidates) != 1:
        print(
            f"WARN: could not safely normalize PlantUML output for {source}; candidates: "
            + ', '.join(str(x.name) for x in candidates),
            file=sys.stderr,
        )
        return expected if expected.exists() else None

    actual = candidates[0]
    if expected.exists() and expected != actual:
        expected.unlink()
    actual.replace(expected)
    print(f"WARN: normalized PlantUML output filename {actual.name} -> {expected.name}", file=sys.stderr)
    return expected



def validate_rendered_output(path: Path, fmt: str) -> bool:
    """Reject empty/error-page renders so broken diagrams are not treated as successful output."""
    if not path.exists() or path.stat().st_size == 0:
        return False
    if fmt == 'svg':
        text=path.read_text(encoding='utf-8', errors='replace')
        if re.search(r'(?i)(error occurred|IllegalStateException|syntax error\??|assumed diagram type)', text):
            return False
    return True

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument('path', type=Path)
    p.add_argument('--format', choices=['svg', 'png'], default='svg')
    p.add_argument('--plantuml-jar', type=Path)
    args = p.parse_args()

    files = [args.path] if args.path.is_file() else sorted(args.path.rglob('*.puml'))
    if not files:
        print('ERROR: no .puml files found')
        return 2
    if args.plantuml_jar:
        cmd = ['java', '-jar', str(args.plantuml_jar)]
    elif shutil.which('plantuml'):
        cmd = ['plantuml']
    else:
        print('ERROR: PlantUML not found. Install a local plantuml command or pass --plantuml-jar /path/to/plantuml.jar.')
        return 2

    rc = 0
    for f in files:
        sanitize_sequence_directions(f)
        before = output_snapshot(f.parent, args.format)
        started = time.time_ns()
        r = subprocess.run(cmd + [f'-t{args.format}', str(f)], text=True)
        rc = max(rc, r.returncode)
        if r.returncode == 0:
            out = normalize_rendered_output(f, args.format, before, started)
            if out is None or not out.exists():
                print(f'WARN: PlantUML returned success but no {args.format.upper()} output was located for {f}', file=sys.stderr)
                rc = max(rc, 1)
            elif not validate_rendered_output(out, args.format):
                print(f'ERROR: rendered {args.format.upper()} appears empty or contains PlantUML error output: {out}', file=sys.stderr)
                rc = max(rc, 1)
    return rc


if __name__ == '__main__':
    raise SystemExit(main())
