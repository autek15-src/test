#!/usr/bin/env python3
"""Build the primary, self-contained architect review report.

The HTML is a first-class human review artifact. It embeds the canonical Markdown,
CSV/YAML/PlantUML/ADR outputs, rendered diagrams when available, interactive
navigation, search, option comparison, table filtering, and raw-artifact downloads.

No third-party Python or JavaScript dependencies are required.
"""
from __future__ import annotations

import argparse
import base64
import csv
import html
import json
import mimetypes
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

REPORT_SCHEMA = "2.1"


def esc(value: object) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def slug(value: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    return s or "section"


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def extract_md_section(text: str, title_fragment: str) -> str:
    """Return Markdown body for the first H2 whose title contains title_fragment."""
    lines = text.splitlines()
    start = None
    needle = title_fragment.lower()
    for i, line in enumerate(lines):
        m = re.match(r"^##\s+(.*)$", line)
        if m and needle in m.group(1).lower():
            start = i + 1
            break
    if start is None:
        return ""
    end = len(lines)
    for i in range(start, len(lines)):
        if re.match(r"^##\s+", lines[i]):
            end = i
            break
    return "\n".join(lines[start:end]).strip()


def split_pipe_row(line: str) -> list[str]:
    line = line.strip().strip("|")
    return [x.strip() for x in re.split(r"(?<!\\)\|", line)]


def inline_md(text: str) -> str:
    """Small safe Markdown inline renderer for generated assessment prose."""
    text = esc(text)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", text)
    # Only allow http(s) and relative links emitted by the agent.
    def link(m: re.Match[str]) -> str:
        label, url = m.group(1), html.unescape(m.group(2))
        if re.match(r"^(https?://|\.?\.?/|[A-Za-z0-9_.-]+/)", url):
            return f'<a href="{esc(url)}" target="_blank" rel="noopener">{label}</a>'
        return label
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", link, text)
    return text


def md_to_html(text: str, heading_prefix: str = "") -> str:
    """Render the Markdown subset used by the skill templates.

    Supports headings, paragraphs, lists, ordered lists, blockquotes, fenced code,
    GFM-style pipe tables, horizontal rules, and basic inline formatting.
    """
    lines = text.splitlines()
    out: list[str] = []
    i = 0
    in_code = False
    code_lang = ""
    code_lines: list[str] = []
    list_type: str | None = None

    def close_list() -> None:
        nonlocal list_type
        if list_type:
            out.append(f"</{list_type}>")
            list_type = None

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if stripped.startswith("```"):
            close_list()
            if not in_code:
                in_code = True
                code_lang = stripped[3:].strip()
                code_lines = []
            else:
                cls = f' class="language-{esc(code_lang)}"' if code_lang else ""
                out.append(f"<pre><code{cls}>{esc(chr(10).join(code_lines))}</code></pre>")
                in_code = False
                code_lang = ""
                code_lines = []
            i += 1
            continue
        if in_code:
            code_lines.append(line)
            i += 1
            continue

        # GFM pipe table detection.
        if "|" in line and i + 1 < len(lines):
            separator = lines[i + 1].strip()
            if re.match(r"^\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?$", separator):
                close_list()
                headers = split_pipe_row(line)
                rows: list[list[str]] = []
                i += 2
                while i < len(lines) and "|" in lines[i] and lines[i].strip():
                    rows.append(split_pipe_row(lines[i]))
                    i += 1
                out.append('<div class="table-wrap md-table"><table><thead><tr>')
                out.extend(f"<th>{inline_md(x)}</th>" for x in headers)
                out.append("</tr></thead><tbody>")
                for row in rows:
                    row += [""] * (len(headers) - len(row))
                    out.append("<tr>")
                    out.extend(f"<td>{inline_md(x)}</td>" for x in row[: len(headers)])
                    out.append("</tr>")
                out.append("</tbody></table></div>")
                continue

        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            close_list()
            level = len(m.group(1))
            title = m.group(2).strip()
            hid = f"{heading_prefix}-{slug(title)}" if heading_prefix else slug(title)
            out.append(f'<h{level} id="{esc(hid)}">{inline_md(title)}</h{level}>')
            i += 1
            continue

        if re.match(r"^\s*[-*_]{3,}\s*$", line):
            close_list()
            out.append("<hr>")
            i += 1
            continue

        um = re.match(r"^\s*[-*+]\s+(.*)$", line)
        om = re.match(r"^\s*\d+[.)]\s+(.*)$", line)
        if um or om:
            wanted = "ul" if um else "ol"
            if list_type != wanted:
                close_list()
                list_type = wanted
                out.append(f"<{wanted}>")
            content = (um or om).group(1)
            # Checkbox support.
            cb = re.match(r"^\[([ xX])\]\s+(.*)$", content)
            if cb:
                checked = " checked" if cb.group(1).lower() == "x" else ""
                content_html = f'<input type="checkbox" disabled{checked}> {inline_md(cb.group(2))}'
            else:
                content_html = inline_md(content)
            out.append(f"<li>{content_html}</li>")
            i += 1
            continue
        close_list()

        if stripped.startswith(">"):
            quote: list[str] = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quote.append(lines[i].strip()[1:].lstrip())
                i += 1
            out.append(f"<blockquote>{inline_md(' '.join(quote))}</blockquote>")
            continue

        if stripped:
            para = [stripped]
            i += 1
            while i < len(lines):
                nxt = lines[i].strip()
                if not nxt or re.match(r"^(#{1,6})\s+", lines[i]) or nxt.startswith("```"):
                    break
                if re.match(r"^[-*+]\s+", nxt) or re.match(r"^\d+[.)]\s+", nxt):
                    break
                if "|" in lines[i] and i + 1 < len(lines) and re.match(r"^\|?\s*:?-{3,}", lines[i + 1].strip()):
                    break
                para.append(nxt)
                i += 1
            out.append(f"<p>{inline_md(' '.join(para))}</p>")
        else:
            i += 1

    close_list()
    if in_code:
        out.append(f"<pre><code>{esc(chr(10).join(code_lines))}</code></pre>")
    return "\n".join(out)


def manifest_path(value: object) -> str:
    """Return a stable forward-slash path/string for report-manifest fields on every OS."""
    if isinstance(value, Path):
        return value.as_posix()
    return re.sub(r'/+', '/', str(value).replace('\\', '/'))


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def csv_table(path: Path, table_id: str, title: str | None = None) -> str:
    with path.open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))
    if not rows:
        return '<div class="empty-state">No rows available.</div>'
    headers = rows[0]
    body = rows[1:]
    title_attr = esc(title or path.name)
    out = [
        f'<div class="data-table" data-table-title="{title_attr}">',
        '<div class="table-tools">',
        f'<input class="table-filter" aria-label="Filter {title_attr}" placeholder="Filter rows…" data-table-target="{esc(table_id)}">',
        f'<span class="row-count"><strong>{len(body)}</strong> row(s)</span>',
        '</div>',
        f'<div class="table-wrap"><table id="{esc(table_id)}"><thead><tr>',
    ]
    for h in headers:
        out.append(f'<th scope="col"><button class="sort-btn" type="button" title="Sort column">{esc(h)} <span aria-hidden="true">↕</span></button></th>')
    out.append("</tr></thead><tbody>")
    for row in body:
        row += [""] * (len(headers) - len(row))
        out.append("<tr>")
        for cell in row[: len(headers)]:
            cls = ""
            val = cell.strip()
            if val in {"READY", "PASS", "REIMPLEMENT", "REPLACED BY"}:
                cls = ' class="cell-good"'
            elif val in {"FAIL", "NOT READY", "P0", "P1"}:
                cls = ' class="cell-bad"'
            elif val in {"READY WITH CONDITIONS", "WARN", "UNKNOWN", "P2"}:
                cls = ' class="cell-warn"'
            out.append(f"<td{cls}>{esc(cell)}</td>")
        out.append("</tr>")
    out.append("</tbody></table></div></div>")
    return "".join(out)


def data_download(path: Path, label: str | None = None) -> str:
    raw = path.read_bytes()
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    b64 = base64.b64encode(raw).decode("ascii")
    return (
        f'<a class="artifact-download" download="{esc(path.name)}" '
        f'href="data:{esc(mime)};base64,{b64}">Download {esc(label or path.name)}</a>'
    )


def extract_readiness(root: Path) -> str:
    p = root / "architecture-assessment.md"
    if not p.exists():
        return "UNKNOWN"
    m = re.search(r"(?im)^\s*Readiness\s*:\s*(READY WITH CONDITIONS|NOT READY|READY)\s*$", read_text(p))
    return m.group(1).upper() if m else "UNKNOWN"


def summary_metrics(root: Path) -> dict[str, object]:
    current = read_csv(root / "current-state/api-inventory.csv")
    trace = read_csv(root / "target-state/traceability-matrix.csv")
    flows = read_csv(root / "current-state/api-flow-inventory.csv")
    connections = read_csv(root / "current-state/connection-inventory.csv")
    comps = read_csv(root / "target-state/cloud-component-inventory.csv")
    limits = read_csv(root / "target-state/aws-limit-validation.csv")
    risks_text = read_text(root / "assumptions-risks-open-questions.md") if (root / "assumptions-risks-open-questions.md").exists() else ""
    disposition: dict[str, int] = {}
    for row in trace:
        d = (row.get("disposition") or "UNKNOWN").strip().upper()
        disposition[d] = disposition.get(d, 0) + 1
    limit_fail = sum(1 for r in limits if (r.get("result") or "").strip().upper() == "FAIL")
    p01 = len(re.findall(r"(?im)\bP[01]\b", risks_text))
    return {
        "current_endpoints": len(current),
        "api_flows": len(flows),
        "current_connections": len(connections),
        "traceability_rows": len(trace),
        "target_components": len(comps),
        "limit_checks": len(limits),
        "limit_failures": limit_fail,
        "p0_p1_mentions": p01,
        "dispositions": disposition,
    }


def metric_card(label: str, value: object, note: str = "") -> str:
    return f'<div class="metric"><div class="metric-value">{esc(value)}</div><div class="metric-label">{esc(label)}</div>{f"<div class=\"metric-note\">{esc(note)}</div>" if note else ""}</div>'


def render_diagram(root: Path, stem: str, title: str, description: str, *, sequence: bool = False) -> str:
    svg = root / "diagrams" / f"{stem}.svg"
    png = root / "diagrams" / f"{stem}.png"
    puml = root / "diagrams" / f"{stem}.puml"
    content = ""
    status = ""
    wrap_class = "diagram-wrap seq-diagram" if sequence else "diagram-wrap"
    if svg.exists():
        svg_text = read_text(svg)
        bad_svg = bool(re.search(r"(?i)(error occurred|IllegalStateException|syntax error\??|assumed diagram type)", svg_text))
        if not bad_svg and svg.stat().st_size > 0:
            # Strip XML/doctype to safely inline the SVG document body.
            svg_text = re.sub(r"^\s*<\?xml[^>]*>\s*", "", svg_text)
            svg_text = re.sub(r"^\s*<!DOCTYPE[^>]*>\s*", "", svg_text, flags=re.I)
            content = f'<div class="{wrap_class}"><div class="diagram-canvas">{svg_text}</div></div>'
            status = "Rendered SVG embedded"
        else:
            fallback = "Sequence diagram not available" if sequence else "Rendered diagram unavailable"
            content = f'<div class="{wrap_class}"><div class="diagram-placeholder"><strong>{fallback}</strong><br>The rendered SVG appears to contain PlantUML error output. The editable source is available below.</div></div>'
            status = "Render error detected"
    elif png.exists():
        b64 = base64.b64encode(png.read_bytes()).decode("ascii")
        content = f'<div class="{wrap_class}"><div class="diagram-canvas"><img src="data:image/png;base64,{b64}" alt="{esc(title)}"></div></div>'
        status = "Rendered PNG embedded"
    else:
        fallback = "Sequence diagram not available" if sequence else "Rendered diagram unavailable"
        content = f'<div class="{wrap_class}"><div class="diagram-placeholder"><strong>{fallback}</strong><br>The editable PlantUML source is embedded below.</div></div>'
        status = "PlantUML source only"
    source_html = ""
    if puml.exists():
        source = read_text(puml)
        source_html = (
            '<details class="source-details"><summary>View editable PlantUML source</summary>'
            f'<pre><code>{esc(source)}</code></pre>{data_download(puml)}</details>'
        )
    did = 'diagram-' + slug(stem)
    return f'''<article class="diagram-card{' sequence-card' if sequence else ''}" id="{esc(did)}">
      <div class="diagram-heading"><div><h3>{esc(title)}</h3><p>{esc(description)}</p></div><span class="badge neutral">{esc(status)}</span></div>
      {content}
      <div class="diagram-actions"><button type="button" class="btn diagram-expand" data-diagram="{esc(did)}">Expand</button></div>
      {source_html}
    </article>'''


def rows_table(rows: list[dict[str, str]], table_id: str, title: str, preferred_columns: list[str] | None = None) -> str:
    if not rows:
        return '<div class="empty-state">No rows available.</div>'
    headers = preferred_columns or list(rows[0].keys())
    headers = [h for h in headers if any((row.get(h) or '').strip() for row in rows)] or list(rows[0].keys())
    out = [
        f'<div class="data-table" data-table-title="{esc(title)}">',
        '<div class="table-tools">',
        f'<input class="table-filter" aria-label="Filter {esc(title)}" placeholder="Filter rows…" data-table-target="{esc(table_id)}">',
        f'<span class="row-count"><strong>{len(rows)}</strong> row(s)</span>',
        '</div>',
        f'<div class="table-wrap"><table id="{esc(table_id)}"><thead><tr>',
    ]
    for h in headers:
        out.append(f'<th scope="col"><button class="sort-btn" type="button" title="Sort column">{esc(h)} <span aria-hidden="true">↕</span></button></th>')
    out.append('</tr></thead><tbody>')
    for row in rows:
        out.append('<tr>')
        for h in headers:
            out.append(f'<td>{esc(row.get(h, ""))}</td>')
        out.append('</tr>')
    out.append('</tbody></table></div></div>')
    return ''.join(out)


def _flow_sequence_stem(row: dict[str, str]) -> str:
    fid=(row.get('flow_id') or '').strip()
    seq=(row.get('sequence_diagram') or f'diagrams/flows/{fid}.puml').strip()
    return Path(seq).stem or fid


def _split_endpoint_refs(value: str) -> list[str]:
    return [x.strip() for x in re.split(r'[;,]', value or '') if x.strip() and x.strip().upper() != 'N/A']


def _flow_path_lists(flow_steps: list[dict[str, str]]) -> tuple[str, str]:
    req=[]
    resp=[]
    for step in flow_steps:
        n=(step.get('step_number') or '').strip()
        actor=(step.get('actor_or_system') or '').strip()
        business=(step.get('business_action') or '').strip()
        technical=(step.get('technical_action') or '').strip()
        event=(step.get('request_or_event') or '').strip()
        detail=' — '.join(x for x in (business, technical) if x)
        if event:
            detail += (f' · {event}' if detail else event)
        req.append(f'<li><strong>{esc(n or "?")}. {esc(actor or "Unknown participant")}</strong>: {esc(detail or "Interaction documented in detailed steps")}</li>')

    for step in reversed(flow_steps):
        n=(step.get('step_number') or '').strip()
        outcome=(step.get('outcome_or_next_step') or '').strip()
        alternate=(step.get('error_or_alternate_path') or '').strip()
        if outcome:
            resp.append(f'<li><strong>Step {esc(n or "?")} outcome:</strong> {esc(outcome)}</li>')
        if alternate:
            resp.append(f'<li class="alternate-path"><strong>Step {esc(n or "?")} alternate/error:</strong> {esc(alternate)}</li>')
    req_html='<ol class="flow-path">'+''.join(req)+'</ol>' if req else '<div class="empty-state">Request / processing path not reconstructed.</div>'
    resp_html='<ol class="flow-path response-path">'+''.join(resp)+'</ol>' if resp else '<div class="empty-state">Response/outcome detail is not separately confirmed; see the sequence diagram and detailed step table.</div>'
    return req_html, resp_html


def render_api_flows(root: Path) -> tuple[str, list[str]]:
    inventory = read_csv(root / 'current-state/api-flow-inventory.csv')
    steps = read_csv(root / 'current-state/api-flow-steps.csv')
    traceability = read_csv(root / 'target-state/traceability-matrix.csv')
    narrative = root / 'current-state/api-flows.md'
    if not inventory:
        body = render_markdown_artifact(narrative, 'api-flows-narrative') if narrative.exists() else ''
        return (body + '<div class="empty-state">No API interaction flows have been populated.</div>', [])
    by_flow: dict[str, list[dict[str, str]]] = {}
    for row in steps:
        by_flow.setdefault((row.get('flow_id') or '').strip(), []).append(row)
    trace_by_endpoint={(row.get('current_endpoint_id') or '').strip(): row for row in traceability if (row.get('current_endpoint_id') or '').strip()}
    descriptors=[]
    for row in inventory:
        fid=(row.get('flow_id') or '').strip()
        if not fid:
            continue
        seq_stem=_flow_sequence_stem(row)
        descriptors.append((row,fid,seq_stem,'api-flow-'+slug(seq_stem)))
    chips = ''.join(
        f'<a class="flow-chip" href="#{esc(anchor)}">{esc(fid)} · {esc(row.get("flow_name") or fid)}</a>'
        for row,fid,seq_stem,anchor in descriptors
    )
    parts = [
        '<div class="flow-index"><div><strong>Flow index</strong><p>Jump directly to a business/API interaction flow.</p></div><div class="flow-chips">',
        chips,
        '</div></div>',
    ]
    if narrative.exists():
        parts.append(f'<details class="flow-notes"><summary>Cross-flow notes and coverage gaps</summary><div class="flow-notes-body">{render_markdown_artifact(narrative,"api-flows-narrative")}</div></details>')
    step_cols = ['step_number','actor_or_system','business_action','technical_action','mule_component_or_endpoint','request_or_event','data_or_transformation','outcome_or_next_step','error_or_alternate_path','evidence_refs']
    for row,fid,seq_stem,anchor in descriptors:
        seq=(row.get('sequence_diagram') or f'diagrams/flows/{fid}.puml').strip()
        rel=Path(seq)
        try:
            stem=rel.relative_to('diagrams').with_suffix('').as_posix() if rel.parts and rel.parts[0]=='diagrams' else rel.with_suffix('').as_posix()
        except ValueError:
            stem=f'flows/{seq_stem}'
        flow_steps=sorted(by_flow.get(fid,[]), key=lambda x: (int(x.get('step_number')) if str(x.get('step_number','')).isdigit() else 9999, x.get('step_number','')))
        request_path,response_path=_flow_path_lists(flow_steps)
        diagram=render_diagram(root, stem, f'{fid} · {row.get("flow_name") or "API interaction flow"}', 'Detailed current-state sequence from business/application trigger through Mule APIs to downstream outcome.', sequence=True)
        endpoint_refs=_split_endpoint_refs(row.get('mule_endpoints') or '')
        mapped=[trace_by_endpoint[x] for x in endpoint_refs if x in trace_by_endpoint]
        if mapped:
            target_bits=[]
            for tr in mapped:
                disp=(tr.get('disposition') or 'Target disposition TBD').strip()
                target=(tr.get('target_component_or_endpoint') or '').strip()
                target_bits.append(f'{tr.get("current_endpoint_id")}: {disp}' + (f' → {target}' if target else ''))
            target_note='; '.join(target_bits)
        else:
            target_note='Flow-level target mapping is not directly derivable from the endpoint references in this flow. Review the source-to-target traceability matrix and ADRs before approval.'
        meta = [
            ('Caller / upstream', row.get('consumer_or_upstream_component','')),
            ('Mule endpoints', row.get('mule_endpoints','')),
            ('Downstream systems', row.get('downstream_systems','')),
            ('Final outcome', row.get('final_outcome','')),
            ('Evidence', row.get('evidence_refs','')),
            ('Confidence', row.get('confidence','')),
        ]
        meta_html=''.join(f'<div class="flow-meta-item"><dt>{esc(k)}</dt><dd>{esc(v) if v else "<span class=\"muted\">Not confirmed</span>"}</dd></div>' for k,v in meta)
        initiated='; '.join(x for x in ((row.get('primary_actor') or '').strip(), (row.get('trigger') or '').strip()) if x) or 'Not confirmed'
        parts.append(f'''<article class="flow-card search-surface" id="{esc(anchor)}" data-flow-id="{esc(fid)}" data-sequence-stem="{esc(seq_stem)}" data-search-title="{esc(fid)} {esc(row.get('flow_name') or '')}">
          <div class="flow-card-heading"><div><span class="eyebrow">API Interaction Flow</span><h3>{esc(fid)} · {esc(row.get('flow_name') or fid)}</h3></div><a class="flow-back" href="#api-flows">Back to flow index ↑</a></div>
          <p class="flow-business-context">{esc(row.get('business_purpose') or 'Business purpose not confirmed.')}</p>
          <div class="initiated-by"><strong>Initiated by:</strong> {esc(initiated)}</div>
          <dl class="flow-meta">{meta_html}</dl>
          <h4>Sequence diagram</h4>
          {diagram}
          <div class="two-col flow-path-grid"><div class="panel"><h4>Request / Processing Path</h4>{request_path}</div><div class="panel"><h4>Response / Outcome Path</h4>{response_path}</div></div>
          <div class="flow-target-note"><strong>AWS target note:</strong> {esc(target_note)}</div>
          <details class="flow-notes detailed-flow-steps"><summary>Detailed step-by-step business, technical, error, and evidence data</summary><div class="flow-notes-body">{rows_table(flow_steps, 'flow-steps-'+slug(fid), f'{fid} steps', step_cols)}</div></details>
        </article>''')
    return ''.join(parts), [seq_stem for _,_,seq_stem,_ in descriptors]


@dataclass
class Option:
    name: str
    sections: dict[str, str]


def parse_options(text: str) -> tuple[str, list[Option], str, str]:
    """Parse standardized architecture-options.md into interactive report data."""
    context = ""
    rec = ""
    rec_why = ""
    options: list[Option] = []
    current_option: Option | None = None
    current_sub: str | None = None
    mode = ""
    buffers: dict[str, list[str]] = {}

    def capture(key: str, value: str) -> None:
        buffers.setdefault(key, []).append(value)

    for line in text.splitlines():
        h2 = re.match(r"^##\s+(.*)$", line)
        h3 = re.match(r"^###\s+(.*)$", line)
        if h2:
            name = h2.group(1).strip()
            if re.match(r"(?i)^Option\b", name):
                current_option = Option(name=name, sections={})
                options.append(current_option)
                current_sub = "Description"
                mode = "option"
            elif name.lower() == "decision context":
                mode = "context"; current_option = None; current_sub = None
            elif name.lower() == "recommendation":
                mode = "recommendation"; current_option = None; current_sub = None
            else:
                mode = "other"; current_option = None; current_sub = None
            continue
        if h3:
            current_sub = h3.group(1).strip()
            if mode == "recommendation" and current_sub.lower() == "why":
                mode = "recommendation-why"
            continue
        if mode == "context": capture("context", line)
        elif mode == "option" and current_option:
            current_option.sections.setdefault(current_sub or "Description", "")
            current_option.sections[current_sub or "Description"] += line + "\n"
        elif mode == "recommendation": capture("recommendation", line)
        elif mode == "recommendation-why": capture("recommendation-why", line)

    context = "\n".join(buffers.get("context", [])).strip()
    rec = "\n".join(buffers.get("recommendation", [])).strip()
    rec_why = "\n".join(buffers.get("recommendation-why", [])).strip()
    return context, options, rec, rec_why


def compact_text(md: str, max_len: int = 700) -> str:
    txt = re.sub(r"[`*_#>-]", " ", md)
    txt = re.sub(r"\s+", " ", txt).strip()
    return txt if len(txt) <= max_len else txt[: max_len - 1] + "…"


def render_options(path: Path) -> str:
    if not path.exists():
        return '<div class="empty-state">Architecture options artifact is missing.</div>'
    context, options, recommendation, why = parse_options(read_text(path))
    if not options:
        return md_to_html(read_text(path), "options")

    known_fields = ["Description", "Pros", "Cons", "Workload Fit", "Security / Network Fit", "Consumer Contract Impact", "Gateway / Proxy Simplification", "Cost / Operational Considerations", "Risks"]
    buttons = []
    panels = []
    compare_rows = []
    rec_plain = compact_text(recommendation).lower()
    for idx, opt in enumerate(options):
        oid = f"option-{idx+1}-{slug(opt.name)}"
        recommended = bool(rec_plain and (opt.name.lower() in rec_plain or opt.name.replace("Option ", "").lower() in rec_plain))
        buttons.append(f'<button class="option-tab{" active" if idx == 0 else ""}" role="tab" aria-selected="{"true" if idx == 0 else "false"}" data-option="{oid}">{esc(opt.name)}{" ★" if recommended else ""}</button>')
        chunks = []
        for field in known_fields:
            val = opt.sections.get(field, "").strip()
            if val:
                chunks.append(f'<section class="option-field"><h4>{esc(field)}</h4>{md_to_html(val, oid + "-" + slug(field))}</section>')
        # Preserve nonstandard subsections too.
        for field, val in opt.sections.items():
            if field not in known_fields and val.strip():
                chunks.append(f'<section class="option-field"><h4>{esc(field)}</h4>{md_to_html(val, oid + "-" + slug(field))}</section>')
        panels.append(f'<div class="option-panel{" active" if idx == 0 else ""}" id="{oid}" role="tabpanel">{"<div class=\"recommended-ribbon\">Recommended</div>" if recommended else ""}<h3>{esc(opt.name)}</h3>{"".join(chunks)}</div>')
        compare_rows.append(
            "<tr>"
            f"<th>{esc(opt.name)}{' <span class=\"badge good\">Recommended</span>' if recommended else ''}</th>"
            f"<td>{esc(compact_text(opt.sections.get('Description',''), 280))}</td>"
            f"<td>{esc(compact_text(opt.sections.get('Pros',''), 380))}</td>"
            f"<td>{esc(compact_text(opt.sections.get('Cons',''), 380))}</td>"
            f"<td>{esc(compact_text(opt.sections.get('Risks',''), 320))}</td>"
            "</tr>"
        )
    return f'''
    <div class="decision-context"><h3>Decision context</h3>{md_to_html(context, "options-context") if context else '<p>See detailed option analysis below.</p>'}</div>
    <div class="option-compare"><h3>At-a-glance comparison</h3><div class="table-wrap"><table><thead><tr><th>Option</th><th>Description</th><th>Pros</th><th>Cons</th><th>Risks</th></tr></thead><tbody>{''.join(compare_rows)}</tbody></table></div></div>
    <div class="option-tabs" role="tablist" aria-label="Migration architecture options">{''.join(buttons)}</div>
    <div class="option-panels">{''.join(panels)}</div>
    <div class="recommendation-box"><h3>Recommendation</h3>{md_to_html(recommendation, "options-recommendation")}{'<h4>Why</h4>'+md_to_html(why, 'options-why') if why else ''}</div>
    '''


def render_adrs(root: Path) -> str:
    decision_dir = root / "decisions"
    if not decision_dir.exists():
        return '<div class="empty-state">No ADR directory.</div>'
    parts: list[str] = []
    for idx, p in enumerate(sorted(decision_dir.glob("*.md"))):
        if "template" in p.name.lower():
            continue
        body = read_text(p)
        title_match = re.search(r"(?m)^#\s+(.+)$", body)
        title = title_match.group(1).strip() if title_match else p.stem
        parts.append(f'<details class="adr" {"open" if idx == 0 else ""}><summary><span>{esc(title)}</span><span class="artifact-path">{esc(p.name)}</span></summary><div class="adr-body">{md_to_html(body, "adr-"+slug(p.stem))}{data_download(p)}</div></details>')
    return "".join(parts) if parts else '<div class="empty-state">No accepted/proposed ADRs were generated.</div>'


def render_markdown_artifact(path: Path, artifact_id: str) -> str:
    if not path.exists():
        return '<div class="empty-state">Artifact unavailable.</div>'
    return md_to_html(read_text(path), artifact_id)


def artifact_appendix(root: Path, include_paths: Iterable[Path]) -> tuple[str, list[str]]:
    parts: list[str] = []
    included: list[str] = []
    for p in sorted(set(include_paths), key=lambda x: str(x.relative_to(root))):
        if not p.exists() or not p.is_file():
            continue
        rel = manifest_path(p.relative_to(root))
        included.append(rel)
        suffix = p.suffix.lower()
        if suffix == ".csv":
            preview = csv_table(p, "appendix-" + slug(rel), rel)
        elif suffix in {".md"}:
            preview = md_to_html(read_text(p), "appendix-" + slug(rel))
        elif suffix in {".yaml", ".yml", ".json", ".puml", ".txt"}:
            preview = f'<pre><code>{esc(read_text(p))}</code></pre>'
        else:
            preview = '<p>Binary/generated artifact available for download.</p>'
        parts.append(
            f'<!-- REPORT_ARTIFACT: {esc(rel)} -->'
            f'<details class="artifact-item" id="artifact-{slug(rel)}"><summary><span>{esc(rel)}</span><span class="badge neutral">{esc(suffix.lstrip(".").upper() or "FILE")}</span></summary><div class="artifact-preview">{preview}<div class="artifact-actions">{data_download(p)}</div></div></details>'
        )
    return "".join(parts), included


def nav_item(section_id: str, label: str, sub: bool = False) -> str:
    return f'<a class="nav-link{" sub" if sub else ""}" href="#{esc(section_id)}" data-nav-target="{esc(section_id)}">{esc(label)}</a>'


def section(section_id: str, eyebrow: str, title: str, intro: str, body: str) -> str:
    return f'''<section class="report-section search-surface" id="{esc(section_id)}" data-search-title="{esc(title)}">
      <div class="section-heading"><div class="eyebrow">{esc(eyebrow)}</div><h2>{esc(title)}</h2>{f'<p class="section-intro">{esc(intro)}</p>' if intro else ''}</div>
      {body}
    </section>'''


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("assessment", type=Path)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--title", default="MuleSoft to AWS Native Architecture Assessment")
    args = ap.parse_args()

    root = args.assessment.resolve()
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    readiness = extract_readiness(root)
    metrics = summary_metrics(root)
    readiness_cls = "good" if readiness == "READY" else "warn" if readiness == "READY WITH CONDITIONS" else "bad"

    # Primary evidence and human-authored artifacts used across sections.
    ex_summary = root / "executive-summary.md"
    assessment_md = root / "architecture-assessment.md"
    risks = root / "assumptions-risks-open-questions.md"
    options = root / "options/architecture-options.md"
    testing = root / "testing/migration-test-strategy.md"
    cutover = root / "migration/migration-cutover-plan.md"
    assessment_text = read_text(assessment_md) if assessment_md.exists() else ""
    recommendation_md = extract_md_section(assessment_text, "Recommendation")
    current_overview_md = extract_md_section(assessment_text, "Current-State Application Overview")
    target_overview_md = extract_md_section(assessment_text, "Recommended Target Architecture")

    # Review snapshot.
    disposition = metrics["dispositions"]
    metric_html = "".join([
        metric_card("Current endpoints", metrics["current_endpoints"]),
        metric_card("API interaction flows", metrics["api_flows"]),
        metric_card("Evidence-backed connections", metrics["current_connections"]),
        metric_card("Traceability rows", metrics["traceability_rows"]),
        metric_card("Target cloud components", metrics["target_components"]),
        metric_card("AWS limit checks", metrics["limit_checks"]),
        metric_card("Limit failures", metrics["limit_failures"]),
        metric_card("P0/P1 references", metrics["p0_p1_mentions"]),
    ])
    disp_chips = "".join(f'<span class="badge neutral">{esc(k)}: {v}</span>' for k, v in sorted(disposition.items())) or '<span class="badge neutral">Not populated</span>'
    overview_body = f'''
      <div class="status-strip"><div><span class="label">Permit-to-Build readiness</span><span class="readiness {readiness_cls}">{esc(readiness)}</span></div><div class="disposition-strip">{disp_chips}</div></div>
      <div class="metrics-grid">{metric_html}</div>
      <div class="two-col">
        <article class="panel"><h3>Executive summary</h3>{render_markdown_artifact(ex_summary, 'executive-summary')}</article>
        <article class="panel"><h3>Recommended direction</h3>{md_to_html(recommendation_md, 'snapshot-recommendation') if recommendation_md else '<p>See the migration options and target-state sections for the recommendation.</p>'}</article>
      </div>
      <article class="panel"><h3>How to review this assessment</h3><ol><li>Start with the recommendation and migration options.</li><li>Confirm the current-state behavior, traffic, security, and dependencies.</li><li>Review target architecture, sizing, AWS limit headroom, and network/security controls.</li><li>Review ADRs, testing/cutover, open risks, and readiness conditions.</li><li>Use the Artifact Explorer only when you need the exact underlying row or source text.</li></ol></article>
    '''

    api_flows_html, flow_ids = render_api_flows(root)

    current_body = f'''
      {f'<article class="panel"><h3>Current-state overview</h3>{md_to_html(current_overview_md, "current-overview")}</article>' if current_overview_md else ''}
      <div class="diagram-grid">
        {render_diagram(root, 'current-context', 'Current-state application/context architecture', 'Mule application boundaries, consumers, dependencies, protocols, and surrounding systems. Every edge is keyed to the connection evidence tables below.')}
        {render_diagram(root, 'current-network', 'Current-state network architecture', 'Current ingress, runtime/network placement, connectivity, trust boundaries, and downstream paths. Every edge is keyed to the connection evidence tables below.')}
      </div>
      <h3 id="current-connections">Current-State Connection Evidence</h3>
      <p class="muted">Each [CONN-###] diagram edge is backed by reachable source/runtime evidence where possible. Documentation is used only as an explicit fallback when code/runtime cannot confirm the relationship. Config-only or unreferenced placeholders are excluded from authoritative diagram edges.</p>
      <h4 id="connection-evidence-table">Connection evidence</h4>{csv_table(root/'current-state/connection-inventory.csv','connection-table','Current-state connection evidence') if (root/'current-state/connection-inventory.csv').exists() else '<div class="empty-state">Connection evidence inventory unavailable.</div>'}
      <h4 id="connection-endpoints-table">Actually called target endpoints / operations</h4>{csv_table(root/'current-state/connection-endpoints.csv','connection-endpoint-table','Actually called target endpoints and operations') if (root/'current-state/connection-endpoints.csv').exists() else '<div class="empty-state">Called endpoint inventory unavailable.</div>'}
      <h3 id="api-flows">API Interaction Flows</h3><p class="muted">Business/application flows that traverse one or more MuleSoft APIs. Each flow includes functional intent, step-by-step behavior, evidence, and a detailed sequence diagram.</p>{api_flows_html}
      <h3 id="current-api-inventory">Current API inventory</h3>{csv_table(root/'current-state/api-inventory.csv','current-api-table','Current API inventory') if (root/'current-state/api-inventory.csv').exists() else '<div class="empty-state">Missing API inventory.</div>'}
      <h3 id="current-traffic">Observed traffic and runtime profile</h3>{csv_table(root/'current-state/traffic-profile.csv','traffic-table','Traffic profile') if (root/'current-state/traffic-profile.csv').exists() else '<div class="empty-state">Traffic profile unavailable.</div>'}
      <div class="two-col">
        <article class="panel"><h3 id="current-policies">Policies and security controls</h3>{csv_table(root/'current-state/policy-inventory.csv','policy-table','Policy inventory') if (root/'current-state/policy-inventory.csv').exists() else '<div class="empty-state">Policy inventory unavailable.</div>'}</article>
        <article class="panel"><h3 id="current-dependencies">Integrations and dependencies</h3>{csv_table(root/'current-state/dependency-inventory.csv','dependency-table','Dependency inventory') if (root/'current-state/dependency-inventory.csv').exists() else '<div class="empty-state">Dependency inventory unavailable.</div>'}</article>
      </div>
    '''

    rationalization_body = f'''
      <h3 id="traceability">Current-to-target disposition and traceability</h3>
      {csv_table(root/'target-state/traceability-matrix.csv','trace-table','Traceability matrix') if (root/'target-state/traceability-matrix.csv').exists() else '<div class="empty-state">Traceability matrix unavailable.</div>'}
      <h3 id="migration-options">Target migration options</h3>
      {render_options(options)}
    '''

    target_body = f'''
      {f'<article class="panel"><h3>Target-state overview and rationale</h3>{md_to_html(target_overview_md, "target-overview")}</article>' if target_overview_md else ''}
      <div class="diagram-grid">
        {render_diagram(root, 'target-context', 'Recommended target application/context architecture', 'Recommended AWS-native replacement of Mule-owned capabilities and its relationships to unchanged surrounding systems.')}
        {render_diagram(root, 'target-network', 'Recommended target network architecture', 'Ingress, VPC/network placement, private connectivity, security boundaries, observability, and downstream paths.')}
      </div>
      <h3 id="target-api">Target API inventory and contract mapping</h3>{csv_table(root/'target-state/target-api-inventory.csv','target-api-table','Target API inventory') if (root/'target-state/target-api-inventory.csv').exists() else '<div class="empty-state">Target API inventory unavailable.</div>'}
      <h3 id="cloud-inventory">Target AWS cloud component inventory</h3>{csv_table(root/'target-state/cloud-component-inventory.csv','cloud-table','Cloud component inventory') if (root/'target-state/cloud-component-inventory.csv').exists() else '<div class="empty-state">Cloud inventory unavailable.</div>'}
      <h3 id="compute-sizing">Compute sizing and runtime settings</h3>{csv_table(root/'target-state/compute-sizing.csv','sizing-table','Compute sizing') if (root/'target-state/compute-sizing.csv').exists() else '<div class="empty-state">Sizing unavailable.</div>'}
      <div class="two-col">
        <article class="panel"><h3 id="configuration">Configuration and secrets mapping</h3>{csv_table(root/'target-state/configuration-mapping.csv','config-table','Configuration mapping') if (root/'target-state/configuration-mapping.csv').exists() else '<div class="empty-state">Configuration mapping unavailable.</div>'}</article>
        <article class="panel"><h3 id="security-map">Security and policy parity</h3>{csv_table(root/'target-state/security-policy-mapping.csv','security-table','Security mapping') if (root/'target-state/security-policy-mapping.csv').exists() else '<div class="empty-state">Security mapping unavailable.</div>'}</article>
      </div>
      <h3 id="aws-limits">AWS service limits and workload headroom</h3>{csv_table(root/'target-state/aws-limit-validation.csv','limits-table','AWS limit validation') if (root/'target-state/aws-limit-validation.csv').exists() else '<div class="empty-state">AWS limit validation unavailable.</div>'}
    '''

    assurance_body = f'''
      <h3 id="adrs">Architecture Decision Records</h3><p class="muted">Each ADR captures a significant decision, its context, alternatives, consequences, and evidence.</p>{render_adrs(root)}
      <div class="two-col">
        <article class="panel"><h3 id="testing">Migration testing and functional-equivalence strategy</h3>{render_markdown_artifact(testing,'testing-strategy')}</article>
        <article class="panel"><h3 id="cutover">Migration, cutover, and rollback</h3>{render_markdown_artifact(cutover,'cutover-plan')}</article>
      </div>
      <h3 id="risks">Assumptions, risks, gaps, and open questions</h3>{render_markdown_artifact(risks,'risks-open-questions')}
    '''

    # Embed the full narrative assessment as a cross-cutting detailed narrative; this avoids losing nuanced prose not mapped above.
    narrative_body = f'''
      <article class="panel narrative-panel">
        <div class="panel-actions">{data_download(assessment_md) if assessment_md.exists() else ''}</div>
        {render_markdown_artifact(assessment_md,'full-assessment')}
      </article>
    '''

    # Validation result, if available.
    validation_path = root / "validation/assessment-validation.json"
    validation_body = ""
    if validation_path.exists():
        try:
            v = json.loads(read_text(validation_path))
            items = v.get("findings", v.get("items", [])) if isinstance(v, dict) else []
            summary = f'<div class="metrics-grid compact">{metric_card("Validation errors", v.get("errors", "?"))}{metric_card("Validation warnings", v.get("warnings", "?"))}</div>'
            if isinstance(items, list) and items:
                rows = [[x.get("severity",""), x.get("code",""), x.get("message",""), x.get("path","")] for x in items if isinstance(x, dict)]
                tbl = ['<div class="table-wrap"><table><thead><tr><th>Severity</th><th>Code</th><th>Finding</th><th>Artifact</th></tr></thead><tbody>']
                for row in rows:
                    tbl.append('<tr>' + ''.join(f'<td>{esc(x)}</td>' for x in row) + '</tr>')
                tbl.append('</tbody></table></div>')
                validation_body = summary + ''.join(tbl)
            else:
                validation_body = summary + '<p>No validator findings remain.</p>'
        except Exception:
            validation_body = f'<pre><code>{esc(read_text(validation_path))}</code></pre>'
    else:
        validation_body = '<div class="empty-state">Validation output has not been generated yet.</div>'

    evidence_body = f'''
      <h3 id="evidence-register">Evidence register</h3>{csv_table(root/'evidence/evidence-register.csv','evidence-table','Evidence register') if (root/'evidence/evidence-register.csv').exists() else '<div class="empty-state">Evidence register unavailable.</div>'}
      <h3 id="source-inventory">Reviewed source inventory</h3>{csv_table(root/'evidence/source-inventory.csv','source-table','Source inventory') if (root/'evidence/source-inventory.csv').exists() else '<div class="empty-state">Source inventory unavailable.</div>'}
      <h3 id="validation-results">Completion validation</h3>{validation_body}
    '''

    # Include all canonical analysis artifacts, ADRs and generated diagram sources/images in the explorer.
    allowed_suffixes = {".md", ".csv", ".yaml", ".yml", ".json", ".puml", ".svg", ".png"}
    include_paths = [p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in allowed_suffixes and ".skill-run" not in p.parts]
    # Avoid recursively embedding the HTML report itself if rebuilding.
    include_paths = [p for p in include_paths if p.resolve() != output]
    appendix_html, included_artifacts = artifact_appendix(root, include_paths)
    appendix_body = f'''
      <div class="artifact-explorer-intro"><p>Everything used to build this review package is available here without leaving the report. Expand an item to view it, or download the original artifact.</p><span class="badge neutral">{len(included_artifacts)} embedded artifact(s)</span></div>
      <div class="artifact-list">{appendix_html}</div>
    '''

    sections = [
        section("overview", "01 · Orientation", "Architect Review Snapshot", "The recommendation, readiness posture, migration disposition, and review path in one place.", overview_body),
        section("current-state", "02 · Understand Today", "Current State", "What the MuleSoft application does today, who calls it, what it depends on, and how it behaves in production.", current_body),
        section("rationalization", "03 · Decide What Survives", "API Rationalization & Migration Options", "Retire, consolidate, absorb, or reimplement each Mule capability before selecting AWS services.", rationalization_body),
        section("target-state", "04 · Review the Design", "Recommended Target State", "AWS-native architecture, contracts, components, sizing, configuration, security parity, and verified service-limit fit.", target_body),
        section("assurance", "05 · Challenge the Design", "Decisions, Testing, Cutover & Risks", "Why key decisions were made, how equivalence will be proven, how cutover will occur, and what remains unresolved.", assurance_body),
        section("detailed-assessment", "06 · Deep Dive", "Full Architecture Assessment Narrative", "Complete cross-cutting analysis for architects who want the detailed reasoning in one continuous narrative.", narrative_body),
        section("evidence", "07 · Verify", "Evidence & Completion Validation", "Trace conclusions back to source evidence and confirm that required architecture gates have been satisfied.", evidence_body),
        section("artifacts", "08 · Reference", "Embedded Artifact Explorer", "View or download the underlying inventories, specifications, ADRs, diagram sources, and validation outputs without browsing the filesystem.", appendix_body),
    ]

    nav = "".join([
        nav_item("overview", "Architect Review Snapshot"),
        nav_item("current-state", "Current State"),
        nav_item("current-connections", "Connection Evidence", True),
        nav_item("api-flows", "API Interaction Flows", True),
        nav_item("current-api-inventory", "API Inventory", True),
        nav_item("current-traffic", "Traffic & Runtime", True),
        nav_item("current-policies", "Policies & Security", True),
        nav_item("current-dependencies", "Dependencies", True),
        nav_item("rationalization", "Rationalization & Options"),
        nav_item("traceability", "Traceability", True),
        nav_item("migration-options", "Migration Options", True),
        nav_item("target-state", "Target State"),
        nav_item("target-api", "Target APIs", True),
        nav_item("cloud-inventory", "Cloud Inventory", True),
        nav_item("compute-sizing", "Sizing", True),
        nav_item("aws-limits", "AWS Limits", True),
        nav_item("assurance", "Decisions & Assurance"),
        nav_item("adrs", "ADRs", True),
        nav_item("testing", "Testing", True),
        nav_item("cutover", "Cutover", True),
        nav_item("risks", "Risks / Open Questions", True),
        nav_item("detailed-assessment", "Full Narrative"),
        nav_item("evidence", "Evidence & Validation"),
        nav_item("artifacts", "Artifact Explorer"),
    ])

    # Hidden machine-readable manifest is used by the completion validator.
    report_manifest = {
        "schema": REPORT_SCHEMA,
        "schema_version": REPORT_SCHEMA,
        "title": args.title,
        "readiness": readiness,
        "sections": ["overview", "current-state", "rationalization", "target-state", "assurance", "detailed-assessment", "evidence", "artifacts"],
        "embedded_artifacts": [manifest_path(x) for x in included_artifacts],
        "diagrams": [manifest_path(x) for x in ["current-context", "current-network", "target-context", "target-network"]],
        "flow_diagrams": [manifest_path(x) for x in flow_ids],
        "features": ["hierarchical-navigation", "anchor-tracking", "global-search", "table-filtering", "table-sorting", "option-tabs", "artifact-explorer", "diagram-modal", "print-view"],
    }

    css = r'''
:root{--bg:#f5f7fa;--surface:#fff;--surface2:#f9fafb;--text:#172033;--muted:#64748b;--line:#dbe2ea;--accent:#2563eb;--accent2:#1d4ed8;--good:#087f5b;--goodbg:#e8f7f1;--warn:#9a6700;--warnbg:#fff6d8;--bad:#b42318;--badbg:#fff0ee;--shadow:0 2px 10px rgba(15,23,42,.06);--radius:10px;--sidebar:282px}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:82px}body{margin:0;background:var(--bg);color:var(--text);font:14px/1.55 Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif}.app{min-height:100vh}.topbar{position:fixed;z-index:50;top:0;left:0;right:0;height:66px;background:rgba(255,255,255,.97);border-bottom:1px solid var(--line);display:flex;align-items:center;padding:0 20px;gap:18px;backdrop-filter:blur(10px)}.brand{display:flex;align-items:center;gap:10px;min-width:var(--sidebar)}.brand-mark{width:32px;height:32px;border-radius:8px;background:#172033;color:white;display:grid;place-items:center;font-weight:800}.brand-title{font-weight:700;font-size:14px}.brand-sub{color:var(--muted);font-size:11px}.global-search{position:relative;flex:1;max-width:680px}.global-search input{width:100%;border:1px solid var(--line);border-radius:8px;padding:10px 12px 10px 36px;background:#f8fafc;outline:none}.global-search input:focus{border-color:#93b4f5;box-shadow:0 0 0 3px #dbeafe}.search-icon{position:absolute;left:12px;top:10px;color:var(--muted)}.search-results{display:none;position:absolute;top:44px;left:0;right:0;max-height:360px;overflow:auto;background:white;border:1px solid var(--line);box-shadow:var(--shadow);border-radius:9px;padding:6px}.search-results.open{display:block}.search-result{display:block;padding:9px 10px;border-radius:6px;text-decoration:none;color:var(--text)}.search-result:hover{background:#f1f5f9}.top-actions{margin-left:auto;display:flex;align-items:center;gap:8px}.btn{border:1px solid var(--line);background:white;color:var(--text);border-radius:7px;padding:7px 10px;cursor:pointer;font:inherit}.btn:hover{border-color:#aab8ca;background:#f8fafc}.sidebar{position:fixed;top:66px;bottom:0;left:0;width:var(--sidebar);background:#fff;border-right:1px solid var(--line);overflow:auto;padding:18px 12px 30px;z-index:30}.nav-label{font-size:10px;text-transform:uppercase;letter-spacing:.09em;color:#94a3b8;font-weight:700;padding:4px 10px 10px}.nav-link{display:block;text-decoration:none;color:#334155;padding:7px 10px;border-radius:6px;margin:1px 0;font-size:13px}.nav-link.sub{padding-left:24px;color:#64748b;font-size:12px}.nav-link:hover{background:#f1f5f9;color:#0f172a}.nav-link.active{background:#eaf1ff;color:#174ea6;font-weight:650}.main{margin-left:var(--sidebar);padding:92px 34px 60px;max-width:1760px}.report-hero{margin-bottom:24px}.report-hero h1{font-size:28px;letter-spacing:-.02em;margin:0 0 6px}.report-hero p{margin:0;color:var(--muted)}.report-section{background:var(--surface);border:1px solid var(--line);border-radius:12px;box-shadow:var(--shadow);padding:28px;margin:0 0 24px}.section-heading{border-bottom:1px solid var(--line);padding-bottom:16px;margin-bottom:22px}.eyebrow{text-transform:uppercase;letter-spacing:.08em;font-weight:750;font-size:10px;color:#5272a4}.section-heading h2{font-size:23px;margin:3px 0 4px;letter-spacing:-.015em}.section-intro{margin:0;color:var(--muted);max-width:980px}.status-strip{display:flex;justify-content:space-between;gap:16px;align-items:center;background:#f8fafc;border:1px solid var(--line);padding:13px 15px;border-radius:9px;margin-bottom:16px}.status-strip .label{font-size:12px;color:var(--muted);margin-right:10px}.readiness,.badge{display:inline-flex;align-items:center;border-radius:999px;font-size:11px;font-weight:750;padding:4px 8px}.readiness.good,.badge.good{color:var(--good);background:var(--goodbg)}.readiness.warn,.badge.warn{color:var(--warn);background:var(--warnbg)}.readiness.bad,.badge.bad{color:var(--bad);background:var(--badbg)}.badge.neutral{background:#eef2f7;color:#475569}.disposition-strip{display:flex;flex-wrap:wrap;gap:5px}.metrics-grid{display:grid;grid-template-columns:repeat(6,minmax(120px,1fr));gap:10px;margin:16px 0 22px}.metrics-grid.compact{grid-template-columns:repeat(2,minmax(140px,240px))}.metric{background:#fbfcfe;border:1px solid var(--line);border-radius:9px;padding:13px}.metric-value{font-size:22px;font-weight:760;letter-spacing:-.02em}.metric-label{font-size:11px;color:var(--muted);margin-top:2px}.metric-note{font-size:10px;color:#94a3b8}.two-col{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:16px;margin:18px 0}.panel{border:1px solid var(--line);background:#fff;border-radius:9px;padding:18px;min-width:0}.panel h3:first-child{margin-top:0}.panel-actions{float:right}h1,h2,h3,h4{line-height:1.25;color:#172033}h3{font-size:17px;margin:26px 0 10px}h4{font-size:14px;margin:18px 0 7px}p{max-width:1050px}a{color:#1d4ed8}code{background:#f1f5f9;border-radius:4px;padding:1px 4px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.93em}pre{background:#0f172a;color:#e2e8f0;padding:14px;border-radius:8px;overflow:auto;white-space:pre;font:12px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace}pre code{background:transparent;color:inherit;padding:0}.muted{color:var(--muted)}blockquote{border-left:3px solid #93b4f5;margin:12px 0;padding:5px 14px;color:#475569;background:#f8fbff}.table-tools{display:flex;align-items:center;gap:10px;margin:7px 0}.table-filter{min-width:260px;border:1px solid var(--line);border-radius:7px;padding:7px 9px}.row-count{font-size:11px;color:var(--muted)}.table-wrap{overflow:auto;max-height:620px;border:1px solid var(--line);border-radius:7px;background:white}.md-table{max-height:none;margin:12px 0}.table-wrap table{border-collapse:separate;border-spacing:0;width:max-content;min-width:100%;font-size:11px}.table-wrap th,.table-wrap td{padding:7px 9px;border-right:1px solid #e6ebf0;border-bottom:1px solid #e6ebf0;vertical-align:top;max-width:420px;white-space:normal}.table-wrap th{position:sticky;top:0;background:#f3f6f9;z-index:2;text-align:left;color:#334155;font-size:10px}.sort-btn{border:0;background:transparent;font:inherit;font-weight:750;color:inherit;padding:0;cursor:pointer;text-align:left}.cell-good{background:#f1fbf7}.cell-warn{background:#fffaf0}.cell-bad{background:#fff4f2}.diagram-grid{display:grid;grid-template-columns:1fr;gap:18px}.diagram-card{border:1px solid var(--line);border-radius:10px;padding:16px;background:#fff}.diagram-heading{display:flex;justify-content:space-between;gap:18px;align-items:start}.diagram-heading h3{margin:0 0 4px}.diagram-heading p{margin:0;color:var(--muted);font-size:12px}.diagram-canvas{margin:14px 0;border:1px solid #e8edf3;border-radius:8px;background:#fff;overflow:auto;padding:12px;min-height:180px}.diagram-canvas svg{display:block;max-width:100%;height:auto;margin:auto}.seq-diagram svg{max-width:100%;height:auto;display:block;margin:0 auto}.seq-diagram{overflow:auto}.flow-business-context{font-size:14px;max-width:1100px}.initiated-by{margin:8px 0 14px;padding:9px 12px;border-left:3px solid #93b4f5;background:#f8fbff;border-radius:5px}.flow-path{margin:8px 0 4px;padding-left:22px}.flow-path li{margin:7px 0}.alternate-path{color:#9a3412}.flow-target-note{margin:14px 0;padding:12px 14px;border-left:4px solid #2563eb;background:#f8fbff;border-radius:7px}.detailed-flow-steps{margin-top:14px}.diagram-canvas img{max-width:100%;height:auto;display:block;margin:auto}.diagram-placeholder{margin:14px 0;padding:28px;text-align:center;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:8px;color:#64748b}.diagram-actions{display:flex;justify-content:flex-end}.source-details{margin-top:10px}.source-details summary,.artifact-item summary,.adr summary{cursor:pointer;color:#334155;font-weight:650}.flow-index{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;padding:14px 16px;margin:12px 0 16px;border:1px solid var(--line);border-radius:9px;background:#f8fafc}.flow-index p{margin:3px 0 0;color:var(--muted);font-size:11px}.flow-chips{display:flex;flex-wrap:wrap;gap:6px;justify-content:flex-end}.flow-chip{display:inline-block;text-decoration:none;border:1px solid #cbd5e1;background:white;padding:6px 9px;border-radius:999px;font-size:11px;color:#334155}.flow-chip:hover{border-color:#93b4f5;background:#eff6ff}.flow-card{border:1px solid var(--line);border-radius:10px;padding:18px;margin:18px 0;background:#fff}.flow-card-heading{display:flex;justify-content:space-between;gap:15px;align-items:flex-start}.flow-card-heading h3{margin:3px 0 0}.flow-back{font-size:11px;text-decoration:none;color:#64748b}.flow-meta{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:15px 0}.flow-meta-item{background:#f8fafc;border:1px solid #edf1f5;border-radius:7px;padding:9px}.flow-meta dt{font-size:9px;text-transform:uppercase;letter-spacing:.05em;color:#64748b;font-weight:700}.flow-meta dd{margin:3px 0 0;font-size:12px}.flow-notes{margin:10px 0 16px;border:1px solid var(--line);border-radius:8px;background:white}.flow-notes summary{padding:10px 12px;cursor:pointer;font-weight:650}.flow-notes-body{padding:0 14px 14px;border-top:1px solid var(--line)}.option-compare{margin:16px 0}.option-tabs{display:flex;gap:6px;flex-wrap:wrap;border-bottom:1px solid var(--line);padding:0 0 8px;margin-top:18px}.option-tab{border:1px solid var(--line);background:white;border-radius:7px;padding:8px 12px;cursor:pointer;font:inherit}.option-tab.active{background:#172033;color:white;border-color:#172033}.option-panel{display:none;position:relative;padding:18px;border:1px solid var(--line);border-top:0;border-radius:0 0 9px 9px}.option-panel.active{display:block}.option-panel h3{margin-top:0}.option-field{margin-bottom:16px}.option-field h4{color:#475569;text-transform:uppercase;letter-spacing:.04em;font-size:10px}.recommended-ribbon{float:right;background:var(--goodbg);color:var(--good);font-weight:750;padding:5px 9px;border-radius:999px;font-size:11px}.recommendation-box,.decision-context{margin-top:16px;padding:16px;border-left:4px solid #2563eb;background:#f8fbff;border-radius:7px}.recommendation-box h3,.decision-context h3{margin-top:0}.adr{border:1px solid var(--line);border-radius:8px;margin:8px 0;background:#fff}.adr summary{display:flex;justify-content:space-between;padding:11px 13px}.adr-body{padding:0 14px 14px;border-top:1px solid var(--line)}.artifact-path{font-weight:400;color:#94a3b8;font-size:11px}.artifact-explorer-intro{display:flex;justify-content:space-between;gap:20px;align-items:center;margin-bottom:12px}.artifact-item{border:1px solid var(--line);border-radius:8px;margin:7px 0;background:#fff}.artifact-item>summary{display:flex;justify-content:space-between;align-items:center;padding:10px 12px}.artifact-preview{border-top:1px solid var(--line);padding:14px}.artifact-actions{margin-top:10px}.artifact-download{display:inline-block;text-decoration:none;border:1px solid var(--line);padding:6px 9px;border-radius:6px;background:white;font-size:11px}.empty-state{padding:18px;border:1px dashed #cbd5e1;border-radius:8px;background:#f8fafc;color:#64748b}.narrative-panel h1{font-size:22px}.narrative-panel h2{font-size:19px;margin-top:32px;border-top:1px solid #edf0f4;padding-top:20px}.modal{display:none;position:fixed;inset:0;z-index:100;background:rgba(15,23,42,.76);padding:30px}.modal.open{display:flex;align-items:center;justify-content:center}.modal-card{width:min(96vw,1700px);height:min(92vh,1100px);background:white;border-radius:10px;display:flex;flex-direction:column;overflow:hidden}.modal-head{display:flex;justify-content:space-between;align-items:center;padding:10px 13px;border-bottom:1px solid var(--line)}.modal-body{overflow:auto;padding:14px;flex:1}.modal-body .diagram-canvas{border:0;min-height:100%}.modal-body svg{max-width:none}.menu-btn{display:none}.back-top{position:fixed;right:18px;bottom:18px;z-index:40;display:none}.back-top.show{display:block}.report-meta{font-size:11px;color:var(--muted);margin-top:5px}
@media(max-width:1050px){:root{--sidebar:240px}.metrics-grid{grid-template-columns:repeat(3,1fr)}.two-col{grid-template-columns:1fr}.flow-meta{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:780px){.flow-index{flex-direction:column}.flow-chips{justify-content:flex-start}.flow-meta{grid-template-columns:1fr}.menu-btn{display:inline-block}.sidebar{transform:translateX(-100%);transition:.2s}.sidebar.open{transform:translateX(0);box-shadow:10px 0 30px rgba(15,23,42,.15)}.main{margin-left:0;padding:88px 14px 40px}.brand{min-width:auto}.brand-sub{display:none}.global-search{max-width:none}.topbar{padding:0 10px}.metrics-grid{grid-template-columns:repeat(2,1fr)}.status-strip{align-items:flex-start;flex-direction:column}.report-section{padding:18px}.top-actions .print-btn{display:none}}
@media print{body{background:white;font-size:10pt}.topbar,.sidebar,.table-tools,.diagram-actions,.back-top,.option-tabs{display:none!important}.main{margin:0;padding:0;max-width:none}.report-section{box-shadow:none;border:0;page-break-before:auto;padding:10px 0}.table-wrap{max-height:none;overflow:visible;border:0}.table-wrap table{width:100%;font-size:7pt}.table-wrap th{position:static}.option-panel{display:block!important;border:1px solid #ddd;margin:8px 0}.diagram-canvas{overflow:visible}.artifact-list details:not([open])>*:not(summary){display:none}.artifact-list{display:none}}
'''

    js = r'''
(function(){
  const qs=(s,r=document)=>r.querySelector(s), qsa=(s,r=document)=>Array.from(r.querySelectorAll(s));
  // Sidebar anchor tracking.
  const navLinks=qsa('.nav-link');
  const targets=navLinks.map(a=>document.getElementById(a.dataset.navTarget)).filter(Boolean);
  const observer=new IntersectionObserver(entries=>{entries.filter(e=>e.isIntersecting).sort((a,b)=>b.intersectionRatio-a.intersectionRatio).slice(0,1).forEach(e=>{navLinks.forEach(a=>a.classList.toggle('active',a.dataset.navTarget===e.target.id));});},{rootMargin:'-80px 0px -70% 0px',threshold:[0,.1,.5]});
  targets.forEach(t=>observer.observe(t));
  // Mobile navigation.
  qs('.menu-btn')?.addEventListener('click',()=>qs('.sidebar').classList.toggle('open'));
  navLinks.forEach(a=>a.addEventListener('click',()=>qs('.sidebar').classList.remove('open')));
  // Global search over named report surfaces, headings and artifact summaries.
  const search=qs('#global-search'), results=qs('#search-results');
  const candidates=qsa('.search-surface, .artifact-item, .adr, h3[id]').map(el=>({el,title:el.dataset.searchTitle||qs('summary',el)?.innerText||qs('h2,h3',el)?.innerText||el.innerText.slice(0,80)}));
  search?.addEventListener('input',()=>{const q=search.value.trim().toLowerCase();results.innerHTML='';if(q.length<2){results.classList.remove('open');return;} const matches=candidates.filter(x=>x.el.innerText.toLowerCase().includes(q)).slice(0,18); matches.forEach(x=>{const a=document.createElement('a');a.className='search-result';a.href='#'+(x.el.id||x.el.closest('[id]')?.id||'overview');a.textContent=x.title;a.addEventListener('click',()=>results.classList.remove('open'));results.appendChild(a)});if(!matches.length){results.innerHTML='<div class="search-result">No matching report section or artifact</div>'}results.classList.add('open');});
  document.addEventListener('click',e=>{if(!e.target.closest('.global-search'))results.classList.remove('open')});
  // Per-table filtering.
  qsa('.table-filter').forEach(inp=>inp.addEventListener('input',()=>{const tbl=document.getElementById(inp.dataset.tableTarget);if(!tbl)return;const q=inp.value.toLowerCase();qsa('tbody tr',tbl).forEach(tr=>tr.hidden=!tr.innerText.toLowerCase().includes(q));}));
  // Simple table sorting.
  qsa('.sort-btn').forEach(btn=>btn.addEventListener('click',()=>{const th=btn.closest('th'),table=btn.closest('table'),idx=Array.from(th.parentNode.children).indexOf(th),body=qs('tbody',table);const asc=th.dataset.sort!=='asc';qsa('th',table).forEach(x=>delete x.dataset.sort);th.dataset.sort=asc?'asc':'desc';const rows=qsa('tr',body);rows.sort((a,b)=>{const av=a.children[idx]?.innerText.trim()||'',bv=b.children[idx]?.innerText.trim()||'';const an=Number(av.replace(/[, %$]/g,'')),bn=Number(bv.replace(/[, %$]/g,''));let c=(!Number.isNaN(an)&&!Number.isNaN(bn)&&av!==''&&bv!=='')?an-bn:av.localeCompare(bv,undefined,{numeric:true,sensitivity:'base'});return asc?c:-c});rows.forEach(r=>body.appendChild(r));}));
  // Architecture option tabs.
  qsa('.option-tab').forEach(tab=>tab.addEventListener('click',()=>{const wrap=tab.closest('.report-section');qsa('.option-tab',wrap).forEach(t=>{t.classList.toggle('active',t===tab);t.setAttribute('aria-selected',t===tab?'true':'false')});qsa('.option-panel',wrap).forEach(p=>p.classList.toggle('active',p.id===tab.dataset.option));}));
  // Diagram modal.
  const modal=qs('#diagram-modal'),modalBody=qs('#diagram-modal-body');
  qsa('.diagram-expand').forEach(b=>b.addEventListener('click',()=>{const card=document.getElementById(b.dataset.diagram),canvas=qs('.diagram-canvas',card);if(!canvas)return;modalBody.innerHTML=canvas.outerHTML;modal.classList.add('open');modal.setAttribute('aria-hidden','false');}));
  qs('#diagram-modal-close')?.addEventListener('click',()=>{modal.classList.remove('open');modal.setAttribute('aria-hidden','true');modalBody.innerHTML=''});
  modal?.addEventListener('click',e=>{if(e.target===modal)qs('#diagram-modal-close').click()});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.classList.contains('open'))qs('#diagram-modal-close').click()});
  // Back to top.
  const top=qs('.back-top');window.addEventListener('scroll',()=>top.classList.toggle('show',window.scrollY>900));top?.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
  qs('.print-btn')?.addEventListener('click',()=>window.print());
})();
'''

    manifest_json = esc(json.dumps(report_manifest, separators=(",", ":")))
    doc = f'''<!doctype html>
<html lang="en" data-report-schema="{REPORT_SCHEMA}">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(args.title)}</title><style>{css}</style></head>
<body>
<div class="app">
<header class="topbar"><button type="button" class="btn menu-btn" aria-label="Open navigation">☰</button><div class="brand"><div class="brand-mark">M→A</div><div><div class="brand-title">Architecture Assessment</div><div class="brand-sub">MuleSoft → AWS Native</div></div></div><div class="global-search"><span class="search-icon">⌕</span><input id="global-search" type="search" autocomplete="off" placeholder="Search sections, decisions, APIs, components, evidence…"><div id="search-results" class="search-results"></div></div><div class="top-actions"><span class="readiness {readiness_cls}">{esc(readiness)}</span><button type="button" class="btn print-btn">Print / PDF</button></div></header>
<aside class="sidebar"><div class="nav-label">Review navigation</div>{nav}</aside>
<main class="main"><header class="report-hero"><h1>{esc(args.title)}</h1><p>Primary architect-facing review artifact. All analysis results are embedded below; underlying artifacts remain downloadable for traceability.</p><div class="report-meta">Report schema {REPORT_SCHEMA} · Self-contained offline HTML · Readiness: {esc(readiness)}</div></header>{''.join(sections)}</main>
<button class="btn back-top" type="button">↑ Top</button>
<div class="modal" id="diagram-modal" aria-hidden="true" role="dialog" aria-label="Expanded architecture diagram"><div class="modal-card"><div class="modal-head"><strong>Architecture diagram</strong><button class="btn" id="diagram-modal-close" type="button">Close</button></div><div class="modal-body" id="diagram-modal-body"></div></div></div>
<script id="report-manifest" type="application/json">{manifest_json}</script>
<script>{js}</script>
</div></body></html>'''
    output.write_text(doc, encoding="utf-8")

    manifest_out = root / "validation" / "html-report-manifest.json"
    manifest_out.parent.mkdir(parents=True, exist_ok=True)
    manifest_out.write_text(json.dumps(report_manifest, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote primary architect report: {output}")
    print(f"Embedded {len(included_artifacts)} analysis artifact(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
