#!/usr/bin/env python3
"""Create a canonical assessment workspace from the skill templates."""
from __future__ import annotations
import argparse, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
T = ROOT / "templates"

COPY_MAP = {
    "architecture-assessment.md": "architecture-assessment.md",
    "executive-summary.md": "executive-summary.md",
    "assumptions-risks-open-questions.md": "assumptions-risks-open-questions.md",
    "architecture-options.md": "options/architecture-options.md",
    "migration-test-strategy.md": "testing/migration-test-strategy.md",
    "migration-cutover-plan.md": "migration/migration-cutover-plan.md",
    "target-openapi.yaml": "target-state/target-openapi.yaml",
    "evidence-register.csv": "evidence/evidence-register.csv",
    "source-inventory.csv": "evidence/source-inventory.csv",
    "current-api-inventory.csv": "current-state/api-inventory.csv",
    "dependency-inventory.csv": "current-state/dependency-inventory.csv",
    "policy-inventory.csv": "current-state/policy-inventory.csv",
    "traffic-profile.csv": "current-state/traffic-profile.csv",
    "target-api-inventory.csv": "target-state/target-api-inventory.csv",
    "cloud-component-inventory.csv": "target-state/cloud-component-inventory.csv",
    "compute-sizing.csv": "target-state/compute-sizing.csv",
    "configuration-mapping.csv": "target-state/configuration-mapping.csv",
    "security-policy-mapping.csv": "target-state/security-policy-mapping.csv",
    "aws-limit-validation.csv": "target-state/aws-limit-validation.csv",
    "traceability-matrix.csv": "target-state/traceability-matrix.csv",
    "diagrams/current-context.puml": "diagrams/current-context.puml",
    "diagrams/current-network.puml": "diagrams/current-network.puml",
    "diagrams/target-context.puml": "diagrams/target-context.puml",
    "diagrams/target-network.puml": "diagrams/target-network.puml",
}

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("assessment_dir", type=Path)
    p.add_argument("--source-repo", type=Path)
    p.add_argument("--force", action="store_true")
    args = p.parse_args()
    out = args.assessment_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    for src_rel, dst_rel in COPY_MAP.items():
        src, dst = T/src_rel, out/dst_rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists() and not args.force:
            continue
        shutil.copy2(src, dst)
    (out/"decisions").mkdir(exist_ok=True)
    (out/"validation").mkdir(exist_ok=True)
    (out/".skill-run").mkdir(exist_ok=True)
    if not (out/"decisions/ADR-001-template.md").exists() or args.force:
        shutil.copy2(T/"adr.md", out/"decisions/ADR-001-template.md")
    if args.source_repo:
        scanner = ROOT/"scripts/scan_mule_project.py"
        cmd = [sys.executable, str(scanner), str(args.source_repo), "--csv", str(out/"evidence/source-inventory.csv"), "--json", str(out/"evidence/mule-scan.json")]
        print("Running Mule source scan...")
        return subprocess.call(cmd)
    print(f"Assessment workspace created: {out}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
