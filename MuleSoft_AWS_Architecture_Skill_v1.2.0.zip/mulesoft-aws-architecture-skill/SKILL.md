---
name: mulesoft-aws-architecture
version: 1.2.0
description: Evidence-driven analysis of MuleSoft applications and design of AWS-native replacement architecture, including automated workspace bootstrap, source discovery, rationalization, API/cloud inventories, AWS-limit validation, security/network mapping, current/target diagrams, ADRs, testing, cutover, remediation loops, completion validation, and a first-class interactive architect HTML review report.
---

# MuleSoft to AWS Native Architecture Skill

Use this skill when analyzing one MuleSoft application, including all APIs/flows it contains, for migration away from MuleSoft to AWS-native services.

## Core objective

Determine what the MuleSoft application actually does, which capabilities should remain, which should be retired/consolidated/absorbed, and what AWS-native design best replaces **only the Mule-owned functionality** while preserving required business behavior and contracts.

Do not perform a 1:1 Mule-to-AWS translation.

## Normal user experience

The user should provide the Mule repository plus any supporting evidence and ask for the migration assessment. The user should **not** normally be asked to run bootstrap, scan, validation, rendering, or report-generation scripts manually.

The agent owns orchestration of the deterministic scripts in this package.

Manual script invocation is a developer/debug/CI fallback, not the standard workflow.

## Hard scope boundary

In scope: Mule APIs, flows/subflows, orchestration, transformations, API policies, validation, retries, schedulers, messaging, object-store behavior, custom Mule-side Java/code, configuration, gateway behavior, and Mule-managed integrations.

Out of scope: redesigning or migrating upstream/downstream/non-Mule applications. Their code/docs may be inspected as evidence. A Mule capability may be recommended for absorption into an existing application when that application naturally owns the capability and absorption reduces unnecessary distributed architecture.

# Mandatory automated execution workflow

The following lifecycle is required. Do not skip it unless the environment prevents script execution; if that occurs, emulate the same steps manually and record the limitation.

## Phase 0: Preflight

Before analysis:

1. Resolve the Mule source repository root.
2. Resolve or create an assessment output directory.
3. Identify every user-supplied evidence location, including documentation, policies, diagrams, Splunk/Anypoint exports, tests, and non-Mule upstream/downstream source.
4. Determine whether this is a new assessment or a continuation.
5. Read `constraints/company-architecture-constraints.yaml` and treat enabled constraints as hard requirements.
6. Read `references/discovery.md`, `references/evidence-discipline.md`, and `references/mule-runtime-semantics.md`.
7. Read `references/html-report-standard.md`; the HTML report is a required first-class deliverable, not an optional summary.

Do not ask the user to initialize the workspace if the repository/output locations can be resolved from the task and filesystem.

## Phase 1: Automatically prepare the assessment

Before architecture reasoning, execute the deterministic prepare phase:

```bash
python scripts/run_assessment.py prepare <assessment-directory> \
  --source-repo <mule-source-repository> \
  --inputs <supporting-evidence-location>
```

Repeat `--inputs` for additional evidence locations.

The prepare phase:

- creates only missing canonical templates;
- preserves an existing assessment by default;
- records supplied input locations;
- seeds a recursive Mule source scan when needed;
- creates machine-readable workflow state.

Do not use `--force-bootstrap` during a continuation unless overwrite is explicitly intended.

Do not repeatedly rescan unchanged source. Use `--rescan` only when the repository changed materially or prior scan output is stale/incomplete.

## Phase 2: Perform evidence-driven analysis

The automated scanner is only a discovery accelerator. It does not replace direct inspection.

Recursively inspect the repository and all supplied evidence. Build an evidence register before making material architecture conclusions.

Build current-state inventories for:

- APIs/endpoints;
- Mule flows/subflows;
- policies;
- dependencies/backends;
- traffic/latency/payload behavior;
- security/authentication/authorization;
- configuration/secrets;
- runtime semantics;
- deployment/network dependencies;
- tests and observed contracts.

Trace every endpoint from ingress to response, including API policies, DataWeave, validation, downstream calls, retries, transactions, error handling, and response mapping.

Use upstream/downstream code only as evidence unless recommending deliberate absorption of Mule-owned logic.

## Phase 3: Rationalize before choosing AWS services

Every current endpoint/API must receive an evidence-backed disposition:

- RETIRE
- CONSOLIDATE
- ABSORB
- REIMPLEMENT

Use `references/api-rationalization.md`.

Do not preserve Mule Experience/Process/System layers automatically.

Do not default to Lambda.

Evaluate service boundaries around domain cohesion, ownership, security boundary, scaling, latency, failure isolation, deployment independence, operational burden, and cost.

## Phase 4: Design and populate canonical target artifacts

Evaluate Lambda, ECS Fargate, API Gateway, ALB, Step Functions, SQS, SNS, EventBridge, S3, DynamoDB/RDS, and other AWS services only where justified.

Use `references/aws-compute-decision-matrix.md` and all other relevant files in `references/`.

Populate the canonical assessment artifacts continuously as evidence and decisions are established. Do not wait until the end and produce prose without the structured inventories.

At minimum create/populate:

- `architecture-assessment.md`
- `executive-summary.md`
- `assumptions-risks-open-questions.md`
- `evidence/evidence-register.csv`
- `evidence/source-inventory.csv`
- `current-state/api-inventory.csv`
- `current-state/dependency-inventory.csv`
- `current-state/policy-inventory.csv`
- `current-state/traffic-profile.csv`
- `target-state/target-api-inventory.csv`
- `target-state/cloud-component-inventory.csv`
- `target-state/compute-sizing.csv`
- `target-state/configuration-mapping.csv`
- `target-state/security-policy-mapping.csv`
- `target-state/aws-limit-validation.csv`
- `target-state/traceability-matrix.csv`
- `options/architecture-options.md`
- `diagrams/current-context.puml`
- `diagrams/current-network.puml`
- `diagrams/target-context.puml`
- `diagrams/target-network.puml`
- `testing/migration-test-strategy.md`
- `migration/migration-cutover-plan.md`
- ADRs for material decisions

Generate `target-state/target-openapi.yaml` when a REST API remains in the target state.

See `references/output-contract.md` for schemas and completion expectations.

## Phase 5: Verify current AWS facts

For every recommended AWS service, verify relevant limits using current official AWS documentation at assessment time.

Never rely only on remembered quotas.

Record:

- service/limit;
- official AWS source URL;
- verification date;
- observed current-state requirement;
- AWS limit;
- headroom;
- pass/fail;
- evidence reference.

See `references/aws-service-limit-validation.md` and `references/official-source-priority.md`.

## Phase 6: Run automatic validation

When the assessment appears complete, do **not** report completion yet.

Execute:

```bash
python scripts/run_assessment.py validate <assessment-directory>
```

This automatically validates a populated target OpenAPI when applicable and runs the canonical assessment validator, writing machine-readable findings to:

`validation/assessment-validation.json`

## Phase 7: Mandatory remediation loop

If validation fails:

1. Read every finding in `validation/assessment-validation.json`.
2. Classify each finding as one of:
   - missing analysis;
   - missing generated artifact;
   - internally inconsistent information;
   - missing source evidence;
   - unresolved architecture decision;
   - genuine architecture blocker.
3. Correct everything that can be corrected using available evidence.
4. Do not weaken, bypass, delete, or edit validator rules merely to obtain a passing result.
5. Do not invent missing evidence.
6. Convert genuinely unavailable evidence into explicit assumptions, UNKNOWNs, P0-P3 findings, or approval conditions as appropriate.
7. Rerun:

```bash
python scripts/run_assessment.py validate <assessment-directory>
```

8. Repeat until either:
   - the validator passes; or
   - remaining blockers genuinely require evidence/decisions that are unavailable.

The validation loop is part of the skill's work, not work delegated to the user.

## Phase 8: Automatically finalize derivative outputs

After blocking canonical-artifact validation findings are resolved, execute:

```bash
python scripts/run_assessment.py finalize <assessment-directory>
```

The finalize phase:

1. runs canonical-artifact validation again;
2. renders current-state and target-state PlantUML diagrams when a local PlantUML runtime is available;
3. preserves `.puml` sources even when local rendering is unavailable;
4. builds `architecture-assessment.html` as the **primary architect-facing review artifact**;
5. embeds the current/target diagrams, inventories, decisions, testing/cutover material, evidence, validation results, and all canonical artifacts into that HTML;
6. provides hierarchical navigation, anchor tracking, search, sortable/filterable inventory tables, migration-option comparison/tabs, diagram expansion, print/PDF styling, and an embedded Artifact Explorer;
7. writes `validation/html-report-manifest.json`;
8. reruns completion validation with HTML-report checks enabled;
9. records final workflow state.

The architect should be able to obtain a full understanding from `architecture-assessment.html` without opening analysis files directly. The underlying files remain important for automation, source control, and exact traceability.

If finalization exposes new validation errors, return to the remediation loop rather than declaring completion.

## Phase 9: Final readiness status

Finish with exactly one assessment status:

- READY
- READY WITH CONDITIONS
- NOT READY

The status must agree with the validator and documented P0-P3 findings.

Summarize:

- endpoint traceability count;
- recommended architecture;
- major rationalization decisions;
- validation result;
- unresolved conditions/blockers;
- generated artifact locations.

# First-class architect HTML report

`architecture-assessment.html` is mandatory after finalization and is the default artifact to hand to an architect.

It must provide both a fast review path and full drill-down. At minimum it must contain:

- architect review snapshot and readiness;
- current-state context and network diagrams;
- current API, traffic, policy/security, and dependency views;
- endpoint rationalization and source-to-target traceability;
- visible migration option comparison with pros/cons and recommendation;
- target context and network diagrams;
- target APIs, cloud components, sizing, configuration/secrets, security parity, and AWS limit headroom;
- ADRs, testing, cutover/rollback, risks, assumptions, and open questions;
- the complete architecture-assessment narrative;
- evidence register and completion-validation results;
- an embedded Artifact Explorer from which every canonical analysis artifact can be viewed and downloaded.

Use `references/html-report-standard.md` as the mandatory UX/content contract. Do not replace structured report sections with a raw appendix dump.

# Evidence rules

Use these fact classes consistently:

- **OBSERVED**: directly supported by code/config/logs/metrics/documentation.
- **INFERRED**: strongly supported by multiple pieces of evidence.
- **ASSUMED**: necessary for analysis but unconfirmed.
- **UNKNOWN**: required information unavailable.
- **RECOMMENDED**: target-state proposal.

Never fabricate traffic, consumers, SLAs, network paths, payload sizes, AWS limits, pricing, or policy behavior.

# Architecture rules

Do not assume:

- one Mule app becomes one Lambda;
- one Mule API becomes one Lambda;
- Mule Experience/Process/System layering must survive;
- synchronous flows must stay synchronous;
- historical service boundaries are correct target boundaries.

Prefer the simplest architecture that meets measured requirements.

# Required target outcomes per current endpoint

Every current endpoint must appear exactly once in the traceability matrix as:

- RETIRED
- CONSOLIDATED INTO
- ABSORBED INTO
- REPLACED BY

No endpoint may silently disappear.

# Company defaults

The constraints file currently establishes these defaults:

- HashiCorp Vault remains the secret store; AWS Secrets Manager is not used.
- Spring Cloud Config is replaced with environment variables and/or S3-based non-secret configuration.
- CloudWatch and Splunk are both part of observability.
- API Gateway cannot be directly exposed to consumers outside the company network.

Do not bypass these with equivalent public exposure patterns unless the user explicitly changes the constraint.

# Diagram rules

Use separate editable diagrams for:

1. Current application/context architecture.
2. Current network architecture.
3. Target application/context architecture.
4. Target network architecture.

All four must be embedded in the first-class HTML report. Keep business/application relationships out of subnet-level clutter and keep network topology out of the context diagrams. Add sequence/auth/async/failure diagrams only when they clarify material complexity.

# Readiness rule

Do not return READY if any of the following remain unresolved:

- current endpoints are missing from traceability;
- current production policy behavior is unknown for security-critical APIs;
- a recommended AWS service conflicts with measured payload/timeout/throughput requirements;
- external-consumer ingress violates company network constraints;
- required security parity is unproven;
- target architecture has a P0/P1 blocker;
- required current or target context/network diagrams are absent;
- finalization cannot produce a structurally complete first-class HTML architect report.

# Script ownership model

The coding agent owns:

- interpretation of source behavior;
- evidence classification;
- API rationalization;
- architecture decisions;
- AWS service selection;
- target design;
- ADRs;
- risk classification;
- artifact authoring;
- remediation of validator findings.

The deterministic scripts own:

- workspace creation;
- repository scanning;
- traffic summarization;
- structural validation;
- omission/inconsistency checks;
- OpenAPI checks;
- diagram rendering;
- HTML generation;
- package self-tests.

Do not move architecture judgment into deterministic scripts merely to make the workflow appear automated.

# Manual/debug entry points

These remain available for skill developers, CI pipelines, or troubleshooting:

```bash
python scripts/bootstrap_assessment.py ...
python scripts/scan_mule_project.py ...
python scripts/analyze_traffic.py ...
python scripts/validate_openapi.py ...
python scripts/validate_assessment.py ...
python scripts/render_diagrams.py ...
python scripts/build_html_report.py ...
```

For normal skill execution, prefer `scripts/run_assessment.py` and let the skill invoke it automatically.
