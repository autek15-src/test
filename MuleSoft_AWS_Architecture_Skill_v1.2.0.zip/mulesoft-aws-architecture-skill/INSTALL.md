# Installation and Use

This bundle is intentionally agent-agnostic. `SKILL.md` is the entry point and the rest of the directory must remain beside it so relative references and scripts resolve.

## Repository-local use

Keep the complete skill directory in source control beside the migration project or in an approved internal skills repository, then configure Codex/Claude Code to load it.

Do not copy only `SKILL.md`; the skill depends on `references/`, `constraints/`, `templates/`, and `scripts/`.

## Direct prompt fallback

If an agent runtime does not support skills directly, instruct the agent to read `SKILL.md` and execute it as the governing workflow.

## Normal execution

Give the agent:

- MuleSoft repository;
- desired assessment output directory;
- all available supporting evidence locations.

The skill automatically performs prepare, analysis, validation, remediation, and finalization.

The final architect-facing deliverable is:

```text
assessment/architecture-assessment.html
```

Open this HTML directly in a modern browser. It is self-contained and works offline. It includes navigation, search, current/target diagrams, migration options, inventories, ADRs, evidence, validation, and the full embedded artifact explorer.

The underlying Markdown/CSV/YAML/OpenAPI/PlantUML files remain available for automation, source control, and exact traceability but should not normally be needed for architecture review.

## Manual/debug use

For CI/troubleshooting/skill development:

```bash
python scripts/run_assessment.py prepare ./assessment \
  --source-repo /path/to/mule/repository \
  --inputs /path/to/supporting/evidence
python scripts/run_assessment.py validate ./assessment
python scripts/run_assessment.py finalize ./assessment
```

`finalize` validates the canonical artifacts, attempts to render all current/target PlantUML diagrams, builds the HTML report, and reruns validation with HTML completeness checks enabled.

## Workflow state and validation

```text
assessment/.skill-run/state.json
assessment/validation/assessment-validation.json
assessment/validation/html-report-manifest.json
```

## Package self-test

```bash
python scripts/run_quality_checks.py
```
