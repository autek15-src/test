# Changelog

## 1.2.0

- Promoted `architecture-assessment.html` to the mandatory first-class architect-facing deliverable.
- Rebuilt the HTML generator as a self-contained offline architecture review portal with hierarchical navigation, active-section tracking, global search, responsive layout, and Print/PDF styling.
- Added an Architect Review Snapshot with readiness, endpoint/traceability/component/limit metrics, and rationalization disposition counts.
- Made current-state context and current-state network diagrams mandatory alongside the target-state diagrams.
- Embedded current and target diagrams with click-to-expand behavior and downloadable PlantUML source.
- Added sortable/filterable inventory tables for detailed review.
- Added migration-option comparison matrix and visible interactive option tabs with recommendation treatment.
- Embedded ADRs, testing/cutover strategy, risks/open questions, the full narrative assessment, evidence register, source inventory, and validator results.
- Added an Embedded Artifact Explorer that contains every canonical analysis artifact and provides in-report download actions.
- Added `references/html-report-standard.md` as the report information-architecture and UX contract.
- Added `validation/html-report-manifest.json` and final HTML structural/completeness validation.
- Updated output contract, bootstrap, templates, lifecycle controller, README, and install guidance for the first-class HTML model.

## 1.1.0

- Made assessment bootstrap, scan, validation, and finalization part of the mandatory skill workflow instead of manual user prerequisites.
- Added `scripts/run_assessment.py` as the deterministic lifecycle controller.
- Added `prepare`, `validate`, `finalize`, and `status` controller phases.
- Added machine-readable workflow state under `.skill-run/state.json`.
- Added machine-readable validation output under `validation/assessment-validation.json`.
- Added mandatory agent remediation loop for validator findings.
- Added automatic target OpenAPI validation when a populated REST target specification exists.
- Added automatic HTML report generation during finalization.
- Added best-effort PlantUML rendering during finalization while preserving `.puml` as canonical source.
- Updated `SKILL.md`, README, and installation instructions so end users are not expected to run bootstrap/validation scripts manually.
- Added orchestration unit tests and retained the modular lower-level scripts for CI/debugging.

## 1.0.0

- Initial complete MuleSoft-to-AWS architecture assessment skill package.
- Added repository scanner, traffic analyzer, OpenAPI validation, PlantUML rendering, HTML report generation, completion validator, package tests, and architecture evaluation scenarios.
