# Output Contract

The assessment has two complementary systems of record:

1. **Canonical engineering artifacts**: Markdown/CSV/OpenAPI/PlantUML/JSON are machine-readable, diffable, and version-controlled.
2. **Primary architect-facing artifact**: `architecture-assessment.html` is the complete interactive review surface and must embed or link every analysis result needed for architecture review.

An architect should not need to browse the assessment filesystem to understand the current state, target state, migration options, decisions, sizing, limits, risks, evidence, test/cutover strategy, or readiness.

Read `references/html-report-standard.md` for the mandatory HTML structure and interaction requirements.

## Minimum files

See `SKILL.md` required outputs.

The four architecture diagram sources are mandatory:

- `diagrams/current-context.puml`
- `diagrams/current-network.puml`
- `diagrams/target-context.puml`
- `diagrams/target-network.puml`

After finalization, these are also mandatory:

- `architecture-assessment.html`
- `validation/html-report-manifest.json`

## Minimum row-level completeness

### Current API inventory
One row per current externally or internally callable endpoint/event interface. Method+path+API/app should form a stable key for HTTP APIs.

### Traceability
Every current endpoint must have exactly one disposition row and a non-empty rationale/evidence reference.

### Cloud component inventory
Every component must state purpose, what it replaces/supports, rationale, and relevant security/config/observability settings.

### AWS limits
Every recommended API Gateway/Lambda/Step Functions/SQS/SNS/EventBridge/Fargate component must have applicable limit checks. Not every theoretical quota is required, but every observed workload dimension that could invalidate the design must be covered.

### HTML completeness
The final HTML report must contain all required canonical artifacts in its Embedded Artifact Explorer and expose the major information through purpose-built sections rather than only dumping files into an appendix.

### Readiness
The report must contain exactly one final readiness state:
- READY
- READY WITH CONDITIONS
- NOT READY

READY is prohibited when validator ERRORs remain.
