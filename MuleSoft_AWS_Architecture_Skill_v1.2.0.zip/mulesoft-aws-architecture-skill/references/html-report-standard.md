# First-Class HTML Architecture Report Standard

`architecture-assessment.html` is the primary architect-facing review surface. The underlying Markdown, CSV, YAML/OpenAPI, PlantUML, ADR, and validation files remain the machine-readable/version-controlled engineering record, but an architect must be able to understand and review the assessment without browsing those files directly.

## Design goals

The report must optimize for two modes:

1. **Fast architecture review**: understand scope, current state, rationalization, options, recommendation, target design, major risks, and readiness in minutes.
2. **Evidence drill-down**: inspect exact API rows, traffic measurements, policy mappings, AWS limit checks, ADRs, source evidence, and raw canonical artifacts from the same HTML document.

## Required UX

The report must be self-contained and work offline without external JavaScript/CSS/CDN dependencies.

It must provide:

- persistent hierarchical navigation;
- anchor/deep-link navigation to major sections and important subsections;
- active-section tracking while scrolling;
- global client-side search across report sections, decisions, and embedded artifacts;
- responsive layout for laptop/tablet/mobile review;
- print/PDF-friendly styling;
- prominent readiness status;
- architecture review snapshot with key counts and rationalization disposition summary;
- current-state context and network diagrams;
- target-state context and network diagrams;
- click-to-expand diagrams;
- table filtering and sorting for large inventories;
- migration option comparison matrix;
- visible tabs for detailed option comparison (do not hide options only in a dropdown);
- explicit recommended-option treatment;
- collapsible ADRs;
- evidence and completion-validation section;
- embedded Artifact Explorer containing all canonical analysis artifacts;
- raw artifact download actions from inside the HTML report.

## Required information architecture

Top-level sections should be kept stable so reviewers learn the report structure:

1. **Architect Review Snapshot**
   - readiness
   - executive recommendation
   - endpoint/component/limit counts
   - rationalization disposition counts
   - review path
2. **Current State**
   - current application/context diagram
   - current network diagram
   - current API inventory
   - traffic/runtime profile
   - API policies and security
   - dependencies/backends
3. **API Rationalization & Migration Options**
   - source-to-target traceability
   - retire/consolidate/absorb/reimplement outcomes
   - option comparison matrix
   - detailed option tabs
   - recommendation and why
4. **Recommended Target State**
   - target context diagram
   - target network diagram
   - target API inventory
   - cloud component inventory
   - sizing/runtime settings
   - configuration/secrets
   - security/policy parity
   - AWS limit validation/headroom
5. **Decisions, Testing, Cutover & Risks**
   - ADRs
   - testing/equivalence strategy
   - cutover/rollback
   - risks, assumptions, gaps, open questions
6. **Full Architecture Assessment Narrative**
   - complete cross-cutting prose analysis
7. **Evidence & Completion Validation**
   - evidence register
   - reviewed source inventory
   - validator status/findings
8. **Embedded Artifact Explorer**
   - every canonical output viewable/expandable
   - every canonical output downloadable

## Diagram behavior

The HTML should embed rendered SVG when available, else PNG. Editable PlantUML source must also be embedded and downloadable.

If rendered diagrams cannot be produced locally, the report may show the PlantUML source with a visible rendering-unavailable warning, but final architecture review should normally include rendered diagrams.

The following diagrams are mandatory:

- `diagrams/current-context.puml`
- `diagrams/current-network.puml`
- `diagrams/target-context.puml`
- `diagrams/target-network.puml`

## Tables

Large inventory tables must:

- preserve all columns and rows;
- use sticky headers;
- allow horizontal scrolling;
- provide client-side row filtering;
- allow basic column sorting;
- visually distinguish key PASS/WARN/FAIL and readiness values where feasible.

Do not remove fields merely to make the HTML prettier. The HTML is intended to support detailed architecture review.

## Architecture options

`options/architecture-options.md` should follow the standard headings in the template so the report can render:

- a comparison matrix;
- one visible tab per credible option;
- description;
- pros;
- cons;
- workload fit;
- security/network fit;
- cost/operational considerations;
- risks;
- recommendation and evidence.

If only one viable option exists, state why alternatives were invalid rather than manufacturing false choices.

## Traceability and evidence

The report must preserve the distinction between:

- OBSERVED
- INFERRED
- ASSUMED
- UNKNOWN
- RECOMMENDED

Detailed evidence must remain inspectable through the evidence register and artifact explorer.

## Report validation

Final validation must verify that:

- the HTML exists and is non-trivial;
- all eight required top-level sections exist;
- global search/navigation features exist;
- all four required diagrams are represented;
- every required canonical analysis artifact is embedded;
- the report manifest uses the expected schema version;
- the report has the same readiness posture as the canonical assessment.

A run is not fully finalized until the first-class HTML report passes these checks.
