from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOOT = ROOT / "scripts" / "bootstrap_assessment.py"
BUILD = ROOT / "scripts" / "build_html_report.py"


class HtmlReportTests(unittest.TestCase):
    def test_builds_first_class_self_contained_report(self):
        with tempfile.TemporaryDirectory(prefix="mule-skill-html-") as td:
            assessment = Path(td) / "assessment"
            subprocess.check_call([sys.executable, str(BOOT), str(assessment)])
            out = assessment / "architecture-assessment.html"
            proc = subprocess.run(
                [sys.executable, str(BUILD), str(assessment), "--output", str(out)],
                capture_output=True,
                text=True,
            )
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            text = out.read_text(encoding="utf-8")
            self.assertIn('data-report-schema="2.0"', text)
            self.assertIn('id="global-search"', text)
            self.assertIn('id="current-state"', text)
            self.assertIn('id="target-state"', text)
            self.assertIn('id="diagram-current-context"', text)
            self.assertIn('id="diagram-current-network"', text)
            self.assertIn('id="diagram-target-context"', text)
            self.assertIn('id="diagram-target-network"', text)
            self.assertIn('id="artifacts"', text)
            manifest = assessment / "validation" / "html-report-manifest.json"
            self.assertTrue(manifest.exists())
            data = json.loads(manifest.read_text(encoding="utf-8"))
            self.assertEqual(data["schema_version"], "2.0")
            self.assertIn("current-state/api-inventory.csv", data["embedded_artifacts"])
            self.assertIn("diagrams/current-context.puml", data["embedded_artifacts"])


if __name__ == "__main__":
    unittest.main()
