---
name: visio-architecture-renderer
description: Render architecture.schema.json, Mermaid, or PlantUML architecture/network diagrams into editable Microsoft Visio VSDX, with optional AWS icons, templates, and stencils.
---

# Visio Architecture Renderer

Use this skill when the user wants an LLM-generated architecture or network diagram converted to editable Microsoft Visio `.vsdx`.

## Inputs

Accept one of:

- canonical JSON matching `schemas/architecture.schema.json`
- Mermaid `.mmd`, `.mermaid`, or Markdown containing a supported Mermaid diagram
- PlantUML `.puml`, `.plantuml`, or `.uml`

Optional user-supplied resources:

- `.vsdx` template
- `.vssx` stencil
- `master-map.json`
- local AWS Architecture Icons directory (official-style SVG or PNG tree)
- optional AWS icon index JSON and organization-specific alias JSON

## Required workflow

1. Inspect the input and preserve semantic labels, boundaries, protocols, and connections.
2. Prefer JSON as the normalized internal representation. For Mermaid/PlantUML, parse conservatively and do not invent unsupported semantics. PlantUML styled links (for example `-[#0066CC]->`) and nested rectangle/package/cloud/node zone blocks are supported and must not be silently dropped or flattened.
3. Run the renderer. Do **not** manually draw a bitmap and place it inside Visio.
4. Let the optimizer evaluate layout profiles and, in `auto` mode, both Graphviz and the internal layered placement engine. Prefer the lowest quality score, with zero diagonal segments and zero component intersections as hard expectations.
5. When a template is supplied, preserve its existing shapes and use `layout.safeArea` when available to avoid title blocks/reserved areas.
6. When a stencil is supplied, prefer explicit `master-map.json` mappings. Use heuristic master matching only as a fallback.
7. When AWS icons are supplied, use the indexed catalog for nodes recognized as AWS services from explicit type, ordinary labels, partial names, and common acronyms (for example APIGW, DDB, RDS, SQS, SNS, SFN, TGW, ALB/NLB). Do not require an `aws.*` source type. Build/reuse the catalog automatically, prefer exact/canonical service resolution, and record unresolved AWS nodes. Do not download or redistribute AWS icon assets unless the user explicitly provides or authorizes them.
8. Prefer SVG source icons when CairoSVG is available; otherwise allow the resolver to fall back to PNG/JPEG. Do not fail the whole diagram merely because one icon cannot be resolved or converted.
9. Always validate the produced VSDX with `scripts/validate_vsdx.py`. Treat its `desktopCompatibilityChecks` result as required. If LibreOffice is installed, include `--libreoffice` as a secondary rendering smoke test; LibreOffice acceptance alone is **not** proof of Microsoft Visio compatibility.
10. When running on Windows with Microsoft Visio installed, additionally run `scripts/validate_with_visio.ps1 OUTPUT.vsdx`. A native Visio open is the strongest compatibility gate.
11. Review the report. `diagonalSegments` and `nodeIntersections` must be zero. If crossings, corridor overlaps, or route fallbacks remain high on a dense diagram, rerun with a different engine/profile or normalize to JSON and add structural grouping/explicit positions.
12. Return the `.vsdx` plus the JSON quality report when one was requested/generated.


## Connector labeling and metadata policy

Determine whether the task is **conversion** or **new diagram authoring** before deciding what appears on connectors. This distinction is mandatory.

### A. Converting an existing diagram source (PlantUML, Mermaid, canonical source diagram, etc.)

Treat connector text as source content. Preserve the **same human-visible connector label as the source file**. Do not shorten, semanticize, paraphrase, replace a REST path with a business phrase, or move source label content exclusively into metadata unless the user explicitly requests that transformation. Preserve supported line breaks and method/path text; only decode source-format escaping required to reproduce the same visible text.

Examples:

- PlantUML source: `A --> B : POST /customers/{id}/documents` -> Visio visible label remains `POST /customers/{id}/documents`.
- Mermaid source: `A -->|PATCH /cases/{caseId}| B` -> Visio visible label remains `PATCH /cases/{caseId}`.

It is acceptable to **add** ScreenTips or Shape Data when reliable information can be derived, but those additions must not replace or rewrite the source label in conversion mode. Store the original source label in Shape Data when useful for traceability.

### B. Generating a new Visio diagram from scratch

Optimize for architecture readability rather than reproducing a pre-existing label. Use a short **semantic interaction label** on the connector, for example `Upload document`, `Create case`, `Publish notification`, or `Load customer profile`. Prefix the semantic action with an HTTP method only when the method materially helps the reader, for example `POST • Upload document`.

Put fine technical details in native Visio metadata:

- **ScreenTip:** full endpoint/operation detail that a reviewer commonly needs on hover. For REST, include at minimum HTTP method + full REST path; normally also include source -> target, protocol, and authentication. For non-REST interactions use the corresponding technical address/operation such as queue/topic name, event type, database operation, file location, or RPC/SOAP operation.
- **Shape Data:** structured fields for the interaction. Recommended fields are Interaction, HTTP Method, REST Path or Operation/Resource, Protocol, Source Component, Target Component, Authentication, Authorization, Content Type/Payload, Timeout, Retry Policy, Idempotency, Error Handling, Purpose, and Source Artifact/Traceability when known. Do not fabricate unknown values.

For generated VSDX, store the ScreenTip on the connector shape's `Comment` cell. Store Shape Data in the connector's `Property` section. **String Shape Data values must be emitted as `<Cell N="Value" V="..." U="STR"/>`; do not put `F="No Formula"` on text Value cells.** This is required for desktop Visio to display the actual text instead of `0` or blank values.

See `docs/CONNECTOR_LABELING_AND_METADATA.md`, `examples/connector-label-conversion.puml`, `examples/connector-label-conversion.mmd`, and `examples/connector-authoring-from-scratch.json`.

## Commands

```bash
python scripts/render_vsdx.py INPUT -o OUTPUT.vsdx --report OUTPUT.report.json
python scripts/validate_vsdx.py OUTPUT.vsdx --libreoffice
# On Windows with Visio installed:
powershell -ExecutionPolicy Bypass -File scripts/validate_with_visio.ps1 OUTPUT.vsdx
```

AWS icon catalog commands:

```bash
arch2visio index-aws-icons AWS-Architecture-Icons
arch2visio resolve-aws-icon AWS-Architecture-Icons aws.api_gateway --label "API Gateway"
```

Template/stencil example:

```bash
python scripts/render_vsdx.py architecture.json \
  --template corporate-template.vsdx \
  --stencil corporate-shapes.vssx \
  --master-map master-map.json \
  --aws-icons-dir AWS-Architecture-Icons \
  --layout-engine auto \
  --report architecture.report.json \
  -o architecture.vsdx
```

## Quality principles

- Architecture diagrams are read as a flow. Prefer one dominant direction.
- Keep related components together inside meaningful system/cloud/network boundaries.
- Avoid connector crossings before optimizing for compactness.
- Spread fan-in/fan-out ports and emit them as explicit Visio Connection Points rows.
- Glue connector endpoints to those connection points, never merely to the whole component shape.
- Require orthogonal-only connectors for network/cloud diagrams. No diagonal connector segment is acceptable.
- Treat every unrelated component rectangle as a hard routing obstacle.
- Keep component labels on the component shape itself and edge labels on the connector shape itself so labels move with their owning object.
- Keep edge labels short and place them on long route segments with a light text background.
- Do not silently drop unresolved nodes or endpoints.
- Do not claim a dense diagram is clean if the quality report shows crossings/fallbacks.

## Completion gate

Before treating the skill package itself as complete, run:

```bash
python scripts/completion_validator.py
```

It must pass unit tests, render all three example input types, structurally validate each VSDX, and perform LibreOffice smoke rendering when LibreOffice is available.


Regression coverage now also includes `examples/uml-test-realworld.puml`, a complex real-world PlantUML architecture diagram fixture used to validate release readiness.


## PUML fidelity gates

For PlantUML architecture inputs, preserve supported explicit/skinparam colors, actor semantics, directed arrowheads, and group boundaries. A release-quality render must report `diagonalSegments = 0`, `nodeIntersections = 0`, and `groupOverlaps = 0`. Use the real-world fixture in `examples/uml-test-realworld.puml` as a regression test before packaging.


Generated architecture rectangles/zones are native Visio groups with member components nested as subshapes. Directed connectors use high-visibility filled triangle arrowheads.


### Visio groups and connector compatibility
Generated architecture zones use geometry-free native Visio group parents with a visible boundary child behind nested components. Connector Geometry must be written in the connector's local coordinate system so initial lines and arrowheads remain visible in desktop Visio and tolerant readers.


### Interactive Visio glue

For native VSDX output, use a **standalone Visio connector ShapeSheet** and do not synthesize or require a Dynamic Connector master. Preserve guarded `PinX/PinY/Width/Height/LocPinX/LocPinY`, `ObjType=2`, `DynFeedback=2`, `ShapeRouteStyle=1`. Do **not** GUARD `BeginX/BeginY/EndX/EndY` point-glue formulas; users must be able to drag an endpoint free or reglue it to another connection point. For generated architecture routes use `ConFixedCode=2` (Never reroute) plus formula-driven terminal adapters so endpoint movement cannot rotate an arrowhead away from its component or collapse the final bend. For generated architecture routes, use deterministic static point glue (`GlueType=0`) to the exact router-selected connection point. `BeginX/BeginY/EndX/EndY` must use group-safe `LOCTOPAR(PNT(Sheet.<target>!Connections.Xn,Sheet.<target>!Connections.Yn),Sheet.<target>!Width,ThePage!PageWidth)` formulas, `<Connect>` rows must target the same `Connections.Xn` row with the matching `ToPart`, and the first/last Geometry vertices must be formula-bound to `Begin*`/`End*`. Do not use whole-shape `PinX` walking glue for a precomputed multi-bend route because Visio may choose a different perimeter position on open and visually detach the Geometry.


## Native Visio interactive-glue validation

When Microsoft Visio is installed on Windows, validate both file opening and actual drag-safe connector behavior. `scripts/validate_with_visio.ps1` verifies that Visio opens the package. `scripts/validate_glue_with_visio.ps1` goes further: it moves a connected component, then its parent generated group when present, and verifies that the glued connector endpoint changes. Use the glue test as the definitive compatibility gate for interactive editing because non-Visio readers cannot prove COM/ShapeSheet drag behavior.


## Visio 2019 connector compatibility

Emit connectors directly in Python using the standalone connector ShapeSheet model. Do not synthesize or require a Dynamic Connector master. Use guarded connector XForm cells, exact `Connections.Xn` point glue with **unguarded** group-safe `LOCTOPAR(PNT(...))` endpoint formulas, `ObjType=2`, `GlueType=0`, `DynFeedback=2`, `ShapeRouteStyle=1`, `ConFixedCode=2`, page-pinned orthogonal middle Geometry plus formula-driven terminal adapters with live first/last vertices, and matching `<Connect>` rows. Microsoft Visio is optional only for the interactive validation scripts; rendering itself must remain pure Python.


## Built-in semantic shapes

When a user/company stencil or official AWS icon is unavailable, prefer the built-in semantic architecture catalog plus automatic native-vector pictograms over a generic rectangle. The catalog is adapted from MIT-licensed OfficeIMO.Visio stencil families and includes database cylinders, gateways, load balancers, queues/events/streams, servers, security/network/client/platform shapes, actors, and external-system notation. PostgreSQL/MySQL/MongoDB labels infer database semantics; Redis infers cache; Kafka infers stream. A curated MIT Tabler subset is precompiled into native Visio vector geometry and used automatically by default; `iconMode: none` opts a node out. Provider recognition covers AWS, Azure, GCP and common enterprise technologies/vendors, while contextual mentions such as deployment platform or auth provider must not hijack the primary component semantics. Use `arch2visio list-shapes` and `arch2visio list-icons` to inspect the catalog.
