# Visio Architecture Renderer Skill

Render LLM-generated architecture descriptions into **editable Microsoft Visio `.vsdx` files** without requiring Microsoft Visio during generation.

Supported inputs:

- canonical `architecture.schema.json`
- Mermaid `.mmd` / `.mermaid`
- PlantUML `.puml` / `.plantuml`

The renderer creates native Visio shapes, text that stays bound to its component, explicit perimeter connection points for manual editing, strictly orthogonal initial connector geometry, and deterministic Visio point glue to router-selected perimeter anchors that follows moved components and enclosing groups. It can optionally use user-supplied AWS icon files, a corporate `.vsdx` template, and `.vssx` stencil masters. When those are absent, a built-in semantic architecture-shape catalog plus automatic native-vector pictograms provides professional database, API/gateway, server, queue, storage, security, network, client, and platform fallbacks instead of generic rectangles or hand-drawn pseudo-icons.

## Quick start

```bash
python -m pip install -e .
arch2visio render examples/aws-target.json -o out.vsdx --report out.report.json
arch2visio validate out.vsdx --libreoffice
```

Or without installing:

```bash
python scripts/render_vsdx.py examples/aws-target.json -o out.vsdx --report out.report.json
python scripts/validate_vsdx.py out.vsdx --libreoffice
```

### Mermaid / PlantUML

```bash
python scripts/render_vsdx.py examples/sample.mmd -o sample-mermaid.vsdx
python scripts/render_vsdx.py examples/sample.puml -o sample-plantuml.vsdx
```


### Built-in architecture shapes and generic icons

No external icon pack is required for useful architecture notation. The renderer includes a native semantic shape catalog adapted from the MIT-licensed OfficeIMO.Visio first-party architecture/network/cloud/security/Kubernetes/data stencil families. For example, `component "PostgreSQL 15"` becomes a database cylinder, Redis becomes a cache cylinder, API Gateway becomes a gateway hexagon, Kafka becomes a stream, and an actor remains a stick figure.

A curated 25-icon subset of MIT-licensed Tabler Icons is also bundled and precompiled into native Visio vector geometry. v1.3.1+ uses these pictograms automatically by default, while preserving semantic container geometry and PUML colors. Set `iconMode: "none"` for a node that should use only the native semantic shape. Inspect what is available with:

```bash
arch2visio list-shapes
arch2visio list-icons
```

See `docs/BUILTIN_SHAPES_AND_ICONS.md`.

### AWS icon collection

Point directly at an extracted AWS Architecture Icons SVG or PNG collection:

```bash
arch2visio index-aws-icons ./AWS-Architecture-Icons
arch2visio render examples/aws-target.json \
  --aws-icons-dir ./AWS-Architecture-Icons \
  --report aws-target.report.json \
  -o aws-target.vsdx
```

The renderer indexes every icon file, caches the catalog, understands common AWS abbreviations/aliases, and can infer AWS services from ordinary node labels such as `DDB`, `APIGW`, `SFN`, `TGW`, `RDS`, `ALB`, `SQS`, and `EventBridge` even when the source node type is just `component`. It prefers SVG when available, falls back to PNG if SVG conversion is unavailable, and records every resolution decision in the render report. Provider-aware semantic recognition also covers common Azure/GCP services and enterprise technologies such as Salesforce/SFDC, Okta, Vault, Splunk, MuleSoft/Anypoint, SAP, PostgreSQL and Snowflake.

To inspect a service match:

```bash
arch2visio resolve-aws-icon ./AWS-Architecture-Icons aws.api_gateway --label "API Gateway"
```

### Corporate template + stencil + AWS icons

```bash
python scripts/render_vsdx.py architecture.json \
  --template corporate-template.vsdx \
  --stencil corporate-shapes.vssx \
  --master-map master-map.json \
  --aws-icons-dir ./AWS-Architecture-Icons \
  --layout-engine auto \
  --report architecture.report.json \
  -o architecture.vsdx
```

See `docs/` for format, layout, template/stencil, and AWS icon details.

### Microsoft Visio desktop compatibility

The current release includes the Visio 2019 package fixes from v1.1.1 plus the later native grouping, routing, arrow, and dynamic-glue improvements. The validator now checks several conditions that LibreOffice and other tolerant readers may accept but desktop Visio can reject: ShapeSheet element ordering, defined style references, native 1-D connector semantics, image relationships, and Windows metadata.

Use:

```bash
arch2visio validate diagram.vsdx
```

A successful result includes `"desktopCompatibilityChecks": "passed"`. On Windows with Microsoft Visio installed, run `powershell -ExecutionPolicy Bypass -File scripts/validate_with_visio.ps1 diagram.vsdx` for a native desktop open test. To verify actual interactive glue, run `powershell -ExecutionPolicy Bypass -File scripts/validate_glue_with_visio.ps1 diagram.vsdx`; that test moves a connected component and, when possible, its parent group and verifies that the connector endpoint follows. LibreOffice rendering remains useful, but is not treated as proof of interactive Visio behavior.

### Pure-Python connector interoperability

The production path is self-contained: Python writes the final editable VSDX directly. A temporary development experiment used Visio COM to create a known-good smoke connector; the resulting VSDX was then reverse-engineered and its standalone ShapeSheet representation was implemented directly in Python. Visio COM is **not** required to render diagrams. The optional COM scripts are validation tools only.

## PlantUML parser notes

PlantUML input supports colored/styled links such as `-[#0066CC]->`, dashed/hidden link styles, and nested rectangle/package/cloud/node blocks as architecture groups.


## Visio editability and routing model (v1.2.7)

Generated components are now single Visio objects: their labels are stored on the component shape itself rather than emitted as independent helper text shapes. AWS bitmap-backed components likewise use one Foreign shape containing both the icon placement and label text block. Connector labels belong to the connector shape.

Each component receives explicit Visio Connection Points rows around its perimeter. Generated connectors keep the proven **standalone Visio ShapeSheet connector object** (guarded `PinX/PinY/Width/Height/LocPinX/LocPinY`, `ObjType=2`, `ShapeRouteStyle=1`, exact point glue, and orthogonal Geometry). v1.3.4 retains the v1.3.3 `ConFixedCode=2` (Never reroute) behavior, pins the middle route to page coordinates, and adds formula-driven 0.25-inch terminal adapters that keep arrowheads perpendicular to their connection-point side during component moves. v1.3.2 binds each endpoint to the exact router-selected `Connections.Xn` anchor instead of whole-shape walking glue. `BeginX/BeginY/EndX/EndY` use **unguarded** group-safe `LOCTOPAR(PNT(...), ..., ThePage!PageWidth)` formulas so users can detach/reglue endpoints, and `<Connect>` records target the matching connection-point row. The first and last Geometry vertices are also formula-bound to the live endpoints. No Dynamic Connector master and no Microsoft Visio generation/finalization step are required.

Routing is orthogonal-only. The router assigns ports globally, adds a perpendicular escape leg from each node, routes around expanded component bounds with a rectilinear visibility graph, strongly penalizes crossings/corridor reuse, and emits only horizontal/vertical Visio geometry with `ShapeRouteStyle=1` (Right Angle). Auto layout evaluates both Graphviz and the internal layered placer when Graphviz is available. The quality report includes `diagonalSegments` and `nodeIntersections`; both must be zero in the completion gate.


## Examples

- `examples/sample.puml` and `examples/sample.mmd`: minimal smoke-test inputs
- `examples/plantuml-styled-zones.puml`: styled zone/group example
- `examples/plantuml-dense-network.puml`: dense routing regression fixture
- `examples/uml-test-realworld.puml`: real-world PlantUML regression fixture used to validate package readiness against a complex architecture diagram



### PlantUML visual fidelity

PlantUML inputs preserve explicit/background colors for supported component, database, and rectangle declarations. Directed links are emitted with native Visio triangle arrowheads, actors use a native stick-figure geometry, and sibling zone rectangles are separated so they do not overlap. The routing gate requires zero diagonal segments, zero connector/component intersections, and zero sibling group overlaps.

The renderer uses a conflict-first whole-page rerouting polish pass after layout selection. See `docs/OSS_RENDERING_AUDIT.md` for the open-source implementation audit and reuse decisions.


### Native movable architecture groups

Architecture zones/rectangles are emitted as native Visio group shapes. Components belonging to a zone are nested as subshapes, so dragging the zone/group moves its components together. Directed connectors use standard medium filled triangle arrowheads for clear directionality.


### Visio groups and connector compatibility
Generated architecture zones use geometry-free native Visio group parents with a visible, translucent boundary child behind nested components. Connectors use a Visio-compatible standalone ShapeSheet with local orthogonal Geometry and deterministic point glue to explicit `Connections.Xn` anchors; no connector master is required.


## Visio interactive editing

Generated connectors use Visio-native **static point glue** without a connector master. `BeginX/BeginY/EndX/EndY` reference the exact generated connection point through group-safe `LOCTOPAR(PNT(...))` formulas; `<Connect>` rows target `Connections.Xn` with the matching `ToPart`; and the standalone connector shape retains `ObjType=2`, `ShapeRouteStyle=1`, `ConFixedCode=2`, and formula-driven terminal adapters. This prevents Visio from choosing a different perimeter location when the file opens while still allowing the endpoint formula to follow moved nested components/groups. Directed links use standard triangle arrowheads.


## Connector labels: conversion vs new authoring

Connector labeling is intent-sensitive. When converting an existing PlantUML/Mermaid/diagram source, preserve the source connector label as visible Visio text. Do not automatically replace a detailed source label with a semantic phrase. When creating a new diagram from requirements or architecture data, prefer a short semantic connector label and place full technical endpoint details in a native Visio ScreenTip plus structured Shape Data on the connector. See `docs/CONNECTOR_LABELING_AND_METADATA.md` and the `connector-label-conversion.*` / `connector-authoring-from-scratch.json` examples.

For VSDX Shape Data text, emit `Value` with `U="STR"` and no `F="No Formula"`; otherwise desktop Visio can display `0` or a blank value.
