from pathlib import Path
import zipfile, tempfile, shutil
from visio_arch_renderer.render import render
from visio_arch_renderer.validate import validate_vsdx
ROOT=Path(__file__).resolve().parents[1]
_RENDER_CACHE_DIR=tempfile.TemporaryDirectory()
_RENDER_CACHE={}
def _render(name):
 td=tempfile.TemporaryDirectory();out=Path(td.name)/(Path(name).stem+'.vsdx')
 if name not in _RENDER_CACHE:
  cached=Path(_RENDER_CACHE_DIR.name)/(Path(name).stem+'.vsdx')
  rep=render(ROOT/'examples'/name,cached)
  _RENDER_CACHE[name]=(cached,rep)
 cached,rep=_RENDER_CACHE[name]
 shutil.copy2(cached,out)
 return td,out,rep

def _is_connector_cells(cells):
 return cells.get('ObjType')=='2' and all(k in cells for k in ('BeginX','BeginY','EndX','EndY'))

def test_render_json():
 td,out,rep=_render('aws-target.json');assert validate_vsdx(out)['ok'];td.cleanup()
def test_render_mermaid():
 td,out,rep=_render('sample.mmd');assert validate_vsdx(out)['ok'];td.cleanup()
def test_render_puml():
 td,out,rep=_render('sample.puml');assert validate_vsdx(out)['ok'];td.cleanup()
def test_native_connects():
 td,out,rep=_render('aws-target.json')
 with zipfile.ZipFile(out) as z: assert b'<Connect ' in z.read('visio/pages/page1.xml')
 td.cleanup()

def test_desktop_scaffold_and_styles():
 td,out,rep=_render('aws-target.json')
 with zipfile.ZipFile(out) as z:
  names=set(z.namelist())
  assert 'visio/windows.xml' in names
  doc=z.read('visio/document.xml')
  assert b'<StyleSheet ID="0"' in doc
  assert b'<DocumentSheet ' in doc
  rels=z.read('visio/_rels/document.xml.rels')
  assert b'/relationships/windows' in rels
 td.cleanup()

def test_shapesheet_content_order_is_visio_schema_safe():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('aws-target.json')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  base={'Cell','Trigger','Section'}
  ext={'Text','Data1','Data2','Data3','ForeignData','Shapes'}
  for shape in root.findall(f'.//{{{V}}}Shape'):
   extension_seen=False
   for child in list(shape):
    local=child.tag.rsplit('}',1)[-1]
    if local in ext: extension_seen=True
    elif local in base: assert not extension_seen, f'Shape {shape.get("ID")} has {local} after extension content'
 td.cleanup()

def test_connectors_are_native_one_d_shapes():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('aws-target.json')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  by_id={s.get('ID'):s for s in root.findall(f'.//{{{V}}}Shape')}
  for conn in root.findall(f'.//{{{V}}}Connect'):
   shape=by_id[conn.get('FromSheet')]
   cells={c.get('N'):c.get('V') for c in shape.findall(f'{{{V}}}Cell')}
   assert _is_connector_cells(cells)
   # Visio-authored standalone connectors need not serialize an explicit OneD cell.
   assert cells.get('OneD') in {None,'1'}
 td.cleanup()


def test_styled_plantuml_edges_render_color_and_hidden_link_is_not_drawn():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('plantuml-styled-zones.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  shapes=root.findall(f'.//{{{V}}}Shape')
  connector_shapes=[]
  colors=[]
  for shape in shapes:
   cells={c.get('N'):c.get('V') for c in shape.findall(f'{{{V}}}Cell')}
   if _is_connector_cells(cells):
    connector_shapes.append(shape)
    colors.append(cells.get('LineColor'))
  # 4 parsed links, but the PlantUML [hidden] relation is layout-only.
  assert len(connector_shapes)==3
  colors=[c.lower() if c else c for c in colors]
  assert '#0066cc' in colors
  assert '#ff9900' in colors
  assert '#2e7d32' in colors
 td.cleanup()

def test_connectors_use_explicit_point_glue_and_right_angle_geometry():
 import xml.etree.ElementTree as ET
 import re
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('aws-target.json')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  by_id={s.get('ID'):s for s in root.findall(f'.//{{{V}}}Shape')}
  connector_ids=set()
  for c in root.findall(f'.//{{{V}}}Connect'):
   m=re.fullmatch(r'Connections\.X(\d+)',c.get('ToCell',''))
   assert m
   row=int(m.group(1))-1
   assert c.get('ToPart')==str(100+row)
   assert c.get('ToSheet') in by_id
   target=by_id[c.get('ToSheet')]
   rows={int(r.get('IX')) for sec in target.findall(f'{{{V}}}Section') if sec.get('N')=='Connection' for r in sec.findall(f'{{{V}}}Row')}
   assert row in rows
   connector_ids.add(c.get('FromSheet'))
  for cid in connector_ids:
   shape=by_id[cid]
   cells={c.get('N'):c for c in shape.findall(f'{{{V}}}Cell')}
   assert cells['ShapeRouteStyle'].get('V')=='1'
   assert cells['GlueType'].get('V')=='0'
   assert cells['ObjType'].get('V')=='2'
   assert cells['ConFixedCode'].get('V')=='2'
   for n in ('BeginX','BeginY','EndX','EndY'):
    f=cells[n].get('F') or ''
    assert 'LOCTOPAR(PNT(Sheet.' in f and 'ThePage!PageWidth' in f
   geom=next(x for x in shape.findall(f'{{{V}}}Section') if x.get('N')=='Geometry')
   pts=[]
   rows=geom.findall(f'{{{V}}}Row')
   for row in rows:
    rc={c.get('N'):float(c.get('V')) for c in row.findall(f'{{{V}}}Cell') if c.get('N') in {'X','Y'}}
    if len(rc)==2: pts.append((rc['X'],rc['Y']))
   assert all(abs(a[0]-b[0])<1e-7 or abs(a[1]-b[1])<1e-7 for a,b in zip(pts,pts[1:]))
   first={c.get('N'):c.get('F') for c in rows[0].findall(f'{{{V}}}Cell')}
   last={c.get('N'):c.get('F') for c in rows[-1].findall(f'{{{V}}}Cell')}
   assert first.get('X')=='BeginX-PinX+LocPinX' and first.get('Y')=='BeginY-PinY+LocPinY'
   assert last.get('X')=='EndX-PinX+LocPinX' and last.get('Y')=='EndY-PinY+LocPinY'
 td.cleanup()


def test_node_and_group_labels_are_not_free_floating_text_shapes():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('plantuml-styled-zones.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  # All non-connector text now belongs to the component/boundary shape itself.
  # There should be no zero-line, zero-fill helper rectangles used only as labels.
  for shape in root.findall(f'.//{{{V}}}Shape'):
   cells={c.get('N'):c.get('V') for c in shape.findall(f'{{{V}}}Cell')}
   if _is_connector_cells(cells):
    continue
   text=shape.find(f'{{{V}}}Text')
   if text is not None and (text.text or '').strip():
    has_geom=any(sec.get('N')=='Geometry' for sec in shape.findall(f'{{{V}}}Section'))
    is_foreign=shape.get('Type')=='Foreign'
    is_master=shape.get('Master') is not None
    assert has_geom or is_foreign or is_master
 td.cleanup()


def test_auto_layout_evaluates_both_graphviz_and_internal_layered_engines():
 td,out,rep=_render('plantuml-dense-network.puml')
 engines={c.get('requestedEngine') for c in rep['candidates']}
 assert 'layered' in engines
 # Graphviz is optional at runtime, but this test environment has it available
 # in the release gate; when unavailable graphviz candidates carry an error.
 assert 'graphviz' in engines
 assert rep['metrics']['diagonalSegments']==0
 assert rep['metrics']['nodeIntersections']==0
 td.cleanup()

def test_connector_labels_belong_to_connector_shape_and_have_text_background():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('plantuml-styled-zones.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  labeled=[]
  for shape in root.findall(f'.//{{{V}}}Shape'):
   cells={c.get('N'):c.get('V') for c in shape.findall(f'{{{V}}}Cell')}
   if _is_connector_cells(cells) and shape.find(f'{{{V}}}Text') is not None:
    labeled.append((shape,cells))
  assert labeled
  assert all((cells.get('TextBkgnd') or '').lower() in {'#ffffff','16777216'} for _,cells in labeled)
 td.cleanup()



def test_realworld_plantuml_fixture_parses_expected_groups_nodes_and_edges():
 from visio_arch_renderer.parsers import parse_diagram
 d=parse_diagram(ROOT/'examples'/'uml-test-realworld.puml')
 assert len(d.nodes)==17
 assert len(d.edges)==23
 assert len(d.groups)==8


def test_realworld_plantuml_fixture_renders_with_quality_gate():
 td,out,rep=_render('uml-test-realworld.puml')
 vr=validate_vsdx(out)
 assert vr['ok']
 metrics=rep['metrics']
 assert metrics['diagonalSegments']==0
 assert metrics['nodeIntersections']==0
 assert metrics['crossings'] <= 16
 assert metrics['overlaps'] <= 4
 assert metrics['fallbacks'] <= 1
 td.cleanup()


def _shape_by_text(root, text, V):
 for shape in root.findall(f'.//{{{V}}}Shape'):
  tx=shape.find(f'{{{V}}}Text')
  if tx is not None and (tx.text or '').startswith(text):
   return shape
 raise AssertionError(f'shape with text {text!r} not found')

def test_realworld_visio_preserves_puml_colors_actor_and_arrowheads():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('uml-test-realworld.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  # Explicit and skinparam-derived PUML fills are retained.
  sf=_shape_by_text(root,'pmp-salesforce-async-api',V)
  gdms=_shape_by_text(root,'gdms-sys-api',V)
  rds=_shape_by_text(root,'Aurora PostgreSQL 15',V)
  gateway_group=_shape_by_text(root,'Internal Gateway',V)
  def cells(sh): return {c.get('N'):c.get('V') for c in sh.findall(f'{{{V}}}Cell')}
  assert cells(sf).get('FillForegnd')=='#FFF0CC'
  assert cells(gdms).get('FillForegnd')=='#FFDACC'
  assert cells(rds).get('FillForegnd')=='#FFFDE7'
  assert cells(gateway_group).get('FillForegnd')=='#D6EED6'
  # Actor is a native custom stick-figure shape, not a generic rectangle.
  actor=_shape_by_text(root,'Internal AIG PAL Staff',V)
  geoms=[sec for sec in actor.findall(f'{{{V}}}Section') if sec.get('N')=='Geometry']
  assert len(geoms)>=2
  assert any(row.get('T')=='Ellipse' for sec in geoms for row in sec.findall(f'{{{V}}}Row'))
  # Directed connectors use Visio's visible Triangle end-arrow value (13).
  connector_cells=[]
  for sh in root.findall(f'.//{{{V}}}Shape'):
   c=cells(sh)
   if _is_connector_cells(c): connector_cells.append(c)
  assert connector_cells
  assert all(c.get('EndArrow')=='13' for c in connector_cells)
 td.cleanup()

def test_realworld_hard_layout_gates_include_group_overlap_and_endpoint_reentry():
 td,out,rep=_render('uml-test-realworld.puml')
 m=rep['metrics']
 assert m['nodeIntersections']==0
 assert m['groupOverlaps']==0
 assert m['diagonalSegments']==0
 assert m['crossings'] <= 10
 td.cleanup()


def test_directed_connectors_use_standard_medium_triangle_arrowheads():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('uml-test-realworld.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  directed=0
  for shape in root.findall(f'.//{{{V}}}Shape'):
   cells={c.get('N'):c.get('V') for c in shape.findall(f'{{{V}}}Cell')}
   if _is_connector_cells(cells) and cells.get('EndArrow')=='13':
    directed += 1
    assert cells.get('EndArrowSize') in {None,'2'}
    assert float(cells.get('LineWeight','0')) >= .015
  assert directed > 0
 td.cleanup()


def test_architecture_groups_are_native_visio_groups_with_nested_member_shapes():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('uml-test-realworld.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  top_shapes=root.find(f'{{{V}}}Shapes')
  groups=[s for s in top_shapes.findall(f'{{{V}}}Shape') if s.get('Type')=='Group']
  assert groups
  # Each real-world architecture zone contains its components as Visio subshapes.
  assert all(g.find(f'{{{V}}}Shapes') is not None for g in groups)
  nested_ids={s.get('ID') for g in groups for s in g.findall(f'.//{{{V}}}Shape')}
  assert nested_ids
  # Connector glue targets the nested component IDs rather than only top-level rectangles.
  targets={c.get('ToSheet') for c in root.findall(f'.//{{{V}}}Connect')}
  assert targets & nested_ids
  # Child pins are local to the owning group's coordinate system.
  for g in groups:
   gc={c.get('N'):float(c.get('V')) for c in g.findall(f'{{{V}}}Cell') if c.get('N') in {'Width','Height'}}
   sub=g.find(f'{{{V}}}Shapes')
   for child in sub.findall(f'{{{V}}}Shape'):
    cc={c.get('N'):float(c.get('V')) for c in child.findall(f'{{{V}}}Cell') if c.get('N') in {'PinX','PinY'}}
    if 'PinX' in cc and 'PinY' in cc:
     assert -0.1 <= cc['PinX'] <= gc['Width'] + .1
     assert -0.1 <= cc['PinY'] <= gc['Height'] + .1
 td.cleanup()


def test_group_parent_is_geometry_free_and_boundary_child_renders_behind_members():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('uml-test-realworld.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  top=root.find(f'{{{V}}}Shapes')
  groups=[s for s in top.findall(f'{{{V}}}Shape') if s.get('Type')=='Group']
  assert groups
  for group in groups:
   # Native group parents must not paint a filled geometry over their children.
   assert not [sec for sec in group.findall(f'{{{V}}}Section') if sec.get('N')=='Geometry']
   sub=group.find(f'{{{V}}}Shapes')
   assert sub is not None and len(sub.findall(f'{{{V}}}Shape')) >= 2
   boundary=sub.findall(f'{{{V}}}Shape')[0]
   assert (boundary.get('NameU') or '').startswith('ArchitectureGroupBoundary.')
   assert any(sec.get('N')=='Geometry' for sec in boundary.findall(f'{{{V}}}Section'))
   cells={c.get('N'):c.get('V') for c in boundary.findall(f'{{{V}}}Cell')}
   assert cells.get('LinePattern')=='1'
   # At least one actual member after the boundary remains a normal renderable shape/group.
   assert any((c.get('NameU') or '').startswith('ArchitectureGroup.') or not (c.get('NameU') or '').startswith('ArchitectureGroupBoundary.') for c in sub.findall(f'{{{V}}}Shape')[1:])
 td.cleanup()


def test_connectors_match_visio_authored_standalone_dynamic_shape_pattern():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('uml-test-realworld.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  directed=0
  for shape in root.findall(f'.//{{{V}}}Shape'):
   cells={c.get('N'):c.get('V') for c in shape.findall(f'{{{V}}}Cell')}
   if not _is_connector_cells(cells):
    continue
   # Reverse-engineered Visio 2019 pattern: standalone shape, guarded XForm,
   # walking glue, ObjType=2, and local geometry. No connector master required.
   assert shape.get('Master') is None
   assert all(k in cells for k in ('PinX','PinY','Width','Height','LocPinX','LocPinY'))
   assert cells.get('OneD') in {None,'1'}
   assert cells.get('ObjType')=='2'
   assert cells.get('ConFixedCode')=='2'
   raw={c.get('N'):c for c in shape.findall(f'{{{V}}}Cell')}
   assert raw['PinX'].get('F')=='GUARD((BeginX+EndX)/2)'
   assert raw['PinY'].get('F')=='GUARD((BeginY+EndY)/2)'
   geom=next(sec for sec in shape.findall(f'{{{V}}}Section') if sec.get('N')=='Geometry')
   pts=[]
   for row in geom.findall(f'{{{V}}}Row'):
    rc={c.get('N'):float(c.get('V')) for c in row.findall(f'{{{V}}}Cell') if c.get('N') in {'X','Y'}}
    if len(rc)==2: pts.append((rc['X'],rc['Y']))
   assert all(abs(a[0]-b[0])<1e-7 or abs(a[1]-b[1])<1e-7 for a,b in zip(pts,pts[1:]))
   if cells.get('EndArrow')=='13': directed += 1
  assert directed > 0
 td.cleanup()


def test_connector_endpoints_use_group_safe_explicit_connection_points():
 import xml.etree.ElementTree as ET
 import re
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('uml-test-realworld.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  connects=root.findall(f'.//{{{V}}}Connect')
  assert connects
  by_id={sh.get('ID'):sh for sh in root.findall(f'.//{{{V}}}Shape')}
  for conn in connects:
   connector=by_id[conn.get('FromSheet')]
   endpoint=conn.get('FromCell')
   other='BeginY' if endpoint=='BeginX' else 'EndY'
   target=conn.get('ToSheet')
   m=re.fullmatch(r'Connections\.X(\d+)',conn.get('ToCell',''))
   assert m
   row=int(m.group(1))
   assert conn.get('ToPart')==str(99+row)
   c1=next(c for c in connector.findall(f'{{{V}}}Cell') if c.get('N')==endpoint)
   c2=next(c for c in connector.findall(f'{{{V}}}Cell') if c.get('N')==other)
   for cell in (c1,c2):
    f=cell.get('F') or ''
    assert f'Sheet.{target}!Connections.X{row}' in f
    assert f'Sheet.{target}!Connections.Y{row}' in f
    assert f'Sheet.{target}!Width' in f
    assert 'LOCTOPAR(' in f and 'ThePage!PageWidth' in f
   cells={c.get('N'):c.get('V') for c in connector.findall(f'{{{V}}}Cell')}
   assert cells.get('ObjType')=='2'
   assert cells.get('GlueType')=='0'
   assert cells.get('ConFixedCode')=='2'
 td.cleanup()


def test_group_and_component_shapes_are_layout_placeable_for_visio_reroute():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('uml-test-realworld.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  for sh in root.findall(f'.//{{{V}}}Shape'):
   cells={c.get('N'):c.get('V') for c in sh.findall(f'{{{V}}}Cell')}
   if sh.get('Type')=='Group':
    assert cells.get('ObjType')=='8'
   elif not _is_connector_cells(cells) and not (sh.get('NameU') or '').startswith('ArchitectureGroupBoundary.'):
    # Actual architecture components are placeable. Some master-backed details
    # may inherit behavior, but generated component shapes have ObjType=1.
    if any(c.get('N')=='Connection' for c in sh.findall(f'{{{V}}}Section')):
     assert cells.get('ObjType')=='1'
 td.cleanup()

def test_connector_smoke_uses_standalone_shape_with_exact_point_glue():
 import xml.etree.ElementTree as ET
 import re
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('connector-smoke.puml')
 with zipfile.ZipFile(out) as z:
  # Keep the proven standalone connector package model: no hand-authored master.
  assert not any(n.startswith('visio/masters/') for n in z.namelist())
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  by_id={s.get('ID'):s for s in root.findall(f'.//{{{V}}}Shape')}
  connects=root.findall(f'.//{{{V}}}Connect')
  assert len(connects)==2
  cid=connects[0].get('FromSheet')
  assert all(c.get('FromSheet')==cid for c in connects)
  sh=by_id[cid]
  cells={c.get('N'):c for c in sh.findall(f'{{{V}}}Cell')}
  assert (sh.get('NameU') or '').startswith('ArchitectureConnector.')
  assert sh.get('Master') is None
  assert 'OneD' not in cells
  assert cells['PinX'].get('F')=='GUARD((BeginX+EndX)/2)'
  assert cells['PinY'].get('F')=='GUARD((BeginY+EndY)/2)'
  assert cells['LocPinX'].get('F')=='GUARD(Width*0.5)'
  assert cells['LocPinY'].get('F')=='GUARD(Height*0.5)'
  for name in ('BeginX','BeginY','EndX','EndY'):
   f=cells[name].get('F') or ''
   assert 'LOCTOPAR(' in f and not f.startswith('GUARD(')
  assert cells['ObjType'].get('V')=='2'
  assert cells['GlueType'].get('V')=='0'
  assert cells['DynFeedback'].get('V')=='2'
  assert cells['ShapeRouteStyle'].get('V')=='1'
  assert cells['ConFixedCode'].get('V')=='2'
  assert cells['EndArrow'].get('V')=='13'
  assert all(re.fullmatch(r'Connections\.X\d+',c.get('ToCell','')) for c in connects)
  geom=next(s for s in sh.findall(f'{{{V}}}Section') if s.get('N')=='Geometry')
  rows=geom.findall(f'{{{V}}}Row')
  assert len(rows)>=7
  p=[]
  for row in rows:
   d={c.get('N'):float(c.get('V')) for c in row.findall(f'{{{V}}}Cell') if c.get('N') in {'X','Y'}}
   p.append((d['X'],d['Y']))
  assert all(abs(a[0]-b[0])<1e-7 or abs(a[1]-b[1])<1e-7 for a,b in zip(p,p[1:]))
  first={c.get('N'):c.get('F') for c in rows[0].findall(f'{{{V}}}Cell')}
  second={c.get('N'):c.get('F') for c in rows[1].findall(f'{{{V}}}Cell')}
  penultimate={c.get('N'):c.get('F') for c in rows[-2].findall(f'{{{V}}}Cell')}
  last={c.get('N'):c.get('F') for c in rows[-1].findall(f'{{{V}}}Cell')}
  assert first.get('X')=='BeginX-PinX+LocPinX' and first.get('Y')=='BeginY-PinY+LocPinY'
  assert last.get('X')=='EndX-PinX+LocPinX' and last.get('Y')=='EndY-PinY+LocPinY'
  # Direct smoke route exits right and enters left. Both terminal legs are
  # explicitly held 0.25in away from the component before the endpoint.
  assert 'BeginX+0.25' in (second.get('X') or '')
  assert 'EndX-0.25' in (penultimate.get('X') or '')
  assert cells['ConFixedCode'].get('V')=='2'
 td.cleanup()

def test_terminal_adapters_follow_connection_point_direction_and_keep_standoff():
 import xml.etree.ElementTree as ET
 import re
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('uml-test-realworld.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  by_id={s.get('ID'):s for s in root.findall(f'.//{{{V}}}Shape')}
  connects=root.findall(f'.//{{{V}}}Connect')
  assert connects
  for c in connects:
   connector=by_id[c.get('FromSheet')]
   target=by_id[c.get('ToSheet')]
   m=re.fullmatch(r'Connections\.X(\d+)',c.get('ToCell',''))
   assert m
   row_ix=int(m.group(1))-1
   sec=next(sec for sec in target.findall(f'{{{V}}}Section') if sec.get('N')=='Connection')
   crow=next(r for r in sec.findall(f'{{{V}}}Row') if int(r.get('IX'))==row_ix)
   cc={x.get('N'):float(x.get('V') or 0) for x in crow.findall(f'{{{V}}}Cell') if x.get('N') in {'DirX','DirY'}}
   geom=next(sec for sec in connector.findall(f'{{{V}}}Section') if sec.get('N')=='Geometry')
   rows=geom.findall(f'{{{V}}}Row')
   assert len(rows)>=7
   endpoint=c.get('FromCell')
   stubrow=rows[1] if endpoint=='BeginX' else rows[-2]
   f={x.get('N'):(x.get('F') or '') for x in stubrow.findall(f'{{{V}}}Cell')}
   prefix='Begin' if endpoint=='BeginX' else 'End'
   dx,dy=cc.get('DirX',0),cc.get('DirY',0)
   # Connection-point Dir vector points inward. The terminal stub must sit
   # exactly 0.25in in the opposite/outward direction from that endpoint.
   if dx>0: assert f'{prefix}X-0.25' in f['X']
   elif dx<0: assert f'{prefix}X+0.25' in f['X']
   elif dy>0: assert f'{prefix}Y-0.25' in f['Y']
   elif dy<0: assert f'{prefix}Y+0.25' in f['Y']
   else: raise AssertionError('generated perimeter connection point must be directional')
   cells={x.get('N'):x.get('V') for x in connector.findall(f'{{{V}}}Cell')}
   assert cells.get('ConFixedCode')=='2'
 td.cleanup()


def test_explicit_puml_group_fills_are_translucent_for_connector_visibility():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('uml-test-realworld.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  boundaries=[s for s in root.findall(f'.//{{{V}}}Shape') if (s.get('NameU') or '').startswith('ArchitectureGroupBoundary.')]
  assert boundaries
  vals=[]
  for sh in boundaries:
   c=next((x for x in sh.findall(f'{{{V}}}Cell') if x.get('N')=='FillForegndTrans'),None)
   assert c is not None
   vals.append(float(c.get('V')))
  # Explicit PUML fills are no longer opaque; this prevents Visio redraw/z-order
  # from completely hiding connector legs beneath a native group boundary.
  assert min(vals) >= 0.70
 td.cleanup()
