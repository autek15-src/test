from pathlib import Path
from visio_arch_renderer.parsers import parse_diagram
from visio_arch_renderer.layout import layout_diagram
from visio_arch_renderer.routing import route_edges,route_metrics
ROOT=Path(__file__).resolve().parents[1]
def test_layout_and_routes():
 d=parse_diagram(ROOT/'examples/aws-target.json');l=layout_diagram(d,'balanced','layered');r=route_edges(d,l.boxes,l.group_boxes);m=route_metrics(r);assert len(l.boxes)==5 and len(r)==4 and m['fallbacks']<=4
def test_graphviz_or_fallback():
 d=parse_diagram(ROOT/'examples/aws-target.json');l=layout_diagram(d,'balanced','auto');assert l.engine in {'graphviz','layered'}

def test_every_route_segment_is_orthogonal_and_avoids_unrelated_nodes():
 d=parse_diagram(ROOT/'examples/plantuml-styled-zones.puml')
 from visio_arch_renderer.layout import autosize_nodes
 autosize_nodes(d)
 l=layout_diagram(d,'balanced','layered');r=route_edges(d,l.boxes,l.group_boxes)
 for idx,route in r.items():
  e=d.edges[idx]
  for a,b in zip(route.points,route.points[1:]):
   assert abs(a[0]-b[0])<1e-7 or abs(a[1]-b[1])<1e-7
   for nid,box in l.boxes.items():
    if nid in {e.source,e.target}: continue
    if abs(a[0]-b[0])<1e-7:
     assert not (box.x < a[0] < box.x+box.w and max(min(a[1],b[1]),box.y) < min(max(a[1],b[1]),box.y+box.h))
    else:
     assert not (box.y < a[1] < box.y+box.h and max(min(a[0],b[0]),box.x) < min(max(a[0],b[0]),box.x+box.w))


def test_nested_group_boxes_enclose_all_child_groups_and_nodes():
 d=parse_diagram(ROOT/'examples/plantuml-dense-network.puml')
 from visio_arch_renderer.layout import autosize_nodes
 autosize_nodes(d)
 l=layout_diagram(d,'balanced','graphviz')
 groups={g.id:g for g in d.groups}
 for g in d.groups:
  gb=l.group_boxes[g.id]
  for n in d.nodes:
   if n.group==g.id:
    b=l.boxes[n.id]
    assert gb.x <= b.x and gb.y <= b.y and gb.x+gb.w >= b.x+b.w and gb.y+gb.h >= b.y+b.h
  for child in d.groups:
   if child.parent==g.id:
    cb=l.group_boxes[child.id]
    assert gb.x <= cb.x and gb.y <= cb.y and gb.x+gb.w >= cb.x+cb.w and gb.y+gb.h >= cb.y+cb.h

def test_dense_network_has_no_diagonal_or_component_intersections():
 d=parse_diagram(ROOT/'examples/plantuml-dense-network.puml')
 from visio_arch_renderer.layout import autosize_nodes
 autosize_nodes(d)
 l=layout_diagram(d,'dense-routing','graphviz')
 r=route_edges(d,l.boxes,l.group_boxes)
 m=route_metrics(r,l.boxes)
 assert m['diagonalSegments']==0
 assert m['nodeIntersections']==0
