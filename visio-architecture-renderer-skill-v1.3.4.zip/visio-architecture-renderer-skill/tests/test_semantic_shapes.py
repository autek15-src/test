from __future__ import annotations

import json, tempfile, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET

from visio_arch_renderer.semantic import resolve_semantic, resolve_provider, list_semantic_shapes
from visio_arch_renderer.builtin_icons import list_builtin_icons, builtin_icon_bytes
from visio_arch_renderer.render import render

ROOT=Path(__file__).resolve().parents[1]
V='http://schemas.microsoft.com/office/visio/2012/main'


def test_semantic_resolution_database_and_aws_gateway():
    s, tech, why=resolve_semantic('component','PostgreSQL 15',{})
    assert s.key=='database' and s.geometry=='database' and tech=='postgresql'
    s, _, _=resolve_semantic('aws.rds','PostgreSQL',{})
    assert s.key=='database'
    s, _, _=resolve_semantic('aws.api_gateway','Public API',{})
    assert s.key=='api_gateway' and s.geometry=='gateway'


def test_officeimo_inspired_catalog_has_architecture_families():
    keys={s.key for s in list_semantic_shapes()}
    for key in {'actor','service','compute','gateway','database','storage','queue','security','network','external','load_balancer','container','kubernetes'}:
        assert key in keys


def test_bundled_tabler_icons_are_present_and_dependency_free_pngs():
    names=set(list_builtin_icons())
    for name in {'database','server','api','cloud','shield-lock','network','world'}:
        assert name in names
        data=builtin_icon_bytes(name)
        assert data and data[1]=='.png' and data[0].startswith(b'\x89PNG')


def test_postgresql_renders_as_icon_group_with_native_database_body():
    with tempfile.TemporaryDirectory() as td:
        out=Path(td)/'gallery.vsdx'; report=Path(td)/'report.json'
        render(ROOT/'examples'/'semantic-shapes.json',out,report=report)
        rep=json.loads(report.read_text())
        node=rep['visioNativeManifest']['nodes']['postgres']
        assert node['semantic']['key']=='database'
        assert node['builtinIcon']['name']=='database' and node['builtinIcon']['automatic'] is True
        with zipfile.ZipFile(out) as z:
            page=ET.fromstring(z.read('visio/pages/page1.xml'))
            assert not any(n.startswith('visio/media/builtin_postgres') for n in z.namelist())
        sid=str(node['shapeId'])
        sh=page.find(f'.//{{{V}}}Shape[@ID="{sid}"]')
        assert sh is not None and (sh.get('NameU') or '').startswith('SemanticIcon.database.')
        assert sh.get('Type')=='Group'
        # The grouped body remains a native editable cylinder, and the icon is
        # native vector geometry rather than a bitmap/Foreign shape.
        nested=sh.findall(f'.//{{{V}}}Shape')
        body=next(x for x in nested if (x.get('NameU') or '').startswith('Semantic.Database.'))
        assert any(r.get('T')=='Ellipse' for sec in body.findall(f'{{{V}}}Section') for r in sec.findall(f'{{{V}}}Row'))
        assert any((x.get('NameU') or '').startswith('ArchitectureVectorIcon.') for x in nested)


def test_explicit_builtin_icon_override_uses_native_tabler_vector():
    with tempfile.TemporaryDirectory() as td:
        out=Path(td)/'icons.vsdx'; report=Path(td)/'report.json'
        render(ROOT/'examples'/'builtin-icon-override.json',out,report=report)
        rep=json.loads(report.read_text())
        assert rep['visioNativeManifest']['nodes']['a']['builtinIcon']['name']=='server'
        with zipfile.ZipFile(out) as z:
            page=ET.fromstring(z.read('visio/pages/page1.xml'))
            assert not any(n.startswith('visio/media/builtin_a') for n in z.namelist())
        sid=str(rep['visioNativeManifest']['nodes']['a']['shapeId'])
        sh=page.find(f'.//{{{V}}}Shape[@ID="{sid}"]')
        assert any((x.get('NameU') or '').startswith('ArchitectureVectorIcon.') for x in sh.findall(f'.//{{{V}}}Shape'))


def test_provider_recognition_handles_cloud_acronyms_partial_names_and_vendors():
    cases={
        ('component','DDB orders'):('aws','dynamodb','database'),
        ('component','APIGW public edge'):('aws','api_gateway','api_gateway'),
        ('component','SFN order workflow'):('aws','step_functions','workflow'),
        ('component','TGW core routing'):('aws','transit_gateway','router'),
        ('component','Azure APIM'):('azure','api_management','api_gateway'),
        ('component','GCS archive bucket'):('gcp','cloud_storage','object_storage'),
        ('component','SFDC CRM'):('salesforce','salesforce','external'),
        ('component','Splunk Observability'):('splunk','splunk','monitoring'),
        ('component','HashiCorp Vault'):('hashicorp_vault','hashicorp_vault','secret_store'),
        ('component','MuleSoft Anypoint Runtime'):('mulesoft','mulesoft','service'),
        ('component','SAP S/4HANA'):('sap','sap','external'),
    }
    for (typ,label),(provider,service,semantic) in cases.items():
        p=resolve_provider(typ,label,{})
        assert p is not None and p.provider==provider and p.service==service and p.confidence=='high'
        assert resolve_semantic(typ,label,{})[0].key==semantic


def test_context_provider_mentions_do_not_hijack_primary_component_semantics():
    p=resolve_provider('component','Angular 18\n(ECS Fargate, AIG network only)',{})
    assert p and p.provider=='aws' and p.service=='fargate' and p.confidence=='context'
    assert resolve_semantic('component','Angular 18\n(ECS Fargate, AIG network only)',{})[0].key=='service'
    p=resolve_provider('component','pmp-gateway-api\n[Internal reverse proxy]\n[Okta JWT]',{})
    assert p and p.provider=='okta' and p.confidence=='context'
    assert resolve_semantic('component','pmp-gateway-api\n[Internal reverse proxy]\n[Okta JWT]',{})[0].key=='api_gateway'
    assert resolve_provider('component','pmp-user-profile-api\n[MFA enrollment/reset]',{}) is None
