from pathlib import Path
from visio_arch_renderer.parsers import parse_diagram

ROOT=Path(__file__).resolve().parents[1]

def test_json():
    d=parse_diagram(ROOT/'examples/aws-target.json')
    assert len(d.nodes)==5 and len(d.edges)==4 and len(d.groups)==2

def test_mermaid():
    d=parse_diagram(ROOT/'examples/sample.mmd')
    assert len(d.nodes)>=5 and len(d.edges)>=4

def test_plantuml():
    d=parse_diagram(ROOT/'examples/sample.puml')
    assert len(d.nodes)>=5 and len(d.edges)>=4
    consumer=next(n for n in d.nodes if n.id=='Consumer')
    assert consumer.label=='External Consumer'
    assert consumer.type=='actor'

def test_plantuml_colored_arrows_and_nested_rectangle_groups():
    d=parse_diagram(ROOT/'examples/plantuml-styled-zones.puml')
    assert len(d.edges)==4
    assert {g.id for g in d.groups} == {'AWS','VPC','PUB','PRIV'}
    parents={g.id:g.parent for g in d.groups}
    assert parents == {'AWS':None,'VPC':'AWS','PUB':'VPC','PRIV':'VPC'}

    nodes={n.id:n for n in d.nodes}
    assert nodes['API'].group=='PUB'
    assert nodes['LAMBDA'].group=='PUB'
    assert nodes['DB'].group=='PRIV'
    assert nodes['Consumer'].group is None
    # Group declarations must not be emitted as leaf nodes.
    assert not ({'AWS','VPC','PUB','PRIV'} & set(nodes))

    edge={(e.source,e.target):e for e in d.edges}
    assert edge[('Consumer','API')].metadata['color']=='#0066CC'
    assert edge[('API','LAMBDA')].metadata['color']=='#FF9900'
    assert edge[('API','LAMBDA')].style=='dashed'
    assert edge[('API','DB')].metadata['hidden'] is True

def test_plantuml_unaliased_rectangle_block_gets_stable_group_id(tmp_path):
    p=tmp_path/'zones.puml'
    p.write_text('''@startuml\nrectangle "Availability Zone A" {\n component "Worker" as W\n}\n@enduml\n''',encoding='utf-8')
    d=parse_diagram(p)
    assert len(d.groups)==1
    assert d.groups[0].id=='Availability_Zone_A'
    assert next(n for n in d.nodes if n.id=='W').group=='Availability_Zone_A'

def test_plantuml_line_break_escapes_become_real_lines(tmp_path):
 p=tmp_path/'multiline.puml'
 p.write_text('@startuml\ncomponent "API\\nGateway\\lHTTPS" as API\ncomponent "Lambda" as L\nAPI --> L : POST /x\\nTLS\n@enduml\n',encoding='utf-8')
 d=parse_diagram(p)
 assert next(n for n in d.nodes if n.id=='API').label == 'API\nGateway\nHTTPS'
 assert d.edges[0].label == 'POST /x\nTLS'


def test_plantuml_preserves_skinparam_and_explicit_fill_colors():
 d=parse_diagram(ROOT/'examples/uml-test-realworld.puml')
 groups={g.id:g for g in d.groups}
 nodes={n.id:n for n in d.nodes}
 assert groups['Internal_Staff_Entry'].metadata['fillColor']=='#E8F4FD'
 assert groups['Internal_Gateway_HIP13_EKS_eksclus_puse1_prod_hip13'].metadata['fillColor']=='#D6EED6'
 assert groups['System_APIs_Shared_HIP13_EKS'].metadata['fillColor']=='#F0F0F0'
 assert nodes['INTPORTAL'].metadata['fillColor']=='#FFFFFF'
 assert nodes['SFASYNC'].metadata['fillColor']=='#FFF0CC'
 assert nodes['GDMSAPI'].metadata['fillColor']=='#FFDACC'
 assert nodes['RDS'].metadata['fillColor']=='#FFFDE7'
 assert nodes['INTPORTAL'].metadata['borderColor']=='#AAAAAA'
 assert d.metadata['defaultArrowColor']=='#555555'


def test_plantuml_reverse_and_headless_links_preserve_direction_semantics(tmp_path):
 p=tmp_path/'arrows.puml'
 p.write_text('@startuml\ncomponent "A" as A\ncomponent "B" as B\nA <-- B : reverse\nA -- B : association\n@enduml\n',encoding='utf-8')
 d=parse_diagram(p)
 assert d.edges[0].source=='B' and d.edges[0].target=='A'
 assert d.edges[0].metadata['directed'] is True
 assert d.edges[1].metadata['directed'] is False
