import json
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

from visio_arch_renderer.parsers.json_parser import parse_json
from visio_arch_renderer.parsers.plantuml_parser import parse_plantuml
from visio_arch_renderer.render import render
from visio_arch_renderer.validate import validate_vsdx

V='http://schemas.microsoft.com/office/visio/2012/main'


def _page_xml(vsdx):
    with zipfile.ZipFile(vsdx) as z:
        return ET.fromstring(z.read('visio/pages/page1.xml'))


def test_conversion_preserves_source_connector_label(tmp_path):
    src=tmp_path/'x.puml'
    src.write_text('@startuml\ncomponent "A" as A\ncomponent "B" as B\nA --> B : POST /customers/{id}/documents\\nOkta JWT\n@enduml\n')
    d=parse_plantuml(src)
    assert len(d.edges)==1
    assert d.edges[0].label=='POST /customers/{id}/documents\nOkta JWT'


def test_authoring_connector_screentip_and_shape_data(tmp_path):
    src=tmp_path/'a.json'; out=tmp_path/'a.vsdx'
    src.write_text(json.dumps({
        'nodes':[{'id':'a','label':'A'},{'id':'b','label':'B'}],
        'edges':[{
            'source':'a','target':'b','label':'Upload document',
            'screenTip':'POST /api/v1/documents\\nA -> B\\nHTTPS/REST',
            'shapeData':{
                'Interaction':'Upload document',
                'HTTP Method':{'value':'POST','prompt':'HTTP verb'},
                'REST Path':'/api/v1/documents'
            }
        }]
    }))
    render(src,out)
    page=_page_xml(out)
    conn=next(s for s in page.findall(f'.//{{{V}}}Shape') if (s.get('NameU') or '').startswith('ArchitectureConnector.'))
    text=conn.find(f'{{{V}}}Text')
    assert text is not None and 'Upload document' in (text.text or '')
    comment=next(c for c in conn.findall(f'{{{V}}}Cell') if c.get('N')=='Comment')
    assert comment.get('V').startswith('POST /api/v1/documents')
    prop=next(sec for sec in conn.findall(f'{{{V}}}Section') if sec.get('N')=='Property')
    values=[]
    for row in prop.findall(f'{{{V}}}Row'):
        v=next(c for c in row.findall(f'{{{V}}}Cell') if c.get('N')=='Value')
        values.append((v.get('V'),v.get('U'),v.get('F')))
    assert ('Upload document','STR',None) in values
    assert ('POST','STR',None) in values
    assert ('/api/v1/documents','STR',None) in values
    validation=validate_vsdx(out)
    assert validation['ok'] is True, validation['errors']
    assert validation['stats']['desktopCompatibilityChecks']=='passed'


def test_point_glue_is_unguarded_for_manual_endpoint_reglue(tmp_path):
    src=tmp_path/'a.json'; out=tmp_path/'a.vsdx'
    src.write_text(json.dumps({'nodes':[{'id':'a'},{'id':'b'}],'edges':[{'source':'a','target':'b','label':'x'}]}))
    render(src,out)
    page=_page_xml(out)
    conn=next(s for s in page.findall(f'.//{{{V}}}Shape') if (s.get('NameU') or '').startswith('ArchitectureConnector.'))
    formulas={c.get('N'):c.get('F','') for c in conn.findall(f'{{{V}}}Cell')}
    assert formulas['BeginX'].startswith('PNTX(LOCTOPAR(')
    assert formulas['EndX'].startswith('PNTX(LOCTOPAR(')
    assert not formulas['BeginX'].startswith('GUARD(')
    assert not formulas['EndX'].startswith('GUARD(')
