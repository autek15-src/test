from __future__ import annotations
from dataclasses import dataclass
import math, subprocess, tempfile
from collections import defaultdict, deque
from .model import Diagram

@dataclass
class Box:
    x: float; y: float; w: float; h: float
    @property
    def cx(self): return self.x+self.w/2
    @property
    def cy(self): return self.y+self.h/2

@dataclass
class LayoutResult:
    boxes: dict[str,Box]
    group_boxes: dict[str,Box]
    width: float
    height: float
    engine: str

PROFILES={
    # rank_gap is clear space *between* adjacent layers (not center distance).
    "compact": dict(rank_gap=70,node_gap=34,margin=45,group_pad=36),
    "balanced": dict(rank_gap=96,node_gap=46,margin=55,group_pad=44),
    "spacious": dict(rank_gap=128,node_gap=62,margin=65,group_pad=54),
    "dense-routing": dict(rank_gap=112,node_gap=70,margin=60,group_pad=50),
}

def autosize_nodes(diagram: Diagram) -> None:
    """Grow default-size nodes to fit realistic architecture labels.

    JSON callers that provide non-default width/height retain those dimensions.
    PlantUML/Mermaid nodes normally use the defaults and are sized from their
    multi-line content before any layout engine runs.
    """
    for n in diagram.nodes:
        lines=(n.label or n.id).splitlines() or [n.id]
        max_len=max((len(x) for x in lines),default=8)
        # Keep architecture boxes readable without making one long endpoint
        # explode the whole page. Long lines wrap inside the selected width.
        if abs(n.width-150.0)<1e-6:
            n.width=max(168.0,min(320.0,92.0+min(max_len,42)*4.8))
        chars_per=max(18,int((n.width-28)/5.2))
        visual_lines=sum(max(1,math.ceil(max(1,len(x))/chars_per)) for x in lines)
        if abs(n.height-74.0)<1e-6:
            n.height=max(74.0,min(240.0,30.0+visual_lines*16.0))


def layout_diagram(diagram: Diagram, profile="balanced", engine="auto") -> LayoutResult:
    cfg=PROFILES.get(profile,PROFILES["balanced"])
    explicit = all(n.x is not None and n.y is not None for n in diagram.nodes) and bool(diagram.nodes)
    if explicit:
        boxes={n.id:Box(n.x or 0,n.y or 0,n.width,n.height) for n in diagram.nodes}
        eng="explicit"
    elif engine in {"auto","graphviz"}:
        try:
            boxes=_graphviz(diagram,cfg)
            eng="graphviz"
        except Exception:
            if engine=="graphviz": raise
            boxes=_layered(diagram,cfg); eng="layered"
    else:
        boxes=_layered(diagram,cfg); eng="layered"
    # Graphviz clusters are excellent placement constraints, but their node
    # positions can still produce overlapping *derived* Visio boundaries.
    # Resolve sibling/group overlaps by translating complete group subtrees,
    # then recompute boundaries. This preserves containment and guarantees that
    # unrelated zone rectangles never occupy the same area.
    _resolve_group_overlaps(diagram, boxes, cfg["group_pad"])
    group_boxes=_groups(diagram,boxes,cfg["group_pad"])
    # shift all positive and include group bounds
    allb=list(boxes.values())+list(group_boxes.values())
    if not allb: return LayoutResult({}, {}, 800, 500, eng)
    minx=min(b.x for b in allb); miny=min(b.y for b in allb)
    dx=cfg["margin"]-minx; dy=cfg["margin"]-miny
    if dx or dy:
        for b in boxes.values(): b.x+=dx; b.y+=dy
        for b in group_boxes.values(): b.x+=dx; b.y+=dy
    maxx=max(b.x+b.w for b in list(boxes.values())+list(group_boxes.values()))+cfg["margin"]
    maxy=max(b.y+b.h for b in list(boxes.values())+list(group_boxes.values()))+cfg["margin"]
    return LayoutResult(boxes,group_boxes,max(500,maxx),max(350,maxy),eng)

def _graphviz(d,cfg):
    node={n.id:n for n in d.nodes}
    rankdir='TB' if d.direction in {'TB','TD','BT'} else 'LR'
    lines=['digraph G {',f'graph [rankdir={rankdir}, nodesep={max(.25,cfg["node_gap"]/96):.3f}, ranksep={max(.4,cfg["rank_gap"]/96):.3f}, splines=ortho, compound=true, newrank=true];','node [shape=box,fixedsize=true];']

    # Graphviz clusters are used only as placement constraints.  The final
    # Visio boundaries are still generated from our own group boxes.  Keeping
    # nested PlantUML/C4/AWS zones together dramatically reduces the chance of
    # a visually unrelated node being placed through another zone.
    groups={g.id:g for g in d.groups}
    child_groups=defaultdict(list)
    group_nodes=defaultdict(list)
    for g in d.groups:
        if g.parent in groups:
            child_groups[g.parent].append(g.id)
    for n in d.nodes:
        if n.group in groups:
            group_nodes[n.group].append(n.id)

    def emit_node(nid,indent='  '):
        n=node[nid]
        lines.append(f'{indent}"{_q(n.id)}" [label="{_q(n.label)}",width={n.width/96:.4f},height={n.height/96:.4f}];')

    def emit_group(gid,indent='  '):
        # cluster identifiers are independent of architecture IDs; quote the
        # user-facing label and keep generous margins for the Visio header.
        lines.append(f'{indent}subgraph "cluster_{_q(gid)}" {{')
        lines.append(f'{indent}  label="{_q(groups[gid].label)}"; margin=24;')
        for nid in sorted(group_nodes.get(gid,[])):
            emit_node(nid,indent+'  ')
        for cid in sorted(child_groups.get(gid,[])):
            emit_group(cid,indent+'  ')
        lines.append(f'{indent}}}')

    grouped={n.id for n in d.nodes if n.group in groups}
    for nid in sorted(n.id for n in d.nodes if n.id not in grouped):
        emit_node(nid)
    for gid in sorted(g.id for g in d.groups if not g.parent or g.parent not in groups):
        emit_group(gid)

    for e in d.edges:
        # Hidden PlantUML relations are useful placement constraints and should
        # remain part of the dot model even though they are never rendered.
        attrs=' [style=invis,weight=2]' if e.metadata.get('hidden') else ''
        lines.append(f'"{_q(e.source)}" -> "{_q(e.target)}"{attrs};')
    lines.append('}')
    p=subprocess.run(['dot','-Tplain'],input='\n'.join(lines),text=True,capture_output=True,check=True)
    pts={}; graph_h=None
    for line in p.stdout.splitlines():
        a=line.split()
        if len(a)>=4 and a[0]=='graph':
            graph_h=float(a[3])*96
        elif len(a)>=6 and a[0]=='node':
            nid=a[1].strip('"'); x=float(a[2])*96; y=float(a[3])*96
            pts[nid]=(x,y)
    if len(pts)!=len(d.nodes): raise RuntimeError('graphviz did not place all nodes')
    if graph_h is None:
        graph_h=max(y for x,y in pts.values())+max((n.height for n in d.nodes),default=74)
    boxes={}
    for n in d.nodes:
        cx,cy=pts[n.id]
        boxes[n.id]=Box(cx-n.width/2, graph_h-cy-n.height/2, n.width, n.height)
    return boxes

def _q(s): return str(s).replace('"','\\"')

def _layered(d,cfg):
    ids=[n.id for n in d.nodes]; incoming=defaultdict(set); outgoing=defaultdict(set)
    for e in d.edges:
        if e.source in ids and e.target in ids and e.source!=e.target:
            outgoing[e.source].add(e.target); incoming[e.target].add(e.source)
    indeg={i:len(incoming[i]) for i in ids}; q=deque([i for i in ids if indeg[i]==0]); order=[]
    while q:
        u=q.popleft(); order.append(u)
        for v in outgoing[u]:
            indeg[v]-=1
            if indeg[v]==0:q.append(v)
    # cycles: append remaining deterministically
    order += [i for i in ids if i not in order]
    rank={i:0 for i in ids}
    for u in order:
        for v in outgoing[u]:
            if rank[v]<=rank[u]: rank[v]=rank[u]+1
    maxrank=max(rank.values(),default=0)
    layers=defaultdict(list)
    for i in ids: layers[rank[i]].append(i)
    # barycentric sweeps
    pos={i:k for r in layers for k,i in enumerate(layers[r])}
    for _ in range(5):
        for r in range(1,maxrank+1):
            layers[r].sort(key=lambda x:(sum(pos[p] for p in incoming[x])/len(incoming[x]) if incoming[x] else pos[x],x)); pos.update({x:k for k,x in enumerate(layers[r])})
        for r in range(maxrank-1,-1,-1):
            layers[r].sort(key=lambda x:(sum(pos[p] for p in outgoing[x])/len(outgoing[x]) if outgoing[x] else pos[x],x)); pos.update({x:k for k,x in enumerate(layers[r])})
    node={n.id:n for n in d.nodes}; boxes={}
    horizontal=d.direction not in {'TB','TD','BT'}
    layer_origin={}
    main=0.0
    for r in range(maxrank+1):
        layer_origin[r]=main
        if horizontal:
            extent=max((node[nid].width for nid in layers[r]),default=0)
        else:
            extent=max((node[nid].height for nid in layers[r]),default=0)
        main+=extent+cfg['rank_gap']
    for r in range(maxrank+1):
        cursor=0.0
        for nid in layers[r]:
            n=node[nid]
            if horizontal:
                boxes[nid]=Box(layer_origin[r],cursor,n.width,n.height); cursor+=n.height+cfg['node_gap']
            else:
                boxes[nid]=Box(cursor,layer_origin[r],n.width,n.height); cursor+=n.width+cfg['node_gap']
    return boxes



def _resolve_group_overlaps(d: Diagram, boxes: dict[str,Box], pad: float) -> None:
    groups={g.id:g for g in d.groups}
    if len(groups)<2:
        return
    children=defaultdict(list)
    direct_nodes=defaultdict(set)
    for g in d.groups:
        if g.parent in groups:
            children[g.parent].append(g.id)
    for n in d.nodes:
        if n.group in groups:
            direct_nodes[n.group].add(n.id)

    memo={}
    def subtree_nodes(gid):
        if gid in memo: return memo[gid]
        out=set(direct_nodes.get(gid,set()))
        for cid in children.get(gid,[]): out.update(subtree_nodes(cid))
        memo[gid]=out; return out
    for gid in groups: subtree_nodes(gid)

    siblings=defaultdict(list)
    for g in d.groups:
        siblings[g.parent if g.parent in groups else None].append(g.id)
    gap=max(16.0,pad*.35)

    def overlap(a:Box,b:Box,extra=0.0):
        ox=min(a.x+a.w,b.x+b.w)-max(a.x,b.x)
        oy=min(a.y+a.h,b.y+b.h)-max(a.y,b.y)
        return max(0.0,ox+extra)*max(0.0,oy+extra)

    for _ in range(80):
        gb=_groups(d,boxes,pad)
        conflicts=[]
        for ids in siblings.values():
            ids=[gid for gid in ids if gid in gb]
            for i,a in enumerate(ids):
                for b in ids[i+1:]:
                    area=overlap(gb[a],gb[b])
                    if area>1e-6: conflicts.append((area,a,b))
        if not conflicts:
            return
        _,ga,gbid=max(conflicts)
        # Prefer moving the smaller subtree; ties move the later declaration.
        na,nb=len(memo[ga]),len(memo[gbid])
        mover,fixed=(ga,gbid) if na<nb else (gbid,ga)
        mb,fb=gb[mover],gb[fixed]
        candidates=[
            (fb.x+fb.w+gap-mb.x,0.0),
            (fb.x-gap-(mb.x+mb.w),0.0),
            (0.0,fb.y+fb.h+gap-mb.y),
            (0.0,fb.y-gap-(mb.y+mb.h)),
        ]
        best=None
        for dx,dy in candidates:
            moved=Box(mb.x+dx,mb.y+dy,mb.w,mb.h)
            secondary=0.0
            for oid,ob in gb.items():
                if oid in {mover,fixed}: continue
                # Only sibling boundaries are true mutually exclusive zones.
                og=groups.get(oid)
                mg=groups.get(mover)
                if og and mg and (og.parent if og.parent in groups else None)==(mg.parent if mg.parent in groups else None):
                    secondary += overlap(moved,ob)
            # Keep LR flows mostly horizontal and TB flows mostly vertical by
            # preferring displacement on the cross-flow axis when equivalent.
            axis_weight = (1.12 if dx else .88) if d.direction not in {'TB','TD','BT'} else (.88 if dx else 1.12)
            score=(abs(dx)+abs(dy))*axis_weight + secondary*1000.0
            if best is None or score<best[0]: best=(score,dx,dy)
        _,dx,dy=best
        for nid in memo[mover]:
            if nid in boxes:
                boxes[nid].x+=dx; boxes[nid].y+=dy

def _groups(d,boxes,pad):
    group_map={g.id:g for g in d.groups}; children=defaultdict(list)
    for n in d.nodes:
        if n.group: children[n.group].append(n.id)
    # nested groups derive from child group boxes iteratively
    result={}
    remaining=set(group_map)
    for _ in range(len(remaining)+2):
        progressed=False
        for gid in list(remaining):
            members=[boxes[n] for n in children[gid] if n in boxes]
            child_groups=[b for cid,b in result.items() if group_map.get(cid) and group_map[cid].parent==gid]
            members+=child_groups
            unresolved=any(group_map[cid].parent==gid and cid not in result for cid in group_map)
            # A parent boundary must not be finalized until *all* child
            # boundaries have been computed.  The previous condition allowed a
            # parent with direct member nodes to be measured too early, so it
            # could fail to enclose later child zones.
            if unresolved: continue
            if members:
                minx=min(b.x for b in members)-pad; miny=min(b.y for b in members)-pad-22
                maxx=max(b.x+b.w for b in members)+pad; maxy=max(b.y+b.h for b in members)+pad
                result[gid]=Box(minx,miny,maxx-minx,maxy-miny)
            else: result[gid]=Box(0,0,260,160)
            remaining.remove(gid); progressed=True
        if not progressed: break
    return result
