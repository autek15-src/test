from __future__ import annotations

"""Semantic architecture shape and provider/service inference.

The semantic catalog is adapted from the MIT-licensed OfficeIMO.Visio stencil
families.  v1.3.1 adds a provider-aware recognizer so ordinary PlantUML labels
such as ``DynamoDB``, ``APIGW``, ``SFDC``, ``Azure APIM`` or ``GCP Pub/Sub`` can
be classified without renderer-specific node types.

The module deliberately separates *what a node means* from *how it is drawn*.
Provider/service recognition can select an official icon when an icon catalog is
available, while the semantic registry provides a deterministic professional
fallback and a bundled generic pictogram.
"""

from dataclasses import dataclass
import re


@dataclass(frozen=True)
class SemanticShape:
    key: str
    geometry: str
    category: str
    aliases: tuple[str, ...] = ()
    icon: str | None = None
    fill: str = "#F7F9FB"
    stroke: str = "#59636E"


@dataclass(frozen=True)
class ProviderMatch:
    provider: str
    service: str
    semantic_key: str
    icon: str | None
    reason: str
    confidence: str = "high"


def _s(key, geometry, category, *aliases, icon=None, fill="#F7F9FB", stroke="#59636E"):
    return SemanticShape(key, geometry, category, tuple(aliases), icon, fill, stroke)


SHAPES: dict[str, SemanticShape] = {
    "actor": _s("actor", "actor", "architecture", "user", "person", "client", "staff", icon="user", fill="#FFFFFF"),
    "service": _s("service", "service", "architecture", "app", "application", "microservice", "business-service", icon="braces", fill="#EEF4FA"),
    "api": _s("api", "api", "architecture", "rest", "rest-api", "graphql", "endpoint", "web-api", icon="api", fill="#EAF4FF", stroke="#3975A6"),
    "compute": _s("compute", "server", "architecture", "vm", "host", "worker", "machine", "instance", icon="server", fill="#F1F5F8"),
    "server": _s("server", "server", "infrastructure", "host", "vm", "node", "machine", icon="server", fill="#F1F5F8"),
    "gateway": _s("gateway", "gateway", "architecture", "ingress", "endpoint-gateway", "proxy", "reverse-proxy", icon="route", fill="#FFF4E5", stroke="#9C6A22"),
    "api_gateway": _s("api_gateway", "gateway", "architecture", "api-gateway", "api gateway", "apigw", "api gw", "edge-gateway", icon="api", fill="#FFF0D8", stroke="#9C6A22"),
    "load_balancer": _s("load_balancer", "load_balancer", "infrastructure", "load-balancer", "lb", "alb", "nlb", "elb", "traffic-manager", icon="arrows-split", fill="#FFF4E5", stroke="#9C6A22"),
    "database": _s("database", "database", "data", "db", "sql", "relational", "data-store", "datastore", icon="database", fill="#FFFBEA", stroke="#8A7430"),
    "storage": _s("storage", "storage", "data", "blob", "disk", "san", "nas", "backup", "archive", icon="database", fill="#F5F1FF", stroke="#70569A"),
    "object_storage": _s("object_storage", "object_storage", "data", "object-store", "bucket", "blob-storage", "s3", icon="database", fill="#F5F1FF", stroke="#70569A"),
    "file_storage": _s("file_storage", "folder", "data", "file-store", "filesystem", "file-system", "efs", "nfs", icon="folder", fill="#F5F1FF", stroke="#70569A"),
    "cache": _s("cache", "cache", "data", "redis", "memcached", "elasticache", "in-memory", icon="database", fill="#FFF0F0", stroke="#9B4A4A"),
    "queue": _s("queue", "queue", "messaging", "message-queue", "broker", "mq", "sqs", "queueing", icon="messages", fill="#F0F8F5", stroke="#4F806B"),
    "topic": _s("topic", "event_bus", "messaging", "pubsub", "pub-sub", "sns", "topic", icon="messages", fill="#F0F8F5", stroke="#4F806B"),
    "event_bus": _s("event_bus", "event_bus", "messaging", "event-bus", "eventbridge", "events", icon="activity", fill="#F0F8F5", stroke="#4F806B"),
    "stream": _s("stream", "stream", "data", "event-stream", "kafka", "kinesis", "streaming", icon="activity", fill="#F0F8F5", stroke="#4F806B"),
    "function": _s("function", "function", "cloud", "serverless", "lambda", "function-app", "faas", icon="braces", fill="#FFF4E5", stroke="#9C6A22"),
    "workflow": _s("workflow", "workflow", "architecture", "orchestration", "step-functions", "state-machine", icon="binary-tree", fill="#F4F0FA", stroke="#73578E"),
    "scheduler": _s("scheduler", "service", "architecture", "cron", "schedule", "timer", icon="clock", fill="#EEF4FA"),
    "security": _s("security", "security", "security", "policy", "guard", "protection", icon="shield-lock", fill="#FFF0F0", stroke="#9B4A4A"),
    "firewall": _s("firewall", "firewall", "security", "waf", "acl", "network-security", "firewall-policy", icon="shield-lock", fill="#FFF0F0", stroke="#9B4A4A"),
    "identity": _s("identity", "identity", "security", "identity-provider", "idp", "oauth", "oidc", "saml", "okta", "cognito", "entra", "azure-ad", icon="key", fill="#FFF0F0", stroke="#9B4A4A"),
    "secret_store": _s("secret_store", "secret", "security", "secret", "secrets", "vault", "key-vault", "secrets-manager", "credential", icon="key", fill="#FFF0F0", stroke="#9B4A4A"),
    "network": _s("network", "network", "network", "subnet-service", "vnet-service", "route", icon="network", fill="#EFF7F2", stroke="#4F806B"),
    "router": _s("router", "router", "network", "route", "routing", "transit-gateway", "tgw", icon="route", fill="#EFF7F2", stroke="#4F806B"),
    "switch": _s("switch", "switch", "network", "hub", "lan", icon="network", fill="#EFF7F2", stroke="#4F806B"),
    "internet": _s("internet", "internet", "network", "wan", "internet", "public-internet", icon="world", fill="#EDF5FF", stroke="#4B77A5"),
    "external": _s("external", "external", "architecture", "external-system", "third-party", "partner", "saas", "crm", icon="cloud", fill="#FAFAFA", stroke="#70777F"),
    "cloud": _s("cloud", "cloud", "cloud", "cloud-service", "managed-service", "paas", icon="cloud", fill="#EDF5FF", stroke="#4B77A5"),
    "monitoring": _s("monitoring", "monitoring", "operations", "observability", "metrics", "telemetry", "apm", icon="activity", fill="#F3F5F7", stroke="#65717C"),
    "logging": _s("logging", "logging", "operations", "logs", "log", "audit-log", icon="file", fill="#F3F5F7", stroke="#65717C"),
    "notification": _s("notification", "notification", "messaging", "notify", "alert", "alerts", icon="message", fill="#F0F8F5", stroke="#4F806B"),
    "email": _s("email", "email", "messaging", "mail", "smtp", "email-service", icon="mail", fill="#F0F8F5", stroke="#4F806B"),
    "browser": _s("browser", "browser", "client", "web-client", "web-ui", "frontend", icon="browser", fill="#F7F9FB"),
    "mobile": _s("mobile", "mobile", "client", "mobile-client", "mobile-app", "phone", icon="device-mobile", fill="#F7F9FB"),
    "workstation": _s("workstation", "server", "client", "desktop", "laptop", "endpoint", icon="device-desktop", fill="#F7F9FB"),
    "folder": _s("folder", "folder", "data", "directory", icon="folder", fill="#FFF8E7", stroke="#9A7B33"),
    "file": _s("file", "document", "data", "document", "artifact", icon="file", fill="#FFFDF6", stroke="#7C7462"),
    "container": _s("container", "container", "platform", "docker", "runtime", "container-runtime", icon="box", fill="#EEF6FF", stroke="#4C79A5"),
    "kubernetes": _s("kubernetes", "cluster", "platform", "k8s", "cluster", "eks", "aks", "gke", icon="hexagon", fill="#EEF6FF", stroke="#4C79A5"),
    "pod": _s("pod", "pod", "platform", "k8s-pod", "workload", icon="hexagon", fill="#EEF6FF", stroke="#4C79A5"),
    "mainframe": _s("mainframe", "server", "infrastructure", "mainframe", "zos", "z/os", icon="server", fill="#F1F5F8"),
}


TECHNOLOGIES: dict[str, tuple[str, str | None]] = {
    "postgresql": ("database", "postgresql"), "postgres": ("database", "postgresql"), "pgsql": ("database", "postgresql"),
    "mysql": ("database", "mysql"), "mariadb": ("database", "mysql"), "mongodb": ("database", "mongodb"),
    "oracle db": ("database", None), "oracle database": ("database", None), "sql server": ("database", None), "mssql": ("database", None),
    "redis": ("cache", "redis"), "memcached": ("cache", None), "kafka": ("stream", "apachekafka"), "rabbitmq": ("queue", None),
    "nginx": ("gateway", "nginx"), "docker": ("container", "docker"), "kubernetes": ("kubernetes", "kubernetes"), "k8s": ("kubernetes", "kubernetes"),
    "snowflake": ("database", None), "elasticsearch": ("database", None), "opensearch": ("database", None),
}

# Canonical AWS service -> semantic body. Unlisted recognized AWS services use
# ``cloud`` rather than becoming a generic application card.
AWS_MAP: dict[str, str] = {
    "lambda":"function", "api_gateway":"api_gateway", "appsync":"api", "ec2":"compute", "ecs":"container", "eks":"kubernetes", "fargate":"container",
    "batch":"compute", "elastic_beanstalk":"compute", "app_runner":"container", "ecr":"storage",
    "rds":"database", "aurora":"database", "dynamodb":"database", "documentdb":"database", "neptune":"database", "redshift":"database", "timestream":"database", "keyspaces":"database", "qldb":"database",
    "s3":"object_storage", "efs":"file_storage", "fsx":"file_storage", "storage_gateway":"storage", "backup":"storage", "snow_family":"storage", "transfer_family":"file_storage",
    "elasticache":"cache", "memorydb":"cache", "sqs":"queue", "sns":"topic", "eventbridge":"event_bus", "mq":"queue", "msk":"stream", "kinesis":"stream", "firehose":"stream", "step_functions":"workflow", "mwaa":"workflow",
    "elastic_load_balancing":"load_balancer", "application_load_balancer":"load_balancer", "network_load_balancer":"load_balancer", "gateway_load_balancer":"load_balancer",
    "cloudfront":"gateway", "route53":"network", "vpc":"network", "subnet":"network", "internet_gateway":"gateway", "nat_gateway":"gateway", "transit_gateway":"router", "private_link":"network", "vpc_endpoint":"network", "direct_connect":"network", "site_to_site_vpn":"network", "client_vpn":"network", "global_accelerator":"network", "cloud_map":"network", "app_mesh":"network",
    "waf":"firewall", "network_firewall":"firewall", "iam":"identity", "cognito":"identity", "kms":"security", "secrets_manager":"secret_store", "certificate_manager":"security", "shield":"security", "guardduty":"security", "security_hub":"security", "inspector":"security", "macie":"security", "detective":"security", "firewall_manager":"firewall",
    "cloudwatch":"monitoring", "xray":"monitoring", "cloudtrail":"logging", "config":"monitoring", "systems_manager":"monitoring", "parameter_store":"secret_store", "managed_grafana":"monitoring", "managed_prometheus":"monitoring",
    "ses":"email", "pinpoint":"notification", "glue":"workflow", "athena":"database", "emr":"compute", "opensearch":"database", "lake_formation":"storage", "quicksight":"service", "dms":"workflow", "datasync":"workflow", "bedrock":"service", "sagemaker":"compute",
}

# High-signal AWS aliases are intentionally usable without the words AWS/Amazon.
# Generic words such as "queue", "monitoring" or "instance" are excluded to
# prevent ordinary architecture nodes from being falsely tagged as AWS.
AWS_ALIASES: dict[str, tuple[str, ...]] = {
    "api_gateway": ("aws api gateway","amazon api gateway","api gw","apigw","execute api","execute-api"),
    "lambda": ("lambda","lambda function","lambda fn"),
    "ec2": ("ec2","amazon ec2"), "ecs": ("ecs","amazon ecs"), "eks": ("eks","amazon eks"), "ecr": ("ecr","amazon ecr"), "fargate": ("fargate",),
    "s3": ("s3","amazon s3"), "efs": ("efs","amazon efs"), "fsx": ("fsx",),
    "rds": ("rds","amazon rds"), "aurora": ("aurora","aurora postgres","aurora postgresql","aurora mysql"), "dynamodb": ("dynamodb","dynamo db","dynamo-db","dynamo","ddb"),
    "documentdb": ("documentdb","document db"), "neptune": ("amazon neptune","neptune db"), "elasticache": ("elasticache","elasti cache"), "memorydb": ("memorydb","memory db"), "redshift": ("redshift",),
    "sqs": ("sqs","amazon sqs"), "sns": ("sns","amazon sns"), "eventbridge": ("eventbridge","event bridge"), "step_functions": ("step functions","stepfunctions","sfn","step fn","step funcs"),
    "mq": ("amazon mq",), "msk": ("msk","amazon msk"), "kinesis": ("kinesis",), "firehose": ("firehose","data firehose"),
    "application_load_balancer": ("application load balancer","alb"), "network_load_balancer": ("network load balancer","nlb"), "gateway_load_balancer": ("gateway load balancer","gwlb"), "elastic_load_balancing": ("elastic load balancing","elb"),
    "cloudfront": ("cloudfront","cloud front"), "route53": ("route53","route 53"), "vpc": ("vpc",), "internet_gateway": ("internet gateway","igw"), "nat_gateway": ("nat gateway","natgw"), "transit_gateway": ("transit gateway","tgw"), "private_link": ("privatelink","private link"), "direct_connect": ("direct connect","aws dx"),
    "waf": ("aws waf",), "iam": ("aws iam",), "cognito": ("cognito",), "kms": ("aws kms","kms"), "secrets_manager": ("secrets manager","aws secrets manager"),
    "cloudwatch": ("cloudwatch","cloud watch"), "xray": ("x-ray","xray","aws xray"), "cloudtrail": ("cloudtrail","cloud trail"), "systems_manager": ("systems manager","aws ssm"), "parameter_store": ("parameter store","ssm parameter store"),
    "bedrock": ("bedrock","amazon bedrock"), "sagemaker": ("sagemaker","sage maker"), "glue": ("aws glue",), "athena": ("athena",), "emr": ("emr",), "opensearch": ("opensearch","open search"), "ses": ("ses","amazon ses"),
}

AZURE_MAP: dict[str, tuple[str, tuple[str, ...]]] = {
    "api_management": ("api_gateway", ("azure api management","api management","apim")),
    "functions": ("function", ("azure functions","azure function","function app")),
    "app_service": ("service", ("azure app service","app service")),
    "aks": ("kubernetes", ("aks","azure kubernetes service")),
    "container_apps": ("container", ("azure container apps","container apps")),
    "service_bus": ("queue", ("azure service bus","service bus")),
    "event_grid": ("event_bus", ("azure event grid","event grid")),
    "event_hubs": ("stream", ("azure event hubs","event hubs")),
    "blob_storage": ("object_storage", ("azure blob","blob storage","azure storage blob")),
    "files": ("file_storage", ("azure files","azure file share")),
    "sql_database": ("database", ("azure sql","azure sql database")),
    "cosmos_db": ("database", ("cosmos db","cosmosdb")),
    "entra_id": ("identity", ("entra id","microsoft entra","azure ad","aad")),
    "key_vault": ("secret_store", ("azure key vault","key vault")),
    "application_insights": ("monitoring", ("application insights","app insights")),
}

GCP_MAP: dict[str, tuple[str, tuple[str, ...]]] = {
    "apigee": ("api_gateway", ("apigee",)), "api_gateway": ("api_gateway", ("gcp api gateway","google api gateway")),
    "cloud_functions": ("function", ("cloud functions","gcp functions","google cloud functions")), "cloud_run": ("container", ("cloud run","gcp cloud run")),
    "gke": ("kubernetes", ("gke","google kubernetes engine")), "compute_engine": ("compute", ("compute engine","gce")),
    "cloud_storage": ("object_storage", ("google cloud storage","gcp storage","gcs")), "cloud_sql": ("database", ("cloud sql","gcp cloud sql")),
    "spanner": ("database", ("cloud spanner","spanner")), "bigtable": ("database", ("bigtable","cloud bigtable")), "bigquery": ("database", ("bigquery","big query")),
    "pubsub": ("topic", ("pub/sub","pubsub","google pub sub")), "eventarc": ("event_bus", ("eventarc",)),
    "secret_manager": ("secret_store", ("gcp secret manager","google secret manager")), "cloud_monitoring": ("monitoring", ("cloud monitoring","stackdriver")),
}

# SaaS/enterprise technology recognition. These entries intentionally choose a
# semantic icon when a vendor logo pack is not available.
VENDOR_MAP: dict[str, tuple[str, tuple[str, ...], str | None]] = {
    "salesforce": ("external", ("salesforce","sfdc","sf crm","salesforce crm","my.salesforce.com","force.com","platform event"), "cloud"),
    "okta": ("identity", ("okta",), "key"),
    "hashicorp_vault": ("secret_store", ("hashicorp vault","vault approle","vault app role"), "key"),
    "splunk": ("monitoring", ("splunk","splunk observability"), "activity"),
    "mulesoft": ("service", ("mulesoft","mule soft","anypoint","mule runtime"), "braces"),
    "sap": ("external", ("sap s/4","sap s4","s/4hana","s4hana","sap hana","sap crm","sap ecc","sap"), "cloud"),
    "snowflake": ("database", ("snowflake",), "database"),
    "datadog": ("monitoring", ("datadog",), "activity"),
    "new_relic": ("monitoring", ("new relic",), "activity"),
    "github": ("external", ("github","github.com"), "cloud"),
}

TYPE_MAP = {
    "actor":"actor", "person":"actor", "user":"actor", "component":"service", "system":"service", "application":"service", "service":"service",
    "interface":"api", "api":"api", "database":"database", "storage":"storage", "queue":"queue", "cloud":"cloud", "node":"server", "server":"server",
    "artifact":"file", "file":"file", "folder":"folder", "container":"container", "hexagon":"function", "boundary":"external", "entity":"service", "control":"service",
}


def _norm(value: str) -> str:
    value = value.strip().lower().replace("::", ".")
    value = re.sub(r"[^a-z0-9]+", "_", value)
    return re.sub(r"_+", "_", value).strip("_")


def _tokens(*values: str) -> str:
    return " ".join(v.lower().replace("_", " ").replace("-", " ") for v in values if v)


def _contains(hay: str, alias: str) -> bool:
    a = alias.lower().replace("_", " ").replace("-", " ")
    a = re.sub(r"\s+", " ", a).strip()
    h = re.sub(r"\s+", " ", hay.lower().replace("_", " ").replace("-", " "))
    if not a:
        return False
    if re.search(rf"(?<![a-z0-9]){re.escape(a)}(?![a-z0-9])", h):
        return True
    # Only punctuation-rich aliases need a punctuation-stripped fallback. Do
    # not collapse ordinary whitespace, otherwise "api MFA" can accidentally
    # become the Azure acronym "APIM".
    raw_alias=alias.lower()
    if any(ch in raw_alias for ch in './:'):
        an = re.sub(r"[^a-z0-9]+", "", raw_alias)
        hn = re.sub(r"[^a-z0-9]+", "", hay.lower())
        return len(an) >= 4 and an in hn
    return False


def _best_alias_match(hay: str, mapping: dict[str, tuple[str, ...]]) -> tuple[str, str] | None:
    candidates: list[tuple[int, str, str]] = []
    for service, aliases in mapping.items():
        for alias in aliases:
            if _contains(hay, alias):
                candidates.append((len(re.sub(r"\W", "", alias)), service, alias))
    if not candidates:
        return None
    _, svc, alias = max(candidates)
    return svc, alias


def resolve_provider(node_type: str, label: str, metadata: dict | None = None) -> ProviderMatch | None:
    """Recognize the node's *primary* cloud/vendor identity.

    The first label line is treated as the component name. Mentions found only
    in descriptive lines (for example "runs on EKS" or "uses Okta JWT") are
    returned with ``confidence='context'`` so they do not hijack the component's
    semantic shape or visual icon.
    """
    metadata = metadata or {}
    explicit_provider = str(metadata.get("provider") or "").strip().lower()
    explicit_service = str(metadata.get("providerService") or metadata.get("provider_service") or "").strip()
    first_line=(label or '').splitlines()[0] if label else ''
    primary_hay = _tokens(node_type, first_line, explicit_service)
    full_hay = _tokens(node_type, label, explicit_service)
    t = (node_type or "").strip().lower()

    def aws_match(hay, confidence='high'):
        hit=_best_alias_match(hay,AWS_ALIASES)
        if not hit:return None
        svc,alias=hit; key=AWS_MAP.get(svc,'cloud')
        return ProviderMatch('aws',svc,key,SHAPES[key].icon,f"AWS alias {alias}",confidence)

    def azure_match(hay, confidence='high'):
        hint = explicit_provider in {"azure","microsoft azure"} or _contains(hay,"azure")
        for svc,(key,aliases) in AZURE_MAP.items():
            matches=[a for a in aliases if _contains(hay,a)]
            if matches and (hint or any(a in {"apim","aks","cosmos db","cosmosdb","entra id","aad"} for a in matches)):
                alias=max(matches,key=len);return ProviderMatch('azure',svc,key,SHAPES[key].icon,f"Azure alias {alias}",confidence)
        return None

    def gcp_match(hay, confidence='high'):
        hint = explicit_provider in {"gcp","google","google cloud"} or any(_contains(hay,x) for x in ("gcp","google cloud"))
        for svc,(key,aliases) in GCP_MAP.items():
            matches=[a for a in aliases if _contains(hay,a)]
            if matches and (hint or any(a in {"gke","gce","gcs","bigquery","big query","apigee","pub/sub","pubsub","cloud run"} for a in matches)):
                alias=max(matches,key=len);return ProviderMatch('gcp',svc,key,SHAPES[key].icon,f"GCP alias {alias}",confidence)
        return None

    def vendor_match(hay, confidence='high'):
        for vendor,(key,aliases,icon) in VENDOR_MAP.items():
            matches=[a for a in aliases if _contains(hay,a)]
            if matches:
                alias=max(matches,key=len)
                if re.search(r"(?<![a-z0-9])api(?![a-z0-9])", hay) or "sys api" in hay or "ext api" in hay:
                    return ProviderMatch(vendor,vendor,'api',SHAPES['api'].icon,f"vendor {vendor} + API label ({alias})",confidence)
                return ProviderMatch(vendor,vendor,key,icon,f"vendor alias {alias}",confidence)
        return None

    if t.startswith("aws.") or explicit_provider in {"aws","amazon","amazon web services"}:
        svc=_norm(t.split('.',1)[1] if t.startswith('aws.') else explicit_service)
        if not svc:
            hit=_best_alias_match(full_hay,AWS_ALIASES);svc=hit[0] if hit else 'cloud_service'
        key=AWS_MAP.get(svc,'cloud')
        return ProviderMatch('aws',svc,key,SHAPES[key].icon,'explicit AWS provider/type','high')
    if explicit_provider in {"azure","microsoft azure"}:
        return azure_match(full_hay,'high') or ProviderMatch('azure',_norm(explicit_service) or 'cloud_service','cloud','cloud','explicit Azure provider','high')
    if explicit_provider in {"gcp","google","google cloud"}:
        return gcp_match(full_hay,'high') or ProviderMatch('gcp',_norm(explicit_service) or 'cloud_service','cloud','cloud','explicit GCP provider','high')

    # Primary-name recognition. Vendor names are checked before deployment
    # providers so "okta-sys-api (HIP10 EKS)" remains an Okta API, not an EKS node.
    for fn in (vendor_match,aws_match,azure_match,gcp_match):
        hit=fn(primary_hay,'high')
        if hit:return hit

    # Descriptive references are useful in reports but must not drive the shape.
    for fn in (vendor_match,aws_match,azure_match,gcp_match):
        hit=fn(full_hay,'context')
        if hit:return hit
    return None


def resolve_semantic(node_type: str, label: str, metadata: dict | None = None) -> tuple[SemanticShape, str | None, str]:
    metadata = metadata or {}
    explicit = metadata.get("semantic") or metadata.get("shapeKind") or metadata.get("shape_kind")
    if explicit:
        key = _norm(str(explicit))
        if key in SHAPES:
            return SHAPES[key], _technology_icon(label), "explicit semantic metadata"

    t = _norm(node_type or "component")
    if t in SHAPES:
        return SHAPES[t], _technology_icon(label), "exact semantic type"

    provider = resolve_provider(node_type, label, metadata)
    if provider and provider.confidence == "high" and provider.semantic_key in SHAPES:
        return SHAPES[provider.semantic_key], _technology_icon(label), provider.reason

    hay = _tokens(node_type, label)
    for tech, (key, icon) in TECHNOLOGIES.items():
        if _contains(hay, tech):
            return SHAPES[key], icon, f"technology match {tech}"

    ordered = [
        ("api gateway","api_gateway"),("gateway api","api_gateway"),("load balancer","load_balancer"),("reverse proxy","gateway"),
        ("message queue","queue"),("event bus","event_bus"),("identity provider","identity"),("secret store","secret_store"),
        ("object storage","object_storage"),("file storage","file_storage"),("data lake","storage"),("data warehouse","storage"),
        ("web browser","browser"),("mobile app","mobile"),("external system","external"),("crm","external"),
    ]
    for phrase,key in ordered:
        if phrase in hay:
            return SHAPES[key], _technology_icon(label), f"label phrase {phrase}"
    if re.search(r"(?<![a-z0-9])api(?![a-z0-9])", hay):
        return SHAPES["api"], _technology_icon(label), "API label token"

    if t in TYPE_MAP:
        return SHAPES[TYPE_MAP[t]], _technology_icon(label), f"type mapping {t}"

    candidates: list[tuple[int, SemanticShape, str]] = []
    for shape in SHAPES.values():
        for alias in shape.aliases:
            if _contains(hay, alias):
                candidates.append((len(alias), shape, alias))
    if candidates:
        _, shape, alias = max(candidates, key=lambda x: x[0])
        return shape, _technology_icon(label), f"semantic alias {alias}"
    return SHAPES["service"], _technology_icon(label), "generic service fallback"


def _technology_icon(label: str) -> str | None:
    hay = (label or "").lower()
    for tech, (_, icon) in TECHNOLOGIES.items():
        if icon and _contains(hay, tech):
            return icon
    return None


def list_semantic_shapes() -> list[SemanticShape]:
    return sorted(SHAPES.values(), key=lambda s: (s.category, s.key))
