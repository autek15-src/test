from __future__ import annotations
import argparse, json
from pathlib import Path
from .render import render
from .validate import validate_vsdx
from .parsers import parse_diagram
from .stencil import inspect_stencil
from .icons import AwsIconCatalog, index_aws_icons
from .semantic import list_semantic_shapes
from .builtin_icons import list_builtin_icons


def main(argv=None):
    ap=argparse.ArgumentParser(prog='arch2visio',description='Render architecture JSON, Mermaid or PlantUML to editable VSDX')
    sp=ap.add_subparsers(dest='cmd')
    r=sp.add_parser('render')
    r.add_argument('input'); r.add_argument('-o','--output',required=True)
    r.add_argument('--template'); r.add_argument('--stencil'); r.add_argument('--master-map')
    r.add_argument('--aws-icons-dir', help='Root of an AWS Architecture Icons PNG/SVG collection')
    r.add_argument('--aws-icon-index', help='Optional explicit path for the cached AWS icon index JSON')
    r.add_argument('--aws-aliases', help='Optional JSON file extending built-in AWS service aliases')
    r.add_argument('--refresh-aws-icon-index', action='store_true', help='Force rebuilding the AWS icon index before rendering')
    r.add_argument('--layout-engine',choices=['auto','graphviz','layered']); r.add_argument('--report')
    v=sp.add_parser('validate'); v.add_argument('vsdx'); v.add_argument('--libreoffice',action='store_true')
    n=sp.add_parser('normalize'); n.add_argument('input'); n.add_argument('-o','--output',required=True)
    s=sp.add_parser('inspect-stencil'); s.add_argument('stencil')
    ai=sp.add_parser('index-aws-icons', help='Scan and cache a user-supplied AWS Architecture Icons tree')
    ai.add_argument('directory'); ai.add_argument('-o','--output',help='Explicit index JSON path; otherwise use the user cache')
    ai.add_argument('--aliases',help='Optional JSON file extending built-in service aliases')
    ai.add_argument('--force',action='store_true'); ai.add_argument('--entries',action='store_true',help='Include every indexed entry in the printed report')
    ar=sp.add_parser('resolve-aws-icon', help='Explain which indexed AWS icon would be selected')
    ar.add_argument('directory'); ar.add_argument('node_type'); ar.add_argument('--label'); ar.add_argument('--index'); ar.add_argument('--aliases'); ar.add_argument('--force',action='store_true')
    sp.add_parser('list-shapes', help='List built-in semantic architecture shapes and aliases')
    sp.add_parser('list-icons', help='List bundled generic Tabler icon names')
    args=ap.parse_args(argv)
    if not args.cmd:
        ap.print_help(); return 2
    if args.cmd=='render':
        rep=render(args.input,args.output,template=args.template,stencil=args.stencil,master_map=args.master_map,
                   aws_icons_dir=args.aws_icons_dir,aws_icon_index=args.aws_icon_index,aws_aliases=args.aws_aliases,
                   refresh_aws_icon_index=args.refresh_aws_icon_index,layout_engine=args.layout_engine,report=args.report)
        print(json.dumps(rep,indent=2)); return 0
    if args.cmd=='validate':
        rep=validate_vsdx(args.vsdx,args.libreoffice); print(json.dumps(rep,indent=2)); return 0 if rep['ok'] else 1
    if args.cmd=='normalize':
        d=parse_diagram(args.input); data={'title':d.title,'direction':d.direction,'groups':[g.__dict__ for g in d.groups],'nodes':[n.__dict__ for n in d.nodes],'edges':[e.__dict__ for e in d.edges],'layout':d.layout}; Path(args.output).write_text(json.dumps(data,indent=2),encoding='utf-8'); return 0
    if args.cmd=='inspect-stencil':
        print(json.dumps(inspect_stencil(args.stencil),indent=2)); return 0
    if args.cmd=='index-aws-icons':
        print(json.dumps(index_aws_icons(args.directory,cache_path=args.output,force=args.force,aliases_path=args.aliases,include_entries=args.entries),indent=2)); return 0
    if args.cmd=='resolve-aws-icon':
        catalog=AwsIconCatalog.from_directory(args.directory,cache_path=args.index,force=args.force,aliases_path=args.aliases)
        path, detail=catalog.resolve(args.node_type,args.label,explain=True)
        print(json.dumps({'path':str(path) if path else None,'detail':detail},indent=2)); return 0 if path else 1
    if args.cmd=='list-shapes':
        print(json.dumps([{'key':x.key,'geometry':x.geometry,'category':x.category,'aliases':list(x.aliases),'icon':x.icon} for x in list_semantic_shapes()],indent=2)); return 0
    if args.cmd=='list-icons':
        print(json.dumps({'pack':'Tabler Icons','license':'MIT','icons':list_builtin_icons()},indent=2)); return 0
    return 2

if __name__=='__main__': raise SystemExit(main())
