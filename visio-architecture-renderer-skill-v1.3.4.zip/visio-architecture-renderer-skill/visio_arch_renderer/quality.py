from __future__ import annotations
from .routing import route_metrics

def _box_overlap(a,b):
    return min(a.x+a.w,b.x+b.w)>max(a.x,b.x) and min(a.y+a.h,b.y+b.h)>max(a.y,b.y)

def score_layout(layout,routes,diagram=None):
    m=route_metrics(routes,layout.boxes); aspect=max(layout.width/layout.height,layout.height/layout.width)
    # Group boundaries are expected to represent mutually exclusive zones. The
    # layout resolver should eliminate all sibling/top-level overlap; retain a
    # metric and hard score penalty as a regression guard.
    group_overlaps=0
    if diagram is not None:
        groups={g.id:g for g in diagram.groups}
        ids=[gid for gid in layout.group_boxes if gid in groups]
        for i,ga in enumerate(ids):
            pa=groups[ga].parent if groups[ga].parent in groups else None
            for gb in ids[i+1:]:
                pb=groups[gb].parent if groups[gb].parent in groups else None
                if pa==pb and _box_overlap(layout.group_boxes[ga],layout.group_boxes[gb]):
                    group_overlaps+=1
    m['groupOverlaps']=group_overlaps
    area=(layout.width*layout.height)/100000.0
    score=(
        m['diagonalSegments']*5000 +
        m.get('nodeIntersections',0)*20000 +
        m.get('groupOverlaps',0)*15000 +
        m['crossings']*1000 +
        m['fallbacks']*500 +
        m.get('overlaps',0)*120 +
        m['bends']*3 +
        max(0,aspect-2.2)*20 + area*.08
    )
    return score,{**m,'width':round(layout.width,1),'height':round(layout.height,1),'aspect':round(aspect,2),'score':round(score,2),'engine':layout.engine}
