from __future__ import annotations
import json, os, posixpath, re, shutil, signal, subprocess, tempfile, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET

V='http://schemas.microsoft.com/office/visio/2012/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
CT='http://schemas.openxmlformats.org/package/2006/content-types'


def _rels_name(part: str) -> str:
    d, b = posixpath.split(part)
    return posixpath.join(d, '_rels', b + '.rels')


def _resolve_target(source_part: str, target: str) -> str:
    return posixpath.normpath(posixpath.join(posixpath.dirname(source_part), target)).lstrip('/')


def _rels_by_id(z, names, source_part: str):
    relpart=_rels_name(source_part)
    if relpart not in names:
        return {}, []
    try:
        root=ET.fromstring(z.read(relpart))
    except Exception as exc:
        return {}, [f'invalid XML {relpart}: {exc}']
    out={}
    errors=[]
    for rel in root.findall(f'{{{REL}}}Relationship'):
        rid=rel.get('Id')
        if not rid:
            errors.append(f'{relpart}: relationship missing Id')
            continue
        if rid in out:
            errors.append(f'{relpart}: duplicate relationship Id {rid}')
        out[rid]=rel
    return out, errors


def _shape_order_errors(shape, page_part):
    # Sheet_Type content (Cell/Trigger/Section) must precede ShapeSheet extension
    # content (Text/Data1/Data2/Data3/ForeignData/Shapes). This is tolerated by
    # some readers but desktop Visio can reject out-of-order XML.
    base={'Cell','Trigger','Section'}
    ext_order={'Text':0,'Data1':1,'Data2':2,'Data3':3,'ForeignData':4,'Shapes':5}
    extension_seen=False
    last_ext=-1
    errs=[]
    for child in list(shape):
        local=child.tag.rsplit('}',1)[-1]
        if local in base:
            if extension_seen:
                errs.append(f'{page_part}: Shape {shape.get("ID")} has {local} after ShapeSheet extension content')
        elif local in ext_order:
            extension_seen=True
            if ext_order[local] < last_ext:
                errs.append(f'{page_part}: Shape {shape.get("ID")} has out-of-order {local} element')
            last_ext=max(last_ext,ext_order[local])
    return errs


def _connection_rows(shape):
    sec=next((x for x in shape.findall(f'{{{V}}}Section') if x.get('N')=='Connection'),None)
    if sec is None:return {}
    return {int(r.get('IX','0')):r for r in sec.findall(f'{{{V}}}Row')}


def _connector_geometry_is_orthogonal(shape):
    sec=next((x for x in shape.findall(f'{{{V}}}Section') if x.get('N')=='Geometry'),None)
    if sec is None:return True
    pts=[]
    for row in sec.findall(f'{{{V}}}Row'):
        cells={c.get('N'):c.get('V') for c in row.findall(f'{{{V}}}Cell')}
        if 'X' in cells and 'Y' in cells:
            try:pts.append((float(cells['X']),float(cells['Y'])))
            except Exception:return False
    return all(abs(a[0]-b[0])<1e-6 or abs(a[1]-b[1])<1e-6 for a,b in zip(pts,pts[1:]))



def _direct_cells(shape):
    return {c.get('N'):c for c in shape.findall(f'{{{V}}}Cell')}


def _num_cell(shape,name,default=0.0):
    c=_direct_cells(shape).get(name)
    try:return float(c.get('V')) if c is not None else float(default)
    except Exception:return float(default)


def _shape_global_boxes(root):
    """Return generated-shape page transforms for initial glue verification.

    Generated architecture groups are unrotated/unscaled. The validator keeps
    this intentionally narrow and uses the actual nested XForms to verify that
    connector endpoint V values land on the exact connection-point anchors.
    """
    out={}
    top=root.find(f'{{{V}}}Shapes')
    if top is None:return out
    def walk(sh,parent_left=0.0,parent_bottom=0.0):
        w=_num_cell(sh,'Width'); h=_num_cell(sh,'Height')
        locx=_num_cell(sh,'LocPinX',w/2); locy=_num_cell(sh,'LocPinY',h/2)
        left=parent_left+_num_cell(sh,'PinX')-locx
        bottom=parent_bottom+_num_cell(sh,'PinY')-locy
        out[sh.get('ID')]={'shape':sh,'left':left,'bottom':bottom,'width':w,'height':h}
        subs=sh.find(f'{{{V}}}Shapes')
        if subs is not None:
            for ch in subs.findall(f'{{{V}}}Shape'):
                walk(ch,left,bottom)
    for sh in top.findall(f'{{{V}}}Shape'):
        walk(sh)
    return out


def _connection_point_page(box,row_index):
    rows=_connection_rows(box['shape'])
    row=rows.get(int(row_index))
    if row is None:return None
    cells={c.get('N'):c for c in row.findall(f'{{{V}}}Cell')}
    try:
        return box['left']+float(cells['X'].get('V')), box['bottom']+float(cells['Y'].get('V'))
    except Exception:
        return None

def validate_vsdx(path, libreoffice=False):
    path=Path(path); errors=[]; warnings=[]; stats={}
    if not path.exists():return {'ok':False,'errors':['file not found'],'warnings':[],'stats':{}}
    try:
        with zipfile.ZipFile(path) as z:
            names=set(z.namelist())
            required={'[Content_Types].xml','_rels/.rels','visio/document.xml','visio/_rels/document.xml.rels','visio/pages/pages.xml','visio/pages/_rels/pages.xml.rels'}
            for r in required:
                if r not in names:errors.append('missing '+r)
            bad=z.testzip()
            if bad:errors.append('CRC failure '+bad)
            for n in names:
                if n.endswith('.xml') or n.endswith('.rels'):
                    try:ET.fromstring(z.read(n))
                    except Exception as e:errors.append(f'invalid XML {n}: {e}')
            if errors:
                return {'ok':False,'errors':errors,'warnings':warnings,'stats':stats}

            # Content types and document relationships.
            ct=ET.fromstring(z.read('[Content_Types].xml'))
            overrides={x.get('PartName'):x.get('ContentType') for x in ct.findall(f'{{{CT}}}Override')}
            defaults={x.get('Extension','').lower():x.get('ContentType') for x in ct.findall(f'{{{CT}}}Default')}
            expected_ct={
                '/visio/document.xml':'application/vnd.ms-visio.drawing.main+xml',
                '/visio/pages/pages.xml':'application/vnd.ms-visio.pages+xml',
            }
            for part,ctype in expected_ct.items():
                if overrides.get(part)!=ctype: errors.append(f'[Content_Types].xml missing/incorrect override for {part}')

            docrels, rel_errors=_rels_by_id(z,names,'visio/document.xml'); errors.extend(rel_errors)
            pages_rel=[r for r in docrels.values() if r.get('Type')=='http://schemas.microsoft.com/visio/2010/relationships/pages']
            if not pages_rel: errors.append('document.xml.rels has no pages relationship')
            windows_rel=[r for r in docrels.values() if r.get('Type')=='http://schemas.microsoft.com/visio/2010/relationships/windows']
            if not windows_rel:
                warnings.append('desktop compatibility: document has no windows.xml relationship')
            else:
                target=_resolve_target('visio/document.xml',windows_rel[0].get('Target',''))
                if target not in names: errors.append(f'document windows relationship target missing: {target}')
                if overrides.get('/'+target)!='application/vnd.ms-visio.windows+xml': errors.append(f'[Content_Types].xml missing windows override for /{target}')

            # Style references: desktop Visio is stricter than LibreOffice here.
            doc=ET.fromstring(z.read('visio/document.xml'))
            styles={s.get('ID') for s in doc.findall(f'.//{{{V}}}StyleSheet') if s.get('ID') is not None}
            settings=doc.find(f'{{{V}}}DocumentSettings')
            if settings is not None:
                for attr in ('DefaultTextStyle','DefaultLineStyle','DefaultFillStyle'):
                    ref=settings.get(attr)
                    if ref is not None and ref not in styles: errors.append(f'document.xml {attr} references undefined style {ref}')
            if '0' not in styles: errors.append('desktop compatibility: document.xml does not define StyleSheet ID 0')

            pages=[n for n in names if re.fullmatch(r'visio/pages/page\d+\.xml',n)]
            stats['pages']=len(pages);stats['media']=len([n for n in names if n.startswith('visio/media/')])
            shapes=connects=foreign=0
            for p in pages:
                root=ET.fromstring(z.read(p))
                # Enforce PageContents child order: Shapes then Connects.
                seen_connects=False
                for child in list(root):
                    local=child.tag.rsplit('}',1)[-1]
                    if local=='Connects': seen_connects=True
                    elif local=='Shapes' and seen_connects: errors.append(f'{p}: Shapes occurs after Connects')

                sh=root.findall(f'.//{{{V}}}Shape'); shapes+=len(sh); ids={s.get('ID') for s in sh}
                by_id={s.get('ID'):s for s in sh}
                page_rels, rel_errors=_rels_by_id(z,names,p); errors.extend(rel_errors)
                for s in sh:
                    errors.extend(_shape_order_errors(s,p))
                    # Style refs on locally-authored shapes should resolve.
                    if s.get('Master') is None:
                        for attr in ('LineStyle','FillStyle','TextStyle'):
                            ref=s.get(attr)
                            if ref is not None and ref not in styles: errors.append(f'{p}: Shape {s.get("ID")} {attr} references undefined style {ref}')
                    fd=s.find(f'{{{V}}}ForeignData')
                    if fd is not None:
                        foreign+=1
                        rel=fd.find(f'{{{V}}}Rel')
                        rid=rel.get(f'{{{R}}}id') if rel is not None else None
                        if not rid or rid not in page_rels:
                            errors.append(f'{p}: Shape {s.get("ID")} ForeignData relationship missing/unresolved')
                        else:
                            target=_resolve_target(p,page_rels[rid].get('Target',''))
                            if target not in names: errors.append(f'{p}: image relationship {rid} target missing: {target}')
                            ext=Path(target).suffix.lower().lstrip('.')
                            if ext and ext not in defaults and ('/'+target) not in overrides:
                                errors.append(f'[Content_Types].xml has no content type for {target}')

                checked_connectors=set()
                global_boxes=_shape_global_boxes(root)
                attachment_checks=0
                for c in root.findall(f'.//{{{V}}}Connect'):
                    connects+=1
                    if c.get('FromSheet') not in ids:errors.append(f'{p}: Connect FromSheet {c.get("FromSheet")} missing')
                    if c.get('ToSheet') not in ids:errors.append(f'{p}: Connect ToSheet {c.get("ToSheet")} missing')
                    source=by_id.get(c.get('FromSheet'))
                    target=by_id.get(c.get('ToSheet'))
                    if source is not None and c.get('FromCell') in {'BeginX','EndX'}:
                        # A Visio-authored standalone dynamic connector does not
                        # necessarily serialize an explicit OneD cell. Desktop Visio infers
                        # the 1-D interaction model from Begin/End XForm1D cells plus
                        # ObjType=2 and dynamic glue. Require that native pattern instead.
                        raw_cells={x.get('N'):x.get('V') for x in source.findall(f'{{{V}}}Cell')}
                        if raw_cells.get('ObjType')!='2' or not all(k in raw_cells for k in ('BeginX','BeginY','EndX','EndY')):
                            errors.append(f'{p}: connected line Shape {source.get("ID")} lacks Visio-native connector XForm1D/ObjType=2')
                        if source.get('ID') not in checked_connectors:
                            cells=raw_cells
                            if cells.get('ShapeRouteStyle')!='1': errors.append(f'{p}: connector Shape {source.get("ID")} is not Right Angle ShapeRouteStyle=1')
                            if (source.get('NameU') or '').startswith('ArchitectureConnector.') and cells.get('ConFixedCode')!='2':
                                errors.append(f'{p}: generated connector Shape {source.get("ID")} must use ConFixedCode=2 to prevent unrelated Visio reroutes')
                            if not _connector_geometry_is_orthogonal(source): errors.append(f'{p}: connector Shape {source.get("ID")} contains diagonal geometry')
                            if (source.get('NameU') or '').startswith('ArchitectureConnector.'):
                                geom=next((x for x in source.findall(f'{{{V}}}Section') if x.get('N')=='Geometry'),None)
                                rows=geom.findall(f'{{{V}}}Row') if geom is not None else []
                                if rows:
                                    first={x.get('N'):x.get('F') for x in rows[0].findall(f'{{{V}}}Cell')}
                                    last={x.get('N'):x.get('F') for x in rows[-1].findall(f'{{{V}}}Cell')}
                                    if first.get('X')!='BeginX-PinX+LocPinX' or first.get('Y')!='BeginY-PinY+LocPinY':
                                        errors.append(f'{p}: connector Shape {source.get("ID")} first Geometry vertex is not bound to BeginX/BeginY')
                                    if last.get('X')!='EndX-PinX+LocPinX' or last.get('Y')!='EndY-PinY+LocPinY':
                                        errors.append(f'{p}: connector Shape {source.get("ID")} last Geometry vertex is not bound to EndX/EndY')
                            checked_connectors.add(source.get('ID'))
                    tocell=c.get('ToCell','')
                    from_cell=c.get('FromCell')
                    if target is not None and from_cell in {'BeginX','EndX'}:
                        # Two valid glue models are recognized:
                        # 1) native dynamic/walking glue: Connect->PinX + _WALKGLUE and
                        #    BegTrigger/EndTrigger -> target EventXFMod;
                        # 2) explicit point glue used by some imported templates.
                        endpoint=next((x for x in source.findall(f'{{{V}}}Cell') if x.get('N')==from_cell),None) if source is not None else None
                        other_name='BeginY' if from_cell=='BeginX' else 'EndY'
                        other=next((x for x in source.findall(f'{{{V}}}Cell') if x.get('N')==other_name),None) if source is not None else None
                        formula=(endpoint.get('F') or '') if endpoint is not None else ''
                        other_formula=(other.get('F') or '') if other is not None else ''
                        target_id=target.get('ID')
                        if tocell=='PinX':
                            if c.get('ToPart') not in {None,'3'}:
                                errors.append(f'{p}: dynamic glue to Shape {target_id} PinX expects ToPart 3, got {c.get("ToPart")}')
                            expected_walk='_WALKGLUE(BegTrigger,EndTrigger,WalkPreference)' if from_cell=='BeginX' else '_WALKGLUE(EndTrigger,BegTrigger,WalkPreference)'
                            if formula!=expected_walk or other_formula!=expected_walk:
                                errors.append(f'{p}: connector {c.get("FromSheet")} {from_cell}/{other_name} lacks native _WALKGLUE formula')
                            trigger_name='BegTrigger' if from_cell=='BeginX' else 'EndTrigger'
                            trigger=next((x for x in source.findall(f'{{{V}}}Cell') if x.get('N')==trigger_name),None) if source is not None else None
                            tf=(trigger.get('F') or '') if trigger is not None else ''
                            expected_trigger=f'_XFTRIGGER(Sheet.{target_id}!EventXFMod)'
                            if expected_trigger not in tf:
                                errors.append(f'{p}: connector {c.get("FromSheet")} {trigger_name} does not depend on target Shape {target_id} EventXFMod')
                        else:
                            m=re.fullmatch(r'Connections\.X(\d+)',tocell)
                            if not m:
                                errors.append(f'{p}: unsupported glue target {tocell} on Shape {target_id}')
                            else:
                                row=int(m.group(1))-1
                                rows=_connection_rows(target)
                                if row not in rows:errors.append(f'{p}: Connect targets missing {tocell} on Shape {target_id}')
                                expected=100+row
                                if c.get('ToPart') is not None and c.get('ToPart')!=str(expected):errors.append(f'{p}: {tocell} expects ToPart {expected}, got {c.get("ToPart")}')
                                required=[f'Sheet.{target_id}!Connections.X{row+1}',f'Sheet.{target_id}!Connections.Y{row+1}']
                                if not formula or not all(token in formula for token in required):
                                    errors.append(f'{p}: connector {c.get("FromSheet")} {from_cell} lacks point-glue formula to {tocell} on Shape {target_id}')
                                if (source.get('NameU') or '').startswith('ArchitectureConnector.'):
                                    for ftxt in (formula,other_formula):
                                        if 'LOCTOPAR(' not in ftxt or f'Sheet.{target_id}!Width' not in ftxt or 'ThePage!PageWidth' not in ftxt:
                                            errors.append(f'{p}: generated connector {c.get("FromSheet")} lacks group-safe LOCTOPAR glue to {tocell}')
                                            break
                                    glue=next((x for x in source.findall(f'{{{V}}}Cell') if x.get('N')=='GlueType'),None)
                                    if glue is None or glue.get('V')!='0':
                                        errors.append(f'{p}: generated point-glued connector {c.get("FromSheet")} must use GlueType=0')
                                    # v1.3.3 terminal adapter contract.  DirX/DirY is the
                                    # inward vector of the selected connection point.  The
                                    # penultimate/second Geometry row must sit 0.25in in the
                                    # opposite direction, locking the arrow/leg orientation.
                                    geom=next((x for x in source.findall(f'{{{V}}}Section') if x.get('N')=='Geometry'),None)
                                    grows=geom.findall(f'{{{V}}}Row') if geom is not None else []
                                    if len(grows)<7:
                                        errors.append(f'{p}: generated connector {c.get("FromSheet")} lacks v1.3.3 terminal adapter rows')
                                    else:
                                        target_rows=_connection_rows(target)
                                        tr=target_rows.get(row)
                                        if tr is not None:
                                            rv={x.get('N'):float(x.get('V') or 0) for x in tr.findall(f'{{{V}}}Cell') if x.get('N') in {'DirX','DirY'}}
                                            stubrow=grows[1] if from_cell=='BeginX' else grows[-2]
                                            sf={x.get('N'):(x.get('F') or '') for x in stubrow.findall(f'{{{V}}}Cell')}
                                            pref='Begin' if from_cell=='BeginX' else 'End'
                                            dx,dy=rv.get('DirX',0),rv.get('DirY',0)
                                            expected=None; axis=None
                                            if dx>0: expected=f'{pref}X-0.25'; axis='X'
                                            elif dx<0: expected=f'{pref}X+0.25'; axis='X'
                                            elif dy>0: expected=f'{pref}Y-0.25'; axis='Y'
                                            elif dy<0: expected=f'{pref}Y+0.25'; axis='Y'
                                            if expected is None or expected not in sf.get(axis,''):
                                                errors.append(f'{p}: connector {c.get("FromSheet")} terminal stub does not honor {tocell} DirX/DirY orientation')
                                    # The initial numeric endpoint must land exactly on the
                                    # generated connection point. This catches route/glue
                                    # drift before desktop Visio ever opens the file.
                                    box=global_boxes.get(target_id)
                                    expected_pt=_connection_point_page(box,row) if box else None
                                    if expected_pt is not None and endpoint is not None and other is not None:
                                        try:
                                            actual=(float(endpoint.get('V')),float(other.get('V')))
                                            if abs(actual[0]-expected_pt[0])>2e-5 or abs(actual[1]-expected_pt[1])>2e-5:
                                                errors.append(f'{p}: connector {c.get("FromSheet")} {from_cell} numeric endpoint {actual} does not match {tocell} page point {expected_pt}')
                                            else:
                                                attachment_checks+=1
                                        except Exception:
                                            errors.append(f'{p}: connector {c.get("FromSheet")} {from_cell} has non-numeric endpoint V value')
                stats.setdefault('initialAttachmentChecks',0)
                stats['initialAttachmentChecks']+=attachment_checks
            stats['shapes']=shapes;stats['connects']=connects;stats['foreignShapes']=foreign
            stats['desktopCompatibilityChecks']='passed' if not errors else 'failed'
    except zipfile.BadZipFile as e:errors.append('not a valid ZIP/VSDX: '+str(e))
    if libreoffice and not errors:
        lo=shutil.which('libreoffice')
        if lo:
            with tempfile.TemporaryDirectory() as td, tempfile.TemporaryDirectory() as profile:
                # Use an isolated LibreOffice user profile for every smoke test.
                # Reusing the default profile after pytest/parallel validations can
                # leave a stale lock or attach to an existing soffice process and
                # make an otherwise valid release validator appear to hang.
                profile_uri=Path(profile).resolve().as_uri()
                cmd=[lo,f'-env:UserInstallation={profile_uri}','--headless','--norestore','--nodefault','--nolockcheck','--convert-to','pdf','--outdir',td,str(path)]
                proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=(os.name!='nt'))
                try:
                    stdout,stderr=proc.communicate(timeout=60)
                except subprocess.TimeoutExpired:
                    if os.name!='nt':
                        try: os.killpg(proc.pid,signal.SIGKILL)
                        except ProcessLookupError: pass
                    else: proc.kill()
                    stdout,stderr=proc.communicate()
                    errors.append('LibreOffice render timed out after 60s')
                    stdout=stdout or ''; stderr=stderr or ''
                pdf=Path(td)/(path.stem+'.pdf')
                if not errors and (proc.returncode!=0 or not pdf.exists() or pdf.stat().st_size<500): errors.append('LibreOffice could not render VSDX: '+(stderr or stdout).strip())
                elif not errors:stats['libreofficePdfBytes']=pdf.stat().st_size
        else:warnings.append('LibreOffice not installed; smoke test skipped')
    return {'ok':not errors,'errors':errors,'warnings':warnings,'stats':stats}
