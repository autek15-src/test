from __future__ import annotations

"""Bundled generic architecture icons.

A curated MIT-licensed Tabler subset is shipped both as original SVG/PNG assets
and as precompiled normalized polyline vectors. v1.3.1 renders the vectors as
native Visio geometry by default, so generic icons remain visible/editable even
without external image support.
"""

from importlib.resources import files
from pathlib import Path
import json

PACK_NAME = "tabler"
_VECTOR_CACHE = None


def _root():
    return files("visio_arch_renderer").joinpath("assets", "icons", "tabler")


def list_builtin_icons() -> list[str]:
    root = _root(); names=[]
    for item in root.iterdir():
        if item.name.endswith((".png",".svg")): names.append(item.name.rsplit('.',1)[0])
    return sorted(set(names))


def builtin_icon_bytes(name: str, *, prefer_png: bool = True) -> tuple[bytes, str] | None:
    key = (name or "").strip().lower().replace("_", "-").replace(" ", "-")
    if not key:return None
    exts = (".png", ".svg") if prefer_png else (".svg", ".png")
    root = _root()
    for ext in exts:
        item = root.joinpath(key + ext)
        try:
            if item.is_file(): return item.read_bytes(), ext
        except (FileNotFoundError, OSError): pass
    return None


def builtin_icon_vectors(name: str) -> list[list[list[float]]] | None:
    """Return normalized native-vector polylines for a bundled icon."""
    global _VECTOR_CACHE
    if _VECTOR_CACHE is None:
        item=files("visio_arch_renderer").joinpath("assets","icons","tabler_vectors.json")
        try:_VECTOR_CACHE=json.loads(item.read_text(encoding='utf-8')).get('icons',{})
        except (FileNotFoundError,OSError,ValueError):_VECTOR_CACHE={}
    key=(name or '').strip().lower().replace('_','-').replace(' ','-')
    data=_VECTOR_CACHE.get(key)
    return data if data else None


def builtin_icon_path(name: str) -> Path | None:
    item = _root().joinpath((name or "").strip().lower().replace("_", "-").replace(" ", "-") + ".png")
    try:return Path(str(item)) if item.is_file() else None
    except (FileNotFoundError, OSError):return None
