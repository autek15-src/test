from __future__ import annotations
from dataclasses import dataclass
import heapq
from collections import defaultdict
from .layout import Box
from .model import Diagram

EPS = 1e-6

@dataclass(frozen=True)
class Port:
    side: str                 # L, R, T, B in top-left diagram coordinates
    fraction: float           # top->bottom for L/R, left->right for T/B
    point: tuple[float, float]

@dataclass
class Route:
    points: list[tuple[float,float]]
    fallback: bool=False
    source_port: Port | None = None
    target_port: Port | None = None
    source: str | None = None
    target: str | None = None


def route_edges(
    diagram: Diagram,
    boxes: dict[str,Box],
    group_boxes: dict[str,Box],
    congestion_penalty: float=12.0,
    grid: float=18.0,  # retained for API compatibility; visibility routing is grid-free
    polish: bool=True,
):
    """Route visible edges as strictly orthogonal polylines.

    Port assignment is performed globally before routing so fan-in/fan-out edges
    use distinct points on the appropriate side of a component.  Each endpoint
    gets an outward escape leg, then an obstacle-aware rectilinear visibility
    graph is used for the middle of the route.  This guarantees that every
    emitted segment is horizontal or vertical, including the first and last.
    """
    routes: dict[int, Route] = {}
    port_pairs = _assign_ports(diagram, boxes)
    obstacles = list(boxes.items())
    used_segments: list[tuple[tuple[float,float],tuple[float,float]]] = []

    visible = [
        i for i,e in enumerate(diagram.edges)
        if not e.metadata.get('hidden') and e.source in boxes and e.target in boxes
    ]
    # Route long/high-span relations first.  They have fewer good alternatives
    # and become stable trunks; shorter edges can then avoid/cross them cheaply.
    visible.sort(key=lambda i: _edge_span(diagram.edges[i], boxes), reverse=True)

    escape = 24.0
    for idx in visible:
        e = diagram.edges[idx]
        sp, tp = port_pairs[idx]
        s0, t0 = sp.point, tp.point
        se = _escape(sp, escape)
        te = _escape(tp, escape)

        # Source/target are obstacles for the middle route too.  Only the explicit
        # first/last escape legs may touch endpoint shapes; otherwise a long route
        # can accidentally leave a node and later re-enter the same box.
        mid = _visibility_route(
            se, te, obstacles, set(), used_segments,
            congestion_penalty=congestion_penalty,
        )
        fallback = False
        if not mid:
            mid = _dogleg(se, te, obstacles, set(), idx)
            fallback = True

        pts = _simplify([s0, se] + mid[1:-1] + [te, t0])
        # Never emit diagonal geometry.  If an unexpected route slips through,
        # replace it with a safe Manhattan bridge and mark it as a fallback.
        if not _is_orthogonal(pts):
            pts = _orthogonalize(pts)
            fallback = True
        routes[idx] = Route(pts, fallback, sp, tp, e.source, e.target)
        used_segments.extend((a,b) for a,b in zip(pts,pts[1:]))

    # OfficeIMO/libavoid-inspired whole-page polish: revisit the most conflicted
    # connectors after an initial full routing pass. A replacement is accepted
    # only when it improves crossing/overlap/bend cost and remains obstacle-free.
    if polish:
        _polish_routes(diagram, boxes, routes, congestion_penalty, passes=2 if len(routes)<=20 else 1)
    return routes


def _polish_routes(diagram, boxes, routes, congestion_penalty, passes=2):
    obstacles=list(boxes.items())
    for _ in range(max(0,passes)):
        changed=False
        ordered=sorted(routes, key=lambda idx:_route_conflict_score(idx,routes), reverse=True)[:min(12,len(routes))]
        for idx in ordered:
            old=routes[idx]; e=diagram.edges[idx]
            if not old.source_port or not old.target_port: continue
            others=[(a,b) for j,r in routes.items() if j!=idx for a,b in zip(r.points,r.points[1:])]
            old_score=_path_cost(old.points,others)
            best=(old_score,old.points,old.fallback)
            for escape in ((24.0,36.0,52.0) if len(routes)<=20 else (36.0,52.0)):
                s0,t0=old.source_port.point,old.target_port.point
                se=_escape(old.source_port,escape);te=_escape(old.target_port,escape)
                mid=_visibility_route(se,te,obstacles,set(),others,congestion_penalty=max(congestion_penalty,18.0))
                if not mid: continue
                pts=_simplify([s0,se]+mid[1:-1]+[te,t0])
                if not _is_orthogonal(pts) or _path_hits_illegal_node(pts,boxes,e.source,e.target): continue
                cost=_path_cost(pts,others)
                if cost+EPS<best[0]: best=(cost,pts,False)
            if best[1] is not old.points and best[0]+EPS<old_score:
                old.points=best[1];old.fallback=best[2];changed=True
        if not changed: break


def _route_conflict_score(idx,routes):
    r=routes[idx]; others=[(a,b) for j,q in routes.items() if j!=idx for a,b in zip(q.points,q.points[1:])]
    return _path_cost(r.points,others)


def _path_cost(points,others):
    crosses=0; overlap=0.0
    for a,b in zip(points,points[1:]):
        c,o=_interaction_cost(a,b,others);crosses+=c;overlap+=o
    length=sum(abs(a[0]-b[0])+abs(a[1]-b[1]) for a,b in zip(points,points[1:]))
    bends=max(0,len(points)-2)
    return crosses*10000.0 + overlap*300.0 + bends*8.0 + length*.01


def _path_hits_illegal_node(points,boxes,source,target):
    nseg=max(0,len(points)-1)
    for si,(a,b) in enumerate(zip(points,points[1:])):
        for nid,box in boxes.items():
            if nid==source and si==0: continue
            if nid==target and si==nseg-1: continue
            if _segment_hits_box(a,b,box): return True
    return False


def _edge_span(edge, boxes):
    a,b=boxes[edge.source],boxes[edge.target]
    return abs(a.cx-b.cx)+abs(a.cy-b.cy)


def _preferred_sides(edge, a:Box, b:Box) -> tuple[str,str]:
    hint=str(edge.metadata.get('directionHint','')).lower()
    if hint=='right': return 'R','L'
    if hint=='left': return 'L','R'
    if hint=='down': return 'B','T'
    if hint=='up': return 'T','B'
    dx=b.cx-a.cx; dy=b.cy-a.cy
    if abs(dx)>=abs(dy):
        return ('R','L') if dx>=0 else ('L','R')
    return ('B','T') if dy>=0 else ('T','B')


def _assign_ports(diagram:Diagram, boxes:dict[str,Box]):
    """Assign one deterministic perimeter port to each edge endpoint.

    Edges sharing a side are ordered by the coordinate of the opposite node,
    which is a standard port-ordering heuristic that reduces crossings before
    the router even starts.
    """
    records=defaultdict(list)  # (node, side) -> (edge_idx, endpoint_kind, order_coord)
    sides={}
    for idx,e in enumerate(diagram.edges):
        if e.metadata.get('hidden') or e.source not in boxes or e.target not in boxes:
            continue
        a,b=boxes[e.source],boxes[e.target]
        ss,ts=_preferred_sides(e,a,b); sides[idx]=(ss,ts)
        records[(e.source,ss)].append((idx,'s', b.cy if ss in {'L','R'} else b.cx))
        records[(e.target,ts)].append((idx,'t', a.cy if ts in {'L','R'} else a.cx))

    assigned={}
    for (node,side), items in records.items():
        items.sort(key=lambda x:(x[2],x[0],x[1]))
        n=len(items)
        for k,(idx,kind,_) in enumerate(items):
            frac=(k+1)/(n+1)
            assigned[(idx,kind)] = Port(side, frac, _port_point(boxes[node], side, frac))

    out={}
    for idx,(ss,ts) in sides.items():
        out[idx]=(assigned[(idx,'s')],assigned[(idx,'t')])
    return out


def _port_point(b:Box, side:str, f:float):
    if side=='L': return (b.x, b.y+b.h*f)
    if side=='R': return (b.x+b.w, b.y+b.h*f)
    if side=='T': return (b.x+b.w*f, b.y)
    return (b.x+b.w*f, b.y+b.h)


def _escape(p:Port, distance:float):
    x,y=p.point
    if p.side=='L': return (x-distance,y)
    if p.side=='R': return (x+distance,y)
    if p.side=='T': return (x,y-distance)
    return (x,y+distance)


def _visibility_route(start,end,obstacles,ignore,used_segments,congestion_penalty):
    """Rectilinear visibility-graph router around expanded component boxes."""
    margin=14.0
    rects=[]
    for nid,b in obstacles:
        if nid in ignore: continue
        rects.append((b.x-margin,b.y-margin,b.x+b.w+margin,b.y+b.h+margin))

    sx,sy=start; ex,ey=end
    xs={sx,ex}; ys={sy,ey}
    for l,t,r,b in rects:
        xs.update((l,r)); ys.update((t,b))
    # Always provide an outside corridor so disconnected channels remain routable.
    allx=[sx,ex]+[q for r in rects for q in (r[0],r[2])]
    ally=[sy,ey]+[q for r in rects for q in (r[1],r[3])]
    xs.update((min(allx)-42,max(allx)+42)); ys.update((min(ally)-42,max(ally)+42))
    xs=sorted(xs); ys=sorted(ys)

    def inside(p):
        x,y=p
        return any(l+EPS<x<r-EPS and t+EPS<y<b-EPS for l,t,r,b in rects)

    points={(x,y) for x in xs for y in ys if not inside((x,y))}
    points.add(start);points.add(end)
    adj=defaultdict(list)

    # Adjacent visible points on each shared X/Y form the rectilinear graph.
    for x in xs:
        col=sorted((y for xx,y in points if abs(xx-x)<EPS))
        for y1,y2 in zip(col,col[1:]):
            a,b=(x,y1),(x,y2)
            if _segment_clear(a,b,rects):
                d=abs(y2-y1);adj[a].append((b,d,'V'));adj[b].append((a,d,'V'))
    for y in ys:
        row=sorted((x for x,yy in points if abs(yy-y)<EPS))
        for x1,x2 in zip(row,row[1:]):
            a,b=(x1,y),(x2,y)
            if _segment_clear(a,b,rects):
                d=abs(x2-x1);adj[a].append((b,d,'H'));adj[b].append((a,d,'H'))

    # start/end can theoretically be absent from the exact row/column loops if
    # floating coordinates differ by tiny amounts.  Explicitly attach them.
    for p in (start,end):
        _attach_point(p,points,adj,rects)

    pq=[]; seq=0
    for direction in (None,):
        heapq.heappush(pq,(0.0,0.0,seq,start,direction));seq+=1
    best={(start,None):0.0}; prev={}
    bend_penalty=26.0
    crossing_penalty=max(600.0,congestion_penalty*25.0)
    while pq:
        _,g,_,p,d0=heapq.heappop(pq)
        if p==end:
            state=(p,d0); path=[p]
            while state in prev:
                state=prev[state];path.append(state[0])
            path.reverse();return _simplify(path)
        if g>best.get((p,d0),float('inf'))+EPS: continue
        for q,dist,d1 in adj.get(p,[]):
            bend=bend_penalty if d0 and d0!=d1 else 0.0
            cross,overlap=_interaction_cost(p,q,used_segments)
            ng=g+dist+bend+cross*crossing_penalty+overlap*congestion_penalty*2.5
            st=(q,d1)
            if ng+EPS<best.get(st,float('inf')):
                best[st]=ng;prev[st]=(p,d0)
                h=abs(q[0]-ex)+abs(q[1]-ey)
                heapq.heappush(pq,(ng+h,ng,seq,q,d1));seq+=1
    return []


def _attach_point(p,points,adj,rects):
    x,y=p
    # nearest visible points sharing exact row/column
    same_x=sorted((q for q in points if abs(q[0]-x)<EPS and q!=p),key=lambda q:abs(q[1]-y))
    same_y=sorted((q for q in points if abs(q[1]-y)<EPS and q!=p),key=lambda q:abs(q[0]-x))
    for candidates,direction in ((same_x,'V'),(same_y,'H')):
        for q in candidates[:2]:
            if _segment_clear(p,q,rects):
                d=abs(q[0]-x)+abs(q[1]-y)
                adj[p].append((q,d,direction));adj[q].append((p,d,direction))


def _segment_clear(a,b,rects):
    x1,y1=a;x2,y2=b
    if abs(x1-x2)<EPS:
        x=x1;lo,hi=sorted((y1,y2))
        for l,t,r,bt in rects:
            if l+EPS<x<r-EPS and max(lo,t+EPS)<min(hi,bt-EPS): return False
        return True
    if abs(y1-y2)<EPS:
        y=y1;lo,hi=sorted((x1,x2))
        for l,t,r,bt in rects:
            if t+EPS<y<bt-EPS and max(lo,l+EPS)<min(hi,r-EPS): return False
        return True
    return False


def _interaction_cost(a,b,used):
    crosses=0; overlap=0.0
    ah=abs(a[1]-b[1])<EPS
    for c,d in used:
        ch=abs(c[1]-d[1])<EPS
        if ah!=ch:
            h1,h2=(a,b) if ah else (c,d);v1,v2=(c,d) if ah else (a,b)
            x=v1[0];y=h1[1]
            if min(h1[0],h2[0])+EPS<x<max(h1[0],h2[0])-EPS and min(v1[1],v2[1])+EPS<y<max(v1[1],v2[1])-EPS:
                crosses+=1
        elif ah:
            if abs(a[1]-c[1])<EPS:
                overlap+=max(0.0,min(max(a[0],b[0]),max(c[0],d[0]))-max(min(a[0],b[0]),min(c[0],d[0]))) / 20.0
        else:
            if abs(a[0]-c[0])<EPS:
                overlap+=max(0.0,min(max(a[1],b[1]),max(c[1],d[1]))-max(min(a[1],b[1]),min(c[1],d[1]))) / 20.0
    return crosses,overlap


def _dogleg(s,e,obstacles,ignore,idx):
    sx,sy=s;ex,ey=e;off=(idx%7-3)*14
    cands=[
        [s,(ex,sy),e],
        [s,(sx,ey),e],
        [s,((sx+ex)/2+off,sy),((sx+ex)/2+off,ey),e],
        [s,(sx,(sy+ey)/2+off),(ex,(sy+ey)/2+off),e],
    ]
    return min(cands,key=lambda p:_route_penalty(p,obstacles,ignore))


def _route_penalty(p,obs,ignore):
    pen=len(p)*2
    for a,b in zip(p,p[1:]):
        if not _axis_aligned(a,b): pen+=10000
        for nid,box in obs:
            if nid in ignore:continue
            if _segment_hits_box(a,b,box):pen+=1000
    return pen


def _segment_hits_box(a,b,r):
    (x1,y1),(x2,y2)=a,b
    if abs(x1-x2)<EPS:return r.x < x1 < r.x+r.w and max(min(y1,y2),r.y)<min(max(y1,y2),r.y+r.h)
    if abs(y1-y2)<EPS:return r.y < y1 < r.y+r.h and max(min(x1,x2),r.x)<min(max(x1,x2),r.x+r.w)
    return True


def _axis_aligned(a,b):
    return abs(a[0]-b[0])<EPS or abs(a[1]-b[1])<EPS


def _is_orthogonal(points):
    return all(_axis_aligned(a,b) for a,b in zip(points,points[1:]))


def _orthogonalize(points):
    if not points:return points
    out=[points[0]]
    for p in points[1:]:
        a=out[-1]
        if _axis_aligned(a,p):out.append(p);continue
        # deterministic horizontal-then-vertical bridge
        out.extend([(p[0],a[1]),p])
    return _simplify(out)


def _simplify(p):
    # Remove duplicate points then collapse collinear runs.
    ded=[]
    for x in p:
        if not ded or abs(ded[-1][0]-x[0])>EPS or abs(ded[-1][1]-x[1])>EPS:ded.append(x)
    if len(ded)<3:return ded
    out=[ded[0]]
    for i in range(1,len(ded)-1):
        a,b,c=out[-1],ded[i],ded[i+1]
        if (abs(a[0]-b[0])<EPS and abs(b[0]-c[0])<EPS) or (abs(a[1]-b[1])<EPS and abs(b[1]-c[1])<EPS): continue
        out.append(b)
    out.append(ded[-1]);return out


def route_metrics(routes, boxes=None):
    fallbacks=sum(r.fallback for r in routes.values())
    bends=sum(max(0,len(r.points)-2) for r in routes.values())
    diagonals=sum(1 for r in routes.values() for a,b in zip(r.points,r.points[1:]) if not _axis_aligned(a,b))
    crossings=0;overlaps=0;node_intersections=0
    segs=[]
    for i,r in routes.items():
        for a,b in zip(r.points,r.points[1:]):segs.append((i,a,b))
    for x in range(len(segs)):
        i,a,b=segs[x]
        for j,c,d in segs[x+1:]:
            if i==j:continue
            if _cross(a,b,c,d):crossings+=1
            if _overlap(a,b,c,d)>EPS:overlaps+=1
    if boxes:
        for r in routes.values():
            seg_count=max(0,len(r.points)-1)
            for si,(a,b) in enumerate(zip(r.points,r.points[1:])):
                for nid,box in boxes.items():
                    # The only legal endpoint-shape contact is the first segment
                    # leaving the source and the final segment entering the target.
                    if nid==r.source and si==0:
                        continue
                    if nid==r.target and si==seg_count-1:
                        continue
                    if _segment_hits_box(a,b,box):
                        node_intersections+=1
    return {"fallbacks":fallbacks,"bends":bends,"crossings":crossings,"overlaps":overlaps,"diagonalSegments":diagonals,"nodeIntersections":node_intersections}


def _cross(a,b,c,d):
    ah=abs(a[1]-b[1])<EPS;ch=abs(c[1]-d[1])<EPS
    if ah==ch:return False
    h1,h2=(a,b) if ah else (c,d);v1,v2=(c,d) if ah else (a,b)
    x=v1[0];y=h1[1]
    return min(h1[0],h2[0])+EPS<x<max(h1[0],h2[0])-EPS and min(v1[1],v2[1])+EPS<y<max(v1[1],v2[1])-EPS


def _overlap(a,b,c,d):
    ah=abs(a[1]-b[1])<EPS;ch=abs(c[1]-d[1])<EPS
    if ah!=ch:return 0.0
    if ah and abs(a[1]-c[1])<EPS:
        return max(0.0,min(max(a[0],b[0]),max(c[0],d[0]))-max(min(a[0],b[0]),min(c[0],d[0])))
    if not ah and abs(a[0]-c[0])<EPS:
        return max(0.0,min(max(a[1],b[1]),max(c[1],d[1]))-max(min(a[1],b[1]),min(c[1],d[1])))
    return 0.0
