#!/usr/bin/env python3
from __future__ import annotations
import json, os, shutil, signal, subprocess, sys, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def _run(cmd, *, cwd=None, timeout=120):
    """Run an isolated child with timeout-safe file-backed output capture.

    Graphviz/LibreOffice descendants can inherit PIPE file descriptors.  Even
    after the direct process is killed, an inherited pipe may remain open and
    make ``communicate()`` wait forever.  Temporary files avoid that failure
    mode while still preserving stdout/stderr for the completion report.
    """
    with tempfile.TemporaryFile(mode='w+t',encoding='utf-8') as out_f, tempfile.TemporaryFile(mode='w+t',encoding='utf-8') as err_f:
        proc=subprocess.Popen(
            cmd,cwd=cwd,stdout=out_f,stderr=err_f,text=True,
            start_new_session=(os.name!='nt')
        )
        try:
            rc=proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            if os.name!='nt':
                try: os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError: pass
            else:
                proc.kill()
            try: proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                pass
            out_f.flush(); err_f.flush(); out_f.seek(0); err_f.seek(0)
            raise subprocess.TimeoutExpired(cmd,timeout,output=out_f.read(),stderr=err_f.read())
        out_f.flush(); err_f.flush(); out_f.seek(0); err_f.seek(0)
        return subprocess.CompletedProcess(cmd,rc,out_f.read(),err_f.read())


def run():
    checks=[]
    def progress(msg): print(msg,file=sys.stderr,flush=True)
    # Keep every expensive phase in its own process.  In earlier releases the
    # validator ran pytest as a subprocess and then imported/reran the renderer
    # in the parent process; on some environments that process lifetime pattern
    # could stall on later dense fixtures.  Process isolation also better models
    # how users invoke the packaged CLI/scripts.
    progress('compileall')
    try:
        cp=_run([sys.executable,'-m','compileall','-q',str(ROOT/'visio_arch_renderer'),str(ROOT/'scripts')],timeout=60)
        checks.append(('compileall',cp.returncode==0,cp.stderr.strip()))
    except Exception as exc:
        checks.append(('compileall',False,repr(exc)))

    progress('pytest')
    try:
        tp=_run([sys.executable,'-m','pytest','-q',str(ROOT/'tests')],cwd=ROOT,timeout=180)
        checks.append(('pytest',tp.returncode==0,(tp.stdout+'\n'+tp.stderr).strip()))
    except Exception as exc:
        checks.append(('pytest',False,repr(exc)))

    fixtures=['connector-smoke.puml','aws-target.json','sample.mmd','sample.puml','plantuml-styled-zones.puml','plantuml-dense-network.puml','uml-test-realworld.puml','semantic-shapes.json','builtin-icon-override.json','provider-recognition.puml']
    with tempfile.TemporaryDirectory() as td_raw:
        td=Path(td_raw)
        realworld_out=None
        connector_smoke_out=None
        for src in fixtures:
            progress(f'render {src}')
            out=td/(Path(src).stem+'.vsdx')
            report=td/(Path(src).stem+'.report.json')
            try:
                rp=_run([
                    sys.executable,str(ROOT/'scripts'/'render_vsdx.py'),str(ROOT/'examples'/src),
                    '-o',str(out),'--report',str(report)
                ],cwd=ROOT,timeout=150)
                if rp.returncode!=0:
                    checks.append((f'render:{src}',False,(rp.stdout+'\n'+rp.stderr).strip()))
                    continue
                rep=json.loads(report.read_text(encoding='utf-8'))

                progress(f'validate {src}')
                vcmd=[sys.executable,str(ROOT/'scripts'/'validate_vsdx.py'),str(out)]
                vp=_run(vcmd,cwd=ROOT,timeout=90)
                try:
                    vr=json.loads(vp.stdout)
                except Exception:
                    vr={'ok':False,'errors':['validator output was not JSON'],'raw':vp.stdout+vp.stderr}
                qm=rep.get('metrics',{})
                gates={
                    'noDiagonalSegments': qm.get('diagonalSegments',0)==0,
                    'noNodeIntersections': qm.get('nodeIntersections',0)==0,
                    'noGroupOverlaps': qm.get('groupOverlaps',0)==0,
                }
                quality_ok=all(gates.values())
                ok=(vp.returncode==0 and vr.get('ok') is True and quality_ok)
                checks.append((f'render:{src}',ok,json.dumps({'render':rep,'validate':vr,'qualityGate':gates},indent=2)))
                if src=='uml-test-realworld.puml' and ok:
                    realworld_out=out
                if src=='connector-smoke.puml' and ok:
                    connector_smoke_out=out
            except subprocess.TimeoutExpired as exc:
                checks.append((f'render:{src}',False,f'timeout after {exc.timeout}s'))
            except Exception as exc:
                checks.append((f'render:{src}',False,repr(exc)))

        # LibreOffice is a useful surrogate reader, but repeatedly launching it
        # for every fixture can be brittle in CI/container environments because
        # soffice profile/lock lifecycles are external to Python. Run one isolated
        # representative smoke test after all structural validations instead.
        if realworld_out is not None and shutil.which('libreoffice'):
            progress('libreoffice smoke')
            try:
                lp=_run([sys.executable,str(ROOT/'scripts'/'validate_vsdx.py'),str(realworld_out),'--libreoffice'],cwd=ROOT,timeout=90)
                try: lr=json.loads(lp.stdout)
                except Exception: lr={'ok':False,'raw':lp.stdout+lp.stderr}
                checks.append(('libreoffice:realworld',lp.returncode==0 and lr.get('ok') is True,json.dumps(lr,indent=2)))
            except Exception as exc:
                checks.append(('libreoffice:realworld',False,repr(exc)))

        if connector_smoke_out is not None and shutil.which('libreoffice'):
            progress('libreoffice connector smoke')
            try:
                lp=_run([sys.executable,str(ROOT/'scripts'/'validate_vsdx.py'),str(connector_smoke_out),'--libreoffice'],cwd=ROOT,timeout=90)
                try: lr=json.loads(lp.stdout)
                except Exception: lr={'ok':False,'raw':lp.stdout+lp.stderr}
                checks.append(('libreoffice:connector-smoke',lp.returncode==0 and lr.get('ok') is True,json.dumps(lr,indent=2)))
            except Exception as exc:
                checks.append(('libreoffice:connector-smoke',False,repr(exc)))

    ok=all(x[1] for x in checks)
    print(json.dumps({'ok':ok,'checks':[{'name':n,'ok':o,'detail':d} for n,o,d in checks]},indent=2))
    return 0 if ok else 1


if __name__=='__main__':
    raise SystemExit(run())
