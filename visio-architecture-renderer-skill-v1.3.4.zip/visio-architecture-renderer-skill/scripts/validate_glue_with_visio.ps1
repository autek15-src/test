param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$Path,
    [double]$MoveInches = 0.35
)

$ErrorActionPreference = 'Stop'
$visio = $null
$doc = $null

function Get-CellResultIU($shape, [string]$name) {
    try { return [double]$shape.CellsU($name).ResultIU } catch { return $null }
}

function Get-CellFormulaU($shape, [string]$name) {
    try { return [string]$shape.CellsU($name).FormulaU } catch { return $null }
}

function Find-ShapeById($shapes, [int]$id) {
    for ($i = 1; $i -le $shapes.Count; $i++) {
        $shape = $shapes.Item($i)
        if ([int]$shape.ID -eq $id) { return $shape }
        try {
            if ($shape.Shapes.Count -gt 0) {
                $found = Find-ShapeById $shape.Shapes $id
                if ($found -ne $null) { return $found }
            }
        } catch {}
    }
    return $null
}

function Find-ParentShapeByChildId($shapes, [int]$childId) {
    for ($i = 1; $i -le $shapes.Count; $i++) {
        $shape = $shapes.Item($i)
        try {
            for ($j = 1; $j -le $shape.Shapes.Count; $j++) {
                $child = $shape.Shapes.Item($j)
                if ([int]$child.ID -eq $childId) { return $shape }
                $nested = Find-ParentShapeByChildId $child.Shapes $childId
                if ($nested -ne $null) { return $nested }
            }
        } catch {}
    }
    return $null
}

function Find-DynamicConnector($shapes) {
    for ($i = 1; $i -le $shapes.Count; $i++) {
        $shape = $shapes.Item($i)
        $oneD = 0
        try { $oneD = [int]$shape.OneD } catch { $oneD = 0 }
        $beg = Get-CellFormulaU $shape 'BegTrigger'
        $end = Get-CellFormulaU $shape 'EndTrigger'
        if ($oneD -ne 0 -and (($beg -like '*_XFTRIGGER*') -or ($end -like '*_XFTRIGGER*'))) {
            return $shape
        }
    }
    return $null
}

try {
    $resolved = (Resolve-Path -LiteralPath $Path).Path
    $visio = New-Object -ComObject Visio.Application
    $visio.Visible = $false
    $version = $visio.Version
    $doc = $visio.Documents.Open($resolved)
    $page = $doc.Pages.Item(1)

    $connector = Find-DynamicConnector $page.Shapes
    if ($connector -eq $null) { throw 'No generated dynamic/walking-glue connector was found.' }

    $begFormula = Get-CellFormulaU $connector 'BegTrigger'
    $endFormula = Get-CellFormulaU $connector 'EndTrigger'
    $endpointCell = 'BeginX'
    $triggerFormula = $begFormula
    if ([string]::IsNullOrWhiteSpace($triggerFormula) -or $triggerFormula -notmatch '_XFTRIGGER\(Sheet\.(\d+)!EventXFMod\)') {
        $endpointCell = 'EndX'
        $triggerFormula = $endFormula
    }
    if ($triggerFormula -notmatch '_XFTRIGGER\(Sheet\.(\d+)!EventXFMod\)') {
        throw "Connector trigger does not identify a target shape: $triggerFormula"
    }
    $targetId = [int]$Matches[1]
    $target = Find-ShapeById $page.Shapes $targetId
    if ($target -eq $null) { throw "Could not find target shape ID $targetId recursively on page 1." }

    $before = Get-CellResultIU $connector $endpointCell
    $targetPinX = Get-CellResultIU $target 'PinX'
    if ($targetPinX -eq $null) { throw "Target shape $targetId has no PinX cell." }
    $target.CellsU('PinX').ResultIU = $targetPinX + $MoveInches
    Start-Sleep -Milliseconds 250
    $after = Get-CellResultIU $connector $endpointCell
    $componentDelta = if ($before -ne $null -and $after -ne $null) { [Math]::Abs($after - $before) } else { 0.0 }
    $componentAttached = $componentDelta -gt 0.001

    # Restore the child before testing the group so the document stays close to its original geometry.
    $target.CellsU('PinX').ResultIU = $targetPinX
    Start-Sleep -Milliseconds 150

    $parent = Find-ParentShapeByChildId $page.Shapes $targetId
    $groupTested = $false
    $groupAttached = $null
    $groupDelta = $null
    $parentId = $null
    if ($parent -ne $null) {
        $parentId = [int]$parent.ID
        $parentPinX = Get-CellResultIU $parent 'PinX'
        if ($parentPinX -ne $null) {
            $groupTested = $true
            $groupBefore = Get-CellResultIU $connector $endpointCell
            $parent.CellsU('PinX').ResultIU = $parentPinX + $MoveInches
            Start-Sleep -Milliseconds 250
            $groupAfter = Get-CellResultIU $connector $endpointCell
            $groupDelta = if ($groupBefore -ne $null -and $groupAfter -ne $null) { [Math]::Abs($groupAfter - $groupBefore) } else { 0.0 }
            $groupAttached = $groupDelta -gt 0.001
            $parent.CellsU('PinX').ResultIU = $parentPinX
        }
    }

    $ok = $componentAttached -and (-not $groupTested -or $groupAttached)
    $connectorOneD = 0
    $connectorNameU = ''
    $connectorConnectCount = 0
    try { $connectorOneD = [int]$connector.OneD } catch { }
    try { $connectorNameU = [string]$connector.NameU } catch { }
    try { $connectorConnectCount = [int]$connector.Connects.Count } catch { }
    $result = [ordered]@{
        ok = $ok
        file = $resolved
        visioVersion = $version
        connectorId = [int]$connector.ID
        connectorOneD = $connectorOneD
        connectorNameU = $connectorNameU
        connectorConnectCount = $connectorConnectCount
        endpointCell = $endpointCell
        targetShapeId = $targetId
        targetParentGroupId = $parentId
        beginTrigger = $begFormula
        endTrigger = $endFormula
        componentMoveTest = [ordered]@{
            attached = $componentAttached
            endpointDeltaInches = $componentDelta
            requestedMoveInches = $MoveInches
        }
        groupMoveTest = [ordered]@{
            tested = $groupTested
            attached = $groupAttached
            endpointDeltaInches = $groupDelta
            requestedMoveInches = $MoveInches
        }
    }
    $result | ConvertTo-Json -Depth 6
    if ($ok) { exit 0 } else { exit 1 }
}
catch {
    $result = [ordered]@{
        ok = $false
        file = $Path
        error = $_.Exception.Message
        hresult = ('0x{0:X8}' -f ($_.Exception.HResult -band 0xffffffff))
    }
    $result | ConvertTo-Json -Depth 4
    exit 1
}
finally {
    if ($doc -ne $null) {
        try { $doc.Saved = $true } catch {}
        try { $doc.Close() } catch {}
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($doc) } catch {}
    }
    if ($visio -ne $null) {
        try { $visio.Quit() } catch {}
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($visio) } catch {}
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
