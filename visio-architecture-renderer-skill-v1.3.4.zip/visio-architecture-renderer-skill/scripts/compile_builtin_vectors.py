#!/usr/bin/env python3
"""Compile bundled Tabler SVGs into dependency-free polyline vectors.

The generated JSON is consumed at runtime so arch2visio does not need an SVG
parser or fontTools. This compiler is only needed when the bundled icon set is
changed.
"""
from __future__ import annotations
import json, math
from pathlib import Path
import xml.etree.ElementTree as ET

try:
    from fontTools.pens.recordingPen import RecordingPen
    from fontTools.svgLib.path import parse_path
except ImportError as exc:
    raise SystemExit("fontTools is required only to rebuild builtin vectors") from exc

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'visio_arch_renderer'/'assets'/'icons'/'tabler'
OUT=ROOT/'visio_arch_renderer'/'assets'/'icons'/'tabler_vectors.json'
NS='{http://www.w3.org/2000/svg}'


def lerp(a,b,t): return a+(b-a)*t

def cubic(p0,p1,p2,p3,t):
    u=1-t
    return (u**3*p0[0]+3*u*u*t*p1[0]+3*u*t*t*p2[0]+t**3*p3[0],
            u**3*p0[1]+3*u*u*t*p1[1]+3*u*t*t*p2[1]+t**3*p3[1])

def qcurve(p0,p1,p2,t):
    u=1-t
    return (u*u*p0[0]+2*u*t*p1[0]+t*t*p2[0], u*u*p0[1]+2*u*t*p1[1]+t*t*p2[1])


def path_to_polylines(d:str, samples=8):
    pen=RecordingPen(); parse_path(d,pen)
    paths=[]; cur=[]; p0=None; start=None
    for op,args in pen.value:
        if op=='moveTo':
            if len(cur)>1: paths.append(cur)
            p0=args[0]; start=p0; cur=[list(p0)]
        elif op=='lineTo':
            p0=args[0]; cur.append(list(p0))
        elif op=='curveTo':
            *controls,p3=args
            if len(controls)==2:
                p1,p2=controls
                for i in range(1,samples+1): cur.append(list(cubic(p0,p1,p2,p3,i/samples)))
            else:
                # RecordingPen can theoretically expose super-beziers; linearly
                # retain control/end points rather than dropping geometry.
                for p in args: cur.append(list(p))
            p0=p3
        elif op=='qCurveTo':
            pts=list(args)
            if len(pts)>=2:
                p1,p2=pts[0],pts[-1]
                for i in range(1,samples+1): cur.append(list(qcurve(p0,p1,p2,i/samples)))
                p0=p2
        elif op=='closePath':
            if start and cur and cur[-1]!=list(start):cur.append(list(start))
            if len(cur)>1: paths.append(cur)
            cur=[];p0=start=None
        elif op=='endPath':
            if len(cur)>1:paths.append(cur)
            cur=[];p0=start=None
    if len(cur)>1:paths.append(cur)
    return paths


def parse_points(s):
    vals=[float(x) for x in s.replace(',',' ').split()]
    return [[vals[i],vals[i+1]] for i in range(0,len(vals)-1,2)]


def svg_vectors(path:Path):
    root=ET.fromstring(path.read_text(encoding='utf-8'))
    vb=[float(x) for x in root.get('viewBox','0 0 24 24').split()]
    ox,oy,vw,vh=vb
    paths=[]
    for e in root.iter():
        tag=e.tag.rsplit('}',1)[-1]
        if tag=='path' and e.get('d'): paths.extend(path_to_polylines(e.get('d')))
        elif tag=='line': paths.append([[float(e.get('x1',0)),float(e.get('y1',0))],[float(e.get('x2',0)),float(e.get('y2',0))]])
        elif tag in {'polyline','polygon'} and e.get('points'):
            pts=parse_points(e.get('points'))
            if tag=='polygon' and pts and pts[-1]!=pts[0]:pts.append(pts[0])
            paths.append(pts)
        elif tag=='rect':
            x=float(e.get('x',0));y=float(e.get('y',0));w=float(e.get('width',0));h=float(e.get('height',0))
            paths.append([[x,y],[x+w,y],[x+w,y+h],[x,y+h],[x,y]])
        elif tag in {'circle','ellipse'}:
            cx=float(e.get('cx',0));cy=float(e.get('cy',0));rx=float(e.get('r',e.get('rx',0)));ry=float(e.get('r',e.get('ry',0)))
            pts=[]
            for i in range(25):
                a=2*math.pi*i/24;pts.append([cx+rx*math.cos(a),cy+ry*math.sin(a)])
            paths.append(pts)
    # normalize to viewBox coordinates (0..1); round to keep artifact compact
    norm=[]
    for poly in paths:
        norm.append([[round((x-ox)/vw,6),round((y-oy)/vh,6)] for x,y in poly])
    return norm


def main():
    data={p.stem:svg_vectors(p) for p in sorted(SRC.glob('*.svg'))}
    OUT.write_text(json.dumps({'version':1,'source':'Tabler Icons','viewBoxNormalized':True,'icons':data},separators=(',',':')),encoding='utf-8')
    print(f'wrote {OUT} ({len(data)} icons)')

if __name__=='__main__':main()
