# Layout and routing behavior

The renderer optimizes architecture readability and Visio editability rather than minimum page area.

1. **Placement candidates**: explicit x/y positions are honored when every node has them. In `auto` mode, the renderer evaluates Graphviz `dot` (when installed) and the built-in layered placer instead of blindly preferring one engine. Graphviz placement uses nested clusters for architecture groups.
2. **Profiles**: compact, balanced, spacious, and dense-routing profiles vary rank and node spacing. All successful engine/profile combinations participate in quality scoring.
3. **Groups**: group and nested-group bounds are derived bottom-up from member nodes and fully resolved child groups. A parent cannot be finalized until all child group bounds exist, so an AWS Cloud/VPC/zone boundary encloses its descendants.
4. **Component sizing**: default-size nodes are expanded from realistic multi-line labels before placement. PlantUML `\n`, `\l`, and `\r` label escapes are normalized to real line breaks.
5. **Ports**: fan-in and fan-out relations are globally assigned distinct perimeter ports. The generated Visio component receives corresponding Connection Points rows (`Connections.X1`, etc.).
6. **Glue**: each connector `<Connect>` record targets the exact connection-point row using Visio `ToPart = 100 + row index`, rather than whole-shape glue.
7. **Orthogonal routing**: every connection leaves its node with a perpendicular escape leg, then uses a rectilinear visibility-graph A* router around expanded component rectangles. Candidate paths contain horizontal/vertical segments only.
8. **Cost model**: routes pay for length, bends, crossing existing connectors, and sharing occupied corridors. Crossings are intentionally expensive, so a longer clean corridor is preferred. `layout.congestionPenalty` controls reuse pressure.
9. **Fallback safety**: if the visibility router cannot find a path, deterministic Manhattan doglegs are evaluated. A final orthogonalization guard prevents diagonal geometry from reaching VSDX.
10. **Quality selection**: candidate scoring heavily penalizes connector crossings, fallbacks, corridor overlap, diagonal segments, and any route intersecting an unrelated component. `diagonalSegments` and `nodeIntersections` are explicit report metrics.
11. **VSDX output**: component labels are stored on the component object; connector labels are stored on the connector object. Generated connectors are native 1-D Visio shapes with `ShapeRouteStyle=1` (Right Angle), explicit orthogonal geometry, and glue to perimeter connection points.

The renderer does not claim a mathematically global optimum for very dense graphs. Dense architectures can still contain connector-to-connector crossings. They should not contain diagonal segments or connectors running through unrelated component rectangles, and the report makes all of these conditions visible.
