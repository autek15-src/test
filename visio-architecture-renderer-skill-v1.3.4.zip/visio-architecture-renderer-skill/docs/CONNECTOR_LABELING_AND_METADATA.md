# Connector labeling and metadata

This skill uses two intentionally different connector-labeling modes. The mode is determined by **user intent**, not merely file extension.

## 1. Conversion fidelity mode

Use this mode when the user asks to convert an existing diagram representation such as PlantUML, Mermaid, or another diagram source into Visio.

### Rule

The visible Visio connector label must reproduce the source connector label. Do not replace a technical source label with a semantic business label just to make the diagram cleaner. Conversion is fidelity-first.

Preserve:

- HTTP methods and paths
- protocol/port annotations
- event names
- line breaks when supported
- explicit source wording
- empty labels as empty labels

Only normalize escaping required by the source syntax, for example PlantUML `\n` becoming a Visio line break.

### Example

Source PlantUML:

```plantuml
PORTAL --> GW : POST /api/v1/customers/{customerId}/documents\nOkta JWT
```

Visible Visio connector text:

```text
POST /api/v1/customers/{customerId}/documents
Okta JWT
```

Do **not** silently change it to `Upload document`.

Additional ScreenTip/Shape Data may be added only as supplemental metadata and only from information that is actually known. If metadata is added, include `Original Source Label` for traceability where practical.

## 2. New-diagram authoring mode

Use this mode when the skill is designing a new Visio diagram from requirements, API inventory, architecture notes, code/repository analysis, or a user description rather than converting an existing diagram verbatim.

### Visible connector label

Keep it short and semantic. Prefer an action or business/integration meaning:

- `Load customer profile`
- `Upload document`
- `Create Salesforce case`
- `Publish profile-changed event`
- `Persist audit record`

Optionally include the HTTP method if it helps distinguish otherwise similar calls:

- `GET • Load customer profile`
- `POST • Upload document`

Avoid placing long REST URLs on the drawing unless the user asks for a detailed API-flow view.

### ScreenTip

ScreenTips provide hover-level technical detail without visual clutter. Store the ScreenTip on the connector's native Visio `Comment` cell.

Recommended REST ScreenTip:

```text
POST /api/v1/customers/{customerId}/documents
Customer Portal -> Customer API Gateway
HTTPS/REST
Auth: Okta Workforce JWT
```

For async/non-REST interactions, replace method/path with the appropriate technical address or operation, for example:

```text
Publish CustomerProfileChanged
SQS queue: customer-profile-events
Customer Service -> Notification Worker
Auth: IAM role
```

### Shape Data

Put structured detail on the connector itself. Suggested common fields:

| Field | Purpose |
| --- | --- |
| Interaction | Semantic interaction name |
| HTTP Method | GET/POST/PATCH/etc. when applicable |
| REST Path | Full REST path when applicable |
| Operation / Resource | SOAP operation, queue/topic, event type, DB operation, file resource, etc. |
| Protocol | HTTPS/REST, SOAP, SQS, JDBC/PostgreSQL, SFTP, etc. |
| Source Component | Initiating component |
| Target Component | Receiving component |
| Authentication | JWT, OAuth2, mTLS, IAM, Basic Auth, etc. |
| Authorization | Scope, role, policy, permission |
| Content Type / Payload | Media type or payload/event type |
| Timeout | Configured/expected timeout; mark observations as observations |
| Retry Policy | Retry/backoff behavior |
| Idempotency | Idempotency key/deduplication behavior |
| Error Handling | DLQ, error mapping, fallback, compensating behavior |
| Purpose | Business/integration purpose |
| Source Artifact | RAML/OpenAPI/PUML/code/log/requirement traceability |

Do not invent values. Omit unknown fields or use an explicitly qualified value such as `Unknown / to confirm`.

### VSDX ShapeSheet requirements

For a connector ScreenTip:

```xml
<Cell N="Comment" V="POST /api/v1/customers/{customerId}/documents&#10;Customer Portal -> Customer API Gateway"/>
```

For Shape Data, use a `Property` section. Text values must use `U="STR"` and must **not** use `F="No Formula"` on the Value cell:

```xml
<Section N="Property">
  <Row N="REST_Path">
    <Cell N="Label" V="REST Path"/>
    <Cell N="Type" V="0"/>
    <Cell N="Value" V="/api/v1/customers/{customerId}/documents" U="STR"/>
    <Cell N="Prompt" V="Full REST resource path."/>
    <Cell N="SortKey" V="03"/>
    <Cell N="Invisible" V="0"/>
  </Row>
</Section>
```

The `U="STR"` rule is important: without the proper string unit desktop Visio may display text values as `0`; using `F="No Formula"` on the text Value cell can result in blank values.

## 3. Mode-selection examples

- `Convert this PUML to Visio` -> **conversion fidelity mode**.
- `Convert this Mermaid diagram to VSDX and preserve it` -> **conversion fidelity mode**.
- `Create a new AWS target-state Visio from these MuleSoft requirements` -> **new-diagram authoring mode**.
- `Build a Visio architecture from this API inventory spreadsheet` -> **new-diagram authoring mode**, unless the user explicitly says the spreadsheet's connection labels are authoritative diagram labels.
- `Use this PUML as a starting point but simplify connector labels` -> conversion source with an **explicit user-requested transformation**; semantic labels are allowed because the user requested them.
