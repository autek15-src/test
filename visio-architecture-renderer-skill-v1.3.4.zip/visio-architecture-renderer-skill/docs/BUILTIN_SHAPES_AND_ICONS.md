# Built-in semantic architecture shapes and icons

The renderer includes an offline semantic fallback layer so a diagram does not collapse to generic rectangles when no company stencil or official provider icon pack is supplied.

## Design source and licensing

The semantic catalog and naming/alias families are adapted from the MIT-licensed **OfficeIMO.Visio** first-party stencil catalogs by Evotec. OfficeIMO provides architecture, network, infrastructure, cloud, security/identity, Kubernetes/container, and data-platform stencil families. This project ports the relevant taxonomy to Python/VSDX and uses native editable Visio geometry for the rendered fallback shapes. See `third_party/OfficeIMO-LICENSE.txt`.

The package also includes a curated set of 25 **Tabler Icons** under the MIT license. Original SVG/PNG assets are retained for reference, and v1.3.1 also ships a precompiled `tabler_vectors.json` derivative. The renderer uses those normalized polylines to create native Visio vector geometry, so automatic generic pictograms do not depend on bitmap rendering, CairoSVG, or other runtime libraries. See `third_party/tabler-icons/LICENSE`.

Provider/vendor icon sets with mixed trademark or asset licensing are intentionally not bundled. AWS icons remain user-supplied through `--aws-icons-dir`.

## Resolution priority

For each component the renderer uses this order:

1. user-supplied Visio template/stencil master
2. user-supplied official AWS icon when the node is recognized as an AWS service, even if the source node type is only `component`
3. automatic bundled native-vector semantic pictogram plus a meaningful semantic container
4. native semantic shape without a pictogram when icon use is disabled/unavailable
5. generic service fallback

Automatic generic icons are the v1.3.1 default. Disable them for a node with `iconMode: "none"` or `icon_mode: "none"`. Explicit `builtinIcon` or `icon: "builtin:<name>"` remains available when a particular generic pictogram is desired.

## Provider and technology recognition

The source does not need renderer-specific types such as `aws.dynamodb`. The recognizer looks at the node type and the component's primary label/name and understands common partial names and acronyms.

Examples:

| Input text | Recognized identity | Semantic fallback |
| --- | --- | --- |
| `DDB`, `DynamoDB`, `Amazon DynamoDB` | AWS DynamoDB | database |
| `APIGW`, `API GW`, `API Gateway` | AWS API Gateway | API gateway |
| `SFN`, `Step Functions` | AWS Step Functions | workflow |
| `TGW`, `ALB`, `NLB`, `RDS`, `SQS`, `SNS`, `EKS`, `ECS` | matching AWS service | service-specific semantic shape |
| `Azure APIM`, `AKS`, `AAD`, `Cosmos DB` | matching Azure service | gateway/Kubernetes/identity/database |
| `GKE`, `GCE`, `GCS`, `BigQuery`, `Pub/Sub`, `Cloud Run` | matching Google Cloud service | service-specific semantic shape |
| `Salesforce`, `SFDC`, `SF CRM`, `*.salesforce.com` | Salesforce | external/cloud, or API when the component itself is an API |
| `Okta` | Okta | identity/API |
| `HashiCorp Vault`, `Vault AppRole` | Vault | secret store |
| `Splunk Observability` | Splunk | monitoring |
| `MuleSoft`, `Anypoint`, `Mule Runtime` | MuleSoft | application/service |
| `SAP S/4HANA`, `SAP ECC` | SAP | external enterprise system |

The first label line is treated as the component's primary identity. Provider/service names found only in descriptive lines are recorded as **context** and do not override the component's semantic shape. For example, `Angular 18 (ECS Fargate)` remains an application/service, and `pmp-gateway-api [Okta JWT]` remains an API gateway.

## Semantic examples

| Input / inferred concept | Default visual |
| --- | --- |
| PostgreSQL/MySQL/MongoDB/RDS/Aurora/DynamoDB | database cylinder + database pictogram |
| Redis / ElastiCache | cache cylinder + database/cache pictogram |
| REST/GraphQL API | clean card + API pictogram |
| API Gateway / ingress / reverse proxy | gateway body + API/route pictogram |
| ALB/NLB/load balancer | architecture card + split-routing pictogram |
| SQS/message queue/broker | architecture card + message pictogram |
| SNS/topic | architecture card + message pictogram |
| EventBridge/event bus | architecture card + activity/event pictogram |
| Kafka/Kinesis/stream | architecture card + activity pictogram |
| Lambda/serverless function | function body + code pictogram |
| server/VM/compute | architecture card + server pictogram |
| firewall/WAF | architecture card + shield pictogram |
| identity provider/Okta/Cognito | architecture card + key pictogram |
| secret store/Vault/Secrets Manager | architecture card + key pictogram |
| object storage/S3 | architecture card + storage pictogram |
| browser/web client | architecture card + browser pictogram |
| mobile client | architecture card + mobile-device pictogram |
| external/partner/SaaS system | external-system body + cloud/world pictogram |
| container/Docker | architecture card + box pictogram |
| Kubernetes/EKS/AKS/GKE | architecture card + cluster/hexagon pictogram |
| actor/user/person | native stick figure |

PUML `skinparam` and declaration-level colors still override the fallback palette.

## Inspect the catalog

```bash
arch2visio list-shapes
arch2visio list-icons
```

The render report includes semantic resolution, provider/service recognition and confidence, the selected visual icon source, and AWS icon-catalog resolution details when applicable.

## Explicit bundled icon override

```json
{
  "id": "server",
  "label": "Legacy Application Server",
  "type": "service",
  "builtinIcon": "server"
}
```

or:

```json
{
  "id": "server",
  "label": "Legacy Application Server",
  "type": "service",
  "icon": "builtin:server"
}
```

The bundled pictogram is emitted as native vector Geometry inside the component's Visio group rather than as a bitmap.

## Bundled Tabler subset

The curated set currently includes: `activity`, `api`, `arrows-split`, `binary-tree`, `box`, `braces`, `browser`, `clock`, `cloud`, `database`, `device-desktop`, `device-mobile`, `file`, `folder`, `hexagon`, `key`, `mail`, `message`, `messages`, `network`, `route`, `server`, `shield-lock`, `user`, and `world`.
