---
name: software-project-status-deck
version: 1.0.0
description: Create polished PowerPoint software project status decks with portfolio status, application milestone date views, and professional Gantt charts from structured project data.
---

# Software Project Status Deck Skill

Use this skill when the user needs a beautiful, executive-ready PowerPoint status deck for a software delivery program, application portfolio, migration, modernization, release, or implementation project.

The skill produces a `.pptx` deck from structured project data. It can lean on Python packages such as `python-pptx`, `matplotlib`, `pandas`, and `Pillow` to create charts, timelines, date views, Gantt charts, tables, and layout elements.

## Core outputs

A standard deck should include, at minimum:

1. Title slide
2. Executive summary
3. Portfolio or application status overview
4. Key dates by application, showing all relevant dates for each application in scope
5. Professional Gantt chart
6. Risks, issues, dependencies, and decisions
7. Next steps and asks
8. Optional appendix with detailed application records

The deck must always include:

- One slide that displays all relevant dates for every application in scope.
- One slide with a professionally styled Gantt chart.
- Clear status indicators for schedule, scope, budget, quality, risk, and overall health when available.
- A concise executive narrative, not just raw tables.

## Input expectations

Ask for or infer the following data when available:

- Deck title, subtitle, report date, sponsor, owner, audience
- Project or program objective
- Reporting period
- Applications in scope
- Per-application owner, status, environment, phase, percent complete
- Per-application milestone dates, for example kickoff, design complete, build start, code complete, SIT start, SIT end, UAT start, UAT end, release readiness, production deployment, warranty end
- Workstreams, tasks, start dates, end dates, owners, dependencies, completion percent
- Risks, issues, decisions, blockers, and actions
- Brand colors or presentation template, if supplied

When data is incomplete, create a best-effort draft with explicit placeholders instead of blocking. Use sensible default milestones and mark missing values as `TBD`.

## Design principles

Create one coherent visual composition per slide. Avoid dense dashboards, excessive cards, tiny labels, and overloaded legends.

Default visual language:

- Widescreen 16:9 layout.
- Clean corporate style, suitable for CIO, VP, PMO, steering committee, or architecture review.
- Large titles, strong hierarchy, restrained color palette, generous whitespace.
- Consistent status colors:
  - Green: on track
  - Amber: watch
  - Red: at risk or blocked
  - Blue: complete or informational
  - Gray: not started or TBD
- Use short, action-oriented slide titles.
- Prefer visuals over long bullet lists.
- Never use font sizes below 9 pt in generated chart images or below 11 pt in PowerPoint objects unless the user explicitly asks for dense appendix material.
- Use appendix slides for detail that would clutter the main story.

## Recommended deck structure

### 1. Title

Show title, subtitle, report date, program, and owner. Keep it minimal.

### 2. Executive summary

Tell the story in 3 to 5 concise statements:

- Overall status
- Most important progress
- Biggest concern
- Near-term decision or ask
- Next major milestone

### 3. Portfolio health overview

Show applications grouped by status or phase. Include simple counts and one readable application table.

Suggested columns:

- Application
- Owner
- Current phase
- Overall status
- Schedule status
- Next milestone
- Next milestone date
- Notes

### 4. Application milestone date view

This slide is mandatory.

Purpose: let stakeholders see every relevant date for each application in scope in one place.

Recommended format:

- Rows: applications
- Columns: milestone dates
- Freeze-like visual hierarchy: application name left, dates across the slide
- Use compact status markers or thin timeline strokes to show completed, active, and future milestones
- Sort applications by go-live date or risk
- Highlight dates that changed since the prior report when that data exists
- Mark missing dates as `TBD`, not blank

Standard milestone columns:

- Kickoff
- Design complete
- Build complete
- SIT start
- SIT end
- UAT start
- UAT end
- Release readiness
- Go-live
- Warranty end

If there are too many columns, group them into phases and use date bands:

- Plan
- Build
- Test
- Release
- Warranty

### 5. Professional Gantt chart

This slide is mandatory.

Purpose: show schedule, task sequencing, current date, dependencies, and critical path when available.

Recommended chart style:

- Horizontal bars by application or workstream
- Phase colors or completion overlays
- Monthly or weekly date axis
- Vertical line for current date
- Labels for major release milestones
- Optional diamond markers for gates
- Legend only when needed
- If task count exceeds 18, group tasks or create appendix detail

### 6. Risks, issues, dependencies, decisions

Use a clean table or 2-column layout. Focus on what leaders need to act on.

Suggested columns:

- Type
- Description
- Impact
- Owner
- Due date
- Status
- Ask or mitigation

### 7. Next steps

Show the next 2 to 4 weeks. Use short, owner-specific actions and dates.

### 8. Appendix

Include detailed data only when useful:

- Full application list
- Raw milestone table
- Detailed Gantt by task
- Change log
- Assumptions

## Data format

Prefer JSON or YAML. The included `templates/status_deck_schema.json` describes the recommended structure. The included sample file shows the expected shape.

Minimum viable input:

```json
{
  "deck": {
    "title": "Project Status",
    "subtitle": "Weekly steering committee update",
    "report_date": "2026-09-01"
  },
  "applications": [
    {
      "name": "Claims API",
      "owner": "Team A",
      "phase": "UAT",
      "overall_status": "Amber",
      "percent_complete": 72,
      "milestones": {
        "kickoff": "2026-07-01",
        "design_complete": "2026-07-19",
        "build_complete": "2026-08-12",
        "sit_start": "2026-08-15",
        "sit_end": "2026-08-28",
        "uat_start": "2026-09-02",
        "uat_end": "2026-09-12",
        "release_readiness": "2026-09-16",
        "go_live": "2026-09-20",
        "warranty_end": "2026-10-04"
      }
    }
  ],
  "tasks": [
    {
      "name": "Claims API UAT",
      "application": "Claims API",
      "owner": "Team A",
      "start": "2026-09-02",
      "end": "2026-09-12",
      "status": "Amber",
      "percent_complete": 30
    }
  ]
}
```

## Generation workflow

1. Normalize dates and status values.
2. Validate that applications have names and at least one date or task.
3. Derive missing next milestone and next milestone date from milestone data.
4. Sort applications by go-live, then status severity, then name.
5. Build the deck narrative before creating slides.
6. Generate date-view and Gantt chart images with Python when this gives better precision than native shapes.
7. Insert charts into PowerPoint with proper margins and high resolution.
8. Run a basic slide audit before saving:
   - no text outside slide bounds
   - no obviously overlapping key elements
   - no unreadable font sizes
   - required slides are present
9. Save the `.pptx` and, when useful, also save the normalized data used to create it.

## Python implementation guidance

The included script `scripts/create_status_deck.py` is the reference implementation. It accepts JSON and creates a `.pptx`.

Typical command:

```bash
python scripts/create_status_deck.py examples/sample_status_data.json --output project_status_deck.pptx
```

Required packages:

```bash
pip install -r requirements.txt
```

## Quality checklist

Before returning a deck, check:

- The title slide is simple and not overloaded.
- The executive summary tells the real story.
- The application date view contains every application in scope.
- Missing dates are shown as `TBD`.
- The Gantt chart has readable labels, correct date scale, and a current-date marker.
- Status colors are consistent.
- Important dates are not cut off or overlapping.
- Tables fit the slide or are split across slides.
- All assumptions are stated either on the slide or in the notes.

## Customization options

Support these optional customizations:

- `theme.primary_color`
- `theme.accent_color`
- `theme.font_family`
- `theme.logo_path`
- `theme.footer_text`
- `deck.audience`
- `deck.confidentiality_label`
- `deck.include_appendix`
- `deck.date_axis_granularity`: `weekly`, `monthly`, or `auto`
- `deck.group_gantt_by`: `application`, `workstream`, `phase`, or `owner`

## Handling large portfolios

For more than 12 applications:

- Keep the main date-view slide high level.
- Use phase date bands rather than every micro-milestone.
- Create appendix slides with the full milestone matrix.
- Create multiple Gantt slides grouped by workstream or release train.

For more than 25 tasks:

- Use summary Gantt in the main deck.
- Move detailed task-level Gantt charts to appendix.

## Notes for generated decks

When using generated images for charts, insert them at sufficient resolution for PowerPoint presentation mode. Avoid screenshots of spreadsheets unless explicitly requested. Use native PowerPoint text for key labels whenever possible so the deck remains editable.
