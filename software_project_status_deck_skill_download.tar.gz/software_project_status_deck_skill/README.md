# Software Project Status Deck Skill

A ChatGPT skill package for creating polished PowerPoint software project status decks from structured project data.

## What it includes

- `SKILL.md`: skill instructions and deck design standards
- `scripts/create_status_deck.py`: reference Python generator
- `templates/status_deck_schema.json`: JSON schema for input data
- `examples/sample_status_data.json`: sample data
- `requirements.txt`: Python dependencies

## Quick start

```bash
pip install -r requirements.txt
python scripts/create_status_deck.py examples/sample_status_data.json --output project_status_deck.pptx
```

The generated deck includes an application date view and a professional Gantt chart.
