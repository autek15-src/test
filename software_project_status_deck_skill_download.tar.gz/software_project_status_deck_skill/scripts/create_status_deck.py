#!/usr/bin/env python3
"""Create an executive-ready software project status PowerPoint deck.

Usage:
    python scripts/create_status_deck.py examples/sample_status_data.json --output project_status_deck.pptx
"""

from __future__ import annotations

import argparse
import json
import math
import tempfile
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
from dateutil.parser import parse as parse_date
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_AUTO_SIZE, PP_ALIGN, MSO_ANCHOR
from pptx.util import Inches, Pt

SLIDE_W = 13.333
SLIDE_H = 7.5

DEFAULT_MILESTONES = [
    ("kickoff", "Kickoff"),
    ("design_complete", "Design"),
    ("build_complete", "Build"),
    ("sit_start", "SIT Start"),
    ("sit_end", "SIT End"),
    ("uat_start", "UAT Start"),
    ("uat_end", "UAT End"),
    ("release_readiness", "Release Ready"),
    ("go_live", "Go-live"),
    ("warranty_end", "Warranty End"),
]

STATUS_COLORS = {
    "green": "3BA55D",
    "on track": "3BA55D",
    "complete": "4472C4",
    "blue": "4472C4",
    "amber": "F6C344",
    "yellow": "F6C344",
    "watch": "F6C344",
    "red": "D83B36",
    "blocked": "D83B36",
    "at risk": "D83B36",
    "open": "7A7A7A",
    "gray": "A6A6A6",
    "grey": "A6A6A6",
    "tbd": "A6A6A6",
}

PHASE_COLORS = {
    "plan": "8EAADB",
    "design": "7FBA00",
    "build": "5B9BD5",
    "test": "F4B183",
    "sit": "F4B183",
    "uat": "FFD966",
    "release": "70AD47",
    "warranty": "A9D18E",
}


@dataclass
class Theme:
    primary: str = "17365D"
    accent: str = "2F75B5"
    font: str = "Aptos"
    footer: str = ""
    confidentiality: str = "Internal"


def rgb(hex_color: str) -> RGBColor:
    hex_color = hex_color.strip().lstrip("#")
    return RGBColor(int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16))


def hex_to_rgb_tuple(hex_color: str) -> Tuple[float, float, float]:
    hex_color = hex_color.strip().lstrip("#")
    return tuple(int(hex_color[i : i + 2], 16) / 255 for i in (0, 2, 4))


def parse_dt(value: Any) -> Optional[date]:
    if value in (None, "", "TBD", "tbd"):
        return None
    if isinstance(value, date):
        return value
    try:
        return parse_date(str(value)).date()
    except Exception:
        return None


def fmt_dt(value: Any) -> str:
    parsed = parse_dt(value)
    return parsed.strftime("%b %-d") if parsed else "TBD"


def safe_status(value: Any) -> str:
    return str(value or "TBD").strip()


def status_color(value: Any) -> str:
    return STATUS_COLORS.get(str(value or "tbd").strip().lower(), "A6A6A6")


def status_rank(value: Any) -> int:
    text = str(value or "").strip().lower()
    if text in {"red", "blocked", "at risk"}:
        return 0
    if text in {"amber", "yellow", "watch"}:
        return 1
    if text in {"green", "on track", "complete", "blue"}:
        return 2
    return 3


def add_text(
    slide,
    text: str,
    x: float,
    y: float,
    w: float,
    h: float,
    size: int = 18,
    bold: bool = False,
    color: str = "1F1F1F",
    font: str = "Aptos",
    align=PP_ALIGN.LEFT,
    valign=MSO_ANCHOR.TOP,
    fill: Optional[str] = None,
    radius_shape=MSO_SHAPE.RECTANGLE,
):
    shape = slide.shapes.add_shape(radius_shape, Inches(x), Inches(y), Inches(w), Inches(h))
    shape.line.fill.background()
    if fill:
        shape.fill.solid()
        shape.fill.fore_color.rgb = rgb(fill)
    else:
        shape.fill.background()
    tf = shape.text_frame
    tf.clear()
    tf.margin_left = Inches(0.08)
    tf.margin_right = Inches(0.08)
    tf.margin_top = Inches(0.04)
    tf.margin_bottom = Inches(0.04)
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
    tf.vertical_anchor = valign
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.name = font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = rgb(color)
    return shape


def add_footer(slide, theme: Theme, slide_no: int) -> None:
    text = theme.footer or "Software project status"
    add_text(slide, text, 0.55, 7.18, 7.0, 0.18, 7, color="6B6B6B", font=theme.font)
    add_text(slide, theme.confidentiality, 10.7, 7.18, 1.4, 0.18, 7, color="6B6B6B", font=theme.font, align=PP_ALIGN.RIGHT)
    add_text(slide, str(slide_no), 12.25, 7.18, 0.4, 0.18, 7, color="6B6B6B", font=theme.font, align=PP_ALIGN.RIGHT)


def add_slide_title(slide, title: str, theme: Theme, slide_no: int) -> None:
    add_text(slide, title, 0.55, 0.35, 11.9, 0.45, 28, True, theme.primary, theme.font)
    line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.55), Inches(0.93), Inches(12.2), Inches(0.03))
    line.fill.solid()
    line.fill.fore_color.rgb = rgb(theme.accent)
    line.line.fill.background()
    add_footer(slide, theme, slide_no)


def blank_slide(prs: Presentation):
    return prs.slides.add_slide(prs.slide_layouts[6])


def build_theme(data: Dict[str, Any]) -> Theme:
    theme_data = data.get("theme", {})
    deck = data.get("deck", {})
    return Theme(
        primary=theme_data.get("primary_color", "17365D"),
        accent=theme_data.get("accent_color", "2F75B5"),
        font=theme_data.get("font_family", "Aptos"),
        footer=theme_data.get("footer_text", deck.get("program", "")),
        confidentiality=deck.get("confidentiality_label", "Internal"),
    )


def next_milestone(app: Dict[str, Any], as_of: date) -> Tuple[str, str]:
    milestones = app.get("milestones", {}) or {}
    future = []
    for key, label in DEFAULT_MILESTONES:
        dt = parse_dt(milestones.get(key))
        if dt and dt >= as_of:
            future.append((dt, label))
    if not future:
        return "Complete", ""
    future.sort(key=lambda item: item[0])
    return future[0][1], future[0][0].strftime("%b %-d")


def sort_applications(apps: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    def key(app):
        go_live = parse_dt((app.get("milestones") or {}).get("go_live")) or date.max
        return (go_live, status_rank(app.get("overall_status")), app.get("name", ""))

    return sorted(apps, key=key)


def add_title_slide(prs: Presentation, data: Dict[str, Any], theme: Theme) -> None:
    deck = data.get("deck", {})
    slide = blank_slide(prs)
    bg = slide.background
    bg.fill.solid()
    bg.fill.fore_color.rgb = rgb("F7F9FC")
    band = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(1.05))
    band.fill.solid()
    band.fill.fore_color.rgb = rgb(theme.primary)
    band.line.fill.background()
    add_text(slide, deck.get("title", "Software Project Status"), 0.7, 2.1, 9.8, 0.8, 36, True, theme.primary, theme.font)
    add_text(slide, deck.get("subtitle", "Executive delivery update"), 0.72, 2.95, 8.5, 0.4, 18, False, "4F4F4F", theme.font)
    meta = []
    if deck.get("program"):
        meta.append(deck["program"])
    if deck.get("report_date"):
        meta.append(f"Report date: {deck['report_date']}")
    if deck.get("owner"):
        meta.append(f"Owner: {deck['owner']}")
    add_text(slide, " | ".join(meta), 0.72, 3.55, 10.0, 0.35, 12, False, "666666", theme.font)
    add_text(slide, deck.get("audience", "Steering Committee"), 9.5, 6.3, 2.8, 0.45, 16, True, "FFFFFF", theme.font, fill=theme.accent, radius_shape=MSO_SHAPE.ROUNDED_RECTANGLE, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)
    add_footer(slide, theme, 1)


def add_exec_summary(prs: Presentation, data: Dict[str, Any], theme: Theme, slide_no: int) -> None:
    slide = blank_slide(prs)
    add_slide_title(slide, "Executive summary", theme, slide_no)
    summary = data.get("summary") or [
        "Status summary was not provided. Replace these placeholders with the most important delivery messages.",
        "Highlight material progress, near-term risks, and leadership decisions required.",
        "Call out the next major milestone and whether the team is ready to meet it.",
    ]
    apps = data.get("applications", [])
    counts = {"Green": 0, "Amber": 0, "Red": 0, "Other": 0}
    for app in apps:
        st = safe_status(app.get("overall_status")).title()
        counts[st if st in counts else "Other"] += 1
    x0 = 0.75
    for i, label in enumerate(["Green", "Amber", "Red", "Other"]):
        x = x0 + i * 1.35
        add_text(slide, str(counts[label]), x, 1.28, 0.9, 0.5, 26, True, status_color(label), theme.font, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, label, x, 1.82, 0.9, 0.26, 10, False, "555555", theme.font, align=PP_ALIGN.CENTER)
    add_text(slide, "Applications by overall health", 0.75, 2.18, 5.4, 0.28, 12, True, theme.primary, theme.font)
    y = 2.75
    for item in summary[:5]:
        add_text(slide, "•", 0.85, y + 0.04, 0.2, 0.18, 15, True, theme.accent, theme.font)
        add_text(slide, str(item), 1.15, y, 10.8, 0.48, 16, False, "202020", theme.font)
        y += 0.72
    add_text(slide, "Leadership focus", 8.7, 1.25, 2.6, 0.35, 14, True, "FFFFFF", theme.font, fill=theme.primary, radius_shape=MSO_SHAPE.ROUNDED_RECTANGLE, align=PP_ALIGN.CENTER)
    focus = "Decisions, blockers, and upcoming release gates should be made explicit here."
    if data.get("risks"):
        first = data["risks"][0]
        focus = f"{first.get('type', 'Risk')}: {first.get('description', '')}"
    add_text(slide, focus, 8.05, 1.75, 3.9, 1.35, 14, False, "202020", theme.font, fill="F2F5F8", radius_shape=MSO_SHAPE.ROUNDED_RECTANGLE)


def add_portfolio_overview(prs: Presentation, data: Dict[str, Any], theme: Theme, slide_no: int) -> None:
    slide = blank_slide(prs)
    add_slide_title(slide, "Portfolio status overview", theme, slide_no)
    apps = sort_applications(data.get("applications", []))[:10]
    headers = ["Application", "Owner", "Phase", "Overall", "Schedule", "Next milestone", "Date", "Notes"]
    col_widths = [2.0, 1.3, 1.3, 0.78, 0.82, 1.55, 0.72, 3.0]
    x = 0.55
    y = 1.2
    row_h = 0.42
    for h, w in zip(headers, col_widths):
        add_text(slide, h, x, y, w, row_h, 9, True, "FFFFFF", theme.font, fill=theme.primary, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)
        x += w
    as_of = parse_dt(data.get("deck", {}).get("report_date")) or date.today()
    y += row_h
    for idx, app in enumerate(apps):
        x = 0.55
        fill = "FFFFFF" if idx % 2 == 0 else "F6F8FA"
        milestone, milestone_date = next_milestone(app, as_of)
        vals = [
            app.get("name", ""), app.get("owner", ""), app.get("phase", ""), safe_status(app.get("overall_status")),
            safe_status(app.get("schedule_status", app.get("overall_status"))), milestone, milestone_date, app.get("notes", "")
        ]
        for ci, (val, w) in enumerate(zip(vals, col_widths)):
            if ci in {3, 4}:
                add_text(slide, str(val), x + 0.08, y + 0.08, w - 0.16, 0.24, 8, True, "FFFFFF", theme.font, fill=status_color(val), radius_shape=MSO_SHAPE.ROUNDED_RECTANGLE, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)
            else:
                add_text(slide, str(val), x, y, w, row_h, 8 if ci != 7 else 7, False, "202020", theme.font, fill=fill, valign=MSO_ANCHOR.MIDDLE)
            x += w
        y += row_h
    if len(data.get("applications", [])) > len(apps):
        add_text(slide, f"Showing first {len(apps)} applications sorted by go-live. See appendix for full list.", 0.55, 6.45, 8.0, 0.25, 10, False, "666666", theme.font)


def make_date_view_image(data: Dict[str, Any], theme: Theme, output_path: Path) -> None:
    apps = sort_applications(data.get("applications", []))
    milestone_pairs = DEFAULT_MILESTONES
    n_rows = max(1, len(apps))
    fig_w = 15.5
    fig_h = max(4.5, min(9.0, 1.0 + n_rows * 0.45))
    fig, ax = plt.subplots(figsize=(fig_w, fig_h), dpi=180)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, n_rows + 1)
    ax.axis("off")
    primary = hex_to_rgb_tuple(theme.primary)
    accent = hex_to_rgb_tuple(theme.accent)
    gray_line = hex_to_rgb_tuple("D9DEE7")
    ax.add_patch(plt.Rectangle((0, n_rows + 0.25), 1, 0.55, color=primary, transform=ax.transData))
    app_col = 0.18
    remaining = 0.79
    col_w = remaining / len(milestone_pairs)
    ax.text(0.012, n_rows + 0.52, "Application", color="white", fontsize=9, fontweight="bold", va="center")
    for i, (_, label) in enumerate(milestone_pairs):
        ax.text(app_col + i * col_w + col_w / 2, n_rows + 0.52, label, color="white", fontsize=7.4, fontweight="bold", ha="center", va="center")
    today = parse_dt(data.get("deck", {}).get("report_date")) or date.today()
    for ri, app in enumerate(apps):
        y = n_rows - ri - 0.1
        row_fill = "#FFFFFF" if ri % 2 == 0 else "#F6F8FA"
        ax.add_patch(plt.Rectangle((0, y - 0.28), 1, 0.42, color=row_fill, zorder=0))
        ax.text(0.012, y - 0.06, app.get("name", ""), fontsize=8, fontweight="bold", va="center", color="#1F1F1F")
        ax.text(0.012, y - 0.22, app.get("phase", ""), fontsize=6.5, va="center", color="#666666")
        status_hex = status_color(app.get("overall_status"))
        ax.add_patch(plt.Circle((0.158, y - 0.06), 0.011, color="#" + status_hex))
        milestones = app.get("milestones", {}) or {}
        parsed_dates = [parse_dt(milestones.get(key)) for key, _ in milestone_pairs]
        valid_x = []
        for i, dt in enumerate(parsed_dates):
            x = app_col + i * col_w + col_w / 2
            if dt:
                valid_x.append(x)
        if len(valid_x) >= 2:
            ax.plot([min(valid_x), max(valid_x)], [y - 0.06, y - 0.06], color=gray_line, linewidth=1.4, zorder=1)
        for i, (key, _) in enumerate(milestone_pairs):
            dt = parse_dt(milestones.get(key))
            x = app_col + i * col_w + col_w / 2
            if dt is None:
                ax.text(x, y - 0.06, "TBD", fontsize=6.1, ha="center", va="center", color="#7A7A7A")
            else:
                color = "#4472C4" if dt < today else "#FFFFFF"
                edge = "#4472C4" if dt < today else "#" + status_hex
                ax.add_patch(plt.Circle((x, y - 0.06), 0.015, facecolor=color, edgecolor=edge, linewidth=1.5, zorder=2))
                ax.text(x, y - 0.24, dt.strftime("%b %-d"), fontsize=5.9, ha="center", va="center", color="#333333")
    for i in range(len(milestone_pairs) + 1):
        x = app_col + i * col_w
        ax.plot([x, x], [0.3, n_rows + 0.8], color="#EEF1F5", linewidth=0.7)
    fig.tight_layout(pad=0.2)
    fig.savefig(output_path, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def add_date_view_slide(prs: Presentation, data: Dict[str, Any], theme: Theme, slide_no: int, tmp_dir: Path) -> None:
    slide = blank_slide(prs)
    add_slide_title(slide, "Application milestone date view", theme, slide_no)
    add_text(slide, "All in-scope applications with standard delivery milestones. Completed milestones are filled; future milestones are outlined.", 0.65, 1.02, 11.8, 0.25, 10, False, "555555", theme.font)
    img = tmp_dir / "application_date_view.png"
    make_date_view_image(data, theme, img)
    slide.shapes.add_picture(str(img), Inches(0.55), Inches(1.35), width=Inches(12.25), height=Inches(5.55))


def make_gantt_image(data: Dict[str, Any], theme: Theme, output_path: Path) -> None:
    tasks = list(data.get("tasks", []))
    if not tasks:
        for app in data.get("applications", []):
            milestones = app.get("milestones", {}) or {}
            start = milestones.get("kickoff") or milestones.get("design_complete")
            end = milestones.get("go_live") or milestones.get("warranty_end")
            if start and end:
                tasks.append({"name": app.get("name", "Application"), "application": app.get("name"), "start": start, "end": end, "status": app.get("overall_status"), "percent_complete": app.get("percent_complete", 0)})
    normalized = []
    for task in tasks:
        start = parse_dt(task.get("start"))
        end = parse_dt(task.get("end"))
        if start and end:
            if end < start:
                start, end = end, start
            normalized.append({**task, "start_dt": start, "end_dt": end})
    if not normalized:
        normalized.append({"name": "Schedule TBD", "start_dt": date.today(), "end_dt": date.today(), "status": "TBD", "percent_complete": 0})
    normalized = sorted(normalized, key=lambda t: (t["start_dt"], t.get("application", ""), t.get("name", "")))[:18]
    fig_h = max(4.8, min(8.0, 1.0 + len(normalized) * 0.36))
    fig, ax = plt.subplots(figsize=(14.5, fig_h), dpi=180)
    y_positions = list(range(len(normalized)))
    for y, task in zip(y_positions, normalized):
        start_num = mdates.date2num(task["start_dt"])
        duration = max(1, (task["end_dt"] - task["start_dt"]).days)
        color = "#" + status_color(task.get("status"))
        ax.barh(y, duration, left=start_num, height=0.55, color=color, alpha=0.86, edgecolor="#2F2F2F", linewidth=0.4)
        pct = float(task.get("percent_complete") or 0) / 100
        if pct > 0:
            ax.barh(y, duration * min(max(pct, 0), 1), left=start_num, height=0.24, color="#1F1F1F", alpha=0.32)
    labels = []
    for task in normalized:
        app = task.get("application") or task.get("workstream") or ""
        name = task.get("name", "")
        labels.append(f"{app}: {name}" if app and app not in name else name)
    ax.set_yticks(y_positions)
    ax.set_yticklabels(labels, fontsize=7.5)
    ax.invert_yaxis()
    min_start = min(t["start_dt"] for t in normalized)
    max_end = max(t["end_dt"] for t in normalized)
    ax.set_xlim(mdates.date2num(min_start) - 3, mdates.date2num(max_end) + 5)
    ax.xaxis.set_major_locator(mdates.WeekdayLocator(interval=1))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %-d"))
    plt.setp(ax.get_xticklabels(), rotation=35, ha="right", fontsize=7)
    ax.grid(axis="x", linestyle="-", linewidth=0.35, alpha=0.4)
    ax.set_axisbelow(True)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.spines["bottom"].set_color("#BFBFBF")
    as_of = parse_dt(data.get("deck", {}).get("report_date")) or date.today()
    ax.axvline(mdates.date2num(as_of), color="#17365D", linewidth=1.6)
    ax.text(mdates.date2num(as_of), -0.85, "Report date", fontsize=7, color="#17365D", fontweight="bold", ha="center")
    ax.set_title("Schedule timeline by application and task", loc="left", fontsize=11, fontweight="bold", color="#" + theme.primary)
    fig.tight_layout(pad=0.4)
    fig.savefig(output_path, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def add_gantt_slide(prs: Presentation, data: Dict[str, Any], theme: Theme, slide_no: int, tmp_dir: Path) -> None:
    slide = blank_slide(prs)
    add_slide_title(slide, "Integrated delivery Gantt chart", theme, slide_no)
    add_text(slide, "Timeline view of major application work, completion overlay, and report-date marker.", 0.65, 1.02, 11.8, 0.25, 10, False, "555555", theme.font)
    img = tmp_dir / "gantt_chart.png"
    make_gantt_image(data, theme, img)
    slide.shapes.add_picture(str(img), Inches(0.62), Inches(1.35), width=Inches(12.1), height=Inches(5.55))


def add_raid_slide(prs: Presentation, data: Dict[str, Any], theme: Theme, slide_no: int) -> None:
    slide = blank_slide(prs)
    add_slide_title(slide, "Risks, issues, decisions, and dependencies", theme, slide_no)
    items = data.get("risks") or []
    if not items:
        items = [{"type": "Placeholder", "description": "No active risks or issues provided.", "impact": "Confirm with project team.", "owner": "TBD", "due_date": "TBD", "status": "TBD", "mitigation": "Add mitigation or ask."}]
    headers = ["Type", "Description", "Impact", "Owner", "Due", "Status", "Mitigation or ask"]
    widths = [0.75, 3.0, 2.0, 1.25, 0.8, 0.75, 3.0]
    x0, y = 0.55, 1.2
    row_h = 0.44
    x = x0
    for h, w in zip(headers, widths):
        add_text(slide, h, x, y, w, row_h, 8.5, True, "FFFFFF", theme.font, fill=theme.primary, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)
        x += w
    y += row_h
    for idx, item in enumerate(items[:8]):
        x = x0
        fill = "FFFFFF" if idx % 2 == 0 else "F6F8FA"
        vals = [item.get("type", ""), item.get("description", ""), item.get("impact", ""), item.get("owner", ""), fmt_dt(item.get("due_date")), item.get("status", ""), item.get("mitigation", "")]
        for ci, (val, w) in enumerate(zip(vals, widths)):
            if ci == 5:
                add_text(slide, str(val), x + 0.08, y + 0.09, w - 0.16, 0.22, 7, True, "FFFFFF", theme.font, fill=status_color(val), radius_shape=MSO_SHAPE.ROUNDED_RECTANGLE, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)
            else:
                add_text(slide, str(val), x, y, w, 0.58, 7.4, False, "202020", theme.font, fill=fill, valign=MSO_ANCHOR.MIDDLE)
            x += w
        y += 0.58


def add_next_steps_slide(prs: Presentation, data: Dict[str, Any], theme: Theme, slide_no: int) -> None:
    slide = blank_slide(prs)
    add_slide_title(slide, "Next steps and leadership asks", theme, slide_no)
    steps = data.get("next_steps") or []
    if not steps:
        steps = [{"action": "Add next action", "owner": "TBD", "due_date": "TBD", "status": "TBD"}]
    y = 1.25
    for idx, step in enumerate(steps[:6], start=1):
        status = step.get("status", "TBD")
        add_text(slide, str(idx), 0.75, y, 0.45, 0.45, 16, True, "FFFFFF", theme.font, fill=status_color(status), radius_shape=MSO_SHAPE.OVAL, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)
        add_text(slide, step.get("action", ""), 1.35, y - 0.02, 7.4, 0.3, 16, True, "202020", theme.font)
        add_text(slide, f"Owner: {step.get('owner', 'TBD')} | Due: {fmt_dt(step.get('due_date'))} | Status: {safe_status(status)}", 1.35, y + 0.35, 8.5, 0.24, 10, False, "666666", theme.font)
        y += 0.85
    add_text(slide, "Ask from this forum", 9.1, 1.35, 2.5, 0.35, 15, True, "FFFFFF", theme.font, fill=theme.primary, radius_shape=MSO_SHAPE.ROUNDED_RECTANGLE, align=PP_ALIGN.CENTER)
    ask = "Confirm open decisions and unblock items that could impact the next release gate."
    decision_items = [r for r in data.get("risks", []) if str(r.get("type", "")).lower() == "decision"]
    if decision_items:
        ask = decision_items[0].get("description", ask)
    add_text(slide, ask, 8.65, 1.9, 3.45, 1.3, 15, False, "202020", theme.font, fill="F2F5F8", radius_shape=MSO_SHAPE.ROUNDED_RECTANGLE)


def add_appendix(prs: Presentation, data: Dict[str, Any], theme: Theme, slide_no: int) -> int:
    if not data.get("deck", {}).get("include_appendix", True):
        return slide_no
    apps = sort_applications(data.get("applications", []))
    if not apps:
        return slide_no
    slide = blank_slide(prs)
    add_slide_title(slide, "Appendix: application detail", theme, slide_no)
    headers = ["Application", "Owner", "Environment", "Phase", "%", "Overall", "Quality", "Risk"]
    widths = [2.4, 1.55, 1.25, 1.5, 0.55, 0.8, 0.8, 0.8]
    x0, y = 0.75, 1.2
    row_h = 0.4
    x = x0
    for h, w in zip(headers, widths):
        add_text(slide, h, x, y, w, row_h, 8.5, True, "FFFFFF", theme.font, fill=theme.primary, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)
        x += w
    y += row_h
    for idx, app in enumerate(apps[:12]):
        x = x0
        vals = [app.get("name", ""), app.get("owner", ""), app.get("environment", ""), app.get("phase", ""), f"{app.get('percent_complete', 0)}%", app.get("overall_status", ""), app.get("quality_status", ""), app.get("risk_status", "")]
        fill = "FFFFFF" if idx % 2 == 0 else "F6F8FA"
        for ci, (val, w) in enumerate(zip(vals, widths)):
            if ci >= 5:
                add_text(slide, str(val), x + 0.08, y + 0.08, w - 0.16, 0.22, 7, True, "FFFFFF", theme.font, fill=status_color(val), radius_shape=MSO_SHAPE.ROUNDED_RECTANGLE, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)
            else:
                add_text(slide, str(val), x, y, w, row_h, 7.8, False, "202020", theme.font, fill=fill, valign=MSO_ANCHOR.MIDDLE)
            x += w
        y += row_h
    return slide_no + 1


def create_deck(data: Dict[str, Any], output_path: Path) -> None:
    prs = Presentation()
    prs.slide_width = Inches(SLIDE_W)
    prs.slide_height = Inches(SLIDE_H)
    theme = build_theme(data)
    with tempfile.TemporaryDirectory() as td:
        tmp_dir = Path(td)
        add_title_slide(prs, data, theme)
        slide_no = 2
        add_exec_summary(prs, data, theme, slide_no); slide_no += 1
        add_portfolio_overview(prs, data, theme, slide_no); slide_no += 1
        add_date_view_slide(prs, data, theme, slide_no, tmp_dir); slide_no += 1
        add_gantt_slide(prs, data, theme, slide_no, tmp_dir); slide_no += 1
        add_raid_slide(prs, data, theme, slide_no); slide_no += 1
        add_next_steps_slide(prs, data, theme, slide_no); slide_no += 1
        slide_no = add_appendix(prs, data, theme, slide_no)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        prs.save(output_path)


def load_data(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a software project status PowerPoint deck.")
    parser.add_argument("input", type=Path, help="Path to status data JSON")
    parser.add_argument("--output", type=Path, default=Path("project_status_deck.pptx"), help="Output PPTX path")
    args = parser.parse_args()
    data = load_data(args.input)
    create_deck(data, args.output)
    print(f"Created {args.output}")


if __name__ == "__main__":
    main()
