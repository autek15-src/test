# Input formats

## Canonical JSON
Use `schemas/architecture.schema.json`. JSON is the preferred LLM output because it preserves semantic type, group membership, explicit positions, layout controls, and edge metadata without reverse-engineering diagram syntax.

Important layout fields:

- `layout.engine`: `auto`, `graphviz`, or `layered`. `auto` tries Graphviz `dot` when installed and falls back to the pure-Python layered placer.
- `layout.congestionPenalty`: increases the cost of reusing already occupied routing corridors.
- `layout.profiles`: limits the layout profiles the optimizer evaluates.
- `layout.safeArea`: optional top-left-origin drawing rectangle, in inches, for a supplied Visio template. Use this to avoid title blocks, headers, or reserved corporate-template areas.

## Mermaid
Supported intentionally conservative subset:

- `flowchart` / `graph` LR/RL/TB/TD/BT
- common node declarations
- labeled arrows
- subgraphs
- `architecture-beta` services, groups, membership, and common connectors

Unsupported Mermaid constructs degrade by omission rather than arbitrary interpretation. For complex Mermaid, normalize to JSON and inspect before final rendering.

## PlantUML
Supported subset:

- component, database, queue, cloud, node, actor, rectangle, storage, package, frame, folder, and other common deployment elements
- common arrows and labels, including styled/colored links such as `-[#0066CC]->`, `-[#green,dashed]->`, and `[hidden]` layout links
- nested `rectangle { ... }`, `package { ... }`, `cloud { ... }`, `node { ... }`, `frame { ... }`, and `folder { ... }` blocks as architecture groups
- `left to right direction` / `top to bottom direction`
- common C4 macros (`Person`, `System`, `Container`, `Rel`, boundaries)
- common AWS macro names such as `Lambda`, `APIGateway`, `RDS`, `S3`, `DynamoDB`, `SQS`, `SNS`, `CloudFront`, and `Route53`

For heavily customized PlantUML macros, normalize to JSON first.

### PlantUML grouping and styled-link example

```plantuml
rectangle "AWS Cloud" as AWS {
  rectangle "VPC" as VPC {
    rectangle "Private Zone" as PRIVATE {
      component "Lambda" as LAMBDA
      database "RDS" as DB
    }
  }
}
LAMBDA -[#0066CC]-> DB : TLS 5432
```

The block hierarchy is retained as Visio group/boundary geometry. Styled links remain edges; supported hex colors are carried into native Visio connector line colors. `[hidden]` links influence layout but are not drawn.
