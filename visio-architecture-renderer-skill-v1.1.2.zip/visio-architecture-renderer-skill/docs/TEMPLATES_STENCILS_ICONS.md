# Templates, stencils, and AWS icons

## Visio template
Pass `--template company-template.vsdx`. The renderer uses the template package as the base and appends generated shapes to the first page, preserving existing template content. Configure `layout.safeArea` in the JSON input to reserve title blocks or headers.

## Visio stencil
Pass `--stencil company-shapes.vssx`. The renderer imports master definitions into the output package and attempts to preserve media relationships used by those masters. Use `scripts/inspect_stencil.py` to list master names.

## Master mapping
Pass `--master-map master-map.json`. Keys are architecture node types or labels, values are stencil/template master names. If no exact mapping exists, a conservative token match is attempted. If no master matches, the renderer falls back to a native generic shape.

## AWS Architecture Icons

Pass the root of a user-supplied AWS Architecture Icons collection:

```bash
arch2visio render architecture.json \
  --aws-icons-dir /path/to/AWS-Architecture-Icons \
  -o architecture.vsdx
```

Both official-style **SVG and PNG collections are supported**. The directory can retain its original nested AWS folders; it does not need to be reorganized.

AWS publishes updated Architecture Icon packages periodically. This skill intentionally does not bundle or silently download AWS icon assets. Obtain the current package from AWS and point the renderer at the extracted directory.

### Catalog/index behavior

The first time an icon directory is used, the renderer recursively indexes every `.svg`, `.png`, `.jpg`, and `.jpeg` file and stores a compact JSON index in the user's cache directory. Subsequent renders load that index instead of repeatedly walking the full icon tree.

Default cache location:

```text
~/.cache/visio-architecture-renderer/aws-icons/<directory-hash>.json
```

Override the cache root with `ARCH2VISIO_CACHE_DIR`, or provide an explicit index file with `--aws-icon-index`.

You can build or inspect the index explicitly:

```bash
arch2visio index-aws-icons /path/to/AWS-Architecture-Icons
python scripts/index_aws_icons.py /path/to/AWS-Architecture-Icons
```

Force rebuilding after replacing/updating the icon collection:

```bash
arch2visio index-aws-icons /path/to/AWS-Architecture-Icons --force
```

or during rendering:

```bash
arch2visio render architecture.json \
  --aws-icons-dir /path/to/AWS-Architecture-Icons \
  --refresh-aws-icon-index \
  -o architecture.vsdx
```

### Service resolution

Resolution is deterministic and scored rather than relying on one filename substring. The catalog uses:

1. exact normalized service-name matches
2. built-in AWS service aliases and common architecture abbreviations
3. official icon-name acronyms
4. token overlap between the node type/label and official filename
5. service-vs-resource icon preference
6. image-format/size preference

Examples of built-in shorthand include `APIGW`, `RDS`, `ALB`, `NLB`, `GWLB`, `SQS`, `SNS`, `SFN`, `TGW`, `IGW`, `DX`, `KMS`, `SSM`, and many others.

The indexer catalogs **all** files dynamically, so a future AWS service can resolve from an official filename even before it is added to the built-in alias table. For example, an icon named `Arch_Amazon-Nova-Service_64.png` can match `aws.nova_service` without a code update.

Explain a match without rendering:

```bash
arch2visio resolve-aws-icon /path/to/AWS-Architecture-Icons aws.api_gateway --label "API Gateway"
```

### Custom aliases

If your architecture model uses organization-specific names, extend the built-in aliases with JSON:

```json
{
  "lambda": ["corp function", "serverless compute"],
  "private_link": ["private service endpoint"]
}
```

Then:

```bash
arch2visio render architecture.json \
  --aws-icons-dir /path/to/AWS-Architecture-Icons \
  --aws-aliases aws-aliases.json \
  -o architecture.vsdx
```

### SVG versus PNG

If the same service is available in multiple formats, the resolver prefers **SVG**. SVG is rasterized at a controlled resolution before being embedded into VSDX, which normally gives better source quality. Install optional icon dependencies with:

```bash
python -m pip install -e ".[icons]"
```

If SVG conversion is unavailable but a PNG/JPEG variant exists in the catalog, the renderer automatically falls back to that raster variant.

PNG files require no optional conversion library and are embedded directly.

### Visio editability

AWS icons are embedded as movable image-backed Visio shapes. Node labels and connectors remain independent native Visio objects, and connectors are glued to their owning component shape. The internal artwork of an AWS icon is not converted into individual Visio vector paths.

### Preference order

For each node, the renderer uses:

1. mapped or confidently matched Visio master from a supplied template/stencil
2. indexed local AWS icon for relevant `aws.*` nodes
3. native generic Visio shape

The render quality report includes the AWS index location, cache-hit status, each resolved icon, unresolved AWS nodes, match score, and match reasoning.
