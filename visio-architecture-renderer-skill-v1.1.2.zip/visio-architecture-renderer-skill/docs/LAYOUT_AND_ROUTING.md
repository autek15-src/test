# Layout and routing behavior

The renderer optimizes for architecture readability rather than minimum page area.

1. **Placement candidates**: explicit x/y positions are honored when every node has them. Otherwise `auto` can use Graphviz `dot`; the built-in fallback uses layered ranking and repeated barycentric ordering.
2. **Profiles**: compact, balanced, spacious, and dense-routing profiles vary rank/node spacing.
3. **Groups**: group and nested-group bounds are derived from member nodes with header padding.
4. **Ports**: fan-out and fan-in edges are spread along node sides instead of sharing a single center point.
5. **Orthogonal routing**: a Manhattan-grid A* router treats non-endpoint nodes as expanded obstacles.
6. **Cost model**: routes pay for distance, bends, and reuse of occupied corridors. `layout.congestionPenalty` controls corridor reuse cost.
7. **Fallback**: if A* cannot route an edge, deterministic dogleg candidates are evaluated. The quality report exposes fallbacks.
8. **Selection**: candidates are scored heavily against crossings and routing fallbacks, then bends, extreme aspect ratio, and unnecessary page area.
9. **VSDX output**: connectors are native Visio polyline geometry and include `<Connect>` glue records to source/target shapes.

The renderer does not claim globally optimal graph drawing. Extremely dense graphs may still require human adjustment in Visio. The generated report makes that visible through crossing, fallback, and bend metrics.
