from pathlib import Path
import zipfile, tempfile
from visio_arch_renderer.render import render
from visio_arch_renderer.validate import validate_vsdx
ROOT=Path(__file__).resolve().parents[1]
def _render(name):
 td=tempfile.TemporaryDirectory();out=Path(td.name)/(Path(name).stem+'.vsdx');rep=render(ROOT/'examples'/name,out);return td,out,rep
def test_render_json():
 td,out,rep=_render('aws-target.json');assert validate_vsdx(out)['ok'];td.cleanup()
def test_render_mermaid():
 td,out,rep=_render('sample.mmd');assert validate_vsdx(out)['ok'];td.cleanup()
def test_render_puml():
 td,out,rep=_render('sample.puml');assert validate_vsdx(out)['ok'];td.cleanup()
def test_native_connects():
 td,out,rep=_render('aws-target.json')
 with zipfile.ZipFile(out) as z: assert b'<Connect ' in z.read('visio/pages/page1.xml')
 td.cleanup()

def test_desktop_scaffold_and_styles():
 td,out,rep=_render('aws-target.json')
 with zipfile.ZipFile(out) as z:
  names=set(z.namelist())
  assert 'visio/windows.xml' in names
  doc=z.read('visio/document.xml')
  assert b'<StyleSheet ID="0"' in doc
  assert b'<DocumentSheet ' in doc
  rels=z.read('visio/_rels/document.xml.rels')
  assert b'/relationships/windows' in rels
 td.cleanup()

def test_shapesheet_content_order_is_visio_schema_safe():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('aws-target.json')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  base={'Cell','Trigger','Section'}
  ext={'Text','Data1','Data2','Data3','ForeignData','Shapes'}
  for shape in root.findall(f'.//{{{V}}}Shape'):
   extension_seen=False
   for child in list(shape):
    local=child.tag.rsplit('}',1)[-1]
    if local in ext: extension_seen=True
    elif local in base: assert not extension_seen, f'Shape {shape.get("ID")} has {local} after extension content'
 td.cleanup()

def test_connectors_are_native_one_d_shapes():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('aws-target.json')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  by_id={s.get('ID'):s for s in root.findall(f'.//{{{V}}}Shape')}
  for conn in root.findall(f'.//{{{V}}}Connect'):
   shape=by_id[conn.get('FromSheet')]
   cells={c.get('N'):c.get('V') for c in shape.findall(f'{{{V}}}Cell')}
   assert cells.get('OneD')=='1'
   assert cells.get('ObjType')=='2'
 td.cleanup()


def test_styled_plantuml_edges_render_color_and_hidden_link_is_not_drawn():
 import xml.etree.ElementTree as ET
 V='http://schemas.microsoft.com/office/visio/2012/main'
 td,out,rep=_render('plantuml-styled-zones.puml')
 with zipfile.ZipFile(out) as z:
  root=ET.fromstring(z.read('visio/pages/page1.xml'))
  shapes=root.findall(f'.//{{{V}}}Shape')
  connector_shapes=[]
  colors=[]
  for shape in shapes:
   cells={c.get('N'):c.get('V') for c in shape.findall(f'{{{V}}}Cell')}
   if cells.get('OneD')=='1':
    connector_shapes.append(shape)
    colors.append(cells.get('LineColor'))
  # 4 parsed links, but the PlantUML [hidden] relation is layout-only.
  assert len(connector_shapes)==3
  assert '#0066CC' in colors
  assert '#FF9900' in colors
  assert '#2E7D32' in colors
 td.cleanup()
