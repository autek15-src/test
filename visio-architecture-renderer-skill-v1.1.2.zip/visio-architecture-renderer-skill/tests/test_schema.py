import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_schema_documents_engine_and_congestion():
 s=json.loads((ROOT/'schemas/architecture.schema.json').read_text());p=s['properties']['layout']['properties'];assert 'engine' in p and 'congestionPenalty' in p and 'safeArea' in p
def test_no_aws_assets_bundled():
 files=[p for p in ROOT.rglob('*') if p.is_file()];assert not any('Architecture-Service-Icons' in p.name for p in files)
