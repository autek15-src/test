from pathlib import Path
from visio_arch_renderer.parsers import parse_diagram
from visio_arch_renderer.layout import layout_diagram
from visio_arch_renderer.routing import route_edges,route_metrics
ROOT=Path(__file__).resolve().parents[1]
def test_layout_and_routes():
 d=parse_diagram(ROOT/'examples/aws-target.json');l=layout_diagram(d,'balanced','layered');r=route_edges(d,l.boxes,l.group_boxes);m=route_metrics(r);assert len(l.boxes)==5 and len(r)==4 and m['fallbacks']<=4
def test_graphviz_or_fallback():
 d=parse_diagram(ROOT/'examples/aws-target.json');l=layout_diagram(d,'balanced','auto');assert l.engine in {'graphviz','layered'}
