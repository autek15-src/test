# Release Notes

## 1.1.2 - PlantUML Architecture Parser Fixes

- Parses styled/colored PlantUML links such as `A -[#0066CC]-> B`, `-[#green,dashed]->`, direction hints, and `[hidden]` links instead of silently dropping those edges.
- Preserves hex arrow colors as edge metadata and uses them for native Visio connector line colors.
- Treats PlantUML `rectangle { ... }`, `package { ... }`, `frame { ... }`, `folder { ... }`, `cloud { ... }`, and `node { ... }` blocks as nested architecture groups rather than leaf nodes.
- Supports aliased and unaliased zone/container blocks, with deterministic IDs for unaliased quoted group labels.
- Preserves parent/child nesting such as AWS Cloud -> VPC -> availability zone/subnet/zone.
- Treats PlantUML `[hidden]` relationships as layout constraints but omits them from rendered Visio connectors.
- Expands standard PlantUML node declarations to include actors and common deployment-diagram element kinds.
- Adds parser and renderer regression fixtures for colored links, dashed links, hidden links, and nested rectangle zones.
- Adds the styled/nested PlantUML fixture to the package completion validator.

## 1.1.1 - Visio Desktop Compatibility Fix

- Fixes Microsoft Visio Standard/Professional 2019 open failure reported as **Error 271 during Open File** for freshly generated VSDX packages.
- Corrects ShapeSheet XML child ordering so Character/Paragraph/Tabs sections precede the `<Text>` element as required by the Visio schema.
- Defines StyleSheet ID 0 and DocumentSheet in fresh `document.xml` instead of referencing an undefined default style.
- Adds desktop-oriented `visio/windows.xml`, its document relationship, and content type.
- Marks generated connectors as native 1-D connector shapes (`OneD=1`, `ObjType=2`, `GlueType=2`).
- Adds PNG `CompressionType` metadata on embedded bitmap ForeignData.
- Expands VSDX validation with desktop compatibility checks for style references, ShapeSheet ordering, connector semantics, image relationships, and Windows metadata.
- Adds regression tests specifically covering these failures.
- Adds `scripts/validate_with_visio.ps1` for an optional native Microsoft Visio COM open test on Windows.

## 1.1.0 - AWS Icon Catalog/Indexer

## AWS icon catalog/indexer
- recursively indexes every user-supplied AWS SVG/PNG/JPEG icon instead of scanning filenames independently for every node
- caches the index outside the AWS asset directory and reuses it on subsequent renders
- adds deterministic scoring using normalized official names, service aliases, acronyms, token overlap, service/resource semantics, format, and image size
- adds a broad built-in AWS service/abbreviation alias catalog while still supporting newly released services directly from official filenames
- prefers SVG when available and automatically falls back to PNG/JPEG if SVG conversion is unavailable
- adds custom alias extension files via `--aws-aliases`
- adds `arch2visio index-aws-icons` and `arch2visio resolve-aws-icon`
- adds explicit `--aws-icon-index` and `--refresh-aws-icon-index` controls
- includes icon resolution details and cache status in the JSON render quality report
- adds AWS index/resolution/render tests, including unknown future-service filename matching

## Existing v1.0 capabilities retained
- canonical architecture JSON schema
- Mermaid parser
- PlantUML/C4/common AWS macro parser
- automatic Graphviz-or-layered placement
- multiple layout profiles with score-based selection
- obstacle-aware orthogonal routing with congestion penalty
- native editable VSDX shapes, text, polyline connectors, and connector glue records
- optional VSDX template preservation and safe drawing area
- optional VSSX stencil master import and master mapping
- structural VSDX validation and optional LibreOffice open/render smoke test
- Codex/Claude-style `SKILL.md`, CLI/scripts, examples, tests, and completion validator
