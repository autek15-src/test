from __future__ import annotations
import json, re, shutil, zipfile
from pathlib import Path, PurePosixPath
import xml.etree.ElementTree as ET
NS='http://schemas.microsoft.com/office/visio/2012/main'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
ET.register_namespace('',NS); ET.register_namespace('r',R)

def inspect_stencil(path:str|Path):
    with zipfile.ZipFile(path) as z:
        if 'visio/masters/masters.xml' not in z.namelist(): return {}
        root=ET.fromstring(z.read('visio/masters/masters.xml'))
        return {m.get('NameU') or m.get('Name') or f"Master {m.get('ID')}": int(m.get('ID')) for m in root.findall(f'{{{NS}}}Master')}

def load_master_map(path):
    if not path:return {}
    return json.loads(Path(path).read_text(encoding='utf-8'))

def choose_master(node_type:str,label:str, masters:dict[str,int], mapping:dict):
    wanted=mapping.get(node_type) or mapping.get(label)
    if wanted:
        for name,mid in masters.items():
            if name.lower()==str(wanted).lower(): return mid
    tokens=_tokens(node_type+' '+label)
    best=None
    for name,mid in masters.items():
        score=len(tokens & _tokens(name))
        if score and (best is None or score>best[0]):best=(score,mid)
    return best[1] if best else None

def _tokens(s):return {x for x in re.split(r'[^a-z0-9]+',s.lower()) if len(x)>2}

def import_stencil_into_package(pkg:dict[str,bytes], stencil_path:str|Path)->dict[str,int]:
    """Merge stencil masters into an in-memory VSDX package. Supports geometry and media-backed masters."""
    with zipfile.ZipFile(stencil_path) as z:
        if 'visio/masters/masters.xml' not in z.namelist():return {}
        s_names=set(z.namelist())
        sroot=ET.fromstring(z.read('visio/masters/masters.xml'))
        srels=_read_rels(z,'visio/masters/_rels/masters.xml.rels')
        # base master list
        if 'visio/masters/masters.xml' in pkg:
            broot=ET.fromstring(pkg['visio/masters/masters.xml'])
            brels=ET.fromstring(pkg.get('visio/masters/_rels/masters.xml.rels',_empty_rels()))
        else:
            broot=ET.Element(f'{{{NS}}}Masters')
            brels=ET.Element(f'{{{REL}}}Relationships')
        max_id=max([int(m.get('ID','0')) for m in broot.findall(f'{{{NS}}}Master')]+[0])
        max_part=max([int(re.search(r'master(\d+)\.xml$',n).group(1)) for n in pkg if re.search(r'visio/masters/master(\d+)\.xml$',n)]+[0])
        max_rid=max([_rid_num(r.get('Id','')) for r in brels]+[0])
        imported={}
        for sm in sroot.findall(f'{{{NS}}}Master'):
            oldrid=sm.find(f'{{{NS}}}Rel')
            if oldrid is None:continue
            rid=oldrid.get(f'{{{R}}}id'); target=srels.get(rid)
            if not target:continue
            src='visio/masters/'+PurePosixPath(target).name
            if src not in s_names:continue
            max_id+=1; max_part+=1; max_rid+=1
            newpart=f'visio/masters/master{max_part}.xml'; pkg[newpart]=z.read(src)
            # copy rels/media for this master, rewriting media targets
            srp=f'visio/masters/_rels/{PurePosixPath(src).name}.rels'
            if srp in s_names:
                rr=ET.fromstring(z.read(srp))
                for rel in rr:
                    tgt=rel.get('Target','')
                    if '../media/' in tgt:
                        media='visio/media/'+PurePosixPath(tgt).name
                        if media in s_names:
                            outmedia=_unique_media(pkg,PurePosixPath(media).name); pkg['visio/media/'+outmedia]=z.read(media); rel.set('Target','../media/'+outmedia)
                pkg[f'visio/masters/_rels/master{max_part}.xml.rels']=ET.tostring(rr,encoding='utf-8',xml_declaration=True)
            nm=ET.fromstring(ET.tostring(sm)); nm.set('ID',str(max_id)); nrid=f'rId{max_rid}'
            relnode=nm.find(f'{{{NS}}}Rel'); relnode.set(f'{{{R}}}id',nrid); broot.append(nm)
            ET.SubElement(brels,f'{{{REL}}}Relationship',{'Id':nrid,'Type':'http://schemas.microsoft.com/visio/2010/relationships/master','Target':PurePosixPath(newpart).name})
            imported[nm.get('NameU') or nm.get('Name') or str(max_id)]=max_id
        pkg['visio/masters/masters.xml']=ET.tostring(broot,encoding='utf-8',xml_declaration=True)
        pkg['visio/masters/_rels/masters.xml.rels']=ET.tostring(brels,encoding='utf-8',xml_declaration=True)
        _ensure_document_master_rel(pkg); _ensure_content_types(pkg)
        return imported

def _empty_rels():return b'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>'
def _read_rels(z,name):
    if name not in z.namelist():return {}
    r=ET.fromstring(z.read(name));return {x.get('Id'):x.get('Target') for x in r}
def _rid_num(s):
    m=re.search(r'(\d+)$',s);return int(m.group(1)) if m else 0
def _unique_media(pkg,name):
    stem=Path(name).stem; suf=Path(name).suffix; out=name;i=2
    while 'visio/media/'+out in pkg:out=f'{stem}_{i}{suf}';i+=1
    return out
def _ensure_document_master_rel(pkg):
    name='visio/_rels/document.xml.rels'; root=ET.fromstring(pkg.get(name,_empty_rels()))
    if not any(x.get('Type','').endswith('/masters') for x in root):
        rid=max([_rid_num(x.get('Id','')) for x in root]+[0])+1;ET.SubElement(root,f'{{{REL}}}Relationship',{'Id':f'rId{rid}','Type':'http://schemas.microsoft.com/visio/2010/relationships/masters','Target':'masters/masters.xml'})
    pkg[name]=ET.tostring(root,encoding='utf-8',xml_declaration=True)
def _ensure_content_types(pkg):
    name='[Content_Types].xml'; CT='http://schemas.openxmlformats.org/package/2006/content-types'; root=ET.fromstring(pkg[name]);existing={x.get('PartName') for x in root}
    for p in pkg:
        if re.match(r'visio/masters/master\d+\.xml$',p):
            pn='/'+p
            if pn not in existing:ET.SubElement(root,f'{{{CT}}}Override',{'PartName':pn,'ContentType':'application/vnd.ms-visio.master+xml'})
    if '/visio/masters/masters.xml' not in existing:ET.SubElement(root,f'{{{CT}}}Override',{'PartName':'/visio/masters/masters.xml','ContentType':'application/vnd.ms-visio.masters+xml'})
    pkg[name]=ET.tostring(root,encoding='utf-8',xml_declaration=True)
