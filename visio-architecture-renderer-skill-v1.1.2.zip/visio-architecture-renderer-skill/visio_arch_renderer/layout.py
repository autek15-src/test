from __future__ import annotations
from dataclasses import dataclass
import math, subprocess, tempfile
from collections import defaultdict, deque
from .model import Diagram

@dataclass
class Box:
    x: float; y: float; w: float; h: float
    @property
    def cx(self): return self.x+self.w/2
    @property
    def cy(self): return self.y+self.h/2

@dataclass
class LayoutResult:
    boxes: dict[str,Box]
    group_boxes: dict[str,Box]
    width: float
    height: float
    engine: str

PROFILES={
    "compact": dict(rank_gap=130,node_gap=32,margin=45,group_pad=34),
    "balanced": dict(rank_gap=170,node_gap=44,margin=55,group_pad=42),
    "spacious": dict(rank_gap=210,node_gap=58,margin=65,group_pad=50),
    "dense-routing": dict(rank_gap=190,node_gap=64,margin=55,group_pad=48),
}

def layout_diagram(diagram: Diagram, profile="balanced", engine="auto") -> LayoutResult:
    cfg=PROFILES.get(profile,PROFILES["balanced"])
    explicit = all(n.x is not None and n.y is not None for n in diagram.nodes) and bool(diagram.nodes)
    if explicit:
        boxes={n.id:Box(n.x or 0,n.y or 0,n.width,n.height) for n in diagram.nodes}
        eng="explicit"
    elif engine in {"auto","graphviz"}:
        try:
            boxes=_graphviz(diagram,cfg)
            eng="graphviz"
        except Exception:
            if engine=="graphviz": raise
            boxes=_layered(diagram,cfg); eng="layered"
    else:
        boxes=_layered(diagram,cfg); eng="layered"
    group_boxes=_groups(diagram,boxes,cfg["group_pad"])
    # shift all positive and include group bounds
    allb=list(boxes.values())+list(group_boxes.values())
    if not allb: return LayoutResult({}, {}, 800, 500, eng)
    minx=min(b.x for b in allb); miny=min(b.y for b in allb)
    dx=cfg["margin"]-minx; dy=cfg["margin"]-miny
    if dx or dy:
        for b in boxes.values(): b.x+=dx; b.y+=dy
        for b in group_boxes.values(): b.x+=dx; b.y+=dy
    maxx=max(b.x+b.w for b in list(boxes.values())+list(group_boxes.values()))+cfg["margin"]
    maxy=max(b.y+b.h for b in list(boxes.values())+list(group_boxes.values()))+cfg["margin"]
    return LayoutResult(boxes,group_boxes,max(500,maxx),max(350,maxy),eng)

def _graphviz(d,cfg):
    lines=['digraph G {','graph [rankdir='+('TB' if d.direction in {'TB','TD','BT'} else 'LR')+', nodesep=0.45, ranksep=0.75];','node [shape=box,fixedsize=true,width=2.1,height=1.0];']
    for n in d.nodes: lines.append(f'"{_q(n.id)}" [label="{_q(n.label)}"];')
    for e in d.edges: lines.append(f'"{_q(e.source)}" -> "{_q(e.target)}";')
    lines.append('}')
    p=subprocess.run(['dot','-Tplain'],input='\n'.join(lines),text=True,capture_output=True,check=True)
    pts={}
    for line in p.stdout.splitlines():
        a=line.split()
        if len(a)>=6 and a[0]=='node':
            nid=a[1].strip('"'); x=float(a[2])*96; y=float(a[3])*96; w=float(a[4])*96; h=float(a[5])*96
            pts[nid]=(x,y,w,h)
    if len(pts)!=len(d.nodes): raise RuntimeError('graphviz did not place all nodes')
    maxy=max(y for x,y,w,h in pts.values())
    return {n.id:Box(pts[n.id][0], maxy-pts[n.id][1], n.width, n.height) for n in d.nodes}

def _q(s): return str(s).replace('"','\\"')

def _layered(d,cfg):
    ids=[n.id for n in d.nodes]; incoming=defaultdict(set); outgoing=defaultdict(set)
    for e in d.edges:
        if e.source in ids and e.target in ids and e.source!=e.target:
            outgoing[e.source].add(e.target); incoming[e.target].add(e.source)
    indeg={i:len(incoming[i]) for i in ids}; q=deque([i for i in ids if indeg[i]==0]); order=[]
    while q:
        u=q.popleft(); order.append(u)
        for v in outgoing[u]:
            indeg[v]-=1
            if indeg[v]==0:q.append(v)
    # cycles: append remaining deterministically
    order += [i for i in ids if i not in order]
    rank={i:0 for i in ids}
    for u in order:
        for v in outgoing[u]:
            if rank[v]<=rank[u]: rank[v]=rank[u]+1
    maxrank=max(rank.values(),default=0)
    layers=defaultdict(list)
    for i in ids: layers[rank[i]].append(i)
    # barycentric sweeps
    pos={i:k for r in layers for k,i in enumerate(layers[r])}
    for _ in range(5):
        for r in range(1,maxrank+1):
            layers[r].sort(key=lambda x:(sum(pos[p] for p in incoming[x])/len(incoming[x]) if incoming[x] else pos[x],x)); pos.update({x:k for k,x in enumerate(layers[r])})
        for r in range(maxrank-1,-1,-1):
            layers[r].sort(key=lambda x:(sum(pos[p] for p in outgoing[x])/len(outgoing[x]) if outgoing[x] else pos[x],x)); pos.update({x:k for k,x in enumerate(layers[r])})
    node={n.id:n for n in d.nodes}; boxes={}
    horizontal=d.direction not in {'TB','TD','BT'}
    for r in range(maxrank+1):
        cursor=0
        for nid in layers[r]:
            n=node[nid]
            if horizontal: boxes[nid]=Box(r*cfg['rank_gap'],cursor,n.width,n.height); cursor+=n.height+cfg['node_gap']
            else: boxes[nid]=Box(cursor,r*cfg['rank_gap'],n.width,n.height); cursor+=n.width+cfg['node_gap']
    return boxes

def _groups(d,boxes,pad):
    group_map={g.id:g for g in d.groups}; children=defaultdict(list)
    for n in d.nodes:
        if n.group: children[n.group].append(n.id)
    # nested groups derive from child group boxes iteratively
    result={}
    remaining=set(group_map)
    for _ in range(len(remaining)+2):
        progressed=False
        for gid in list(remaining):
            members=[boxes[n] for n in children[gid] if n in boxes]
            child_groups=[b for cid,b in result.items() if group_map.get(cid) and group_map[cid].parent==gid]
            members+=child_groups
            unresolved=any(group_map[cid].parent==gid and cid not in result for cid in group_map)
            if unresolved and not members: continue
            if members:
                minx=min(b.x for b in members)-pad; miny=min(b.y for b in members)-pad-22
                maxx=max(b.x+b.w for b in members)+pad; maxy=max(b.y+b.h for b in members)+pad
                result[gid]=Box(minx,miny,maxx-minx,maxy-miny)
            else: result[gid]=Box(0,0,260,160)
            remaining.remove(gid); progressed=True
        if not progressed: break
    return result
