from __future__ import annotations
import json, posixpath, re, shutil, subprocess, tempfile, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET

V='http://schemas.microsoft.com/office/visio/2012/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
CT='http://schemas.openxmlformats.org/package/2006/content-types'


def _rels_name(part: str) -> str:
    d, b = posixpath.split(part)
    return posixpath.join(d, '_rels', b + '.rels')


def _resolve_target(source_part: str, target: str) -> str:
    return posixpath.normpath(posixpath.join(posixpath.dirname(source_part), target)).lstrip('/')


def _rels_by_id(z, names, source_part: str):
    relpart=_rels_name(source_part)
    if relpart not in names:
        return {}, []
    try:
        root=ET.fromstring(z.read(relpart))
    except Exception as exc:
        return {}, [f'invalid XML {relpart}: {exc}']
    out={}
    errors=[]
    for rel in root.findall(f'{{{REL}}}Relationship'):
        rid=rel.get('Id')
        if not rid:
            errors.append(f'{relpart}: relationship missing Id')
            continue
        if rid in out:
            errors.append(f'{relpart}: duplicate relationship Id {rid}')
        out[rid]=rel
    return out, errors


def _shape_order_errors(shape, page_part):
    # Sheet_Type content (Cell/Trigger/Section) must precede ShapeSheet extension
    # content (Text/Data1/Data2/Data3/ForeignData/Shapes). This is tolerated by
    # some readers but desktop Visio can reject out-of-order XML.
    base={'Cell','Trigger','Section'}
    ext_order={'Text':0,'Data1':1,'Data2':2,'Data3':3,'ForeignData':4,'Shapes':5}
    extension_seen=False
    last_ext=-1
    errs=[]
    for child in list(shape):
        local=child.tag.rsplit('}',1)[-1]
        if local in base:
            if extension_seen:
                errs.append(f'{page_part}: Shape {shape.get("ID")} has {local} after ShapeSheet extension content')
        elif local in ext_order:
            extension_seen=True
            if ext_order[local] < last_ext:
                errs.append(f'{page_part}: Shape {shape.get("ID")} has out-of-order {local} element')
            last_ext=max(last_ext,ext_order[local])
    return errs


def validate_vsdx(path, libreoffice=False):
    path=Path(path); errors=[]; warnings=[]; stats={}
    if not path.exists():return {'ok':False,'errors':['file not found'],'warnings':[],'stats':{}}
    try:
        with zipfile.ZipFile(path) as z:
            names=set(z.namelist())
            required={'[Content_Types].xml','_rels/.rels','visio/document.xml','visio/_rels/document.xml.rels','visio/pages/pages.xml','visio/pages/_rels/pages.xml.rels'}
            for r in required:
                if r not in names:errors.append('missing '+r)
            bad=z.testzip()
            if bad:errors.append('CRC failure '+bad)
            for n in names:
                if n.endswith('.xml') or n.endswith('.rels'):
                    try:ET.fromstring(z.read(n))
                    except Exception as e:errors.append(f'invalid XML {n}: {e}')
            if errors:
                return {'ok':False,'errors':errors,'warnings':warnings,'stats':stats}

            # Content types and document relationships.
            ct=ET.fromstring(z.read('[Content_Types].xml'))
            overrides={x.get('PartName'):x.get('ContentType') for x in ct.findall(f'{{{CT}}}Override')}
            defaults={x.get('Extension','').lower():x.get('ContentType') for x in ct.findall(f'{{{CT}}}Default')}
            expected_ct={
                '/visio/document.xml':'application/vnd.ms-visio.drawing.main+xml',
                '/visio/pages/pages.xml':'application/vnd.ms-visio.pages+xml',
            }
            for part,ctype in expected_ct.items():
                if overrides.get(part)!=ctype: errors.append(f'[Content_Types].xml missing/incorrect override for {part}')

            docrels, rel_errors=_rels_by_id(z,names,'visio/document.xml'); errors.extend(rel_errors)
            pages_rel=[r for r in docrels.values() if r.get('Type')=='http://schemas.microsoft.com/visio/2010/relationships/pages']
            if not pages_rel: errors.append('document.xml.rels has no pages relationship')
            windows_rel=[r for r in docrels.values() if r.get('Type')=='http://schemas.microsoft.com/visio/2010/relationships/windows']
            if not windows_rel:
                warnings.append('desktop compatibility: document has no windows.xml relationship')
            else:
                target=_resolve_target('visio/document.xml',windows_rel[0].get('Target',''))
                if target not in names: errors.append(f'document windows relationship target missing: {target}')
                if overrides.get('/'+target)!='application/vnd.ms-visio.windows+xml': errors.append(f'[Content_Types].xml missing windows override for /{target}')

            # Style references: desktop Visio is stricter than LibreOffice here.
            doc=ET.fromstring(z.read('visio/document.xml'))
            styles={s.get('ID') for s in doc.findall(f'.//{{{V}}}StyleSheet') if s.get('ID') is not None}
            settings=doc.find(f'{{{V}}}DocumentSettings')
            if settings is not None:
                for attr in ('DefaultTextStyle','DefaultLineStyle','DefaultFillStyle'):
                    ref=settings.get(attr)
                    if ref is not None and ref not in styles: errors.append(f'document.xml {attr} references undefined style {ref}')
            if '0' not in styles: errors.append('desktop compatibility: document.xml does not define StyleSheet ID 0')

            pages=[n for n in names if re.fullmatch(r'visio/pages/page\d+\.xml',n)]
            stats['pages']=len(pages);stats['media']=len([n for n in names if n.startswith('visio/media/')])
            shapes=connects=foreign=0
            for p in pages:
                root=ET.fromstring(z.read(p))
                # Enforce PageContents child order: Shapes then Connects.
                seen_connects=False
                for child in list(root):
                    local=child.tag.rsplit('}',1)[-1]
                    if local=='Connects': seen_connects=True
                    elif local=='Shapes' and seen_connects: errors.append(f'{p}: Shapes occurs after Connects')

                sh=root.findall(f'.//{{{V}}}Shape'); shapes+=len(sh); ids={s.get('ID') for s in sh}
                by_id={s.get('ID'):s for s in sh}
                page_rels, rel_errors=_rels_by_id(z,names,p); errors.extend(rel_errors)
                for s in sh:
                    errors.extend(_shape_order_errors(s,p))
                    # Style refs on locally-authored shapes should resolve.
                    if s.get('Master') is None:
                        for attr in ('LineStyle','FillStyle','TextStyle'):
                            ref=s.get(attr)
                            if ref is not None and ref not in styles: errors.append(f'{p}: Shape {s.get("ID")} {attr} references undefined style {ref}')
                    fd=s.find(f'{{{V}}}ForeignData')
                    if fd is not None:
                        foreign+=1
                        rel=fd.find(f'{{{V}}}Rel')
                        rid=rel.get(f'{{{R}}}id') if rel is not None else None
                        if not rid or rid not in page_rels:
                            errors.append(f'{p}: Shape {s.get("ID")} ForeignData relationship missing/unresolved')
                        else:
                            target=_resolve_target(p,page_rels[rid].get('Target',''))
                            if target not in names: errors.append(f'{p}: image relationship {rid} target missing: {target}')
                            ext=Path(target).suffix.lower().lstrip('.')
                            if ext and ext not in defaults and ('/'+target) not in overrides:
                                errors.append(f'[Content_Types].xml has no content type for {target}')

                for c in root.findall(f'.//{{{V}}}Connect'):
                    connects+=1
                    if c.get('FromSheet') not in ids:errors.append(f'{p}: Connect FromSheet {c.get("FromSheet")} missing')
                    if c.get('ToSheet') not in ids:errors.append(f'{p}: Connect ToSheet {c.get("ToSheet")} missing')
                    source=by_id.get(c.get('FromSheet'))
                    if source is not None and c.get('FromCell') in {'BeginX','EndX'}:
                        one_d=next((x.get('V') for x in source.findall(f'{{{V}}}Cell') if x.get('N')=='OneD'),None)
                        if one_d!='1': errors.append(f'{p}: connected line Shape {source.get("ID")} is not marked OneD=1')
            stats['shapes']=shapes;stats['connects']=connects;stats['foreignShapes']=foreign
            stats['desktopCompatibilityChecks']='passed' if not errors else 'failed'
    except zipfile.BadZipFile as e:errors.append('not a valid ZIP/VSDX: '+str(e))
    if libreoffice and not errors:
        lo=shutil.which('libreoffice')
        if lo:
            with tempfile.TemporaryDirectory() as td:
                p=subprocess.run([lo,'--headless','--convert-to','pdf','--outdir',td,str(path)],capture_output=True,text=True,timeout=60)
                pdf=Path(td)/(path.stem+'.pdf')
                if p.returncode!=0 or not pdf.exists() or pdf.stat().st_size<500: errors.append('LibreOffice could not render VSDX: '+(p.stderr or p.stdout).strip())
                else:stats['libreofficePdfBytes']=pdf.stat().st_size
        else:warnings.append('LibreOffice not installed; smoke test skipped')
    return {'ok':not errors,'errors':errors,'warnings':warnings,'stats':stats}
