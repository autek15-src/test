from __future__ import annotations

import hashlib
import io
import json
import os
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

INDEX_VERSION = 2
SUPPORTED_EXTENSIONS = {'.svg', '.png', '.jpg', '.jpeg'}

# Aliases are intentionally broader than the current AWS icon set. The indexer still
# catalogs every file dynamically, so new AWS services can resolve by their official
# filename even before this table is updated. Aliases mainly cover abbreviations and
# common architecture shorthand used by humans and LLMs.
BUILTIN_ALIASES: dict[str, list[str]] = {
    'api_gateway': ['api gateway', 'apigateway', 'amazon api gateway', 'execute api', 'rest api', 'http api'],
    'lambda': ['lambda', 'aws lambda', 'lambda function', 'serverless function'],
    'ec2': ['ec2', 'elastic compute cloud', 'amazon ec2', 'instance', 'compute instance'],
    'ecs': ['ecs', 'elastic container service', 'amazon ecs'],
    'eks': ['eks', 'elastic kubernetes service', 'amazon eks', 'kubernetes'],
    'ecr': ['ecr', 'elastic container registry', 'amazon ecr', 'container registry'],
    'fargate': ['fargate', 'aws fargate'],
    'batch': ['batch', 'aws batch'],
    'elastic_beanstalk': ['elastic beanstalk', 'beanstalk'],
    'app_runner': ['app runner', 'apprunner'],
    'lightsail': ['lightsail'],
    'outposts': ['outposts', 'aws outposts'],
    'local_zones': ['local zones', 'local zone'],
    'wavelength': ['wavelength'],
    's3': ['s3', 'simple storage service', 'amazon s3', 'object storage'],
    'efs': ['efs', 'elastic file system', 'amazon efs'],
    'fsx': ['fsx', 'amazon fsx'],
    'storage_gateway': ['storage gateway', 'aws storage gateway'],
    'backup': ['aws backup', 'backup'],
    'snow_family': ['snow family', 'snowball', 'snowcone', 'snowmobile'],
    'transfer_family': ['transfer family', 'aws transfer family', 'sftp'],
    'rds': ['rds', 'relational database service', 'amazon rds', 'relational database'],
    'aurora': ['aurora', 'amazon aurora'],
    'dynamodb': ['dynamodb', 'dynamo db', 'amazon dynamodb'],
    'documentdb': ['documentdb', 'document db', 'amazon documentdb'],
    'neptune': ['neptune', 'amazon neptune', 'graph database'],
    'elasticache': ['elasticache', 'elasti cache', 'amazon elasticache'],
    'memorydb': ['memorydb', 'memory db', 'amazon memorydb'],
    'redshift': ['redshift', 'amazon redshift'],
    'timestream': ['timestream', 'amazon timestream'],
    'keyspaces': ['keyspaces', 'amazon keyspaces', 'managed cassandra'],
    'qldb': ['qldb', 'quantum ledger database'],
    'sqs': ['sqs', 'simple queue service', 'amazon sqs', 'queue'],
    'sns': ['sns', 'simple notification service', 'amazon sns', 'notification topic'],
    'eventbridge': ['eventbridge', 'event bridge', 'amazon eventbridge', 'event bus'],
    'step_functions': ['step functions', 'stepfunctions', 'sfn', 'state machine'],
    'mq': ['amazon mq', 'mq', 'managed message broker'],
    'appsync': ['appsync', 'app sync', 'aws appsync', 'graphql api'],
    'kinesis': ['kinesis', 'amazon kinesis', 'kinesis data streams'],
    'firehose': ['firehose', 'kinesis firehose', 'amazon data firehose', 'data firehose'],
    'msk': ['msk', 'managed streaming for apache kafka', 'amazon msk', 'kafka'],
    'vpc': ['vpc', 'virtual private cloud', 'amazon vpc'],
    'subnet': ['subnet', 'vpc subnet'],
    'internet_gateway': ['internet gateway', 'igw'],
    'nat_gateway': ['nat gateway', 'natgw'],
    'transit_gateway': ['transit gateway', 'tgw'],
    'private_link': ['privatelink', 'private link', 'aws privatelink'],
    'vpc_endpoint': ['vpc endpoint', 'interface endpoint', 'gateway endpoint'],
    'direct_connect': ['direct connect', 'dx', 'aws direct connect'],
    'site_to_site_vpn': ['site to site vpn', 'site-to-site vpn', 'vpn connection', 'aws vpn'],
    'client_vpn': ['client vpn', 'aws client vpn'],
    'route53': ['route53', 'route 53', 'amazon route 53', 'dns'],
    'cloudfront': ['cloudfront', 'cloud front', 'amazon cloudfront', 'cdn'],
    'global_accelerator': ['global accelerator', 'aws global accelerator'],
    'elastic_load_balancing': ['elastic load balancing', 'elb', 'load balancer'],
    'application_load_balancer': ['application load balancer', 'alb'],
    'network_load_balancer': ['network load balancer', 'nlb'],
    'gateway_load_balancer': ['gateway load balancer', 'gwlb'],
    'network_firewall': ['network firewall', 'aws network firewall'],
    'cloud_map': ['cloud map', 'aws cloud map', 'service discovery'],
    'app_mesh': ['app mesh', 'aws app mesh', 'service mesh'],
    'cloudwatch': ['cloudwatch', 'cloud watch', 'amazon cloudwatch', 'monitoring'],
    'xray': ['x-ray', 'xray', 'aws x-ray', 'tracing'],
    'cloudtrail': ['cloudtrail', 'cloud trail', 'aws cloudtrail'],
    'config': ['aws config', 'config service'],
    'systems_manager': ['systems manager', 'ssm', 'aws systems manager'],
    'parameter_store': ['parameter store', 'ssm parameter store'],
    'managed_grafana': ['managed grafana', 'amazon managed grafana', 'grafana'],
    'managed_prometheus': ['managed service for prometheus', 'amazon managed prometheus', 'prometheus'],
    'iam': ['iam', 'identity and access management', 'aws iam'],
    'cognito': ['cognito', 'amazon cognito'],
    'kms': ['kms', 'key management service', 'aws kms'],
    'secrets_manager': ['secrets manager', 'aws secrets manager', 'secret manager'],
    'certificate_manager': ['certificate manager', 'acm', 'aws certificate manager'],
    'waf': ['waf', 'aws waf', 'web application firewall'],
    'shield': ['shield', 'aws shield'],
    'guardduty': ['guardduty', 'guard duty', 'amazon guardduty'],
    'security_hub': ['security hub', 'aws security hub'],
    'inspector': ['inspector', 'amazon inspector'],
    'macie': ['macie', 'amazon macie'],
    'detective': ['detective', 'amazon detective'],
    'firewall_manager': ['firewall manager', 'aws firewall manager'],
    'organizations': ['organizations', 'aws organizations'],
    'control_tower': ['control tower', 'aws control tower'],
    'artifact': ['aws artifact', 'artifact'],
    'cloudformation': ['cloudformation', 'cloud formation', 'aws cloudformation', 'cfn'],
    'cdk': ['cloud development kit', 'aws cdk', 'cdk'],
    'codepipeline': ['codepipeline', 'code pipeline', 'aws codepipeline'],
    'codebuild': ['codebuild', 'code build', 'aws codebuild'],
    'codedeploy': ['codedeploy', 'code deploy', 'aws codedeploy'],
    'codeartifact': ['codeartifact', 'code artifact', 'aws codeartifact'],
    'codecommit': ['codecommit', 'code commit', 'aws codecommit'],
    'amplify': ['amplify', 'aws amplify'],
    'device_farm': ['device farm', 'aws device farm'],
    'cloud9': ['cloud9', 'cloud 9', 'aws cloud9'],
    'bedrock': ['bedrock', 'amazon bedrock'],
    'sagemaker': ['sagemaker', 'sage maker', 'amazon sagemaker'],
    'comprehend': ['comprehend', 'amazon comprehend'],
    'textract': ['textract', 'amazon textract'],
    'rekognition': ['rekognition', 'amazon rekognition'],
    'polly': ['polly', 'amazon polly'],
    'transcribe': ['transcribe', 'amazon transcribe'],
    'translate': ['translate', 'amazon translate'],
    'lex': ['lex', 'amazon lex'],
    'personalize': ['personalize', 'amazon personalize'],
    'forecast': ['forecast', 'amazon forecast'],
    'kendra': ['kendra', 'amazon kendra'],
    'q_business': ['amazon q business', 'q business'],
    'q_developer': ['amazon q developer', 'q developer'],
    'glue': ['glue', 'aws glue'],
    'athena': ['athena', 'amazon athena'],
    'emr': ['emr', 'elastic mapreduce', 'amazon emr'],
    'opensearch': ['opensearch', 'open search', 'amazon opensearch', 'elasticsearch service'],
    'lake_formation': ['lake formation', 'aws lake formation'],
    'data_exchange': ['data exchange', 'aws data exchange'],
    'datazone': ['datazone', 'data zone', 'amazon datazone'],
    'quicksight': ['quicksight', 'quick sight', 'amazon quicksight'],
    'dms': ['database migration service', 'dms', 'aws dms'],
    'datasync': ['datasync', 'data sync', 'aws datasync'],
    'migration_hub': ['migration hub', 'aws migration hub'],
    'application_migration_service': ['application migration service', 'mgn', 'aws mgn'],
    'mainframe_modernization': ['mainframe modernization', 'aws mainframe modernization'],
    'connect': ['amazon connect', 'connect contact center'],
    'ses': ['ses', 'simple email service', 'amazon ses'],
    'pinpoint': ['pinpoint', 'amazon pinpoint'],
    'workspaces': ['workspaces', 'amazon workspaces'],
    'workmail': ['workmail', 'amazon workmail'],
    'chime': ['chime', 'amazon chime'],
    'iot_core': ['iot core', 'aws iot core'],
    'iot_greengrass': ['iot greengrass', 'greengrass', 'aws iot greengrass'],
    'iot_sitewise': ['iot sitewise', 'sitewise', 'aws iot sitewise'],
    'iot_events': ['iot events', 'aws iot events'],
    'iot_analytics': ['iot analytics', 'aws iot analytics'],
    'location_service': ['location service', 'amazon location service', 'location'],
    'braket': ['braket', 'amazon braket'],
    'managed_blockchain': ['managed blockchain', 'amazon managed blockchain'],
    'mwaa': ['mwaa', 'managed workflows for apache airflow', 'amazon mwaa', 'airflow'],
    'serverless_application_repository': ['serverless application repository', 'sar'],
}

# Types where an AWS resource icon is usually more semantically useful than the
# high-level service icon when both exist in the official package.
RESOURCE_PREFERRED = {
    'subnet', 'internet_gateway', 'nat_gateway', 'transit_gateway', 'vpc_endpoint',
    'application_load_balancer', 'network_load_balancer', 'gateway_load_balancer',
}

NOISE_TOKENS = {
    'aws', 'amazon', 'arch', 'architecture', 'icon', 'icons', 'service', 'services',
    'resource', 'resources', 'res', 'category', 'light', 'dark', 'generic', 'general',
}

PREFIX_RE = re.compile(r'^(?:arch(?:itecture)?[-_ ]?|res(?:ource)?[-_ ]?|category[-_ ]?)+', re.I)
SIZE_RE = re.compile(r'(?:[-_](16|24|32|48|64|128|256|512))(?=$|[-_])', re.I)
TRAILING_VARIANT_RE = re.compile(r'(?:[-_](?:light|dark|squid|service|resource|icon|architecture))+$', re.I)


def _text_tokens(value: str) -> list[str]:
    # Split camel case before punctuation normalization.
    value = re.sub(r'([a-z0-9])([A-Z])', r'\1 \2', value)
    parts = re.findall(r'[A-Za-z0-9]+', value.lower())
    return [p for p in parts if p and p not in NOISE_TOKENS and not p.isdigit()]


def _norm(value: str) -> str:
    return ''.join(_text_tokens(value))


def _clean_stem(stem: str) -> str:
    s = PREFIX_RE.sub('', stem)
    s = SIZE_RE.sub('', s)
    s = TRAILING_VARIANT_RE.sub('', s)
    s = s.replace('_', ' ').replace('-', ' ')
    return re.sub(r'\s+', ' ', s).strip()


def _size_hint(stem: str) -> int:
    values = [int(x) for x in SIZE_RE.findall(stem)]
    return max(values) if values else 0


def _kind(path: Path) -> str:
    text = '/'.join(x.lower() for x in path.parts)
    stem = path.stem.lower()
    if stem.startswith('res_') or 'resource-icon' in text or '/resource' in text:
        return 'resource'
    if 'category-icon' in text or stem.startswith('arch-category') or stem.startswith('category_'):
        return 'category'
    return 'service'


def _category(path: Path) -> str:
    # Prefer the nearest meaningful parent, e.g. Arch_Compute or Networking-Content-Delivery.
    for part in reversed(path.parts[:-1]):
        clean = _clean_stem(part)
        toks = _text_tokens(clean)
        if toks and not all(t in {'architecture', 'service', 'icons', 'icon', 'resource'} for t in toks):
            return clean
    return ''


def _acronym(tokens: Iterable[str]) -> str:
    toks = [t for t in tokens if t]
    return ''.join(t[0] for t in toks) if len(toks) > 1 else ''


def _alias_norms(aliases: dict[str, list[str]]) -> dict[str, set[str]]:
    out: dict[str, set[str]] = {}
    for canonical, vals in aliases.items():
        norms = {_norm(canonical), *(_norm(v) for v in vals)}
        out[canonical] = {n for n in norms if n}
    return out


def load_aliases(path: str | Path | None = None) -> dict[str, list[str]]:
    aliases = {k: list(v) for k, v in BUILTIN_ALIASES.items()}
    if path:
        raw = json.loads(Path(path).read_text(encoding='utf-8'))
        if not isinstance(raw, dict):
            raise ValueError('AWS alias file must contain a JSON object')
        for key, values in raw.items():
            if isinstance(values, str):
                values = [values]
            if not isinstance(values, list):
                raise ValueError(f'AWS alias entry {key!r} must be a string or array')
            aliases.setdefault(str(key), []).extend(str(v) for v in values)
    return aliases


def canonical_service(value: str, aliases: dict[str, list[str]] | None = None) -> str | None:
    aliases = aliases or BUILTIN_ALIASES
    n = _norm(value)
    if not n:
        return None
    for canonical, norms in _alias_norms(aliases).items():
        if n in norms:
            return canonical
    return None


@dataclass(frozen=True)
class IconRecord:
    relative_path: str
    display_name: str
    normalized: str
    tokens: tuple[str, ...]
    acronym: str
    kind: str
    category: str
    extension: str
    size_hint: int

    @classmethod
    def from_path(cls, root: Path, path: Path) -> 'IconRecord':
        display = _clean_stem(path.stem)
        toks = tuple(_text_tokens(display))
        return cls(
            relative_path=path.relative_to(root).as_posix(),
            display_name=display,
            normalized=''.join(toks),
            tokens=toks,
            acronym=_acronym(toks),
            kind=_kind(path.relative_to(root)),
            category=_category(path.relative_to(root)),
            extension=path.suffix.lower(),
            size_hint=_size_hint(path.stem),
        )

    def to_json(self) -> dict:
        return {
            'path': self.relative_path,
            'displayName': self.display_name,
            'normalized': self.normalized,
            'tokens': list(self.tokens),
            'acronym': self.acronym,
            'kind': self.kind,
            'category': self.category,
            'extension': self.extension,
            'sizeHint': self.size_hint,
        }

    @classmethod
    def from_json(cls, raw: dict) -> 'IconRecord':
        return cls(
            relative_path=str(raw['path']),
            display_name=str(raw.get('displayName', '')),
            normalized=str(raw.get('normalized', '')),
            tokens=tuple(str(x) for x in raw.get('tokens', [])),
            acronym=str(raw.get('acronym', '')),
            kind=str(raw.get('kind', 'service')),
            category=str(raw.get('category', '')),
            extension=str(raw.get('extension', '')).lower(),
            size_hint=int(raw.get('sizeHint', 0) or 0),
        )


class AwsIconCatalog:
    """Index and resolve icons from a user-supplied AWS Architecture Icons tree.

    The directory is indexed once and cached outside the source icon directory. New
    or unknown services still work when the LLM uses wording close to the official
    AWS filename; the built-in alias catalog adds deterministic handling for common
    abbreviations such as APIGW, RDS, ALB, NLB, SQS, SNS, SFN, and TGW.
    """

    def __init__(self, root: Path, records: list[IconRecord], *, aliases: dict[str, list[str]], cache_path: Path | None, cache_hit: bool):
        self.root = root
        self.records = records
        self.aliases = aliases
        self.alias_norms = _alias_norms(aliases)
        self.cache_path = cache_path
        self.cache_hit = cache_hit
        self._by_norm: dict[str, list[IconRecord]] = defaultdict(list)
        self._by_acronym: dict[str, list[IconRecord]] = defaultdict(list)
        self._by_canonical: dict[str, list[IconRecord]] = defaultdict(list)
        for record in records:
            if record.normalized:
                self._by_norm[record.normalized].append(record)
            if record.acronym:
                self._by_acronym[record.acronym].append(record)
            canonical = self._canonical_for_record(record)
            if canonical:
                self._by_canonical[canonical].append(record)

    @classmethod
    def from_directory(
        cls,
        icon_dir: str | Path,
        *,
        cache_path: str | Path | None = None,
        force: bool = False,
        aliases_path: str | Path | None = None,
    ) -> 'AwsIconCatalog':
        root = Path(icon_dir).expanduser().resolve()
        if not root.is_dir():
            raise FileNotFoundError(f'AWS icon directory does not exist: {root}')
        aliases = load_aliases(aliases_path)
        cache = Path(cache_path).expanduser() if cache_path else _default_cache_path(root)
        records, hit = _load_or_build_index(root, cache, force=force)
        return cls(root, records, aliases=aliases, cache_path=cache, cache_hit=hit)

    def _canonical_for_record(self, record: IconRecord) -> str | None:
        values = [record.display_name, record.normalized, record.acronym]
        for canonical, norms in self.alias_norms.items():
            if any(_norm(v) in norms for v in values if v):
                return canonical
        # A conservative contains match handles filenames like "Amazon RDS for Oracle".
        for canonical, norms in self.alias_norms.items():
            if any(n and (n in record.normalized or record.normalized in n) for n in norms):
                return canonical
        return None

    def resolve(self, node_type: str, label: str | None = None, *, explain: bool = False, allowed_extensions: set[str] | None = None):
        query = _strip_provider(node_type)
        qnorm = _norm(query)
        lnorm = _norm(label or '')
        qtokens = set(_text_tokens(query))
        ltokens = set(_text_tokens(label or ''))
        canonical = canonical_service(query, self.aliases) or canonical_service(label or '', self.aliases)

        candidates: set[IconRecord] = set()
        if qnorm:
            candidates.update(self._by_norm.get(qnorm, []))
            candidates.update(self._by_acronym.get(qnorm, []))
        if lnorm:
            candidates.update(self._by_norm.get(lnorm, []))
            candidates.update(self._by_acronym.get(lnorm, []))
        if canonical:
            candidates.update(self._by_canonical.get(canonical, []))
        # If exact/canonical lookup did not narrow enough, score the full catalog.
        pool = list(candidates) if candidates else self.records
        if allowed_extensions is not None:
            allowed = {x.lower() for x in allowed_extensions}
            pool = [r for r in pool if r.extension in allowed]
        if not pool:
            return (None, {'reason': 'empty catalog'}) if explain else None

        ranked: list[tuple[float, IconRecord, list[str]]] = []
        for record in pool:
            score, reasons = self._score(record, qnorm, lnorm, qtokens, ltokens, canonical)
            if score > 0:
                ranked.append((score, record, reasons))
        if not ranked:
            return (None, {'reason': 'no positive match', 'query': query, 'label': label}) if explain else None
        ranked.sort(key=lambda item: (item[0], _format_rank(item[1]), item[1].size_hint, -len(item[1].relative_path)), reverse=True)
        score, best, reasons = ranked[0]
        # Avoid weak accidental fuzzy matches. Exact alias/name matches score far above this.
        if score < 260:
            return (None, {'reason': 'match below confidence threshold', 'score': score, 'candidate': best.relative_path}) if explain else None
        path = self.root / best.relative_path
        if explain:
            return path, {
                'score': score,
                'query': query,
                'label': label,
                'canonical': canonical,
                'path': best.relative_path,
                'displayName': best.display_name,
                'kind': best.kind,
                'format': best.extension,
                'reasons': reasons,
            }
        return path

    def _score(self, record: IconRecord, qnorm: str, lnorm: str, qtokens: set[str], ltokens: set[str], canonical: str | None) -> tuple[float, list[str]]:
        score = 0.0
        reasons: list[str] = []
        rcanonical = self._canonical_for_record(record)
        if canonical and rcanonical == canonical:
            score += 1200
            reasons.append('canonical alias match')
        if qnorm and record.normalized == qnorm:
            score += 1100
            reasons.append('exact normalized type match')
        if lnorm and record.normalized == lnorm:
            score += 900
            reasons.append('exact normalized label match')
        if qnorm and record.acronym == qnorm:
            score += 850
            reasons.append('official-name acronym match')
        if lnorm and record.acronym == lnorm:
            score += 700
            reasons.append('label acronym match')
        if qnorm and (qnorm in record.normalized or record.normalized in qnorm):
            ratio = min(len(qnorm), len(record.normalized)) / max(len(qnorm), len(record.normalized), 1)
            score += 420 * ratio
            reasons.append('type substring match')
        if lnorm and (lnorm in record.normalized or record.normalized in lnorm):
            ratio = min(len(lnorm), len(record.normalized)) / max(len(lnorm), len(record.normalized), 1)
            score += 300 * ratio
            reasons.append('label substring match')
        rtokens = set(record.tokens)
        if qtokens and rtokens:
            overlap = len(qtokens & rtokens)
            if overlap:
                score += 360 * overlap / max(len(qtokens | rtokens), 1)
                reasons.append('type token overlap')
        if ltokens and rtokens:
            overlap = len(ltokens & rtokens)
            if overlap:
                score += 220 * overlap / max(len(ltokens | rtokens), 1)
                reasons.append('label token overlap')

        prefer_resource = canonical in RESOURCE_PREFERRED if canonical else False
        if prefer_resource:
            score += 80 if record.kind == 'resource' else -20
        else:
            score += 70 if record.kind == 'service' else (10 if record.kind == 'resource' else -35)
        if record.kind == 'category':
            score -= 90

        score += _format_rank(record)
        if record.extension == '.png':
            score += min(record.size_hint, 512) / 32.0
        return score, reasons

    def report(self, *, include_entries: bool = False) -> dict:
        formats = Counter(r.extension for r in self.records)
        kinds = Counter(r.kind for r in self.records)
        categories = Counter(r.category for r in self.records if r.category)
        report = {
            'root': str(self.root),
            'cachePath': str(self.cache_path) if self.cache_path else None,
            'cacheHit': self.cache_hit,
            'iconCount': len(self.records),
            'formats': dict(sorted(formats.items())),
            'kinds': dict(sorted(kinds.items())),
            'topCategories': dict(categories.most_common(25)),
            'aliasGroups': len(self.aliases),
        }
        if include_entries:
            report['entries'] = [r.to_json() for r in self.records]
        return report


def _strip_provider(node_type: str) -> str:
    s = node_type.strip()
    s = re.sub(r'^(?:aws|amazon)[.:/_-]+', '', s, flags=re.I)
    return s


def _format_rank(record: IconRecord) -> int:
    # SVG is preferred when available because it can be rasterized cleanly at a
    # controlled resolution. PNG remains a zero-dependency direct-embed fallback.
    return {'.svg': 45, '.png': 30, '.jpg': 10, '.jpeg': 10}.get(record.extension, 0)


def _default_cache_path(root: Path) -> Path:
    base = os.environ.get('ARCH2VISIO_CACHE_DIR')
    cache_root = Path(base).expanduser() if base else Path.home() / '.cache' / 'visio-architecture-renderer'
    digest = hashlib.sha256(str(root).encode('utf-8')).hexdigest()[:20]
    return cache_root / 'aws-icons' / f'{digest}.json'


def _root_fingerprint(root: Path) -> dict:
    st = root.stat()
    return {'root': str(root), 'rootMtimeNs': int(st.st_mtime_ns)}


def _load_or_build_index(root: Path, cache: Path, *, force: bool) -> tuple[list[IconRecord], bool]:
    fingerprint = _root_fingerprint(root)
    if not force and cache.is_file():
        try:
            raw = json.loads(cache.read_text(encoding='utf-8'))
            if raw.get('version') == INDEX_VERSION and raw.get('fingerprint') == fingerprint:
                return [IconRecord.from_json(x) for x in raw.get('entries', [])], True
        except Exception:
            pass

    paths = sorted(
        (p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS),
        key=lambda p: p.as_posix().lower(),
    )
    records = [IconRecord.from_path(root, p) for p in paths]
    payload = {
        'version': INDEX_VERSION,
        'fingerprint': fingerprint,
        'iconCount': len(records),
        'entries': [r.to_json() for r in records],
    }
    try:
        cache.parent.mkdir(parents=True, exist_ok=True)
        tmp = cache.with_suffix(cache.suffix + '.tmp')
        tmp.write_text(json.dumps(payload, indent=2), encoding='utf-8')
        tmp.replace(cache)
    except OSError:
        cache = None  # type: ignore[assignment]
    return records, False


def index_aws_icons(
    icon_dir: str | Path,
    *,
    cache_path: str | Path | None = None,
    force: bool = False,
    aliases_path: str | Path | None = None,
    include_entries: bool = False,
) -> dict:
    catalog = AwsIconCatalog.from_directory(
        icon_dir, cache_path=cache_path, force=force, aliases_path=aliases_path
    )
    return catalog.report(include_entries=include_entries)


# Backwards-compatible convenience API.
def find_icon(node_type: str, icon_dir: str | None, label: str | None = None, *, cache_path: str | None = None, force: bool = False, aliases_path: str | None = None):
    if not icon_dir:
        return None
    try:
        catalog = AwsIconCatalog.from_directory(icon_dir, cache_path=cache_path, force=force, aliases_path=aliases_path)
        return catalog.resolve(node_type, label)
    except (FileNotFoundError, ValueError):
        return None


def icon_to_png(path: Path, *, target_px: int = 256) -> bytes | None:
    ext = path.suffix.lower()
    if ext == '.png':
        return path.read_bytes()
    try:
        if ext == '.svg':
            import cairosvg
            # Width only preserves the source aspect ratio.
            return cairosvg.svg2png(bytestring=path.read_bytes(), output_width=target_px)
        from PIL import Image
        im = Image.open(path)
        im.thumbnail((target_px, target_px))
        out = io.BytesIO()
        im.convert('RGBA').save(out, format='PNG')
        return out.getvalue()
    except Exception:
        return None
