from __future__ import annotations
import re
from pathlib import Path
from ..model import Diagram, Node, Group, Edge

ID = r"[A-Za-z_][A-Za-z0-9_.:-]*"

def parse_mermaid(path: str | Path) -> Diagram:
    text = Path(path).read_text(encoding="utf-8")
    d = Diagram(title=Path(path).stem)
    if re.search(r"^\s*architecture-beta\b", text, re.M):
        _parse_architecture(text, d)
    else:
        _parse_flowchart(text, d)
    return d

def _add_node(d, node_id, label=None, ntype="component", group=None):
    if not any(n.id == node_id for n in d.nodes):
        d.nodes.append(Node(node_id, label or node_id, ntype, group=group))

def _parse_flowchart(text: str, d: Diagram):
    m = re.search(r"^\s*(?:flowchart|graph)\s+(LR|RL|TB|TD|BT)\b", text, re.M|re.I)
    if m: d.direction = "TB" if m.group(1).upper() in {"TB","TD"} else m.group(1).upper()
    current_group = None
    group_stack = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("%%"): continue
        sm = re.match(r"subgraph\s+(\S+)(?:\s*\[(.*?)\]|\s+(.+))?$", line, re.I)
        if sm:
            gid = sm.group(1); label = sm.group(2) or sm.group(3) or gid
            d.groups.append(Group(gid, label.strip('"'), "group", parent=current_group))
            group_stack.append(current_group); current_group = gid; continue
        if line.lower() == "end":
            current_group = group_stack.pop() if group_stack else None; continue
        # collect declared nodes
        for nm in re.finditer(rf"(?P<id>{ID})\s*(?:\[\[(?P<a>.*?)\]\]|\[(?P<b>.*?)\]|\((?P<c>.*?)\)|\{{(?P<d>.*?)\}})", line):
            label = next((nm.group(x) for x in ('a','b','c','d') if nm.group(x) is not None), nm.group('id'))
            _add_node(d, nm.group('id'), label.strip('"'), "component", current_group)
        em = re.search(rf"(?P<s>{ID}).*?(?P<arrow><-->|<-->|-->|---|-.->|==>)\s*(?:\|(?P<label>[^|]+)\|)?\s*(?P<t>{ID})", line)
        if em:
            s,t=em.group('s'),em.group('t'); _add_node(d,s,group=current_group); _add_node(d,t,group=current_group)
            arrow=em.group('arrow'); d.edges.append(Edge(s,t,(em.group('label') or '').strip(),"dashed" if '.' in arrow else "solid", arrow.startswith('<') and arrow.endswith('>')))

def _parse_architecture(text: str, d: Diagram):
    groups: dict[str,str|None] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("%%") or line.startswith("architecture-beta"): continue
        gm = re.match(rf"group\s+({ID})\s*\(([^)]+)\)\s*\[([^]]+)\](?:\s+in\s+({ID}))?", line)
        if gm:
            gid, icon, label, parent = gm.groups(); groups[gid]=parent; d.groups.append(Group(gid,label,icon,parent)); continue
        sm = re.match(rf"service\s+({ID})\s*\(([^)]+)\)\s*\[([^]]+)\](?:\s+in\s+({ID}))?", line)
        if sm:
            nid, icon, label, group = sm.groups(); _add_node(d,nid,label,icon,group); continue
        # architecture connectors: a:R --> L:b
        em = re.match(rf"({ID})(?::[TBRL])?\s*(<-->|-->|---)\s*(?:[TBRL]:)?({ID})", line)
        if em:
            s,arrow,t=em.groups(); _add_node(d,s); _add_node(d,t); d.edges.append(Edge(s,t,bidirectional=arrow=='<-->'))
