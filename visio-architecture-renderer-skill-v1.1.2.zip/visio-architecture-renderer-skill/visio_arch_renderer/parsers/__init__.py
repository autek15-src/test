from pathlib import Path
from .json_parser import parse_json
from .mermaid_parser import parse_mermaid
from .plantuml_parser import parse_plantuml

def parse_diagram(path):
    p=Path(path); ext=p.suffix.lower()
    if ext=='.json': return parse_json(p)
    if ext in {'.mmd','.mermaid','.md'}: return parse_mermaid(p)
    if ext in {'.puml','.plantuml','.uml'}: return parse_plantuml(p)
    raise ValueError(f"Unsupported input format: {ext}")
