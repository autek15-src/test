from __future__ import annotations

import re
from pathlib import Path

from ..model import Diagram, Edge, Group, Node

ALIAS = r"[A-Za-z_][A-Za-z0-9_.:-]*"
_BLOCK_KINDS = {"rectangle", "package", "frame", "folder", "cloud", "node"}
_NODE_KINDS = {
    "actor", "agent", "artifact", "boundary", "card", "cloud", "collections",
    "component", "control", "database", "entity", "file", "folder", "frame",
    "hexagon", "interface", "label", "node", "package", "person", "queue",
    "rectangle", "stack", "storage", "usecase",
}
_REL_MACROS = {"Rel", "Rel_R", "Rel_L", "Rel_U", "Rel_D", "BiRel", "BiRel_R", "BiRel_L", "BiRel_U", "BiRel_D"}


def parse_plantuml(path: str | Path) -> Diagram:
    path = Path(path)
    text = path.read_text(encoding="utf-8")
    d = Diagram(title=path.stem)
    if re.search(r"left\s+to\s+right\s+direction", text, re.I):
        d.direction = "LR"
    elif re.search(r"top\s+to\s+bottom\s+direction", text, re.I):
        d.direction = "TB"

    group_stack: list[str] = []

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("'") or line.startswith("@") or line.startswith("!"):
            continue

        # Close one nesting level. PlantUML architecture/deployment grouping generally
        # uses one block per line; tolerate a trailing comment after the brace.
        if re.match(r"^}\s*(?:'.*)?$", line):
            if group_stack:
                group_stack.pop()
            continue

        # C4-PlantUML boundaries, e.g. System_Boundary(core, "Core") {
        bm = re.match(
            r'(?:System_Boundary|Container_Boundary|Boundary|Enterprise_Boundary)\s*\(\s*([^,]+),\s*"([^"]+)"',
            line,
            re.I,
        )
        if bm:
            gid, label = bm.groups()
            gid = gid.strip()
            _add_group(d, gid, label, "boundary", group_stack[-1] if group_stack else None)
            group_stack.append(gid)
            continue

        # Standard PlantUML grouping blocks. A rectangle/cloud/node/etc. followed by
        # "{" is a container, not a drawable leaf node. This is common in network
        # diagrams for Cloud -> VPC -> AZ/subnet/zone nesting.
        block = _parse_block_declaration(line)
        if block:
            kind, gid, label = block
            parent = group_stack[-1] if group_stack else None
            _add_group(d, gid, label, kind, parent, metadata={"plantumlKind": kind})
            group_stack.append(gid)
            continue

        # C4/AWS macros: Person(id,"label"...), System(id,"label"), Lambda(id,"label"...)
        mm = re.match(rf'([A-Za-z_][A-Za-z0-9_]*)\s*\(\s*({ALIAS})\s*,\s*"([^"]+)"', line)
        if mm and mm.group(1) not in _REL_MACROS:
            macro, nid, label = mm.groups()
            _add_node(d, nid, label, _macro_type(macro), group_stack[-1] if group_stack else None)
            continue

        # Standard declarations, including actor/component/database and common
        # deployment diagram elements. Supports both `kind "Label" as Alias` and
        # `kind Alias as "Label"` forms.
        decl = _parse_node_declaration(line)
        if decl:
            kind, nid, label = decl
            _add_node(d, nid, label, kind, group_stack[-1] if group_stack else None)
            continue

        # C4 relation macros.
        rm = re.match(
            r'(Rel|Rel_R|Rel_L|Rel_U|Rel_D|BiRel|BiRel_R|BiRel_L|BiRel_U|BiRel_D)\s*\(\s*([^,]+),\s*([^,]+),\s*"([^"]*)"',
            line,
            re.I,
        )
        if rm:
            macro, s, t, label = rm.groups()
            s, t, label = s.strip(), t.strip(), label.strip()
            _add_node(d, s, s)
            _add_node(d, t, t)
            d.edges.append(Edge(s, t, label, bidirectional=macro.lower().startswith("birel"), metadata={"plantumlMacro": macro}))
            continue

        # Native PlantUML links. Accept styling inside the arrow token, including:
        #   A -[#0066CC]-> B
        #   A -[#green,dashed]-> B
        #   A -[hidden]-> B
        #   A -down-> B
        edge = _parse_edge(line)
        if edge:
            s, t, label, style, bidirectional, metadata = edge
            _add_node(d, s, s)
            _add_node(d, t, t)
            d.edges.append(Edge(s, t, label, style, bidirectional, metadata))

    return d


def _parse_block_declaration(line: str) -> tuple[str, str, str] | None:
    if "{" not in line:
        return None
    before = line.rsplit("{", 1)[0].strip()
    m = re.match(rf'(?P<kind>{"|".join(sorted(_BLOCK_KINDS))})\s+(?P<body>.+?)\s*$', before, re.I)
    if not m:
        return None
    kind = m.group("kind").lower()
    body = _strip_decl_suffix(m.group("body"))
    parsed = _parse_label_alias(body)
    if not parsed:
        return None
    label, alias = parsed
    gid = alias or _slug(label)
    return kind, gid, label


def _parse_node_declaration(line: str) -> tuple[str, str, str] | None:
    kinds = "|".join(sorted(_NODE_KINDS))
    m = re.match(rf'(?P<kind>{kinds})\s+(?P<body>.+?)\s*$', line, re.I)
    if not m:
        return None
    kind = m.group("kind").lower()
    body = _strip_decl_suffix(m.group("body"))
    parsed = _parse_label_alias(body)
    if not parsed:
        return None
    label, alias = parsed
    nid = alias or _slug(label)
    return kind, nid, label


def _strip_decl_suffix(body: str) -> str:
    # Remove stereotypes/colors that follow a declaration while leaving quoted
    # labels intact. Examples: `as API #E7157B`, `<<external>> #gray`.
    # Repeat because PlantUML permits both suffixes together in either order.
    previous = None
    while body != previous:
        previous = body
        body = re.sub(r'\s+#[A-Za-z0-9_?/\\|.-]+\s*$', '', body).strip()
        body = re.sub(r'\s+<<[^>]+>>\s*$', '', body).strip()
    return body


def _parse_label_alias(body: str) -> tuple[str, str | None] | None:
    # "Display Label" as Alias
    m = re.match(rf'^"(?P<label>[^"]+)"(?:\s+as\s+(?P<id>{ALIAS}))?$', body, re.I)
    if m:
        return m.group("label"), m.group("id")

    # Alias as "Display Label" (common in deployment diagrams)
    m = re.match(rf'^(?P<id>{ALIAS})\s+as\s+"(?P<label>[^"]+)"$', body, re.I)
    if m:
        return m.group("label"), m.group("id")

    # Alias [Display Label]
    m = re.match(rf'^(?P<id>{ALIAS})\s*\[(?P<label>[^]]+)\]$', body)
    if m:
        return m.group("label").strip('"'), m.group("id")

    # Unquoted identifier/name, optionally aliased.
    m = re.match(rf'^(?P<label>{ALIAS})(?:\s+as\s+(?P<id>{ALIAS}))?$', body, re.I)
    if m:
        return m.group("label"), m.group("id")
    return None


def _parse_edge(line: str) -> tuple[str, str, str, str, bool, dict] | None:
    # Arrow token must contain at least one line character and may carry a style
    # bracket. The alternatives cover arrows with a head on either/both ends,
    # plus headless association lines. Whitespace-delimited aliases are the
    # architecture-oriented form this renderer consumes.
    arrow = r'(?:<[-.=][^\s:]*>|<[-.=][^\s:]*|[-.=][^\s:]*>|[-.=]{2,})'
    m = re.match(rf'^(?P<s>{ALIAS})\s*(?P<arrow>{arrow})\s*(?P<t>{ALIAS})(?:\s*:\s*(?P<label>.*))?$', line)
    if not m:
        return None
    s, token, t, label = m.group("s"), m.group("arrow"), m.group("t"), (m.group("label") or "").strip()
    low = token.lower()
    style_spec = ""
    sm = re.search(r'\[([^]]+)\]', token)
    if sm:
        style_spec = sm.group(1)
    low_spec = style_spec.lower()
    hidden = "hidden" in low_spec
    style = "dashed" if ("dashed" in low_spec or "dotted" in low_spec or "." in token) else "solid"
    bidirectional = "<" in token and ">" in token
    metadata: dict[str, object] = {"plantumlArrow": token}
    if style_spec:
        metadata["plantumlStyle"] = style_spec
    color = _extract_color(style_spec)
    if color:
        metadata["color"] = color
    if hidden:
        metadata["hidden"] = True
    dm = re.search(r'(?:left|right|up|down)', low)
    if dm:
        metadata["directionHint"] = dm.group(0)
    return s, t, label, style, bidirectional, metadata


def _extract_color(style_spec: str) -> str | None:
    # Preserve exact hex colors for the native Visio emitter. Named PlantUML
    # colors remain in plantumlStyle metadata but are not translated here.
    m = re.search(r'(?i)(#[0-9a-f]{3}(?:[0-9a-f]{3})?(?:[0-9a-f]{2})?)\b', style_spec)
    return m.group(1).upper() if m else None


def _macro_type(macro: str) -> str:
    m = macro.lower()
    aws = {
        "lambda": "aws.lambda",
        "apigateway": "aws.api_gateway",
        "rds": "aws.rds",
        "s3": "aws.s3",
        "dynamodb": "aws.dynamodb",
        "sqs": "aws.sqs",
        "sns": "aws.sns",
        "cloudfront": "aws.cloudfront",
        "route53": "aws.route53",
        "elasticloadbalancing": "aws.elb",
    }
    if m in aws:
        return aws[m]
    if m.startswith("person"):
        return "person"
    if "database" in m:
        return "database"
    if m.startswith("container"):
        return "container"
    if m.startswith("system"):
        return "system"
    return macro


def _add_group(d: Diagram, gid: str, label: str, gtype: str = "group", parent: str | None = None, metadata: dict | None = None) -> None:
    existing = next((g for g in d.groups if g.id == gid), None)
    if existing:
        if existing.label == existing.id and label != gid:
            existing.label = label
        if parent and not existing.parent:
            existing.parent = parent
        if metadata:
            existing.metadata.update(metadata)
        return
    d.groups.append(Group(gid, label, gtype, parent, metadata or {}))


def _add_node(d: Diagram, nid: str, label: str, ntype: str = "component", group: str | None = None) -> None:
    existing = next((n for n in d.nodes if n.id == nid), None)
    if existing:
        if existing.label == existing.id and label != nid:
            existing.label = label
        if existing.type == "component" and ntype != "component":
            existing.type = ntype
        if group and not existing.group:
            existing.group = group
        return
    d.nodes.append(Node(nid, label, ntype, group=group))


def _slug(s: str) -> str:
    return re.sub(r'\W+', '_', s).strip('_') or 'node'
