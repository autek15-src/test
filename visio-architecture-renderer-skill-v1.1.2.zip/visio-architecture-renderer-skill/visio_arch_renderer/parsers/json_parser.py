from __future__ import annotations
import json
from pathlib import Path
from ..model import Diagram, Node, Group, Edge

def parse_json(path: str | Path) -> Diagram:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if "diagram" in data and isinstance(data["diagram"], dict):
        data = data["diagram"]
    d = Diagram(
        title=data.get("title", "Architecture"),
        direction=str(data.get("direction", data.get("layout", {}).get("direction", "LR"))).upper(),
        layout=dict(data.get("layout", {})),
        metadata=dict(data.get("metadata", {})),
    )
    for g in data.get("groups", []):
        d.groups.append(Group(
            id=str(g["id"]), label=str(g.get("label", g["id"])), type=str(g.get("type", g.get("vendor", "group"))),
            parent=g.get("parent"), metadata={k:v for k,v in g.items() if k not in {"id","label","type","vendor","parent"}}
        ))
    for n in data.get("nodes", []):
        ntype = n.get("type") or n.get("service") or n.get("kind") or "component"
        d.nodes.append(Node(
            id=str(n["id"]), label=str(n.get("label", n["id"])), type=str(ntype), group=n.get("group"),
            x=_num(n.get("x")), y=_num(n.get("y")), width=float(n.get("width", 150)), height=float(n.get("height", 74)),
            metadata={k:v for k,v in n.items() if k not in {"id","label","type","service","kind","group","x","y","width","height"}}
        ))
    for e in data.get("edges", data.get("connections", [])):
        d.edges.append(Edge(
            source=str(e.get("source", e.get("from"))), target=str(e.get("target", e.get("to"))),
            label=str(e.get("label", e.get("protocol", ""))), style=str(e.get("style", "solid")),
            bidirectional=bool(e.get("bidirectional", False)), metadata={k:v for k,v in e.items() if k not in {"source","from","target","to","label","protocol","style","bidirectional"}}
        ))
    return d

def _num(v):
    try: return None if v is None else float(v)
    except (TypeError, ValueError): return None
