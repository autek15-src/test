from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass
class Node:
    id: str
    label: str
    type: str = "component"
    group: str | None = None
    x: float | None = None
    y: float | None = None
    width: float = 150.0
    height: float = 74.0
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class Group:
    id: str
    label: str
    type: str = "group"
    parent: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class Edge:
    source: str
    target: str
    label: str = ""
    style: str = "solid"
    bidirectional: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class Diagram:
    title: str = "Architecture"
    direction: str = "LR"
    nodes: list[Node] = field(default_factory=list)
    groups: list[Group] = field(default_factory=list)
    edges: list[Edge] = field(default_factory=list)
    layout: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> list[str]:
        errors: list[str] = []
        ids = [n.id for n in self.nodes]
        if len(ids) != len(set(ids)):
            errors.append("duplicate node ids")
        node_ids = set(ids)
        group_ids = {g.id for g in self.groups}
        for n in self.nodes:
            if n.group and n.group not in group_ids:
                errors.append(f"node {n.id} references unknown group {n.group}")
        for e in self.edges:
            if e.source not in node_ids:
                errors.append(f"edge source {e.source} does not exist")
            if e.target not in node_ids:
                errors.append(f"edge target {e.target} does not exist")
        return errors
