from __future__ import annotations
from .routing import route_metrics

def score_layout(layout,routes):
    m=route_metrics(routes); aspect=max(layout.width/layout.height,layout.height/layout.width)
    area=(layout.width*layout.height)/100000.0
    score=m['crossings']*1000+m['fallbacks']*500+m['bends']*3+max(0,aspect-2.2)*20+area*.08
    return score,{**m,'width':round(layout.width,1),'height':round(layout.height,1),'aspect':round(aspect,2),'score':round(score,2),'engine':layout.engine}
