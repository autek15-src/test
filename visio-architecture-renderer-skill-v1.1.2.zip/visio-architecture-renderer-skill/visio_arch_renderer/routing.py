from __future__ import annotations
from dataclasses import dataclass
import heapq, math
from .layout import Box
from .model import Diagram, Edge

@dataclass
class Route:
    points: list[tuple[float,float]]
    fallback: bool=False

def route_edges(diagram:Diagram, boxes:dict[str,Box], group_boxes:dict[str,Box], congestion_penalty:float=12.0, grid:float=18.0):
    routes={}; usage={}
    obstacles=list(boxes.items())
    for idx,e in enumerate(diagram.edges):
        if e.source not in boxes or e.target not in boxes: continue
        a,b=boxes[e.source],boxes[e.target]
        start,end=_ports(a,b,idx,diagram.edges,e.source,e.target)
        pts=_astar(start,end,obstacles,{e.source,e.target},usage,grid,congestion_penalty)
        fallback=False
        if not pts:
            pts=_dogleg(start,end,obstacles,{e.source,e.target},idx); fallback=True
        pts=_simplify(pts)
        routes[idx]=Route(pts,fallback)
        for s,t in zip(pts,pts[1:]): usage[_segkey(s,t)]=usage.get(_segkey(s,t),0)+1
    return routes

def _ports(a,b,idx,edges,source,target):
    # spread same-direction fanout over target-facing side
    outgoing=[i for i,e in enumerate(edges) if e.source==source]
    incoming=[i for i,e in enumerate(edges) if e.target==target]
    oslot=(outgoing.index(idx)+1)/(len(outgoing)+1) if idx in outgoing else .5
    islot=(incoming.index(idx)+1)/(len(incoming)+1) if idx in incoming else .5
    dx=b.cx-a.cx; dy=b.cy-a.cy
    if abs(dx)>=abs(dy):
        if dx>=0: return (a.x+a.w,a.y+a.h*oslot),(b.x,b.y+b.h*islot)
        return (a.x,a.y+a.h*oslot),(b.x+b.w,b.y+b.h*islot)
    if dy>=0:return (a.x+a.w*oslot,a.y+a.h),(b.x+b.w*islot,b.y)
    return (a.x+a.w*oslot,a.y),(b.x+b.w*islot,b.y+b.h)

def _astar(start,end,obstacles,ignore,usage,grid,congestion):
    margin=16
    sx,sy=start; ex,ey=end
    minx=min([sx,ex]+[b.x for _,b in obstacles])-70; miny=min([sy,ey]+[b.y for _,b in obstacles])-70
    maxx=max([sx,ex]+[b.x+b.w for _,b in obstacles])+70; maxy=max([sy,ey]+[b.y+b.h for _,b in obstacles])+70
    def cell(p): return (round((p[0]-minx)/grid),round((p[1]-miny)/grid))
    def pt(c): return (minx+c[0]*grid,miny+c[1]*grid)
    sc,ec=cell(start),cell(end)
    def blocked(c):
        if c in {sc,ec}: return False
        x,y=pt(c)
        for nid,b in obstacles:
            if nid in ignore: continue
            if b.x-margin < x < b.x+b.w+margin and b.y-margin < y < b.y+b.h+margin:return True
        return False
    openh=[(0,0,sc,None)]; best={(sc,None):0}; prev={}; seq=0
    while openh and seq<30000:
        _,g,c,dir0=heapq.heappop(openh); seq+=1
        if c==ec:
            state=(c,dir0); cells=[]
            while state in prev:
                cells.append(state[0]); state=prev[state]
            cells.append(sc); cells.reverse()
            pts=[start]+[pt(c) for c in cells[1:-1]]+[end]
            return pts
        for dx,dy,dname in [(1,0,'H'),(-1,0,'H'),(0,1,'V'),(0,-1,'V')]:
            n=(c[0]+dx,c[1]+dy)
            x,y=pt(n)
            if x<minx or x>maxx or y<miny or y>maxy or blocked(n): continue
            bend=9 if dir0 and dir0!=dname else 0
            seg=_segkey(pt(c),pt(n)); cg=g+1+bend+usage.get(seg,0)*congestion
            st=(n,dname)
            if cg<best.get(st,1e18):
                best[st]=cg; prev[st]=(c,dir0); h=abs(n[0]-ec[0])+abs(n[1]-ec[1]); heapq.heappush(openh,(cg+h,cg,n,dname))
    return []

def _dogleg(s,e,obstacles,ignore,idx):
    sx,sy=s; ex,ey=e; off=(idx%7-3)*12
    cands=[[(sx,sy),(ex,sy),(ex,ey)],[(sx,sy),(sx,ey),(ex,ey)],[(sx,sy),((sx+ex)/2+off,sy),((sx+ex)/2+off,ey),(ex,ey)]]
    return min(cands,key=lambda p:_route_penalty(p,obstacles,ignore))

def _route_penalty(p,obs,ignore):
    pen=len(p)*2
    for a,b in zip(p,p[1:]):
        for nid,box in obs:
            if nid in ignore:continue
            if _segment_hits_box(a,b,box):pen+=1000
    return pen

def _segment_hits_box(a,b,r):
    (x1,y1),(x2,y2)=a,b
    if x1==x2:return r.x < x1 < r.x+r.w and max(min(y1,y2),r.y)<min(max(y1,y2),r.y+r.h)
    if y1==y2:return r.y < y1 < r.y+r.h and max(min(x1,x2),r.x)<min(max(x1,x2),r.x+r.w)
    return False

def _simplify(p):
    if len(p)<3:return p
    out=[p[0]]
    for i in range(1,len(p)-1):
        a,b,c=out[-1],p[i],p[i+1]
        if (abs(a[0]-b[0])<1e-6 and abs(b[0]-c[0])<1e-6) or (abs(a[1]-b[1])<1e-6 and abs(b[1]-c[1])<1e-6): continue
        out.append(b)
    out.append(p[-1]); return out

def _segkey(a,b):
    a=(round(a[0],1),round(a[1],1)); b=(round(b[0],1),round(b[1],1)); return tuple(sorted((a,b)))

def route_metrics(routes):
    fallbacks=sum(r.fallback for r in routes.values()); bends=sum(max(0,len(r.points)-2) for r in routes.values()); crossings=0
    segs=[]
    for i,r in routes.items():
        for a,b in zip(r.points,r.points[1:]):segs.append((i,a,b))
    for x in range(len(segs)):
        i,a,b=segs[x]
        for j,c,d in segs[x+1:]:
            if i==j:continue
            if _cross(a,b,c,d):crossings+=1
    return {"fallbacks":fallbacks,"bends":bends,"crossings":crossings}

def _cross(a,b,c,d):
    # Count strict orthogonal crossings only, not shared endpoints/overlaps.
    ah=abs(a[1]-b[1])<1e-6; ch=abs(c[1]-d[1])<1e-6
    if ah==ch:return False
    h1,h2=(a,b) if ah else (c,d); v1,v2=(c,d) if ah else (a,b)
    x=v1[0]; y=h1[1]
    return min(h1[0],h2[0])<x<max(h1[0],h2[0]) and min(v1[1],v2[1])<y<max(v1[1],v2[1])
