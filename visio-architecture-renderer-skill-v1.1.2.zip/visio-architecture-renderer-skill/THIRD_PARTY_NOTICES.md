# Third-party notices

This implementation was designed after reviewing several permissively licensed VSDX emitters. It does not bundle their repositories or AWS icon assets, but reuses general implementation techniques such as Open Packaging Convention structure, Visio coordinate transforms, native geometry cells, connector glue records, and media relationships.

## archdiagram
- Repository: https://github.com/bharathgnana/archdiagram
- License: MIT
- Copyright (c) 2026 Bharath Adapa

## svgtovisio
- Repository: https://github.com/McMarius11/svgtovisio
- License: MIT
- Copyright (c) 2026 McMarius11

## cytoscape-vsdx
- Repository: https://github.com/ShanteshSindgi/cytoscape-vsdx
- npm package declares license: MIT

## AWS Architecture Icons
AWS Architecture Icons are not included in this package. If the user supplies AWS icons, the renderer can embed them. Users are responsible for complying with AWS trademark/icon usage terms.
