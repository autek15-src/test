# Visio Architecture Renderer Skill

Render LLM-generated architecture descriptions into **editable Microsoft Visio `.vsdx` files** without requiring Microsoft Visio during generation.

Supported inputs:

- canonical `architecture.schema.json`
- Mermaid `.mmd` / `.mermaid`
- PlantUML `.puml` / `.plantuml`

The renderer creates native Visio shapes, text, orthogonal connector geometry, and glue records. It can optionally use user-supplied AWS icon files, a corporate `.vsdx` template, and `.vssx` stencil masters.

## Quick start

```bash
python -m pip install -e .
arch2visio render examples/aws-target.json -o out.vsdx --report out.report.json
arch2visio validate out.vsdx --libreoffice
```

Or without installing:

```bash
python scripts/render_vsdx.py examples/aws-target.json -o out.vsdx --report out.report.json
python scripts/validate_vsdx.py out.vsdx --libreoffice
```

### Mermaid / PlantUML

```bash
python scripts/render_vsdx.py examples/sample.mmd -o sample-mermaid.vsdx
python scripts/render_vsdx.py examples/sample.puml -o sample-plantuml.vsdx
```

### AWS icon collection

Point directly at an extracted AWS Architecture Icons SVG or PNG collection:

```bash
arch2visio index-aws-icons ./AWS-Architecture-Icons
arch2visio render examples/aws-target.json \
  --aws-icons-dir ./AWS-Architecture-Icons \
  --report aws-target.report.json \
  -o aws-target.vsdx
```

The renderer indexes every icon file, caches the catalog, understands common AWS abbreviations/aliases, prefers SVG when available, falls back to PNG if SVG conversion is unavailable, and records every resolution decision in the render report.

To inspect a service match:

```bash
arch2visio resolve-aws-icon ./AWS-Architecture-Icons aws.api_gateway --label "API Gateway"
```

### Corporate template + stencil + AWS icons

```bash
python scripts/render_vsdx.py architecture.json \
  --template corporate-template.vsdx \
  --stencil corporate-shapes.vssx \
  --master-map master-map.json \
  --aws-icons-dir ./AWS-Architecture-Icons \
  --layout-engine auto \
  --report architecture.report.json \
  -o architecture.vsdx
```

See `docs/` for format, layout, template/stencil, and AWS icon details.

### Microsoft Visio desktop compatibility

v1.1.1 tightens fresh-package output for Microsoft Visio desktop, including Visio Standard/Professional 2019. The validator now checks several conditions that LibreOffice and other tolerant readers may accept but desktop Visio can reject: ShapeSheet element ordering, defined style references, native 1-D connector semantics, image relationships, and Windows metadata.

Use:

```bash
arch2visio validate diagram.vsdx
```

A successful result includes `"desktopCompatibilityChecks": "passed"`. On Windows with Microsoft Visio installed, run `powershell -ExecutionPolicy Bypass -File scripts/validate_with_visio.ps1 diagram.vsdx` for a native desktop open test. LibreOffice rendering remains useful, but is not treated as proof that desktop Visio will accept the package.

## PlantUML parser notes

PlantUML input supports colored/styled links such as `-[#0066CC]->`, dashed/hidden link styles, and nested rectangle/package/cloud/node blocks as architecture groups.
