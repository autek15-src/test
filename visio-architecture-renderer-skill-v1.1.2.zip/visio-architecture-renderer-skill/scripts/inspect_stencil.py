#!/usr/bin/env python3
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from visio_arch_renderer.stencil import inspect_stencil
p=argparse.ArgumentParser();p.add_argument('stencil');a=p.parse_args();print(json.dumps(inspect_stencil(a.stencil),indent=2))
