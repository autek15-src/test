#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from visio_arch_renderer.render import render
p=argparse.ArgumentParser()
p.add_argument('input'); p.add_argument('-o','--output',required=True); p.add_argument('--template'); p.add_argument('--stencil'); p.add_argument('--master-map')
p.add_argument('--aws-icons-dir'); p.add_argument('--aws-icon-index'); p.add_argument('--aws-aliases'); p.add_argument('--refresh-aws-icon-index',action='store_true')
p.add_argument('--layout-engine',choices=['auto','graphviz','layered']); p.add_argument('--report'); a=p.parse_args()
print(json.dumps(render(a.input,a.output,template=a.template,stencil=a.stencil,master_map=a.master_map,
                        aws_icons_dir=a.aws_icons_dir,aws_icon_index=a.aws_icon_index,aws_aliases=a.aws_aliases,
                        refresh_aws_icon_index=a.refresh_aws_icon_index,layout_engine=a.layout_engine,report=a.report),indent=2))
