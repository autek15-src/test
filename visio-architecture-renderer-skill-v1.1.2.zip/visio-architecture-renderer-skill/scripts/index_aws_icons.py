#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from visio_arch_renderer.icons import index_aws_icons
p=argparse.ArgumentParser(description='Build/cache a catalog for a user-supplied AWS Architecture Icons directory')
p.add_argument('directory'); p.add_argument('-o','--output'); p.add_argument('--aliases'); p.add_argument('--force',action='store_true'); p.add_argument('--entries',action='store_true'); a=p.parse_args()
print(json.dumps(index_aws_icons(a.directory,cache_path=a.output,force=a.force,aliases_path=a.aliases,include_entries=a.entries),indent=2))
