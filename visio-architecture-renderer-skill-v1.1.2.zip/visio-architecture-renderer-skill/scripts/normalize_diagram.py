#!/usr/bin/env python3
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from visio_arch_renderer.parsers import parse_diagram
p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('-o','--output',required=True);a=p.parse_args();d=parse_diagram(a.input);Path(a.output).write_text(json.dumps({'title':d.title,'direction':d.direction,'groups':[g.__dict__ for g in d.groups],'nodes':[n.__dict__ for n in d.nodes],'edges':[e.__dict__ for e in d.edges],'layout':d.layout},indent=2),encoding='utf-8')
