#!/usr/bin/env python3
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from visio_arch_renderer.validate import validate_vsdx
p=argparse.ArgumentParser();p.add_argument('vsdx');p.add_argument('--libreoffice',action='store_true');a=p.parse_args();r=validate_vsdx(a.vsdx,a.libreoffice);print(json.dumps(r,indent=2));raise SystemExit(0 if r['ok'] else 1)
