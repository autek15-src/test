param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$Path
)

$ErrorActionPreference = 'Stop'
$visio = $null
$doc = $null
try {
    $resolved = (Resolve-Path -LiteralPath $Path).Path
    $visio = New-Object -ComObject Visio.Application
    $visio.Visible = $false
    $version = $visio.Version
    $doc = $visio.Documents.Open($resolved)
    $result = [ordered]@{
        ok = $true
        file = $resolved
        visioVersion = $version
        pageCount = $doc.Pages.Count
        documentName = $doc.Name
    }
    $result | ConvertTo-Json -Depth 4
    exit 0
}
catch {
    $result = [ordered]@{
        ok = $false
        file = $Path
        error = $_.Exception.Message
        hresult = ('0x{0:X8}' -f ($_.Exception.HResult -band 0xffffffff))
    }
    $result | ConvertTo-Json -Depth 4
    exit 1
}
finally {
    if ($doc -ne $null) {
        try { $doc.Close() } catch {}
        [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($doc)
    }
    if ($visio -ne $null) {
        try { $visio.Quit() } catch {}
        [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($visio)
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
