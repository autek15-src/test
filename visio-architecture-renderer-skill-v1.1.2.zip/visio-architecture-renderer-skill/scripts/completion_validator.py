#!/usr/bin/env python3
from __future__ import annotations
import json, os, shutil, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from visio_arch_renderer.render import render
from visio_arch_renderer.validate import validate_vsdx

def run():
    checks=[]
    # Compile all Python
    cp=subprocess.run([sys.executable,'-m','compileall','-q',str(ROOT/'visio_arch_renderer'),str(ROOT/'scripts')],capture_output=True,text=True)
    checks.append(('compileall',cp.returncode==0,cp.stderr.strip()))
    # Tests
    tp=subprocess.run([sys.executable,'-m','pytest','-q',str(ROOT/'tests')],cwd=ROOT,capture_output=True,text=True)
    checks.append(('pytest',tp.returncode==0,(tp.stdout+'\n'+tp.stderr).strip()))
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        for src in ['aws-target.json','sample.mmd','sample.puml','plantuml-styled-zones.puml']:
            out=td/(Path(src).stem+'.vsdx'); report=td/(Path(src).stem+'.report.json')
            try:
                rep=render(ROOT/'examples'/src,out,report=report)
                vr=validate_vsdx(out,libreoffice=bool(shutil.which('libreoffice')))
                checks.append((f'render:{src}',vr['ok'],json.dumps({'render':rep,'validate':vr},indent=2)))
            except Exception as e: checks.append((f'render:{src}',False,repr(e)))
    ok=all(x[1] for x in checks)
    print(json.dumps({'ok':ok,'checks':[{'name':n,'ok':o,'detail':d} for n,o,d in checks]},indent=2))
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(run())
