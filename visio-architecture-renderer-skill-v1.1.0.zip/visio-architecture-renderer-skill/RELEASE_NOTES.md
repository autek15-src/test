# Release notes - v1.1.0

## AWS icon catalog/indexer
- recursively indexes every user-supplied AWS SVG/PNG/JPEG icon instead of scanning filenames independently for every node
- caches the index outside the AWS asset directory and reuses it on subsequent renders
- adds deterministic scoring using normalized official names, service aliases, acronyms, token overlap, service/resource semantics, format, and image size
- adds a broad built-in AWS service/abbreviation alias catalog while still supporting newly released services directly from official filenames
- prefers SVG when available and automatically falls back to PNG/JPEG if SVG conversion is unavailable
- adds custom alias extension files via `--aws-aliases`
- adds `arch2visio index-aws-icons` and `arch2visio resolve-aws-icon`
- adds explicit `--aws-icon-index` and `--refresh-aws-icon-index` controls
- includes icon resolution details and cache status in the JSON render quality report
- adds AWS index/resolution/render tests, including unknown future-service filename matching

## Existing v1.0 capabilities retained
- canonical architecture JSON schema
- Mermaid parser
- PlantUML/C4/common AWS macro parser
- automatic Graphviz-or-layered placement
- multiple layout profiles with score-based selection
- obstacle-aware orthogonal routing with congestion penalty
- native editable VSDX shapes, text, polyline connectors, and connector glue records
- optional VSDX template preservation and safe drawing area
- optional VSSX stencil master import and master mapping
- structural VSDX validation and optional LibreOffice open/render smoke test
- Codex/Claude-style `SKILL.md`, CLI/scripts, examples, tests, and completion validator
