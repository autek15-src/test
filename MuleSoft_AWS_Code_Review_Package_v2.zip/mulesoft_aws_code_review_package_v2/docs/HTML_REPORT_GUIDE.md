# HTML Report: Quick User Guide

The full application review produces an **offline `00-review-dashboard.html`**, alongside Markdown narratives, CSV evidence inventories, and a `15-review-summary.json`. Open the HTML locally in Chrome, Edge or another modern browser. Keep it in the original review-output folder if you want the relative evidence-file downloads to work.

## Where to look first

1. **Overview:** Identifies the application, source Mule and target AWS revisions, environment and recommended review status, with explicit denominators for parity and actual passing tests.
2. **Readiness:** Shows mandatory pass/unverified gates and data consistency warnings. `ASSURANCE_INCOMPLETE` means a claimed ready status was internally contradicted, not that the report author signed off.
3. **Findings:** Search by description or evidence path, filter by P0–P3, and click a finding to expand trigger, expected vs observed results, affected paths, impact, source/design/IaC evidence, fix, test and owner.
4. **Traceability:** Search for a Mule source endpoint/path and inspect the mapped AWS components, parity status, linked test IDs, accepted deviations and open findings.
5. **Tests:** Search execution evidence; `PASS` must have a real run, scenario and an independently derived expected result.
6. **Current and target inventories:** Inspect the complete Mule source endpoints/business paths and AWS deployment components, not just public API routes.
7. **Detailed chapters:** Consumer contracts, security/API Manager policies, errors/retries/side effects, NFRs/quotas, deployment/rollback, narrative findings and open questions.
8. **Files:** Open supporting CSV, Markdown or JSON in the same report snapshot. This is the audit record behind the HTML.

## Interpreting readiness

- **`CHANGES_REQUIRED`:** confirmed release-blocking issues, typically active P0/P1 or unapproved functional/consumer-contract changes.
- **`INSUFFICIENT_EVIDENCE`:** missing code/config/policies, test results or other information prevents an assurance conclusion.
- **`ASSURANCE_INCOMPLETE`:** renderer detected an internally inconsistent `READY_FOR_HUMAN_SIGNOFF` claim (missing ledgers, open P0/P1, unverified paths, critical unknowns or failed gates).
- **`READY_FOR_HUMAN_SIGNOFF`:** all mandatory criteria are reportedly satisfied with evidence. **It is not a production deployment approval.** Humans must verify signoff.
- **`CONDITIONAL_EXCEPTION_REVIEW`:** explicit owner-governed exception review required. No agent can accept risk on behalf of an owner.

The HTML is a **point-in-time snapshot**. Regenerate it when raw data changes; do not edit it by hand. Conduct a *new* snapshot run after code changes or a new deployment and compare results with previous review files. Files should be kept in a controlled repository or artifact store with appropriate retention and access controls.

## Privacy and security

The renderer uses no external libraries, CDNs, APIs or trackers. Its data is embedded in a single file. However, **an exported HTML audit can still contain source paths, internal architecture, business logic and vulnerability evidence**. Share it only with authorized reviewers. Redact secrets, customer information, bearer tokens and production payloads before generating reports.

## Viewing the synthetic sample

`sample-review-output/00-review-dashboard.html` demonstrates the UX using invented code references, invented tests, invented defects and invented sample metadata. Do not cite it as evidence for any real application.
