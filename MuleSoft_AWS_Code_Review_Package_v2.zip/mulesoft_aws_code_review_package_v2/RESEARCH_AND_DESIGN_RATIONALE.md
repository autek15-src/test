# Published LLM Review Skills and Human Code Review Guidelines: Research Synthesis

**Researched:** 2026-10-12 | **Purpose:** Select trustworthy, published review techniques for an application-level MuleSoft→AWS native migration assurance process. **Not** a popularity ranking by downloads or installation counts. We favor recognized published sources and explicitly adapt them rather than asserting the tools already solve migration verification.

| Published resource | What it actually emphasizes | Borrowed into framework | Limitation / necessary migration extension |
|---|---|---|---|
| [Anthropic Code Review Plugin](https://github.com/anthropics/claude-code/blob/main/plugins/code-review/README.md) | Multiple parallel reviewers; code/history/rules coverage; independent confirmation; high-confidence findings, PR focus | Split specialist passes; confidence scored separately from severity; second-pass adjudication; deduplicate root causes | Its PR-diff boundary and high-confidence filtering can miss unmigrated legacy functions; our unmatched inventory and critical-unknown register are always reported |
| [Anthropic PR Review Toolkit](https://github.com/anthropics/claude-code/blob/main/plugins/pr-review-toolkit/README.md) | Agents for test quality, silent failures, types, comments, simplification | Dedicated test effectiveness and silent failure hunts; type/design review; use targeted reviewers | Expand to Mule transformations/policies, IaC wiring, backend effects, async recovery and release constraints |
| [Anthropic Engineering Code Review Skill](https://github.com/anthropics/knowledge-work-plugins/blob/main/engineering/skills/code-review/SKILL.md) | Structured review of security/performance/correctness/maintainability; actionable findings/verdict | Consistent review output, prioritized evidence/action and summary | Requires source/target/intent split and 100% workflow traceability for migration |
| [Anthropic Skill Creator](https://github.com/anthropics/skills/blob/main/skills/skill-creator/SKILL.md) | Skill metadata, trigger description, progressive disclosure, reference documents, iteration/tests | Short `SKILL.md` wrapper, detailed reference file, optional reusable templates | Packaging pattern is not itself code review methodology |
| [GitHub Copilot review guidance](https://docs.github.com/en/copilot/how-tos/copilot-on-github/use-copilot-agents/copilot-code-review) | Repository-wide / path-specific custom instructions; AGENTS.md and conventions for reviews | Explicit project-specific review charter, inputs and environment rules; can integrate with existing instructions | Doesn't inherently discover behavior omitted by code generation |
| [Google Engineering Practices](https://google.github.io/eng-practices/review/reviewer/looking-for.html) | Design first; functionality, edge cases, concurrency, complexity, tests that fail when code breaks; avoid nits | Architecture/behavior priority; quality of tests; system/maintainability check; review what's actually in scope | Generic code review, not a source-to-target migration audit |
| [OWASP ASVS 5.0](https://github.com/OWASP/ASVS/tree/master/5.0/en) and [Code Review Guide](https://owasp.org/projects/code-review-guide) | Verification requirements for validation/business logic, authorization, secure processing | Security parity requirements; positive/negative authorization and data-flow testing | Security is only one pillar of migration fidelity and operations |
| [AWS Serverless Applications Lens](https://docs.aws.amazon.com/wellarchitected/latest/serverless-applications-lens/) | Design for failure/duplicates, concurrency, limits, security and operational excellence | Cross-service operational and resilience review, architecture fitness gates | Does not compare with original Mule behavior |
| [AWS Lambda best practices](https://docs.aws.amazon.com/lambda/latest/dg/best-practices.html) | Execution environment reuse, safe immutable client setup, idempotency, bounded state | Lambda runtime and correctness checks | Need explicit runtime/SDK/version and per-service quotas validated at review time |
| [AWS SQS Lambda failure behavior](https://docs.aws.amazon.com/lambda/latest/dg/services-sqs-errorhandling.html) | Batch failure semantics, partial responses, FIFO behavior | Config-plus-code check for `ReportBatchItemFailures`, idempotency and replay | Add source Mule retry/transaction comparison |
| [AWS EventBridge DLQ](https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-rule-dlq.html) | Rule target retry/failure destinations and monitoring | Producer+bus+rule+target recovery verification | Acknowledged delivery does not imply business completion |
| [Mule error handlers](https://docs.mulesoft.com/mule-runtime/latest/error-handling) | `on-error-continue` vs `on-error-propagate` and routing of errors | Source error decision tree and observable response/rollback review | Must inspect effective app-specific implementation, not just defaults |

## Consciously rejected practices

1. **"Review only changed lines" for the baseline migration**: inappropriate when generated AWS code may not contain an omitted source feature. Do an application-level initial audit, then risk-based incremental re-reviews.
2. **"Only report findings with confidence ≥80"**: useful to reduce PR noise, unsafe as the sole release rule. Report unresolved high-impact risks as critical UNKNOWNs with investigation tasks.
3. **"High test coverage proves equivalence"**: generated implementation may have matching generated tests and still disagree with Mule. Require source-derived fixtures, behavior/side-effect assertions and target deployed integration tests.
4. **"1 Mule flow = 1 Lambda"**: can preserve unwanted complexity or violate limits. Architecture can consolidate/refactor with documented semantics and approvals.
5. **"Missing code = removed behavior"**: absence in target is a migration defect until explicitly approved as obsolete/moved/retired.
6. **"All AWS services require the same recommended defaults"**: DLQ, SQS FIFO, API Gateway REST/HTTP, Lambda vs ECS, RDS Proxy, concurrency and Step Functions require architecture-specific suitability and quota checks.

## Project-specific review differentiators

- Immutable source/target baselines and environment-resolved policy/configuration.
- Every endpoint can have several business paths; every path must be mapped independently.
- Consumer contracts unchanged by default except explicitly approved target architecture deviations, including API consolidation/backend-layer moves.
- Explicit Mule DataWeave, exception semantics, backend side effects, ack/retry semantics, and policy-to-IAM/authorizer mapping.
- AWS wiring/config review, not just function source.
- Splunk-centric log observability when required, with AWS metrics/alarms retained for native service failure modes.
- Dependencies between Mule applications and shared deployment clusters included in cutover approval.
- Evidence-based machine-readable review with P0–P3 and separate confidence/investigation tracking.

## Additional authoritative service references for reviewers

- [AWS SQS event source mapping configuration](https://docs.aws.amazon.com/lambda/latest/dg/services-sqs-configure.html)
- [AWS SQS message quotas](https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/quotas-messages.html)
- [AWS EventBridge rule defaults and DLQ](https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-create-rule-wizard.html)
- [AWS API Gateway HTTP API quotas](https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-quotas.html)
- [AWS Lambda Powertools Batch Processing (TypeScript)](https://docs.aws.amazon.com/powertools/typescript/latest/features/batch/)
- [AWS Lambda Powertools Idempotency (TypeScript)](https://docs.aws.amazon.com/powertools/typescript/latest/features/idempotency/)

**Standards/license note:** Documents paraphrase/generalize ideas and link to authoritative sources rather than reproducing substantive skill source texts. Do not assume licenses are identical across linked repositories. Verify original license before redistributing verbatim text from external resources.
