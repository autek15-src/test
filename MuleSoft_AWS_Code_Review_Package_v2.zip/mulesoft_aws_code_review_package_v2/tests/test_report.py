"""Smoke tests for self-contained review skill. Run: python -m unittest discover -s tests -v"""
import csv
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SKILL=ROOT/'.claude/skills/mulesoft-aws-migration-code-review'
RENDER=SKILL/'scripts/render_review.py'
INIT=SKILL/'scripts/init_review.py'
SAMPLE=ROOT/'sample-review-output'

class ReviewPackageTests(unittest.TestCase):
    def test_templates_match_generated_sample_headers(self):
        for template in sorted((SKILL/'assets/templates').glob('*.csv')):
            with template.open(encoding='utf-8',newline='') as f: source=next(csv.reader(f))
            with (SAMPLE/template.name).open(encoding='utf-8',newline='') as f: example=next(csv.reader(f))
            self.assertEqual(source,example,template.name)
        self.assertEqual(len(list((SKILL/'assets/templates').glob('*.csv'))),7)

    def test_init_and_immutable_runs(self):
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'run/review-output'
            cmd=[sys.executable,str(INIT),'--output',str(path),'--application','Test-App','--target-sha','abcdef','--mule-sha','012345']
            result=subprocess.run(cmd,text=True,capture_output=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual(len(list(path.iterdir())),16)
            summary=json.loads((path/'15-review-summary.json').read_text())
            self.assertEqual(summary['status'],'INSUFFICIENT_EVIDENCE')
            self.assertTrue(all(value is False for value in summary['gates'].values()))
            again=subprocess.run(cmd,text=True,capture_output=True)
            self.assertNotEqual(again.returncode,0)

    def test_offline_dashboard_smoke_and_escape(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'review-output'
            shutil.copytree(SAMPLE,p)
            summary=json.loads((p/'15-review-summary.json').read_text())
            summary['application']='<img src=x onerror=alert(42)>'
            (p/'15-review-summary.json').write_text(json.dumps(summary))
            with (p/'16-findings.csv').open(encoding='utf-8',newline='') as f:
                reader=csv.DictReader(f);headers=reader.fieldnames;data=list(reader)
            data[0]['title']='<svg onload=alert(42)>'
            with (p/'16-findings.csv').open('w',encoding='utf-8',newline='') as f:
                writer=csv.DictWriter(f,fieldnames=headers);writer.writeheader();writer.writerows(data)
            r=subprocess.run([sys.executable,str(RENDER),'--input',str(p)],text=True,capture_output=True)
            self.assertEqual(r.returncode,0,r.stderr)
            text=(p/'00-review-dashboard.html').read_text()
            self.assertIn('&lt;img src=x onerror=alert(42)&gt;',text)
            self.assertIn('&lt;svg onload=alert(42)&gt;',text)
            self.assertNotIn('<img src=x',text)
            self.assertNotIn('<svg onload',text)
            self.assertIn('data-filter-search="findings"',text)
            self.assertIn('data-filter-select="findings"',text)
            self.assertIn('id="traceability"',text)
            self.assertIn('id="contracts"',text)
            self.assertIn('id="artifacts"',text)
            self.assertIn('src/handlers/getCustomer.ts:63-75',text)
            self.assertIn('CHANGES REQUIRED',text)
            self.assertNotIn('https://cdn',text)

    def test_invalid_ready_claim_is_downgraded(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'review-output';shutil.copytree(SAMPLE,p)
            summary=json.loads((p/'15-review-summary.json').read_text())
            summary['status']='READY_FOR_HUMAN_SIGNOFF'
            (p/'15-review-summary.json').write_text(json.dumps(summary))
            r=subprocess.run([sys.executable,str(RENDER),'--input',str(p)],text=True,capture_output=True)
            self.assertEqual(r.returncode,0,r.stderr)
            page=(p/'00-review-dashboard.html').read_text()
            self.assertIn('ASSURANCE INCOMPLETE',page)
            self.assertIn('Inconsistent READY verdict',page)
            strict=subprocess.run([sys.executable,str(RENDER),'--input',str(p),'--strict'],text=True,capture_output=True)
            self.assertEqual(strict.returncode,2)

    def test_missing_ledgers_remain_unverified(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'review-output';p.mkdir()
            result=subprocess.run([sys.executable,str(RENDER),'--input',str(p)],capture_output=True,text=True)
            self.assertEqual(result.returncode,0)
            html=(p/'00-review-dashboard.html').read_text()
            self.assertIn('INSUFFICIENT EVIDENCE',html)
            self.assertIn('Missing required CSV',html)
            self.assertIn('Not assessed',html)

if __name__=='__main__': unittest.main()
