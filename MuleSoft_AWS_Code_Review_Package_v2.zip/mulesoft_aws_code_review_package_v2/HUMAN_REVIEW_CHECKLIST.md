# Human Technical Lead Checklist: MuleSoft-to-AWS Native Application Review

**Version:** 2.0 | **Prepared:** 2026-10-12 | **Review unit:** Entire migrated MuleSoft application (not one API or PR)

## Intended use

Use this checklist for a **human review of LLM-generated AWS-native code, infrastructure-as-code (IaC), deployment configuration, policies, and test assets**. Includes TypeScript/Node.js and Java Lambda, API Gateway, SQS, EventBridge, Step Functions, ECS/Fargate, data stores and supporting components. It complements an independent AI agent review; it is not a substitute for it.

**How to record results:** For each check, record **PASS / FAIL / UNKNOWN / N/A**, reviewer, file and line or deployed resource, evidence (test ID/log/trace/config/ADR), severity of any defect (P0–P3), and remediation ticket. N/A requires a rationale. UNKNOWN is *not* PASS. For high-risk checks, read both source and target code/config and obtain test evidence. A row checked off without evidence does not establish completion. Adapt implementation-specific questions to the approved design: do not require Lambda, DLQ, FIFO, caching, or any other mechanism indiscriminately.

**Evidence precedence:** For current implementation behavior, use the correctly tagged/deployed Mule code plus resolved configuration and policies, verified against relevant observed traces/tests; use specs and documentation as additional evidence, not unquestioned truth. For intended target behavior, use the approved target HLD/LLD/ADRs and explicit approved change decisions. When evidence conflicts, investigate and document the conflict; do not silently choose a convenient source.

**Mandatory release gates** (unless the accountable architecture/security/application owner formally approves a documented exception):
1. 100% of discovered in-scope endpoints, triggers, reachable business branches and side-effecting paths mapped to a target implementation, approved replacement, or approved retirement. Unreachable/unused paths require evidence.
2. No unresolved P0/P1; no unapproved consumer-visible contract differences or authentication/authorization regressions.
3. Critical source behavior and target requirements have executable tests and documented evidence, including failure/retry/idempotency paths.
4. Every deployed component, permission, event route and environment-specific configuration is traceable to version-controlled or explicitly controlled deployment configuration; no plaintext secret leakage.
5. Critical UNKNOWNs, contradictory architecture instructions, missing input sources and unverified capacity/limits block *unconditional* sign-off. Release exception must be specific, owned, time-bounded and accepted through governance.
6. Security review, operational readiness, backout, monitoring and owner approvals are recorded.

## A. Review baseline, scope and governance

- [ ] **H001** Application boundary documented: all Mule apps/APIs, shared libraries, scheduled jobs, event listeners, and deployment dependencies included/excluded.
- [ ] **H002** Source Mule Git repository, branch, immutable commit/tag, Mule runtime version, JDK, dependency graph and relevant environment identified.
- [ ] **H003** All other input repositories pinned: UI/upstream callers, downstream backends, Java libraries, shared APIs, contract repositories, tests.
- [ ] **H004** Environment-specific effective Mule properties, secure properties, Anypoint API Manager policies and relevant external gateways/ingress provided or explicitly marked unavailable.
- [ ] **H005** Approved target HLD, LLD, sequence/network diagrams, API contract, ADRs and deviations pinned to versions.
- [ ] **H006** Target repository revision, lockfiles, IaC state/plan/synth output, CI/CD workflow and deployable artifacts pinned.
- [ ] **H007** Review includes all added, modified and unmodified generated code as needed; PR-only diff is insufficient for initial migration sign-off.
- [ ] **H008** Open assumptions, unknowns, decisions, acceptance criteria, RACI and artifact owners recorded.
- [ ] **H009** LLM-generated code and documentation inspected as untrusted output; placeholder implementations and fabricated evidence actively searched.
- [ ] **H010** Source/target dependencies and release groups identified at application and shared-cluster level.

## B. MuleSoft current-state behavior discovery

- [ ] **H011** Every Mule `http:listener`, APIKit/RAML/OAS route, SOAP listener, scheduler and message/event consumer inventoried; generated and implicit routes considered.
- [ ] **H012** Every flow, subflow, private flow reference, batch job, choice/when, scatter-gather, parallel-foreach, foreach and until-successful traversed.
- [ ] **H013** Each endpoint's distinct business scenarios identified, not collapsed into one simplistic happy path; branches with dynamic routing and feature flags included.
- [ ] **H014** Actual effective Mule route method, full base path, path/query/header/body contract, defaulting and validation compared with published specs.
- [ ] **H015** Every DataWeave transformation and external script/module inventoried, including null/absent handling, coercions, dates, timezone, numeric precision, XML namespaces, arrays and encoding.
- [ ] **H016** Variables, attributes, payload changes and connector outputs traced across processors with scope/order preserved.
- [ ] **H017** All connectors and downstream operations listed: SAP, DB, HTTP, JMS/MQ, Salesforce, SFTP, file systems, etc.; operations include reads, writes and external side effects.
- [ ] **H018** Mule retry/reconnect rules, timeouts, transactions, redelivery, ack/nack, rollback and `on-error-continue` versus `on-error-propagate` mapped.
- [ ] **H019** Authorization, API Manager policies, token propagation, client ID/secret, basic auth, mutual TLS, IP restrictions, quotas and throttling captured.
- [ ] **H020** MUnit, Postman, SoapUI, integration samples, payload captures and production traces reviewed for real behavior and hidden cases.
- [ ] **H021** Dead/unreachable logic identified by evidence, not assumption; retirement requires approval.
- [ ] **H022** Shared cluster/environment dependencies and potential collateral effects identified.

## C. Architecture and end-to-end functional equivalence

- [ ] **H023** Each source path mapped to target ingress, compute, transforms, integrations, state transitions and return/ack path.
- [ ] **H024** Each target behavior traces back to approved source behavior or explicit target change (no invented endpoints/rules/side effects).
- [ ] **H025** Approved target design implemented; deviations and optimizations supported by a recorded ADR/change approval.
- [ ] **H026** Compute fit justified for each workload: Lambda vs ECS/Fargate based on payload, processing time, cold start, dependencies, state, concurrency and latency.
- [ ] **H027** Sync-to-async conversion preserves externally promised response/ack and completion semantics; eventual consistency exposed only as approved.
- [ ] **H028** End-to-end processing order, transaction boundaries and side effect ordering preserved or deliberately redesigned.
- [ ] **H029** Shared component dependencies, fan-out/fan-in paths, orchestration and failure compensation reviewed.
- [ ] **H030** Idempotency boundaries defined by *business operation* (not merely request ID), including duplicate and concurrent requests.
- [ ] **H031** Multiple business paths per endpoint reviewed separately; no branch silently omitted.
- [ ] **H032** External system compatibility verified against actual interface and credential expectations.
- [ ] **H033** Throughput, service quotas, resilience and network topology compatible with documented target NFRs.
- [ ] **H034** Any moved, merged or eliminated API behavior has consumer impact analysis and signed decision.

## D. API Gateway, ingress, and consumer contracts

- [ ] **H035** All public/internal methods and paths preserved, except explicit approved changes; path casing, stage/base-path mappings, greedy routes and URL encoding verified.
- [ ] **H036** Request: path/query/header/cookie names and multiplicity, optionality, content types, bodies, multipart/binary and maximum sizes tested.
- [ ] **H037** Response: status codes, body fields/types/order where contractual, null/missing distinction, content types, CORS and headers tested.
- [ ] **H038** Error responses preserve consumer-facing semantics, mapping, masking and retryability; gateway-generated 4xx/5xx evaluated.
- [ ] **H039** OpenAPI/RAML-derived target API definition matches deployed API Gateway routes, integrations, validators, stages and deployment settings.
- [ ] **H040** HTTP API vs REST API capabilities and constraints consciously selected; no assumptions that features/quotas are interchangeable.
- [ ] **H041** JWT/OIDC authorizer uses correct token type, issuer, audience, scopes, algorithm/JWKS, expiry and clock-skew handling; application-level authorization included.
- [ ] **H042** Basic auth, API keys/client IDs, mTLS and legacy consumer accommodation use approved controls, with no credentials hardcoded or silently downgraded.
- [ ] **H043** API keys are not mistaken for user authorization; deny-by-default access and per-resource/operation authorization verified.
- [ ] **H044** Resource policies, WAF, throttling, request limits, quotas, TLS, custom domain/certificates and logging configured appropriately.
- [ ] **H045** Authorizer cache TTL/key and token revocation implications reviewed; principal context/header forwarding cannot be spoofed.
- [ ] **H046** Edge/network path (DNS, NLB/ALB, VPC Link, private endpoints, SG/NACL, routes, certificates and TLS termination) validated where applicable.
- [ ] **H047** Integration timeout, payload quota and binary/base64 behavior confirmed against selected API type and region *using current AWS documentation*.
- [ ] **H048** Consumer regression/contract tests cover success, invalid inputs, auth failure, authorization failure, upstream/downstream errors and pagination/versioning.

## E. Lambda TypeScript/Node.js and Java implementation

- [ ] **H049** Handler is thin; routing, validation, mapping, business logic and downstream clients modular and testable.
- [ ] **H050** Strict typing/schema validation at trust boundaries; TypeScript `any`, unsafe casts, `!`, ignored promises and unhandled rejections investigated.
- [ ] **H051** Java handler serialization/deserialization and library/runtime version compatibility tested; managed vs custom runtime justified.
- [ ] **H052** Async execution completed/awaited before response; no fire-and-forget business-critical work in short-lived handlers.
- [ ] **H053** Exceptions propagate intentionally; catch blocks never silently return success on failed side effects.
- [ ] **H054** Null/undefined/absent, falsy zero/false, array shape, URL encoding and character encoding explicitly handled.
- [ ] **H055** Monetary/decimal and timestamps use semantics required by source system, including rounding, timezone, DST and date-only behavior.
- [ ] **H056** Retries at SDK/client layer bounded with timeout and backoff; nested retries do not amplify outages.
- [ ] **H057** Clients and safe immutable config reused across warm invocations, but mutable user/request state never leaks between invocations.
- [ ] **H058** Connection keepalive, pool limits, stale connection recovery and cleanup appropriate to Node or Java runtime.
- [ ] **H059** Resource cleanup works on success/failure; streams, temp files and memory bounded; `/tmp` not treated as durable state.
- [ ] **H060** Dependencies lock/pin versions; no invented SDK API calls, fake imports or incompatible bundling/module formats.
- [ ] **H061** Supply-chain and application vulnerability scan reviewed; vulnerable dependencies have owner, severity and plan.
- [ ] **H062** Java cold-start/heap and concurrency considerations reviewed; JVM, SDK/HTTP pool and serialization tuning measured where needed.
- [ ] **H063** Unit tests assert *business outcomes*, not only mocked function invocations or snapshots.
- [ ] **H064** Logging excludes tokens, Basic credentials, Vault secrets and PII unless explicitly redacted under policy.

## F. Lambda configuration, IAM, networking and lifecycle

- [ ] **H065** Function handler, runtime, architecture, build output, layer dependencies and deployment package/container image correct.
- [ ] **H066** Memory/CPU, timeout, ephemeral disk, concurrency, reserved/provisioned concurrency (if justified), environment and DLQ/destination configured and reviewed.
- [ ] **H067** Lambda runtime deadline shorter than upstream timeout budget; downstream timeouts leave time for cleanup/ack/error response.
- [ ] **H068** VPC/subnet/SG/NAT/VPC endpoint/route/DNS settings enable needed on-prem and AWS communication without unnecessary exposure.
- [ ] **H069** Role and resource-based policies use least privilege and correct source ARN/account conditions; no wildcards without approved reason.
- [ ] **H070** Layers and extensions have clear version, support, patching, cold-start/size, observability and licensing ownership.
- [ ] **H071** Environment variables contain nonsecret references/config rather than plaintext credentials; secure retrieval/caching/rotation defined.
- [ ] **H072** HashiCorp Vault access, auth, role/policy, renewal, secret TTL, rotation and failure behavior verified if used.
- [ ] **H073** Aliases/versions and deployment strategy support rollback; unsupported runtimes/deprecation dates tracked.
- [ ] **H074** Runtime budget and quota checks include invoke payload, response limits, duration, concurrency and downstream capacity.

## G. SQS and asynchronous consumers

- [ ] **H075** Queue choice (standard vs FIFO), required ordering/group ID, duplication, delay, throughput and DLQ policy documented.
- [ ] **H076** Producer validates SendMessage result and handles failures without falsely acknowledging completed business processing.
- [ ] **H077** Consumer deserialization/schema validation, poison message handling and idempotency tested.
- [ ] **H078** Event-source mapping enabled/configured: batch size/window, filter, concurrency and failure response settings.
- [ ] **H079** Lambda and source mapping timeouts, queue visibility timeout, expected batch processing duration and redrive thresholds are coherent.
- [ ] **H080** Partial batch failures are returned correctly where chosen; if FIFO, stop at first failure and return failed plus unprocessed messages.
- [ ] **H081** Duplicates, concurrent redelivery and reprocessing after partial downstream success do not double-apply effects.
- [ ] **H082** DLQ policy, retention, encryption, alarms, replay procedure and ownership tested; not merely declared in IaC.
- [ ] **H083** Ack/nack/deletion and transaction boundaries match source messaging behavior or approved change.
- [ ] **H084** Queue/IAM/KMS resource policies and cross-account access tested if applicable.
- [ ] **H085** Payload sizes/attributes, batch request and quota differences validated against current AWS documentation.

## H. EventBridge, schedules and event contracts

- [ ] **H086** Event source, detail-type, event schema/version and event bus selection documented for every producer and consumer.
- [ ] **H087** Events published only when intended business preconditions succeed; transactional outbox or equivalent assessed for DB+publish scenarios.
- [ ] **H088** `PutEvents` partial failures checked at the entry level; retry only failed entries where safe.
- [ ] **H089** Rule patterns and input transformers tested against actual event fixtures; accidental broad matching or silent dropping avoided.
- [ ] **H090** Delivery target permission, cross-account/region rules, resource-based policies and encryption correct.
- [ ] **H091** Each important rule target has justified retry policy and target DLQ (or alternative recovery guarantee), with test evidence.
- [ ] **H092** EventBridge Scheduler time zone, daylight-saving, duplicate execution, retries and dates verified if replacing Mule scheduler.
- [ ] **H093** Event ordering and at-least-once behavior explicitly addressed; downstream deduplication implemented when required.
- [ ] **H094** Archive/replay, retention, event evolution and schema compatibility strategy reviewed when required by recovery/operational design.
- [ ] **H095** Rule/target metrics, failed-invocation/DLQ alarms and runbook exist.

## I. Step Functions, ECS/Fargate, ALB and other compute

- [ ] **H096** State machine definition and input/output transformations reviewed for every branch, retries, catches, compensation and terminal state.
- [ ] **H097** Standard vs Express state machine selection justified by duration, execution and delivery semantics, observability and cost.
- [ ] **H098** State payload/transaction history/integration limits and execution timeout verified for selected Step Functions type.
- [ ] **H099** Task token/callback patterns and external completion/timeouts safe from orphaned workflows.
- [ ] **H100** ECS/Fargate image scan, task CPU/memory, health probes, shutdown grace, auto scaling, secrets and task/execution roles reviewed.
- [ ] **H101** ECS/ALB listener rules, target group health, connection draining, timeouts and TLS/network design validated where applicable.
- [ ] **H102** Long-lived work, high payloads or persistent connections intentionally assigned to fitting compute; not forced through Lambda.
- [ ] **H103** Jobs/tasks and non-HTTP triggers have failure/replay/alerting and ownership.

## J. Downstream integrations and persistent state

- [ ] **H104** Each outbound operation preserves URI, HTTP method, content type, headers, auth, timeout, redirect handling and actual backend business semantics.
- [ ] **H105** SAP/BAPI/RFC/REST integration data shape, date/number encoding, errors, credentials and connectivity verified with backend owners.
- [ ] **H106** Request-level auth and user context propagate only as approved; no trusted identity derived from spoofable headers.
- [ ] **H107** Database SQL/transaction/isolation/locking, RDS Proxy need, connection pool limits and query error mapping reviewed.
- [ ] **H108** DynamoDB keys, conditional writes, indexes, TTL, consistency, item limits and hotspot behavior reviewed if used.
- [ ] **H109** S3 key naming, object metadata/encryption, multipart uploads, path traversal, event notifications and lifecycle evaluated if used.
- [ ] **H110** Duplicate writes/external side effects protected by business-appropriate idempotency, durable checkpoint or reconciliation.
- [ ] **H111** Partial multi-system failures have explicit compensation, recovery or documented accepted behavior.
- [ ] **H112** Circuit-breaking, bulkhead, rate limits and bounded retry budgets protect downstream services where appropriate.
- [ ] **H113** Cross-account, VPN/Direct Connect, DNS, proxy, certificates, mTLS and egress allowlists validated.
- [ ] **H114** Schema/API version drift and downstream deployment dependencies documented.

## K. Security, privacy, policy parity and supply chain

- [ ] **H115** Threat model addresses authentication, authorization, injection, deserialization, SSRF, replay, event forgery and data exfiltration.
- [ ] **H116** All Mule and API Manager policies have target enforcement point, configuration, tests and ownership; missing policies explicitly flagged.
- [ ] **H117** Both endpoint-level and object/resource-level authorization verified under positive/negative test identities.
- [ ] **H118** JWT signatures and claim checks actually enforced where applicable (not merely decoded); client credentials/basic auth protected.
- [ ] **H119** Secrets never committed, echoed in CI, logged, placed in plain env vars or sent through untrusted prompts.
- [ ] **H120** Sensitive data encrypted in transit/at rest as required; KMS policies and storage retention/deletion verified.
- [ ] **H121** External requests protected against injections, XXE, unsafe redirects, header injection and SSRF as applicable.
- [ ] **H122** Error and trace messages do not leak credentials, detailed stack internals or regulated personal information.
- [ ] **H123** Build provenance, dependency lockfiles/SBOM, SCA, secret scanning, IaC scanning and license checks exist.
- [ ] **H124** No production access or infrastructure mutation granted to LLM review tooling beyond explicitly approved need.

## L. Observability and supportability

- [ ] **H125** Correlation/trace IDs flow from API Gateway or source event through all Lambdas, queues, rules and downstream calls.
- [ ] **H126** Structured logs record action, outcomes and safe contextual identifiers; logging policy handles sensitive data redaction.
- [ ] **H127** Logs and traces delivered to enterprise Splunk when specified, with data delivery/backpressure/failure handling; AWS-native metrics still available as needed.
- [ ] **H128** Critical metrics and alerts cover API 4xx/5xx/latency, Lambda errors/duration/throttles, SQS age/DLQ, EventBridge failed delivery and downstream dependency health.
- [ ] **H129** Success metrics represent *business completion*, not only API 202 or successful enqueue.
- [ ] **H130** Dashboard, alert routing, runbooks, DLQ replay and operational access are production-ready and exercised.
- [ ] **H131** Logs/traces can connect one business operation across async boundaries with no PII leakage.
- [ ] **H132** Monitoring changes compared to Anypoint baseline and supports equivalent or improved operational diagnosis.

## M. IaC, environments and CI/CD

- [ ] **H133** Every deployed resource reproducible via Terraform/CDK/CloudFormation/SAM or approved declarative provisioning; console-only drift identified.
- [ ] **H134** Resource dependencies/permissions correct in effective deployed configuration, not just in source IaC templates.
- [ ] **H135** `dev`, `test`, `stage`, `prod` config/schema/environment differences reviewed in a matrix, without secret values.
- [ ] **H136** Nonproduction safe defaults: mock endpoints, no accidental production backend invocation, permissions appropriately scoped.
- [ ] **H137** Parameter names, secret paths, DNS, topics, queues, region/account, certificates, mappings and feature flags match real environment setup.
- [ ] **H138** CI builds, unit/integration tests, SAST/SCA/IaC checks, artifact signing/pinning and promotion controlled by version.
- [ ] **H139** IaC `plan`, `synth`, `validate` and relevant deployment dry-runs performed without unintended modification.
- [ ] **H140** Artifact/SDK/runtime versions fixed; automated update and patch ownership defined.
- [ ] **H141** Rollback accounts for schemas, asynchronous in-flight messages, events, idempotency records and non-backward-compatible consumers.
- [ ] **H142** IAM permissions of CI/CD pipeline, cross-account deployment, secure secret injection and audit trail reviewed.
- [ ] **H143** IaC drift detection and safe destruction/retention controls established for stateful AWS resources.

## N. Performance, reliability, capacity and cost

- [ ] **H144** Source traffic metrics include peak/steady TPS, concurrency, burst profiles, request/response size percentiles and long-tail latency.
- [ ] **H145** Downstream measured latency/timeout profiles and connection/transaction quotas inform compute/memory/concurrency configuration.
- [ ] **H146** End-to-end timeout budget established across gateway, load balancer, Lambda, message delay, retries and downstream services.
- [ ] **H147** AWS service quotas validated for selected API type, Lambda invocation, SQS, EventBridge, Step Functions, storage and network in target region/account.
- [ ] **H148** Cold starts, Java initialization, VPC, connection pool growth and downstream scaling covered by measurements or credible tests.
- [ ] **H149** Load/soak/spike/recovery tests demonstrate NFR behavior at expected and peak workload.
- [ ] **H150** Availability, RTO/RPO, replay strategy, regional failure mode and restore procedure match design where applicable.
- [ ] **H151** Cost model includes retries, logs/Splunk forwarding, NAT, API requests, data transfer, queues and idle ECS capacity; no false Lambda-is-always-cheaper claim.

## O. Test effectiveness and source-to-target comparison

- [ ] **H152** Test coverage maps every in-scope endpoint *business branch*, trigger, transform, side effect and important error path to at least one concrete test.
- [ ] **H153** Golden-master comparison uses trusted Mule responses/side effects or approved specs with anonymized fixtures; source/target parity verified at wire level.
- [ ] **H154** Test harness executes on deployed integration paths as well as unit mocks; tests are not solely self-referential to generated implementation.
- [ ] **H155** Consumer-facing RestAssured contract test suite covers unchanged API signatures and explicit authorized exceptions.
- [ ] **H156** Positive, negative, boundary, authn/authz, backend failure, timeout, retry, duplicate, poison-message and concurrent-execution tests exist.
- [ ] **H157** DataWeave vs TypeScript/Java comparison includes numeric precision, timestamps, XML, absent/null values, locale and array ordering.
- [ ] **H158** MUnit/SoapUI/Postman cases traced forward; uncovered legacy cases documented with disposition.
- [ ] **H159** Assertions inspect payload, headers, status, calls, persisted state and event emission (not only HTTP status or mock invocation count).
- [ ] **H160** Coverage percentages cannot conceal missing branches; mutation testing and independent negative cases considered for critical mapping logic.
- [ ] **H161** Test reports and observed logs linked to source commit, target commit, environment, test-data version and timestamp.
- [ ] **H162** Failed/flaky tests are recorded and explained; never reported as passing or quietly excluded.

## P. Release coordination, operations and sign-off

- [ ] **H163** Cross-app consumer and backend dependencies, shared deployment clusters and application-level migration waves are mapped.
- [ ] **H164** Deployment order, DNS/routing cutover, parallel run, traffic shifting, contract compatibility and rollback process documented.
- [ ] **H165** In-flight async messages, scheduled jobs, replays, idempotency TTL and potential double-processing addressed at cutover.
- [ ] **H166** Go/no-go thresholds and functional/operational verification after deployment defined.
- [ ] **H167** Security, application, operations, cloud platform and consumer-owner sign-offs recorded where required.
- [ ] **H168** Outstanding findings, documented exceptions, residual risks and deadlines accepted by accountable owners.

## Q. Independent LLM report output and HTML dashboard signoff (v2)

- [ ] **H169** Independent review agent followed the full methodology in `references/AGENT_REVIEW_INSTRUCTIONS.md` and `references/REPORTING_CONTRACT.md`, not only a PR diff or generated-code lint pass.
- [ ] **H170** Report run is immutable, identified by application/environment, source Mule and target AWS commit SHAs, baseline architecture revisions, reviewer and generation timestamp.
- [ ] **H171** Seven structured CSVs (`02`, `03`, `04`, `05`, `06`, `10`, `16`) use the standard template headers, stable IDs and actual code/config/test/ADR evidence. P0–P3 finding IDs agree between `13-findings.md` and `16-findings.csv`.
- [ ] **H172** All 17 required artifacts (`00`–`16`) exist; initialized NOT REVIEWED placeholders, missing source rows, zero denominators, unverified paths and stale summary JSON are not mistaken for a completed review.
- [ ] **H173** `00-review-dashboard.html` opens locally without internet and has clear navigation, executive metrics with denominators, release gates, search/filter findings, traceability, tests, source/target inventories, security, NFRs, deployment, open issues and source artifact links.
- [ ] **H174** HTML summary values reconcile against raw ledgers and source/target evidence; dashboard warnings, active P0/P1, critical UNKNOWNs, review exceptions and failing gates are understood and dispositioned by named owners.
- [ ] **H175** Detailed finding evidence is read directly in source or deployment configuration for every P0/P1 and representative P2/P3 sample; report generator behavior and rendered HTML have not hidden defects or added unverified PASS claims.
- [ ] **H176** Report contains no credentials, OAuth tokens, Vault secrets, personal data or uncontrolled production payloads; accessible source links remain inside the approved review evidence set, and the report is retained under enterprise access control.

## Prioritization model

| Severity | Meaning | Example | Treatment |
|---|---|---|---|
| **P0 Critical** | Active or near-certain severe production compromise, major data integrity/confidentiality breach, destructive behavior or systemic outage | Unauthenticated access to sensitive data; business operation always double-posts payments | Stop release, immediate escalation |
| **P1 High** | Significant security, functional parity, operational or compliance defect likely to impact production | Missing business branch, invalid auth audience, silent data loss on async failure | Release-blocking until fixed or formally governed exception |
| **P2 Medium** | Bounded defect with workaround, modest reliability/performance issue or meaningful testing gap | Partial edge-case date mismatch, missing noncritical alert | Fix before release when practical or track approved remediation |
| **P3 Low** | Maintainability improvement, minor performance or nonblocking style/documentation | Redundant code, unclear comment | Backlog/normal remediation |

**Important:** Severity is impact; confidence is how strong the evidence is. An unproven high-impact concern must remain an **open investigation/critical UNKNOWN**, not disappear because an LLM assigned confidence below 80.

## Review evidence register (copy per application)

| Check ID | Status | Evidence: path:line / test ID / deployed config | Finding ID/severity | Reviewer | Date |
|---|---|---|---|---|---|
| H023 | UNKNOWN | Source-to-target path matrix pending | RISK-001 |  |  |
| H041 | UNKNOWN | Authorizer config and token negative test pending |  |  |  |

## Technical lead final disposition

- **Application / source baseline / target baseline / environment:**
- **Endpoints / business paths / event triggers discovered:**
- **Mapped / approved retired / approved changed / unmapped:**
- **Tests executed (link to run):**
- **P0 / P1 / P2 / P3 open counts; critical UNKNOWN count:**
- **Security and infrastructure review owner:**
- **Contract, architecture and release exception IDs:**
- **Release decision:** APPROVE / APPROVE WITH FORMAL EXCEPTION / REQUEST CHANGES / INSUFFICIENT EVIDENCE
- **Owner signatures and date:**

## Source references and rationale

Borrowed review concepts (not copied checklists verbatim): Google's design/functionality/complexity/test approach; Anthropic's independent specialized reviewers, test and silent-failure checks, confidence-based validation; GitHub's repository-specific review instructions; OWASP ASVS 5.0 validation/business logic/authorization requirements; AWS Serverless Lens and service-specific guidance. Migration-specific traceability, source-of-truth hierarchy, approval gates, cross-component state/side-effect verification and evidence matrices are custom additions.

- Google Engineering Practices: https://google.github.io/eng-practices/review/reviewer/looking-for.html
- Anthropic Code Review Plugin: https://github.com/anthropics/claude-code/blob/main/plugins/code-review/README.md
- Anthropic PR Review Toolkit: https://github.com/anthropics/claude-code/blob/main/plugins/pr-review-toolkit/README.md
- GitHub Copilot Review Instructions: https://docs.github.com/en/copilot/how-tos/copilot-on-github/use-copilot-agents/copilot-code-review
- OWASP ASVS 5.0: https://github.com/OWASP/ASVS/tree/master/5.0/en
- AWS Serverless Applications Lens: https://docs.aws.amazon.com/wellarchitected/latest/serverless-applications-lens/
- AWS Lambda Best Practices: https://docs.aws.amazon.com/lambda/latest/dg/best-practices.html
- AWS Lambda with SQS error handling: https://docs.aws.amazon.com/lambda/latest/dg/services-sqs-errorhandling.html
- Amazon EventBridge DLQs: https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-rule-dlq.html
- MuleSoft Error Handlers: https://docs.mulesoft.com/mule-runtime/latest/error-handling
