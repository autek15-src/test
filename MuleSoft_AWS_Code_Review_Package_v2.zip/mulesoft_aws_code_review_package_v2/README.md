# MuleSoft → AWS Native Code Review Assurance Package

**Version 2.0 | October 12, 2026 | Application-level migration assurance**

This package contains two related deliverables: (1) a human technical-lead review checklist (176 evidence-based checks) and (2) a standalone installable **Claude Code skill** to independently review generated AWS-native applications against MuleSoft source behavior, effective policy/configuration, approved target architecture, deployment IaC and observed tests. It additionally contains a **self-contained HTML dashboard generator** and a synthetic sample review showing expected navigation and output. The skill reviews a whole migrated application, not just a Lambda or pull-request diff.

## Package contents

```text
mulesoft_aws_code_review_package_v2/
├── README.md
├── HUMAN_REVIEW_CHECKLIST.md             # Human technical lead, 176 checks
├── AGENT_REVIEW_INSTRUCTIONS.md         # Standalone detailed review protocol
├── RESEARCH_AND_DESIGN_RATIONALE.md     # Published review practices and sources
├── .claude/skills/
│   └── mulesoft-aws-migration-code-review/
│       ├── SKILL.md                    # Installable skill entrypoint
│       ├── references/
│       │   ├── AGENT_REVIEW_INSTRUCTIONS.md
│       │   └── REPORTING_CONTRACT.md    # Required report schemas/HTML contract
│       ├── assets/templates/           # SEVEN standardized CSV headers
│       └── scripts/
│           ├── init_review.py          # Safe, non-overwriting run scaffolder
│           └── render_review.py        # Offline, searchable HTML dashboard
├── docs/HTML_REPORT_GUIDE.md
├── sample-review-output/              # SYNTHETIC example; not a real assessment
│   ├── 00-review-dashboard.html        # Open in web browser
│   └── 01...16 review artifacts
└── tests/test_report.py                # Smoke / safety / data consistency tests
```

## Install Claude Code skill

Copy the entire **`mulesoft-aws-migration-code-review/`** directory from this package's `.claude/skills/` into either:

- Your project repository's `.claude/skills/mulesoft-aws-migration-code-review/`, for project-specific availability, or
- Your Claude Code user-level skill directory (`~/.claude/skills/mulesoft-aws-migration-code-review/`) for reuse across repos.

**Preserve the entire directory**, including both reference Markdown files, all seven CSV templates and both scripts. Do not copy only `SKILL.md`. The skill wrapper requires reading the full instructions and reporting contract before proceeding. When using Codex or another coding LLM without Claude skills, provide `AGENT_REVIEW_INSTRUCTIONS.md` plus the reporting contract, template schemas and scripts.

## Recommended review invocation

> Use the `mulesoft-aws-migration-code-review` skill to independently review the **entire application**. Review the original MuleSoft source repo at `<mule-sha>` and effective stage/prod configuration/policies, the target code/IaC repo at `<target-sha>`, approved HLD/LLD/ADRs, existing and generated tests, and relevant upstream/downstream integrations. Do not modify implementation code. Create a new unique review run, analyze every source endpoint and reachable business path, perform bidirectional source/target traceability, identify and prove P0–P3 defects and critical unknowns, and produce **all 17 files including the searchable offline HTML report**. Keep all evidence references, execution results, gaps and release gate status traceable.

The agent should ask only for truly missing blocking inputs, then continue reviewing whatever can be proven. A review is not complete merely because files were generated. Code changes, deployments and human release approval require separate explicit authorization.

## Output process (automated inside the skill)

1. **Initialize a new run directory:**

   ```bash
   python .claude/skills/mulesoft-aws-migration-code-review/scripts/init_review.py \
     --output reviews/customer-app/20261012T230000Z-a1b2c3/review-output \
     --application customer-app --environment stage \
     --mule-sha <immutable-mule-sha> --target-sha <immutable-aws-sha>
   ```

2. Agent inventories current and target states, performs independent cross-checks and fills ledgers/narratives with referenced evidence. It reconciles `15-review-summary.json` and records confirmed defects in BOTH `13-findings.md` and `16-findings.csv`.

3. **Generate HTML** after evidence writing:

   ```bash
   python .claude/skills/mulesoft-aws-migration-code-review/scripts/render_review.py \
     --input reviews/customer-app/20261012T230000Z-a1b2c3/review-output
   ```

4. Review `00-review-dashboard.html` in a browser. Review integrity warnings, gates, source/target parity, findings and test evidence. A reviewer should also inspect the raw CSVs and relevant repository lines.

Optional `--strict` returns non-zero when review is not yet a clean, evidenced human-signoff candidate. It never performs cloud changes. Both scripts use **Python standard library only** and need no network access, package installs or external JS/CSS assets.

## HTML dashboard features

- App/environment/revision/review-time identification and executive verdict.
- KPI cards showing discovered Mule endpoints, verified / total business paths, target AWS resource inventory, actual passing tests, active P0/P1 findings and data integrity warnings.
- Release gates, mismatched counts, unknown evidence and open issues.
- Searchable/filterable P0–P3 findings, expandable evidence/impact/remediation/verification details.
- Searchable bidirectional path mapping and test evidence, Mule and AWS inventories.
- Readable contract, policy, error/retries/side effects, NFR/quotas and deploy sections from the detailed audit.
- Sidebar anchor navigation, responsive/print styles, relative downloads of input Markdown/CSV/JSON ledgers.
- Single offline HTML with locally executed JavaScript only. All untrusted data is HTML-escaped. No cloud calls or telemetry.

The **sample** is synthetic and expressly does not reflect a review of a real application. Its two P1 findings and evidence warnings demonstrate blocker presentation.

## What changed from version 1

- Skill now **includes** both authoritative reference documents, CSV schemas and runnable scripts, with no missing out-of-skill path dependencies.
- Added source entrypoint CSV (`03`) and a structured finding CSV (`16`) in addition to 13-findings.md.
- Introduced a safe, versioned run initializer and explicit allowable CSV values / reconciliation rules.
- Added **required `00-review-dashboard.html`**, which renders all detailed chapters and structured ledgers from the actual review output.
- Dashboard flags inconsistent `READY` statuses, missing artifacts, mismatched counts and invalid VERIFIED claims instead of conveying false assurance.
- Expanded human review checks from 168 to 176 with dedicated report and artifact validation section.
- Includes a synthetic sample and automated tests for HTML escaping, missing-data handling, readiness guarding and run immutability.

## Safety and limits

The skill and dashboard do not perform review until the agent is actually provided code/config/design/test evidence. The renderer can validate structural consistency but **cannot prove functional parity itself**. Release remains a human-owned go/no-go decision. Never include real credentials, tokens or unredacted PII in findings or HTML. Treat current AWS quotas as environment/API/region dependent and confirm against current vendor documentation at review time.
