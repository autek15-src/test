# Authentication and authorization

The effective API Manager policy settings are **partially missing**, so `security_policy_parity_verified` remains false. Do not infer target JWT scopes or a pass from a generated API specification.

## Review checklist

- Identify exact issuer and audience.
- Verify per-operation authorization.
- Test missing/invalid/expired JWT and privilege escalation.
