# Error / retry and side-effect matrix

| Flow | Failure | Expected | Risk |
|---|---|---|---|
| Customer lookup | SAP 404 | Consumer 404 | P1 regression |
| Customer refresh | Queue publish timeout | Return retryable failure, no premature 202 | P1 lost event |

The callback must await the side effect to distinguish *accepted* from *completed*.
