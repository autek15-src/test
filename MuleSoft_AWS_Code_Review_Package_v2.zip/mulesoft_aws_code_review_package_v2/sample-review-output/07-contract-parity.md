# API contracts

| API | Mule behavior | AWS behavior | Result |
|---|---|---|---|
| `GET /customers/{id}` success | 200 with customer | 200 with customer | Tested match |
| `GET /customers/{id}` absent | 404 | 500 | **P1 mismatch** |
| `POST /customers/{id}/refresh` publish timeout | 503 | may return 202 | **P1 mismatch** |
