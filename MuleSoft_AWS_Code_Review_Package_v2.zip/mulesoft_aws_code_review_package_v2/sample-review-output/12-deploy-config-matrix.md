# Deployment and environment configuration

| Environment | IaC | Notes |
|---|---|---|
| stage | `infra/*` | Illustrative paths only; actual deployment not observed |
| production | Unknown | IAM and monitoring approvals missing |
