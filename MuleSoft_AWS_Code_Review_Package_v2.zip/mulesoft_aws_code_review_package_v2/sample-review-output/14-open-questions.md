# Open questions and evidence gaps

1. **Critical:** What are the exact stage API Manager policy values (issuer/audience/scopes)? Owner: Security. Decision blocks policy parity.
2. Are there production request-duration and payload-size measurements? Owner: Operations. Prevents NFR validation.
3. Have all downstream team release dependencies been approved? Owner: Application owner.
