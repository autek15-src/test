# Detailed findings

## FND-001 (P1): Customer 404 contract break

Observed in synthetic example at `src/handlers/getCustomer.ts:63-75`; source flow `src/main/mule/customer-api.xml:40-54` maps SAP not-found to 404. Add a source-derived regression test.

## FND-002 (P1): Premature refresh acknowledgement

Synthetic target handler does not await SQS publication. Fix acknowledgement boundary, exercise timeout/failed publish and duplicate tests.
