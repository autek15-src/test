#!/usr/bin/env python3
"""Render an offline, single-file HTML assurance dashboard from an agent review ledger.

Python standard library only. Never reads code repositories or contacts a network.
Usage: python render_review.py --input /path/to/review-output
"""
from __future__ import annotations

import argparse
import csv
import html
import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

CSV_FILES = (
    '02-input-evidence-register.csv',
    '03-source-entrypoints.csv',
    '04-source-business-paths.csv',
    '05-target-components.csv',
    '06-bidirectional-traceability.csv',
    '10-test-coverage.csv',
    '16-findings.csv',
)
REPORT_FILES = (
    '01-executive-review.md', '07-contract-parity.md',
    '08-security-policy-parity.md', '09-error-retry-side-effects.md',
    '11-nfr-quota-assessment.md', '12-deploy-config-matrix.md',
    '13-findings.md', '14-open-questions.md',
)
SUMMARY_FILE = '15-review-summary.json'
OUTPUT_FILE = '00-review-dashboard.html'
GATE_NAMES = {
    'full_scope_inventoried': 'Complete application inventory',
    'consumer_contract_parity_or_approved_exceptions': 'Consumer contracts and approved changes',
    'critical_source_behavior_verified': 'Critical business behavior and tests',
    'security_policy_parity_verified': 'Security / Mule policy parity',
    'deployed_iac_configuration_verified': 'Actual deployable configuration and wiring',
    'retry_idempotency_and_recovery_verified': 'Retries, idempotency, recovery',
    'operational_and_release_readiness_verified': 'Observability, release and rollback',
}
RESOLVED_STATES = {'VERIFIED_FIXED', 'FALSE_POSITIVE', 'CLOSED_VERIFIED'}
PATH_GOOD = {'VERIFIED', 'APPROVED_RETIREMENT'}
FAIL_STATES = {'FAIL', 'FAILED', 'ERROR'}
TEST_PASSED = {'PASS', 'PASSED', 'EXECUTED_PASS', 'SUCCESS'}


def esc(value: object) -> str:
    return html.escape('' if value is None else str(value), quote=True)


def safe_url(url: str) -> str | None:
    """Only render trustworthy web or local artifact links, never arbitrary schemes."""
    if not url or any(c in url for c in '\r\n\x00'):
        return None
    parsed = urlsplit(url)
    if parsed.scheme in ('https', 'http') and parsed.netloc:
        return url
    if not parsed.scheme and not parsed.netloc and not url.startswith(('/', '\\', '#')) and '..' not in Path(parsed.path).parts:
        return url
    return None


def inline_md(value: str) -> str:
    # Escaping first and permitting only Markdown formatting constructed by us
    text = esc(value)
    text = re.sub(r'`([^`]+)`', lambda m: '<code>'+m.group(1)+'</code>', text)
    text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', text)
    return text


def markdown_to_html(source: str) -> str:
    """Conservative Markdown subset. Escapes ALL raw HTML/source text."""
    lines = source.splitlines()
    out = []
    idx = 0
    opened_list = None
    def close_list():
        nonlocal opened_list
        if opened_list:
            out.append(f'</{opened_list}>')
            opened_list = None
    while idx < len(lines):
        line = lines[idx].rstrip()
        if line.startswith('```'):
            close_list()
            lang = esc(line[3:].strip())
            code = []
            idx += 1
            while idx < len(lines) and not lines[idx].startswith('```'):
                code.append(lines[idx]); idx += 1
            out.append(f'<pre><code data-language="{lang}">{esc(chr(10).join(code))}</code></pre>')
        elif not line.strip():
            close_list()
        elif re.match(r'^#{1,5}\s', line):
            close_list()
            level = min(len(line) - len(line.lstrip('#')) + 1, 6)
            out.append(f'<h{level}>{inline_md(line.split(" ", 1)[1])}</h{level}>')
        elif line.startswith('> '):
            close_list()
            out.append('<blockquote>'+inline_md(line[2:])+'</blockquote>')
        elif line.startswith('|') and idx+1 < len(lines) and re.match(r'^\s*\|[ :\-|]+\|\s*$',lines[idx+1]):
            close_list()
            rows = [line]
            idx += 2
            while idx < len(lines) and lines[idx].lstrip().startswith('|'):
                rows.append(lines[idx]); idx+=1
            head = [x.strip() for x in rows[0].strip('|').split('|')]
            out.append('<div class="table-scroll"><table class="mini-table"><thead><tr>'+''.join('<th>'+inline_md(x)+'</th>' for x in head)+'</tr></thead><tbody>')
            for row in rows[1:]:
                vals = [x.strip() for x in row.strip('|').split('|')]
                out.append('<tr>'+''.join('<td>'+inline_md(x)+'</td>' for x in vals)+'</tr>')
            out.append('</tbody></table></div>')
            continue
        elif re.match(r'^\s*[-*] ', line) or re.match(r'^\s*\d+\. ',line):
            kind = 'ol' if re.match(r'^\s*\d+\. ',line) else 'ul'
            if opened_list != kind:
                close_list(); out.append(f'<{kind}>'); opened_list=kind
            content = re.sub(r'^\s*(?:[-*]|\d+\.)\s+', '',line)
            out.append('<li>'+inline_md(content)+'</li>')
        else:
            close_list()
            out.append('<p>'+inline_md(line)+'</p>')
        idx += 1
    close_list()
    return '\n'.join(out)


def read_csv(path: Path, diagnostics: list[str]) -> list[dict[str,str]]:
    if not path.is_file():
        diagnostics.append(f'Missing required CSV: {path.name}')
        return []
    try:
        with path.open('r', encoding='utf-8-sig', newline='') as file:
            rows = list(csv.DictReader(file))
        if rows and any(None in row for row in rows):
            diagnostics.append(f'Column count mismatch in {path.name}')
        return [{str(k): ('' if v is None else str(v)) for k,v in row.items() if k is not None} for row in rows]
    except (UnicodeError, OSError, csv.Error) as error:
        diagnostics.append(f'Cannot parse {path.name}: {type(error).__name__}')
        return []


def read_summary(path: Path, diagnostics: list[str]) -> dict:
    if not path.is_file():
        diagnostics.append('Missing required review summary JSON')
        return {}
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(data,dict):
            raise ValueError('Expected JSON object')
        return data
    except (ValueError, UnicodeError, OSError):
        diagnostics.append('Review summary JSON invalid or unreadable')
        return {}


def status_class(status: str) -> str:
    val=status.upper()
    if val in ('VERIFIED', 'PASS', 'PASSED', 'VERIFIED_FIXED', 'READY_FOR_HUMAN_SIGNOFF'):
        return 'good'
    if val in ('P0','P1','CHANGES_REQUIRED','FAIL','FAILED','MISMATCH','MISSING','OPEN'):
        return 'bad'
    return 'caution'


def pill(value: object, kind: str = '') -> str:
    val=str(value or 'UNVERIFIED')
    return f'<span class="pill {esc(kind or status_class(val))}">{esc(val.replace("_", " "))}</span>'


def csv_table(rows: list[dict[str, str]], columns: list[tuple[str,str]], table_id: str, filter_keys: list[str] | None=None, limit: int=0) -> str:
    # Never silently truncate: all rows are rendered, with CSS horizontal scrolling.
    header='<tr>'+''.join('<th scope="col">'+esc(label)+'</th>' for key,label in columns)+'</tr>'
    cells=[]
    for row in rows:
        attrs=' '.join(f'data-{esc(key.replace("_","-"))}="{esc(row.get(key, "").upper())}"' for key in (filter_keys or []))
        tds=[]
        for key,label in columns:
            val=row.get(key,'')
            content=pill(val) if key in ('severity', 'parity_status', 'executed_status','state', 'availability_status') else esc(val or '—')
            tds.append('<td>'+content+'</td>')
        cells.append(f'<tr class="filter-row" {attrs}>'+''.join(tds)+'</tr>')
    return '<div class="table-scroll"><table id="'+esc(table_id)+'"><thead>'+header+'</thead><tbody>'+''.join(cells)+'</tbody></table></div>'


def search_controls(scope:str, choices: list[tuple[str,str]]|None=None) -> str:
    sels=''
    if choices:
        options=''.join(f'<option value="{esc(k)}">{esc(v)}</option>' for k,v in choices)
        sels=f'<select data-filter-select="{esc(scope)}" aria-label="Filter {esc(scope)}"><option value="">All statuses</option>{options}</select>'
    return f'<div class="filters"><label class="sr-only" for="q-{esc(scope)}">Search {esc(scope)}</label><input id="q-{esc(scope)}" type="search" data-filter-search="{esc(scope)}" placeholder="Search rows…" autocomplete="off" />{sels}<span class="match-count" data-count="{esc(scope)}" aria-live="polite"></span></div>'


def section(key: str,title: str,content: str,kicker: str='') -> str:
    return f'<section id="{esc(key)}" class="panel"><div class="panel-head"><div><p class="kicker">{esc(kicker)}</p><h2>{esc(title)}</h2></div><a class="anchor" href="#{esc(key)}" aria-label="Link to {esc(title)}">#</a></div>{content}</section>'


def render_report(input_dir: Path, output_path: Path) -> tuple[list[str],str]:
    diagnostics=[]
    data={name:read_csv(input_dir/name,diagnostics) for name in CSV_FILES}
    summary=read_summary(input_dir/SUMMARY_FILE,diagnostics)
    for name in REPORT_FILES:
        if not (input_dir/name).is_file():
            diagnostics.append(f'Missing narrative report: {name}')

    rows_source=data['03-source-entrypoints.csv']
    rows_bp=data['04-source-business-paths.csv']
    rows_target=data['05-target-components.csv']
    rows_trace=data['06-bidirectional-traceability.csv']
    rows_find=data['16-findings.csv']
    rows_tests=data['10-test-coverage.csv']
    rows_inputs=data['02-input-evidence-register.csv']
    active_find=[r for r in rows_find if r.get('state','').upper() not in RESOLVED_STATES]
    active_by_sev=Counter(r.get('severity','UNKNOWN').upper() for r in active_find)
    passing_test_ids={r.get('test_id') for r in rows_tests if r.get('executed_status','').upper() in TEST_PASSED}
    verified_bp=set()
    for t in rows_trace:
        if t.get('parity_status','').upper()=='VERIFIED' and t.get('source_bp_id'):
            tests_referenced={v.strip() for v in re.split(r'[;,\s]+', t.get('test_ids','')) if v.strip()}
            has_source_proof=bool(t.get('target_component_ids') and (t.get('target_code_refs') or t.get('target_iac_refs')))
            has_test_proof=bool(t.get('test_execution_evidence') and (tests_referenced & passing_test_ids))
            if has_source_proof and has_test_proof:
                verified_bp.add(t['source_bp_id'])
            else:
                diagnostics.append(f'Unsubstantiated VERIFIED status for path {t["source_bp_id"]}: missing target implementation or passing test evidence')
    mapped_bp={r.get('source_bp_id') for r in rows_trace if r.get('source_bp_id') and r.get('target_component_ids') and r.get('parity_status','').upper() not in ('MISSING','UNMAPPED')}
    all_bp={r.get('source_bp_id') for r in rows_bp if r.get('source_bp_id')}
    approved_retired={r.get('source_bp_id') for r in rows_trace if r.get('source_bp_id') and r.get('parity_status','').upper()=='APPROVED_RETIREMENT' and r.get('approved_design_or_adr')}
    if len(rows_bp) != len(all_bp): diagnostics.append('Duplicate or missing source business path IDs')
    if len({r.get('source_ep_id') for r in rows_source if r.get('source_ep_id')}) != len(rows_source):
        diagnostics.append('Duplicate or missing source entrypoint IDs')
    if len({r.get('finding_id') for r in rows_find if r.get('finding_id')}) != len(rows_find):
        diagnostics.append('Duplicate or missing finding IDs')
    if not rows_bp: diagnostics.append('No source business paths inventoried; cannot assert full migration coverage')
    if not rows_trace: diagnostics.append('No bidirectional traceability entries')
    if not rows_tests: diagnostics.append('No test evidence rows')
    for id in sorted(all_bp - {r.get('source_bp_id') for r in rows_trace}):
        diagnostics.append(f'Source business path not in traceability: {id}')
    for r in rows_trace:
        if r.get('source_bp_id') and r.get('source_bp_id') not in all_bp:
            diagnostics.append(f'Traceability references unknown source business path: {r.get("source_bp_id")}')
    for r in rows_find:
        if not r.get('finding_id') or not r.get('severity') or not r.get('state'):
            diagnostics.append('Findings CSV has missing finding ID, severity or state')
    missing_sources=[r for r in rows_inputs if r.get('availability_status','').upper() in ('MISSING','CONFLICTING','PARTIAL')]
    if missing_sources:
        diagnostics.append(f'{len(missing_sources)} source inputs unavailable, incomplete or conflicting')
    for tr in rows_trace:
        if tr.get('target_component_ids'):
            for target_id in (v.strip() for v in re.split(r'[;,]',tr['target_component_ids']) if v.strip()):
                if target_id not in {r.get('target_component_id') for r in rows_target}:
                    diagnostics.append(f'Traceability references missing AWS inventory component: {target_id}')
    for comp in rows_target:
        c_id=comp.get('target_component_id','')
        if c_id and not any(c_id in {v.strip() for v in re.split(r'[;,]',r.get('target_component_ids',''))} for r in rows_trace):
            diagnostics.append(f'Target component lacks reverse traceability record: {c_id}')
    findings_md = input_dir / '13-findings.md'
    if findings_md.exists():
        markdown_findings=findings_md.read_text(encoding='utf-8',errors='replace')
        for finding in rows_find:
            if finding.get('finding_id') and finding['finding_id'] not in markdown_findings:
                diagnostics.append(f'Finding missing in narrative report: {finding["finding_id"]}')
    declared=summary.get('business_paths',{}) or {}
    if 'discovered' in declared and declared['discovered'] != len(rows_bp):
        diagnostics.append(f'Business paths total mismatch: summary={declared["discovered"]}, rows={len(rows_bp)}')
    if 'verified_with_tests' in declared and declared['verified_with_tests'] != len(verified_bp & all_bp):
        diagnostics.append(f'Verified-with-tests count mismatch: summary={declared["verified_with_tests"]}, demonstrated={len(verified_bp & all_bp)}')
    if 'implemented' in declared and declared['implemented'] != len(mapped_bp & all_bp):
        diagnostics.append(f'Implemented-path count mismatch: summary={declared["implemented"]}, mapped={len(mapped_bp & all_bp)}')
    ep_summary=summary.get('source_entrypoints',{}) or {}
    if 'discovered' in ep_summary and ep_summary['discovered'] != len(rows_source):
        diagnostics.append(f'Source entrypoint count mismatch: summary={ep_summary["discovered"]}, rows={len(rows_source)}')
    for field in ('mule_sha','target_sha'):
        if str(summary.get(field,'')).upper() in ('','NOT_PINNED','UNKNOWN','NONE'):
            diagnostics.append(f'Immutable baseline missing: {field}')
    declared_find=summary.get('findings',{}) or {}
    for severity in ('P0','P1','P2','P3'):
        if severity in declared_find and declared_find[severity] != active_by_sev[severity]:
            diagnostics.append(f'Open {severity} count mismatch: summary={declared_find[severity]}, CSV={active_by_sev[severity]}')
    gates=summary.get('gates',{}) or {}
    failed_gates=[key for key in GATE_NAMES if gates.get(key) is not True]
    critical_unknowns=declared_find.get('critical_unknowns',0)
    if not isinstance(critical_unknowns,int):
        diagnostics.append('Critical unknown count must be an integer'); critical_unknowns=0
    reported_status=summary.get('status','INSUFFICIENT_EVIDENCE')
    risk_block=bool(active_by_sev['P0']+active_by_sev['P1'] or critical_unknowns or failed_gates or diagnostics or summary.get('missing_evidence') or (all_bp - verified_bp - approved_retired))
    ready_claim_invalid=(reported_status=='READY_FOR_HUMAN_SIGNOFF' and risk_block)
    if ready_claim_invalid:
        diagnostics.append('Inconsistent READY verdict: active P0/P1, unknowns, failed gates, or evidence gaps')
    effective_status='ASSURANCE_INCOMPLETE' if ready_claim_invalid else reported_status
    if not summary: effective_status='INSUFFICIENT_EVIDENCE'
    # These are from observed data; distinguish from declarative JSON counts.
    bp_total=len(all_bp)
    bp_ver=len(verified_bp & all_bp)
    pct=f'{(bp_ver/bp_total*100):.0f}%' if bp_total else 'Not assessed'
    test_pass=sum(1 for r in rows_tests if r.get('executed_status','').upper() in TEST_PASSED)
    data_warnings=len(diagnostics)

    title=summary.get('application','Application not provided')
    env=summary.get('target_environment','Unspecified')
    mule_sha=summary.get('mule_sha','Unknown')
    target_sha=summary.get('target_sha','Unknown')
    generated=summary.get('generated_at') or datetime.now(timezone.utc).isoformat(timespec='seconds')
    summary_note=('The generated status is an evidence-based recommendation, never production approval. '
                  'Human owners must make the release decision.')
    disclaimer='<div class="notice"><strong>Review boundary:</strong> '+esc(summary_note)+'</div>'

    stats=''.join([
        f'<div class="metric"><span>Source entrypoints</span><strong>{len(rows_source)}</strong><small>Discovered in scoped baseline</small></div>',
        f'<div class="metric"><span>Business-path parity</span><strong>{bp_ver} / {bp_total}</strong><small>VERIFIED rows · {pct}</small></div>',
        f'<div class="metric"><span>AWS components</span><strong>{len(rows_target)}</strong><small>Including wiring and configuration</small></div>',
        f'<div class="metric"><span>Executed passing tests</span><strong>{test_pass} / {len(rows_tests)}</strong><small>As recorded in test ledger</small></div>',
        f'<div class="metric risk"><span>Active P0 / P1</span><strong>{active_by_sev["P0"]} / {active_by_sev["P1"]}</strong><small>Release-blocking severity</small></div>',
        f'<div class="metric"><span>Evidence issues</span><strong>{len(diagnostics)}</strong><small>Includes data integrity checks</small></div>',
    ])
    hero=f'''<div class="hero" id="overview"><p class="kicker">MIGRATION ASSURANCE · APPLICATION LEVEL</p>
    <h1>{esc(title)}</h1><p class="subtitle">Independent MuleSoft → AWS native implementation review</p>
    <div class="hero-status"><span class="status-caption">Effective assurance status</span>{pill(effective_status)}<span class="status-small">Reported: {esc(reported_status)}</span></div>
    <div class="metadata"><span><b>Environment</b> {esc(env)}</span><span><b>Mule revision</b> <code>{esc(mule_sha)}</code></span><span><b>Target revision</b> <code>{esc(target_sha)}</code></span><span><b>Generated</b> {esc(generated)}</span></div>
    </div><div class="metric-grid">{stats}</div>{disclaimer}'''

    warning_html='<div class="empty">No integrity or evidence warnings detected by the report generator. This is not a substitute for manual validation.</div>'
    if diagnostics:
        warning_html='<div class="alert"><h3>Needs attention: '+str(len(diagnostics))+' warnings</h3><ul>'+''.join('<li>'+esc(x)+'</li>' for x in diagnostics)+'</ul></div>'
    gate_items=''.join(f'<li class="gate"><span class="gate-icon">{"✓" if gates.get(key) is True else "!"}</span><span>{esc(display)}</span>{pill("PASS" if gates.get(key) is True else "UNVERIFIED")}</li>' for key,display in GATE_NAMES.items())
    gate_html='<div class="two-col"><div><h3>Mandatory release gates</h3><ul class="gate-list">'+gate_items+'</ul></div><div><h3>Audit integrity checks</h3>'+warning_html+'</div></div>'

    findings_html=search_controls('findings',[('P0','P0'),('P1','P1'),('P2','P2'),('P3','P3')])
    if rows_find:
        findings_html+='<div class="finding-list">'
        for row in rows_find:
            sev=row.get('severity','UNKNOWN').upper(); state=row.get('state','UNKNOWN')
            f_id=row.get('finding_id','Unidentified')
            def field(name,key):return '<dt>'+esc(name)+'</dt><dd>'+esc(row.get(key,'') or 'Not recorded')+'</dd>'
            fields=''.join(field(n,k) for n,k in [('Trigger','trigger'),('Expected','expected_behavior'),('Observed','observed_behavior'),('Impact','impact'),('Source evidence','source_evidence_refs'),('Target code','target_code_refs'),('Target IaC','target_config_refs'),('Approved design','design_evidence_refs'),('Recommendation','recommended_fix'),('Regression proof','regression_test'),('Owner','owner'),('Exception','exception_id')])
            searchable=' '.join(str(v) for v in row.values())
            findings_html+=f'''<details class="finding filter-row" data-severity="{esc(sev)}" data-search="{esc(searchable.lower())}" id="finding-{esc(f_id)}"><summary><span class="finding-title">{pill(sev)} <strong>{esc(f_id)}</strong> {esc(row.get('title','Untitled finding'))}</span><span class="finding-meta">{pill(state)} {esc(row.get('confidence','UNRATED'))} confidence <span class="chevron">⌄</span></span></summary><dl class="detail-grid">{fields}</dl><div class="finding-footer">Class: {esc(row.get('classification','Not assigned'))} · Affected paths: {esc(row.get('source_bp_ids','Not recorded'))}</div></details>'''
        findings_html+='</div>'
    else: findings_html+='<div class="empty">No findings recorded. This does not establish that review is complete.</div>'

    trace_html=search_controls('trace',[('VERIFIED','Verified'),('MISSING','Missing'),('MISMATCH','Mismatch'),('UNVERIFIED','Unverified'),('APPROVED_CHANGE','Approved change'),('APPROVED_RETIREMENT','Approved retirement')])
    trace_html+=csv_table(rows_trace, [('source_ep_id','Source endpoint'),('source_bp_id','Business path'),('source_behavior','Required behavior'),('target_component_ids','AWS components'),('disposition','Disposition'),('parity_status','Parity'),('test_ids','Test IDs'),('finding_ids','Findings'),('reviewer_notes','Reviewer notes')],'trace-table',['parity_status'])
    tests_html=search_controls('tests',[(x,x.replace('_',' ').title()) for x in ('PASS','FAIL','NOT_RUN','BLOCKED','UNVERIFIED')])
    tests_html+=csv_table(rows_tests,[('test_id','Test'),('source_bp_id','Source path'),('test_type','Type'),('scenario','Scenario'),('test_environment','Environment'),('executed_status','Execution'),('run_id','Run ID'),('evidence_refs','Evidence / CI refs')],'tests-table',['executed_status'])
    inputs_html=csv_table(rows_inputs,[('source_id','Source ID'),('type','Type'),('repository_or_location','Repository / artifact'),('commit_or_version','Version'),('environment','Environment'),('availability_status','Availability'),('limitations','Limitations')],'inputs-table',['availability_status'])
    source_html=csv_table(rows_source,[('source_ep_id','Endpoint ID'),('mule_application','Mule app'),('trigger','Trigger'),('method_or_operation','Method / operation'),('route_or_schedule','Route / schedule'),('source_file_lines','Source evidence'),('config_policy_refs','Policies')],'source-table')
    paths_html=csv_table(rows_bp,[('source_bp_id','Path ID'),('source_ep_id','Parent endpoint'),('scenario','Business scenario'),('branch_preconditions','Branch conditions'),('downstream_operations','Backend operations'),('side_effects','Side effects'),('error_handling','Error behavior')],'paths-table')
    targets_html=csv_table(rows_target,[('target_component_id','Target ID'),('service','AWS service'),('resource_name','Resource'),('trigger','Trigger'),('code_file','Source code'),('configuration_or_iac_file','IaC / config'),('review_status','Review status')],'target-table')
    nav_reports=[('executive','Executive assessment','01-executive-review.md'),('contracts','Consumer contract parity','07-contract-parity.md'),('security','Security and policy parity','08-security-policy-parity.md'),('errors','Errors, retries and side effects','09-error-retry-side-effects.md'),('nfr','Nonfunctional requirements and quotas','11-nfr-quota-assessment.md'),('deployment','Deployment and environments','12-deploy-config-matrix.md'),('narrative-findings','Narrative finding details','13-findings.md'),('questions','Open questions and decisions','14-open-questions.md')]
    blocks=[section('readiness','Release readiness and evidence integrity',gate_html,'DECISION GATES'),
            section('findings','Findings and remediation',findings_html,'P0–P3 · FILTERABLE · EXPAND TO SEE PROOF'),
            section('traceability','Bidirectional business-path traceability',trace_html,'SOURCE BEHAVIOR → TARGET IMPLEMENTATION'),
            section('testing','Test coverage and execution proof',tests_html,'SOURCE-DERIVED TESTS'),
            section('source','MuleSoft endpoint inventory',source_html,'CURRENT STATE'),
            section('paths','Source business-path inventory',paths_html,'MULTIPLE SCENARIOS PER ENDPOINT'),
            section('aws','Target AWS component inventory',targets_html,'TARGET APPLICATION + IAC'),
            section('inputs','Reviewed inputs and evidence provenance',inputs_html,'BASELINES · DOCUMENTS · CONFIG'),
            ]
    for anchor,label,path in nav_reports:
        try: content=(input_dir/path).read_text(encoding='utf-8') if (input_dir/path).is_file() else '*Not reviewed: report missing.*'
        except (OSError,UnicodeError): content='*Unreadable report; evidence missing.*'
        blocks.append(section(anchor,label,'<div class="narrative">'+markdown_to_html(content)+'</div>','DETAILED REVIEW'))
    artifacts=[OUTPUT_FILE,*REPORT_FILES,*CSV_FILES,SUMMARY_FILE]
    artifacts=sorted(set(artifacts))
    artifacts_html='<div class="artifact-grid">'+''.join(f'<a class="artifact" href="{esc(name)}" download><span>{esc(name)}</span><small>{"Available" if name==OUTPUT_FILE or (input_dir/name).is_file() else "MISSING"}</small></a>' for name in artifacts if name==OUTPUT_FILE or (input_dir/name).is_file())+'</div>'
    blocks.append(section('artifacts','Download or inspect underlying review evidence',artifacts_html,'SOURCE ARTIFACTS · LOCAL FILES'))
    nav_items=[('overview','Overview'),('readiness','Readiness'),('findings','Findings'),('traceability','Traceability'),('testing','Tests'),('source','Mule endpoints'),('paths','Business paths'),('aws','AWS inventory'),('inputs','Evidence inputs'),*[(k,t) for k,t,_ in nav_reports],('artifacts','Files')]
    nav=''.join(f'<a href="#{esc(anchor)}">{esc(label)}</a>' for anchor,label in nav_items)
    css=r'''<style>
:root{color-scheme:light;--ink:#1d2939;--muted:#667085;--border:#e4e7ec;--panel:#fff;--wash:#f6f8fb;--nav:#14243a;--nav2:#1a304b;--accent:#146d83;--blue:#125caa;--red:#b42318;--amber:#8b5700;--green:#067647}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--wash);color:var(--ink);font:14px/1.6 -apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif}a{color:#145ea8}a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid #62b5da;outline-offset:2px}.sr-only{position:absolute;left:-9999px}
.sidebar{background:var(--nav);color:#eef5fb;width:256px;position:fixed;inset:0 auto 0 0;overflow-y:auto;padding:30px 17px}.brand{font-weight:750;font-size:17px;line-height:1.3;margin:0 0 7px}.brand-sub{color:#b9d0e5;font-size:12px;margin:0 0 20px}.sidebar nav{display:flex;flex-direction:column;gap:2px}.sidebar a{display:block;padding:8px 11px;border-radius:7px;color:#dae8f3;text-decoration:none;font-size:13px}.sidebar a:hover,.sidebar a.active{background:var(--nav2);color:#fff}.layout{margin-left:256px;max-width:1700px;padding:28px 44px 60px}.hero{background:#fff;padding:32px;border:1px solid var(--border);border-radius:14px;margin-bottom:16px;box-shadow:0 2px 8px #223b5510}.kicker{margin:0 0 6px;color:var(--accent);font-size:11px;font-weight:800;letter-spacing:.11em;text-transform:uppercase}h1{font-size:30px;margin:0;line-height:1.2;letter-spacing:-.6px}.subtitle{color:var(--muted);font-size:15px;margin:8px 0 22px}.metadata{display:flex;flex-wrap:wrap;gap:10px 25px;padding-top:15px;border-top:1px solid var(--border);font-size:12px;color:var(--muted)}.metadata b{color:var(--ink);margin-right:5px}.metadata code{font-size:11px;overflow-wrap:anywhere}.hero-status{display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin:0 0 18px}.status-caption,.status-small{color:var(--muted);font-size:12px}.pill{display:inline-flex;align-items:center;max-width:100%;white-space:normal;line-height:1.2;padding:5px 9px;border-radius:999px;font-weight:750;font-size:11px;letter-spacing:.02em;background:#edf2f8;color:#305779}.pill.good{color:#08623b;background:#dff4e8}.pill.bad{color:#9a1f19;background:#fce8e7}.pill.caution{color:#875b05;background:#fff2d4}
.metric-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:13px;margin:16px 0}.metric{background:var(--panel);border:1px solid var(--border);border-radius:12px;padding:18px 20px;min-width:0}.metric span{color:var(--muted);display:block;font-size:12px}.metric strong{display:block;font-size:27px;line-height:1.2;margin:8px 0 6px;letter-spacing:-.4px}.metric small{color:var(--muted);font-size:11px}.metric.risk{border-top:3px solid var(--red)}.notice{font-size:13px;padding:13px 17px;background:#eef4f9;border:1px solid #d5e3ee;border-radius:10px;margin-bottom:24px}
.panel{background:var(--panel);border:1px solid var(--border);border-radius:13px;margin:20px 0;padding:25px 25px 27px;scroll-margin-top:14px;min-width:0}.panel-head{display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border);padding-bottom:16px;margin-bottom:16px}.panel-head h2{font-size:20px;line-height:1.2;margin:0;letter-spacing:-.3px}.anchor{text-decoration:none;color:#a1afbd;font-weight:bold;font-size:18px}.two-col{display:grid;grid-template-columns:1fr 1fr;gap:26px}.two-col h3{font-size:15px;margin:0 0 10px}.gate-list{list-style:none;margin:0;padding:0}.gate{display:flex;gap:11px;align-items:center;border-bottom:1px solid var(--border);padding:10px 0}.gate>.pill{margin-left:auto;flex-shrink:0}.gate-icon{display:grid;place-items:center;width:23px;height:23px;flex-shrink:0;border-radius:50%;background:#eef1f4;color:#775f1c;font-weight:800}.alert{padding:12px 15px;background:#fff8eb;border:1px solid #efdab7;border-radius:8px;color:#754c00}.alert h3{margin:0}.alert ul{padding-left:19px}.alert li{overflow-wrap:anywhere;margin:4px 0}.empty{padding:18px;border:1px dashed var(--border);border-radius:8px;color:var(--muted)}
.filters{display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap}.filters input,.filters select{border:1px solid #cdd5df;border-radius:7px;font:inherit;padding:9px 11px;background:#fff;max-width:100%}.filters input{min-width:250px;flex:1}.match-count{font-size:12px;color:var(--muted);margin-left:auto}.table-scroll{overflow:auto;border:1px solid var(--border);border-radius:8px}table{border-collapse:collapse;width:100%;min-width:820px;text-align:left;font-size:12px}th{background:#eff3f8;color:#475467;font-weight:750;white-space:nowrap}th,td{vertical-align:top;border-bottom:1px solid var(--border);padding:11px 12px;text-align:left}td{max-width:320px;overflow-wrap:anywhere}tbody tr:nth-child(even){background:#fafbfd}tbody tr:hover{background:#f0f6fd}.mini-table{min-width:600px}.filter-row.hidden{display:none!important}
.finding-list{display:flex;flex-direction:column;gap:9px}.finding{border:1px solid var(--border);border-radius:9px;overflow:hidden}.finding>summary{cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center;gap:20px;padding:15px 16px;background:#fbfcfd}.finding>summary::-webkit-details-marker{display:none}.finding[open]>summary{border-bottom:1px solid var(--border)}.finding-title,.finding-meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.finding-meta{color:var(--muted);font-size:12px;justify-content:flex-end}.detail-grid{padding:16px;display:grid;grid-template-columns:145px 1fr;gap:8px 14px;margin:0;font-size:13px}.detail-grid dt{font-weight:750;color:#475467}.detail-grid dd{margin:0;overflow-wrap:anywhere}.finding-footer{padding:10px 16px;background:#f6f8fb;border-top:1px solid var(--border);color:#596b80;font-size:12px}.chevron{font-size:17px}
.narrative{font-size:13px;line-height:1.75;overflow-wrap:anywhere}.narrative p{margin:9px 0}.narrative h2{font-size:17px;margin:18px 0 7px}.narrative h3{font-size:15px;margin:17px 0 7px}.narrative h4{font-size:14px;margin:14px 0 6px}.narrative pre{white-space:pre-wrap;background:#101e2d;color:#f5f8fa;padding:15px;border-radius:8px;overflow:auto}.narrative code{font-family:Consolas,'Courier New',monospace}.narrative :not(pre)>code{background:#eff2f5;border-radius:3px;padding:1px 3px}.narrative blockquote{border-left:3px solid #a6c5d5;padding:8px 12px;margin:12px 0;color:#556577}.narrative ol,.narrative ul{padding-left:21px}
.artifact-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.artifact{display:flex;align-items:center;justify-content:space-between;gap:13px;padding:12px;border:1px solid var(--border);border-radius:7px;text-decoration:none;font-size:12px;overflow-wrap:anywhere}.artifact:hover{background:#eef5fc}.artifact small{color:var(--muted);flex-shrink:0}.footer{margin:32px 0;text-align:center;font-size:12px;color:var(--muted)}
@media(max-width:1090px){.sidebar{position:static;width:auto;padding:14px 20px}.sidebar nav{flex-direction:row;overflow:auto;white-space:nowrap}.sidebar a{flex-shrink:0}.brand-sub{display:none}.brand{margin-bottom:8px}.layout{margin:0;padding:17px}.two-col{grid-template-columns:1fr}}
@media(max-width:690px){.metric-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.hero{padding:21px}h1{font-size:24px}.panel{padding:16px}.artifact-grid{grid-template-columns:1fr}.detail-grid{grid-template-columns:1fr}.detail-grid dd{padding-bottom:8px}.finding>summary{flex-direction:column;align-items:flex-start}.filters input{min-width:160px}}
@media print{body{background:#fff}.sidebar,.filters,.anchor{display:none!important}.layout{margin:0;max-width:none;padding:0}.panel,.hero,.metric{break-inside:avoid;box-shadow:none}.table-scroll{overflow:visible}table{min-width:0}.finding:not([open]) .detail-grid{display:grid}.footer{display:none}}
</style>'''
    js=r'''<script>
(function(){
  function filterSet(name,container){
    const q=document.querySelector('[data-filter-search="'+name+'"]');
    const sel=document.querySelector('[data-filter-select="'+name+'"]');
    const count=document.querySelector('[data-count="'+name+'"]');
    const entries=Array.from(container.querySelectorAll('.filter-row'));
    function update(){const needle=((q&&q.value)||'').toLocaleLowerCase().trim();const selected=((sel&&sel.value)||'').toUpperCase();let matches=0;
      entries.forEach(row=>{const hay=(row.getAttribute('data-search')||row.textContent).toLocaleLowerCase();const column=name==='findings'?'severity':(name==='trace'?'parity-status':'executed-status');const value=(row.getAttribute('data-'+column)||'').toUpperCase();const yes=(!needle||hay.includes(needle))&&(!selected||value===selected);row.classList.toggle('hidden',!yes);if(yes)matches++;});if(count)count.textContent=matches+' / '+entries.length+' shown';}
    if(q)q.addEventListener('input',update);if(sel)sel.addEventListener('change',update);update();
  }
  filterSet('findings',document.getElementById('findings'));
  filterSet('trace',document.getElementById('traceability'));
  filterSet('tests',document.getElementById('testing'));
  if('IntersectionObserver' in window){const links=Array.from(document.querySelectorAll('.sidebar nav a'));const sections=links.map(a=>document.getElementById(a.hash.slice(1))).filter(Boolean);const observer=new IntersectionObserver(items=>{items.forEach(item=>{if(item.isIntersecting){links.forEach(a=>a.classList.toggle('active',a.hash==='#'+item.target.id));}})},{rootMargin:'-5% 0px -82% 0px'});sections.forEach(s=>observer.observe(s));}
})();
</script>'''
    page=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title>{esc(title)} | Migration Code Review</title>{css}</head>
<body><aside class="sidebar"><div class="brand">MuleSoft → AWS</div><p class="brand-sub">Independent migration code review</p><nav aria-label="Report sections">{nav}</nav></aside>
<main class="layout">{hero}{''.join(blocks)}<p class="footer">Offline, single-file report · No external scripts, styles, fonts or data calls · Release approval remains with accountable humans</p></main>{js}</body></html>'''
    output_path.parent.mkdir(parents=True,exist_ok=True)
    output_path.write_text(page,encoding='utf-8')
    return diagnostics,effective_status


def main()->int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,required=True,help='Review-output directory holding 15 outputs and findings CSV')
    parser.add_argument('--output',type=Path,help='Destination HTML file (default: <input>/00-review-dashboard.html)')
    parser.add_argument('--strict',action='store_true',help='Exit non-zero if missing inputs, contradictions or active release blockers; still writes HTML')
    args=parser.parse_args()
    root=args.input.resolve()
    output=(args.output or root/OUTPUT_FILE).resolve()
    issues,status=render_report(root,output)
    print(f'Created {output} (status={status}, integrity_warnings={len(issues)})')
    for issue in issues[:30]: print('WARN:',issue)
    if len(issues)>30: print(f'... and {len(issues)-30} more warnings')
    if args.strict and (issues or status not in ('READY_FOR_HUMAN_SIGNOFF',)):
        return 2
    return 0

if __name__=='__main__':
    raise SystemExit(main())
