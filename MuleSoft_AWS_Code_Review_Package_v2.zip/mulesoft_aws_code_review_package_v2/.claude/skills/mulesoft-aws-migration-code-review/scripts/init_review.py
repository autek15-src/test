#!/usr/bin/env python3
"""Create a new, non-overwriting review-output folder with versioned CSV headers.

Usage: python init_review.py --output reviews/customer-app/20261012-targetabc/review-output --application customer-app
The initialized artifacts are explicitly NOT REVIEWED; do not treat as an audit.
"""
from __future__ import annotations
import argparse
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

MD_FILES = {
 '01-executive-review.md': 'Executive review',
 '07-contract-parity.md': 'Consumer-facing contract parity',
 '08-security-policy-parity.md': 'Security and policy parity',
 '09-error-retry-side-effects.md': 'Errors, retries and side effects',
 '11-nfr-quota-assessment.md': 'NFR and AWS service quota assessment',
 '12-deploy-config-matrix.md': 'Deploy/configuration matrix',
 '13-findings.md': 'Confirmed findings',
 '14-open-questions.md': 'Open questions and critical unknowns',
}
GATES=['full_scope_inventoried','consumer_contract_parity_or_approved_exceptions','critical_source_behavior_verified','security_policy_parity_verified','deployed_iac_configuration_verified','retry_idempotency_and_recovery_verified','operational_and_release_readiness_verified']

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--output',type=Path,required=True,help='New review-output folder; must not already exist')
 p.add_argument('--application',required=True)
 p.add_argument('--environment',default='NOT_IDENTIFIED')
 p.add_argument('--mule-sha',default='NOT_PINNED')
 p.add_argument('--target-sha',default='NOT_PINNED')
 args=p.parse_args()
 output=args.output.resolve()
 if output.exists():
  p.error('Output folder already exists. Create a unique versioned run folder; previous reviews are immutable.')
 templates=Path(__file__).resolve().parent.parent/'assets/templates'
 required=sorted(templates.glob('*.csv'))
 if len(required)!=7:
  p.error('Expected seven CSV templates next to this script; skill installation is incomplete.')
 output.mkdir(parents=True)
 for tpl in required: shutil.copyfile(tpl,output/tpl.name)
 for name,heading in MD_FILES.items():
  (output/name).write_text(f'# {heading}\n\n**NOT REVIEWED.** This is an initialized placeholder, not evidence of passing checks. Replace with sourced analysis during the review.\n',encoding='utf-8')
 summary={
  'review_version':'2.0', 'application':args.application,'mule_sha':args.mule_sha,
  'target_sha':args.target_sha,'target_environment':args.environment,
  'status':'INSUFFICIENT_EVIDENCE',
  'source_entrypoints':{'discovered':0,'mapped':0,'approved_retired':0,'unresolved':0},
  'business_paths':{'discovered':0,'implemented':0,'verified_with_tests':0,'unresolved':0},
  'findings':{'P0':0,'P1':0,'P2':0,'P3':0,'critical_unknowns':0},
  'gates':{g:False for g in GATES},'executed_tests':[],
  'missing_evidence':['Review has not started. Initial scaffolding only.'],
  'exception_ids':[], 'generated_at':datetime.now(timezone.utc).isoformat(timespec='seconds'),
  'reviewer':'NOT ASSIGNED','report_generation':'NOT_STARTED',
 }
 (output/'15-review-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
 print('Created initialized NOT-REVIEWED artifacts at',output)
 print('Next: populate source and target evidence; then run render_review.py to generate the report.')

if __name__=='__main__': main()
