# Review output contract, CSV schemas, and HTML dashboard

**Version 2.0. Mandatory for every baseline application review and re-review.** This specification complements the full `AGENT_REVIEW_INSTRUCTIONS.md` and must not weaken any of its discovery, comparison, security, test or release-gate requirements.

## 1. Review execution lifecycle

1. Pin immutable source Mule revisions, target revisions, effective per-environment Mule and AWS configuration, approved design revisions, and coverage boundaries. Name the run `<application>/<UTC-run-YYYYMMDDTHHMMSSZ>-<target-shortsha>/review-output/`. Do not reuse old run folders or overwrite evidence from another run.
2. Initialize with `python scripts/init_review.py --output <review-output> --application <name> --environment <env> --mule-sha <full SHA> --target-sha <full SHA>` (script paths relative to installed skill). Creates all seven CSV headers, eight explicitly NOT REVIEWED Markdown placeholders, and one conservative summary JSON. It does not perform a review and **does not create fabricated evidence**.
3. Conduct all stages in the main agent review instructions. Populate the CSV ledgers **incrementally**, retaining stable SRC-EP, SRC-BP, TGT, TEST and FND IDs and exact source/config/design references. Every path must end in verified, approved exception/change/retirement, or an explicitly unresolved status.
4. Generate Markdown narrative reports with findings including severity, confidence, cause, supporting sources, expected/observed behavior, remediation, regression tests, ownership and disposition. Create `16-findings.csv` **in addition** to human-readable `13-findings.md`.
5. **Reconcile** the counts in `15-review-summary.json` against row-level ledgers. Critical UNKNOWNs are counted separately from confirmed P0–P3 findings, and may still block signoff. Do not claim tests ran unless proof exists. Set gates to `true` only when supported.
6. Run `python scripts/render_review.py --input <review-output>` after all ledgers and narratives are saved. Always generate `00-review-dashboard.html`. Inspect diagnostics and repair missing/broken evidence. Re-render after changes. `--strict` is optional for CI and intentionally returns non-zero for anything other than a fully evidenced, clean human-signoff candidate.
7. Deliver **both** the readable HTML and source evidence ledgers. The HTML is generated, not hand-authored: never manually embellish the status or fill missing proof with guesswork. Human reviewers retain release authority.

## 2. Authoritative report files

| Name | Format | Use |
|---|---|---|
| `00-review-dashboard.html` | Offline HTML | **Required** executive navigation, statuses, findings, traces, tests, architecture checks, evidence provenance and detailed review sections |
| `01-executive-review.md` | Markdown | Boundaries, summary, outcomes, blocker list, recommended release decision |
| `02-input-evidence-register.csv` | CSV | Mule/target/design/config/test/neighbor input register, immutable revision and authority |
| `03-source-entrypoints.csv` | CSV | All source endpoints, listeners, schedules and event sources |
| `04-source-business-paths.csv` | CSV | All reachable success/error/branch/scenario paths, transforms and side effects |
| `05-target-components.csv` | CSV | AWS resources, handlers, code, IAM and deployed/IaC configuration references |
| `06-bidirectional-traceability.csv` | CSV | Source → target and target → source/design approved mapping, tests and parity state |
| `07-contract-parity.md` | Markdown | Consumer-visible method/paths/auth/request/response/error comparison |
| `08-security-policy-parity.md` | Markdown | Mule policies mapped to AWS enforcement and negative proof |
| `09-error-retry-side-effects.md` | Markdown | Per path success/failure/timeout/duplicate/replay consequences |
| `10-test-coverage.csv` | CSV | Source-derived tests, environments, results and actual run references |
| `11-nfr-quota-assessment.md` | Markdown | Measured workloads and AWS service constraints/budgets |
| `12-deploy-config-matrix.md` | Markdown | Environment-specific config, IaC, network, DNS, secret references, rollback |
| `13-findings.md` | Markdown | Full analyst-grade explanation of findings and evidence |
| `14-open-questions.md` | Markdown | Unknowns, missing evidence, architecture decisions and owners |
| `15-review-summary.json` | JSON | Structured status, counts, gates, baselines, exceptions and unknowns |
| `16-findings.csv` | CSV | **Required machine-readable** P0–P3 findings used by dashboard search/filter; matches detailed findings IDs |

**All 17 artifacts are required** for a completed full application review (00–16 inclusive). A review started from a stub may contain explicitly incomplete artifacts, but it must never be presented as ready.

## 3. CSV template conventions

Use the exact **seven** header schemas under `assets/templates/`. Each file is UTF-8 with one header, correct CSV quoting and **one logical record per row**. Never paste Markdown tables into CSV, change or translate column names, or make extra columns without an approved schema version. Use `;` to separate multiple traceability IDs in a cell. Use actual relative repo `file:line-range` references, immutable SHAs or supplied evidence IDs, never fabricated source citations. Distinguish unknown from empty/none. Dates should be ISO-8601 with timezone. Store no secrets, PII or unredacted private payloads. Use text not spreadsheets for sensitive exports, and beware formula injection if opening CSVs in Excel.

Expected values:

- `availability_status`: `PRESENT`, `PARTIAL`, `MISSING`, `CONFLICTING`, `NOT_APPLICABLE`.
- `evidence_status`: `VERIFIED`, `PARTIAL`, `UNVERIFIED`, `UNKNOWN`.
- `parity_status` on traceability: `VERIFIED`, `MATCHED_NOT_TESTED`, `MISSING`, `MISMATCH`, `UNVERIFIED`, `APPROVED_CHANGE`, `APPROVED_RETIREMENT`, `TARGET_ONLY_UNAPPROVED`, `NOT_APPLICABLE`.
- `disposition`: `IMPLEMENTED`, `MODIFIED_APPROVED`, `RETIRED_APPROVED`, `MISSING`, `UNRESOLVED`, `TARGET_ONLY_APPROVED`, `TARGET_ONLY_UNAPPROVED`.
- `executed_status`: `PASS`, `FAIL`, `NOT_RUN`, `BLOCKED`, `UNVERIFIED`. Include run time, environment and tangible evidence for `PASS` or `FAIL`.
- `severity`: `P0`, `P1`, `P2`, `P3`. Store critical evidence unknowns in the open-questions register and JSON, not as fictional confirmed defects. A P0/P1 suspicion may be documented as a hypothesis in `14-open-questions.md` pending proof.
- `confidence`: `HIGH`, `MEDIUM`, `LOW`; separate from severity.
- `state`: `OPEN`, `IN_PROGRESS`, `MITIGATED_PENDING_VERIFICATION`, `VERIFIED_FIXED`, `ACCEPTED_EXCEPTION`, `FALSE_POSITIVE`; only independently verified fixes and verified false positives are closed for current-risk counts. Exception is still visible as active risk.

For `VERIFIED` traceability, cite target code and/or deployable IaC, link at least one actual **passing test ID** in `10-test-coverage.csv`, and put the run/test evidence in `test_execution_evidence`. For an approved retirement, cite the exact ADR/approval and consumer disposition. Every target-only route, scheduled task, publish, side effect, or database write must have an explicit reverse traceability record even if no legacy `source_bp_id` exists.

**Never mark a business path VERIFIED solely because generated tests asserted the same generated implementation assumptions.** The underlying expected outcome must be independently derived from source code/config/observations or approved target design.

## 4. JSON summary requirements and reconciliation

Start with the initialized `15-review-summary.json` schema. Populate all keys from verified source documents/ledgers. Set `review_version` to `2.0`, record immutable SHAs, real environment, reviewer/toolchain, UTC timestamp, and full scope. `source_entrypoints.discovered` and `business_paths.discovered` must equal the corresponding CSV row counts; `findings.P0...P3` count *active* CSV findings only (states other than `VERIFIED_FIXED` and `FALSE_POSITIVE`). `business_paths.verified_with_tests` must be supported by passing linked tests, not merely a nonempty test filename.

Gates remain `false` when any materially required behavior, policy, deployment setting, recovery scenario, performance limit or signoff evidence is unknown. Do not mark `READY_FOR_HUMAN_SIGNOFF` if any active P0/P1, critical UNKNOWN, incomplete input or report, unverified critical path, failed gate, contradictory source data, or unknown deployment wiring.

`00-review-dashboard.html` is generated from CSVs + JSON and safely escaped Markdown narratives. It recomputes visible counts for endpoints, business paths, traceability and active severities and **flags mismatches** rather than silently accepting model-supplied summary numbers. It may show `ASSURANCE_INCOMPLETE` instead of an internally inconsistent `READY` claim.

## 5. HTML dashboard requirements

The checked-in renderer provides:

- **Fixed or responsive sidebar** with navigation to overview, gates, findings, traceability, tests, Mule source inventory, AWS components, evidence, contract parity, security, error/retries, NFR/quotas, deployment, open decisions and downloadable artifacts.
- **Executive-level KPI cards** with exact denominators, current P0/P1, and uncertainties. Avoid false 100% when no source paths found.
- **Expandable P0–P3 findings** showing evidence, impact, expected/observed behavior, remediation, regression proof, owners and exceptions.
- **Client-side search/filter** by severity, parity and test status. Human-readable tables with horizontal scrolling for detailed ledgers.
- **Release gates and data-integrity warnings** clearly visible and separated from formal human signoff.
- **Self-contained HTML:** inline CSS and JavaScript, no internet, external fonts/CDNs, trackers, external API calls or embedded secrets. Escapes CSV and Markdown inputs against HTML/script injection.
- **Accessible/responsive and printable layout.** The HTML is a snapshot tied to a particular application, review run, revision and environment, not an up-to-date live AWS monitoring dashboard.
- **Source artifact links** are relative: preserve HTML in the same `review-output` directory as its CSV, JSON and Markdown neighbors.

If Python execution is unavailable, do not claim HTML generated: record a report generation blocker in `14-open-questions.md` and provide Markdown and CSV artifacts, along with the command for a human to render it.

## 6. Example invocation

```bash
# From an installed skill root, use a fresh run directory. Examples only; do not overwrite existing reviews.
python scripts/init_review.py \
  --output /approved/reviews/customer-app/20261012T220000Z-ab12cd/review-output \
  --application customer-app --environment stage \
  --mule-sha 0123456789abcdef --target-sha abcdef0123456789

# Agent populates the 16 source reports/ledgers (01 through 16), then:
python scripts/render_review.py \
  --input /approved/reviews/customer-app/20261012T220000Z-ab12cd/review-output

# Optional in CI. Never use 'strict passed' as production authorization.
python scripts/render_review.py --input /approved/reviews/customer-app/20261012T220000Z-ab12cd/review-output --strict
```

## 7. Explicit limits

Dashboard generation is **not** code analysis. It reports evidence the agent actually produced, with consistency checks; it cannot independently prove upstream/downstream behavior, application logic or actual AWS deployment state. If review outputs are incomplete or misleading, the dashboard remains incomplete or misleading; critical checks should be challenged by a human and an independent pass. No HTML report grants a production release approval.
