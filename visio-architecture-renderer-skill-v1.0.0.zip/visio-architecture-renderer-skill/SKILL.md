---
name: visio-architecture-renderer
description: Render architecture.schema.json, Mermaid, or PlantUML architecture/network diagrams into editable Microsoft Visio VSDX, with optional AWS icons, templates, and stencils.
---

# Visio Architecture Renderer

Use this skill when the user wants an LLM-generated architecture or network diagram converted to editable Microsoft Visio `.vsdx`.

## Inputs

Accept one of:

- canonical JSON matching `schemas/architecture.schema.json`
- Mermaid `.mmd`, `.mermaid`, or Markdown containing a supported Mermaid diagram
- PlantUML `.puml`, `.plantuml`, or `.uml`

Optional user-supplied resources:

- `.vsdx` template
- `.vssx` stencil
- `master-map.json`
- local AWS Architecture Icons directory

## Required workflow

1. Inspect the input and preserve semantic labels, boundaries, protocols, and connections.
2. Prefer JSON as the normalized internal representation. For Mermaid/PlantUML, parse conservatively and do not invent unsupported semantics.
3. Run the renderer. Do **not** manually draw a bitmap and place it inside Visio.
4. Let the optimizer evaluate layout profiles. Prefer the candidate with the fewest crossings and routing fallbacks.
5. When a template is supplied, preserve its existing shapes and use `layout.safeArea` when available to avoid title blocks/reserved areas.
6. When a stencil is supplied, prefer explicit `master-map.json` mappings. Use heuristic master matching only as a fallback.
7. When AWS icons are supplied, use them only for relevant `aws.*` nodes. Do not download or redistribute AWS icon assets unless the user explicitly provides or authorizes them.
8. Always validate the produced VSDX with `scripts/validate_vsdx.py`. If LibreOffice is installed, include `--libreoffice` for an actual open/render smoke test.
9. Review the report. If crossings or route fallbacks are non-zero on a diagram where clarity matters, rerun with a different engine/profile or normalize to JSON and add structural grouping/explicit positions.
10. Return the `.vsdx` plus the JSON quality report when one was requested/generated.

## Commands

```bash
python scripts/render_vsdx.py INPUT -o OUTPUT.vsdx --report OUTPUT.report.json
python scripts/validate_vsdx.py OUTPUT.vsdx --libreoffice
```

Template/stencil example:

```bash
python scripts/render_vsdx.py architecture.json \
  --template corporate-template.vsdx \
  --stencil corporate-shapes.vssx \
  --master-map master-map.json \
  --aws-icons-dir AWS-Architecture-Icons \
  --layout-engine auto \
  --report architecture.report.json \
  -o architecture.vsdx
```

## Quality principles

- Architecture diagrams are read as a flow. Prefer one dominant direction.
- Keep related components together inside meaningful system/cloud/network boundaries.
- Avoid connector crossings before optimizing for compactness.
- Spread fan-in/fan-out ports.
- Prefer orthogonal connectors for network/cloud diagrams.
- Keep edge labels short and place them on long route segments.
- Do not silently drop unresolved nodes or endpoints.
- Do not claim a dense diagram is clean if the quality report shows crossings/fallbacks.

## Completion gate

Before treating the skill package itself as complete, run:

```bash
python scripts/completion_validator.py
```

It must pass unit tests, render all three example input types, structurally validate each VSDX, and perform LibreOffice smoke rendering when LibreOffice is available.
