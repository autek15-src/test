# Templates, stencils, and AWS icons

## Visio template
Pass `--template company-template.vsdx`. The renderer uses the template package as the base and appends generated shapes to the first page, preserving existing template content. Configure `layout.safeArea` in the JSON input to reserve title blocks or headers.

## Visio stencil
Pass `--stencil company-shapes.vssx`. The renderer imports master definitions into the output package and attempts to preserve media relationships used by those masters. Use `scripts/inspect_stencil.py` to list master names.

## Master mapping
Pass `--master-map master-map.json`. Keys are architecture node types or labels, values are stencil/template master names. If no exact mapping exists, a conservative token match is attempted. If no master matches, the renderer falls back to a native generic shape.

## AWS icons
Pass `--aws-icons-dir /path/to/AWS-Architecture-Icons`. The directory is searched recursively using normalized service aliases. PNG assets are embedded directly. SVG and JPEG assets can be rasterized when optional `cairosvg` / Pillow dependencies are installed. AWS icon assets are not included in this package.

Preference order for each node is:

1. mapped or confidently matched Visio master
2. locally supplied AWS icon for `aws.*` node types
3. native generic Visio shape
