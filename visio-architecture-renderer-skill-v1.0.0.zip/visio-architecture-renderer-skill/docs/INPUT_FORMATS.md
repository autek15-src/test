# Input formats

## Canonical JSON
Use `schemas/architecture.schema.json`. JSON is the preferred LLM output because it preserves semantic type, group membership, explicit positions, layout controls, and edge metadata without reverse-engineering diagram syntax.

Important layout fields:

- `layout.engine`: `auto`, `graphviz`, or `layered`. `auto` tries Graphviz `dot` when installed and falls back to the pure-Python layered placer.
- `layout.congestionPenalty`: increases the cost of reusing already occupied routing corridors.
- `layout.profiles`: limits the layout profiles the optimizer evaluates.
- `layout.safeArea`: optional top-left-origin drawing rectangle, in inches, for a supplied Visio template. Use this to avoid title blocks, headers, or reserved corporate-template areas.

## Mermaid
Supported intentionally conservative subset:

- `flowchart` / `graph` LR/RL/TB/TD/BT
- common node declarations
- labeled arrows
- subgraphs
- `architecture-beta` services, groups, membership, and common connectors

Unsupported Mermaid constructs degrade by omission rather than arbitrary interpretation. For complex Mermaid, normalize to JSON and inspect before final rendering.

## PlantUML
Supported subset:

- component, database, queue, cloud, node, actor, rectangle, storage
- common arrows and labels
- `left to right direction` / `top to bottom direction`
- common C4 macros (`Person`, `System`, `Container`, `Rel`, boundaries)
- common AWS macro names such as `Lambda`, `APIGateway`, `RDS`, `S3`, `DynamoDB`, `SQS`, `SNS`, `CloudFront`, and `Route53`

For heavily customized PlantUML macros, normalize to JSON first.
