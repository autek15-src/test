# Visio Architecture Renderer Skill

Render LLM-generated architecture descriptions into **editable Microsoft Visio `.vsdx` files** without requiring Microsoft Visio during generation.

Supported inputs:

- canonical `architecture.schema.json`
- Mermaid `.mmd` / `.mermaid`
- PlantUML `.puml` / `.plantuml`

The renderer creates native Visio shapes, text, orthogonal connector geometry, and glue records. It can optionally use user-supplied AWS icon files, a corporate `.vsdx` template, and `.vssx` stencil masters.

## Quick start

```bash
python -m pip install -e .
arch2visio render examples/aws-target.json -o out.vsdx --report out.report.json
arch2visio validate out.vsdx --libreoffice
```

Or without installing:

```bash
python scripts/render_vsdx.py examples/aws-target.json -o out.vsdx --report out.report.json
python scripts/validate_vsdx.py out.vsdx --libreoffice
```

### Mermaid / PlantUML

```bash
python scripts/render_vsdx.py examples/sample.mmd -o sample-mermaid.vsdx
python scripts/render_vsdx.py examples/sample.puml -o sample-plantuml.vsdx
```

### Corporate template + stencil + AWS icons

```bash
python scripts/render_vsdx.py architecture.json \
  --template corporate-template.vsdx \
  --stencil corporate-shapes.vssx \
  --master-map master-map.json \
  --aws-icons-dir ./AWS-Architecture-Icons \
  --layout-engine auto \
  --report architecture.report.json \
  -o architecture.vsdx
```

See `docs/` for format, layout, template/stencil, and AWS icon details.
