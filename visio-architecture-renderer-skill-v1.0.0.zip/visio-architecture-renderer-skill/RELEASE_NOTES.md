# Release notes - v1.0.0

Initial release of the Visio Architecture Renderer skill.

## Included
- canonical architecture JSON schema
- Mermaid parser
- PlantUML/C4/common AWS macro parser
- automatic Graphviz-or-layered placement
- multiple layout profiles with score-based selection
- obstacle-aware orthogonal routing with congestion penalty
- native editable VSDX shapes, text, polyline connectors, and connector glue records
- optional AWS icon embedding from user-supplied local assets
- optional VSDX template preservation and safe drawing area
- optional VSSX stencil master import and master mapping
- structural VSDX validation and optional LibreOffice open/render smoke test
- Codex/Claude-style `SKILL.md`, CLI/scripts, examples, tests, and completion validator

## Completion status
The release gate renders JSON, Mermaid, and PlantUML examples; validates VSDX package structure and connector references; and performs a LibreOffice smoke render when LibreOffice is present.
