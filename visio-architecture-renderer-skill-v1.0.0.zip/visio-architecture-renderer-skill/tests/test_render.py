from pathlib import Path
import zipfile, tempfile
from visio_arch_renderer.render import render
from visio_arch_renderer.validate import validate_vsdx
ROOT=Path(__file__).resolve().parents[1]
def _render(name):
 td=tempfile.TemporaryDirectory();out=Path(td.name)/(Path(name).stem+'.vsdx');rep=render(ROOT/'examples'/name,out);return td,out,rep
def test_render_json():
 td,out,rep=_render('aws-target.json');assert validate_vsdx(out)['ok'];td.cleanup()
def test_render_mermaid():
 td,out,rep=_render('sample.mmd');assert validate_vsdx(out)['ok'];td.cleanup()
def test_render_puml():
 td,out,rep=_render('sample.puml');assert validate_vsdx(out)['ok'];td.cleanup()
def test_native_connects():
 td,out,rep=_render('aws-target.json')
 with zipfile.ZipFile(out) as z: assert b'<Connect ' in z.read('visio/pages/page1.xml')
 td.cleanup()
