from pathlib import Path
from visio_arch_renderer.parsers import parse_diagram
ROOT=Path(__file__).resolve().parents[1]
def test_json():
 d=parse_diagram(ROOT/'examples/aws-target.json');assert len(d.nodes)==5 and len(d.edges)==4 and len(d.groups)==2
def test_mermaid():
 d=parse_diagram(ROOT/'examples/sample.mmd');assert len(d.nodes)>=5 and len(d.edges)>=4
def test_plantuml():
 d=parse_diagram(ROOT/'examples/sample.puml');assert len(d.nodes)>=5 and len(d.edges)>=4
