from __future__ import annotations
import json, shutil
from pathlib import Path
from .parsers import parse_diagram
from .layout import layout_diagram
from .routing import route_edges
from .quality import score_layout
from .emitter import emit_vsdx

def render(input_path, output_path, *, template=None, stencil=None, master_map=None, aws_icons_dir=None, layout_engine=None, report=None):
    d=parse_diagram(input_path)
    errors=d.validate()
    if errors: raise ValueError('; '.join(errors))
    requested=layout_engine or d.layout.get('engine','auto')
    congestion=float(d.layout.get('congestionPenalty', d.layout.get('congestion_penalty',12.0)))
    profiles=d.layout.get('profiles') or ['compact','balanced','spacious','dense-routing']
    candidates=[]
    for profile in profiles:
        try:
            l=layout_diagram(d,profile,requested); r=route_edges(d,l.boxes,l.group_boxes,congestion_penalty=congestion);score,metrics=score_layout(l,r);candidates.append((score,profile,l,r,metrics))
        except Exception as e:
            candidates.append((1e18,profile,None,None,{'error':str(e)}))
    valid=[x for x in candidates if x[2] is not None]
    if not valid: raise RuntimeError('No layout candidate succeeded: '+json.dumps([x[4] for x in candidates]))
    best=min(valid,key=lambda x:x[0]);_,profile,l,r,metrics=best
    emit_vsdx(d,l,r,output_path,template=template,stencil=stencil,master_map=master_map,aws_icons_dir=aws_icons_dir)
    rep={'input':str(input_path),'output':str(output_path),'selectedProfile':profile,'layoutEngine':l.engine,'metrics':metrics,'candidates':[{'profile':x[1],**x[4]} for x in candidates]}
    if report:Path(report).write_text(json.dumps(rep,indent=2),encoding='utf-8')
    return rep
