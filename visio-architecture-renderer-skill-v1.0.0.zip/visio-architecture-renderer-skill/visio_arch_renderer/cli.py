from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from .render import render
from .validate import validate_vsdx
from .parsers import parse_diagram
from .stencil import inspect_stencil

def main(argv=None):
    ap=argparse.ArgumentParser(prog='arch2visio',description='Render architecture JSON, Mermaid or PlantUML to editable VSDX')
    sp=ap.add_subparsers(dest='cmd')
    r=sp.add_parser('render');r.add_argument('input');r.add_argument('-o','--output',required=True);r.add_argument('--template');r.add_argument('--stencil');r.add_argument('--master-map');r.add_argument('--aws-icons-dir');r.add_argument('--layout-engine',choices=['auto','graphviz','layered']);r.add_argument('--report')
    v=sp.add_parser('validate');v.add_argument('vsdx');v.add_argument('--libreoffice',action='store_true')
    n=sp.add_parser('normalize');n.add_argument('input');n.add_argument('-o','--output',required=True)
    s=sp.add_parser('inspect-stencil');s.add_argument('stencil')
    args=ap.parse_args(argv)
    if not args.cmd:
        # backwards-compatible convenience: arch2visio input -o output is handled by scripts wrapper; CLI requires subcommand
        ap.print_help();return 2
    if args.cmd=='render':
        rep=render(args.input,args.output,template=args.template,stencil=args.stencil,master_map=args.master_map,aws_icons_dir=args.aws_icons_dir,layout_engine=args.layout_engine,report=args.report);print(json.dumps(rep,indent=2));return 0
    if args.cmd=='validate':
        rep=validate_vsdx(args.vsdx,args.libreoffice);print(json.dumps(rep,indent=2));return 0 if rep['ok'] else 1
    if args.cmd=='normalize':
        d=parse_diagram(args.input); data={'title':d.title,'direction':d.direction,'groups':[g.__dict__ for g in d.groups],'nodes':[n.__dict__ for n in d.nodes],'edges':[e.__dict__ for e in d.edges],'layout':d.layout};Path(args.output).write_text(json.dumps(data,indent=2),encoding='utf-8');return 0
    if args.cmd=='inspect-stencil':print(json.dumps(inspect_stencil(args.stencil),indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
