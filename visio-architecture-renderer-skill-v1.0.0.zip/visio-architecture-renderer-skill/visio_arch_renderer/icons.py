from __future__ import annotations
import re
from pathlib import Path

def _norm(s:str)->str:
    return re.sub(r'[^a-z0-9]+','',s.lower().replace('amazon','').replace('aws',''))
ALIASES={
 'apigateway':['apigateway','api gateway'], 'lambda':['lambda'], 'rds':['rds','relationaldatabase'],
 's3':['s3','simplestorageservice'], 'dynamodb':['dynamodb'], 'sqs':['sqs','simplequeueservice'],
 'sns':['sns','simplenotificationservice'], 'cloudfront':['cloudfront'], 'route53':['route53'], 'elb':['elasticloadbalancing','loadbalancer']
}

def find_icon(node_type:str, icon_dir:str|None):
    if not icon_dir:return None
    root=Path(icon_dir)
    if not root.exists():return None
    key=_norm(node_type.split('.')[-1])
    terms=[key]+[_norm(x) for x in ALIASES.get(key,[])]
    candidates=[]
    for p in root.rglob('*'):
        if p.suffix.lower() not in {'.png','.svg','.jpg','.jpeg'}:continue
        np=_norm(p.stem)
        score=max((len(t) for t in terms if t and (t in np or np in t)),default=0)
        if score:candidates.append((score, -len(str(p)), p))
    return max(candidates)[2] if candidates else None

def icon_to_png(path:Path)->bytes|None:
    ext=path.suffix.lower()
    if ext=='.png':return path.read_bytes()
    try:
        if ext=='.svg':
            import cairosvg
            return cairosvg.svg2png(bytestring=path.read_bytes(),output_width=128,output_height=128)
        from PIL import Image
        import io
        im=Image.open(path); out=io.BytesIO(); im.save(out,format='PNG'); return out.getvalue()
    except Exception:return None
