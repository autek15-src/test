from __future__ import annotations
import json, re, shutil, subprocess, tempfile, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
V='http://schemas.microsoft.com/office/visio/2012/main';REL='http://schemas.openxmlformats.org/package/2006/relationships'

def validate_vsdx(path, libreoffice=False):
    path=Path(path); errors=[]; warnings=[]; stats={}
    if not path.exists():return {'ok':False,'errors':['file not found'],'warnings':[],'stats':{}}
    try:
        with zipfile.ZipFile(path) as z:
            names=set(z.namelist());required={'[Content_Types].xml','_rels/.rels','visio/document.xml','visio/pages/pages.xml','visio/pages/_rels/pages.xml.rels'}
            for r in required:
                if r not in names:errors.append('missing '+r)
            bad=z.testzip()
            if bad:errors.append('CRC failure '+bad)
            for n in names:
                if n.endswith('.xml') or n.endswith('.rels'):
                    try:ET.fromstring(z.read(n))
                    except Exception as e:errors.append(f'invalid XML {n}: {e}')
            pages=[n for n in names if re.fullmatch(r'visio/pages/page\d+\.xml',n)]
            stats['pages']=len(pages);stats['media']=len([n for n in names if n.startswith('visio/media/')])
            shapes=connects=0
            for p in pages:
                root=ET.fromstring(z.read(p)); sh=root.findall(f'.//{{{V}}}Shape'); shapes+=len(sh); ids={s.get('ID') for s in sh}
                for c in root.findall(f'.//{{{V}}}Connect'):
                    connects+=1
                    if c.get('FromSheet') not in ids:errors.append(f'{p}: Connect FromSheet {c.get("FromSheet")} missing')
                    if c.get('ToSheet') not in ids:errors.append(f'{p}: Connect ToSheet {c.get("ToSheet")} missing')
            stats['shapes']=shapes;stats['connects']=connects
    except zipfile.BadZipFile as e:errors.append('not a valid ZIP/VSDX: '+str(e))
    if libreoffice and not errors:
        lo=shutil.which('libreoffice')
        if lo:
            with tempfile.TemporaryDirectory() as td:
                p=subprocess.run([lo,'--headless','--convert-to','pdf','--outdir',td,str(path)],capture_output=True,text=True,timeout=60)
                pdf=Path(td)/(path.stem+'.pdf')
                if p.returncode!=0 or not pdf.exists() or pdf.stat().st_size<500: errors.append('LibreOffice could not render VSDX: '+(p.stderr or p.stdout).strip())
                else:stats['libreofficePdfBytes']=pdf.stat().st_size
        else:warnings.append('LibreOffice not installed; smoke test skipped')
    return {'ok':not errors,'errors':errors,'warnings':warnings,'stats':stats}
