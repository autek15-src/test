from __future__ import annotations
import re
from pathlib import Path
from ..model import Diagram, Node, Group, Edge

ALIAS = r"[A-Za-z_][A-Za-z0-9_.:-]*"

def parse_plantuml(path: str | Path) -> Diagram:
    text = Path(path).read_text(encoding="utf-8")
    d = Diagram(title=Path(path).stem)
    if re.search(r"left\s+to\s+right\s+direction", text, re.I): d.direction="LR"
    elif re.search(r"top\s+to\s+bottom\s+direction", text, re.I): d.direction="TB"
    aliases: dict[str,str] = {}
    group_stack: list[str] = []
    for raw in text.splitlines():
        line=raw.strip()
        if not line or line.startswith("'") or line.startswith("@") or line.startswith("!"): continue
        # C4 group / boundaries
        bm = re.match(r'(?:System_Boundary|Container_Boundary|Boundary)\s*\(\s*([^,]+),\s*"([^"]+)"', line)
        if bm:
            gid,label=bm.groups(); gid=gid.strip(); d.groups.append(Group(gid,label,"boundary",group_stack[-1] if group_stack else None)); group_stack.append(gid); continue
        if line == "}":
            if group_stack: group_stack.pop()
            continue
        # C4/AWS macros: Person(id,"label"...), System(id,"label"), Lambda(id,"label"...)
        mm = re.match(rf'([A-Za-z_][A-Za-z0-9_]*)\s*\(\s*({ALIAS})\s*,\s*"([^"]+)"', line)
        if mm and mm.group(1) not in {"Rel","Rel_R","Rel_L","Rel_U","Rel_D"}:
            macro,nid,label=mm.groups(); ntype=_macro_type(macro); _add(d,nid,label,ntype,group_stack[-1] if group_stack else None); aliases[nid]=nid; continue
        # Standard component/database/cloud syntax
        sm = re.match(r'(?P<kind>component|database|queue|cloud|node|actor|rectangle|storage)\s+(?:"(?P<label>[^"]+)"|(?P<label2>\S+))(?:\s+as\s+(?P<id>'+ALIAS+r'))?', line, re.I)
        if sm:
            label=sm.group('label') or sm.group('label2'); nid=sm.group('id') or _slug(label); _add(d,nid,label,sm.group('kind').lower(),group_stack[-1] if group_stack else None); aliases[nid]=nid; continue
        rm = re.match(r'(?:Rel|Rel_R|Rel_L|Rel_U|Rel_D)\s*\(\s*([^,]+),\s*([^,]+),\s*"([^"]*)"', line)
        if rm:
            s,t,label=(x.strip() for x in rm.groups()); _add(d,s,s); _add(d,t,t); d.edges.append(Edge(s,t,label)); continue
        em = re.match(rf'({ALIAS})\s*([-.=]*<?[-.=>]+)\s*({ALIAS})(?:\s*:\s*(.*))?$', line)
        if em:
            s,arrow,t,label=em.groups(); _add(d,s,s); _add(d,t,t); d.edges.append(Edge(s,t,(label or '').strip(),"dashed" if '.' in arrow else "solid", '<' in arrow and '>' in arrow)); continue
    return d

def _macro_type(macro:str)->str:
    m=macro.lower()
    aws = {"lambda":"aws.lambda","apigateway":"aws.api_gateway","rds":"aws.rds","s3":"aws.s3","dynamodb":"aws.dynamodb","sqs":"aws.sqs","sns":"aws.sns","cloudfront":"aws.cloudfront","route53":"aws.route53","elasticloadbalancing":"aws.elb"}
    if m in aws: return aws[m]
    if m.startswith("person"): return "person"
    if "database" in m: return "database"
    if m.startswith("container"): return "container"
    if m.startswith("system"): return "system"
    return macro

def _add(d,nid,label,ntype="component",group=None):
    if not any(n.id==nid for n in d.nodes): d.nodes.append(Node(nid,label,ntype,group=group))

def _slug(s): return re.sub(r'\W+','_',s).strip('_') or 'node'
