from __future__ import annotations
import html, io, math, re, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
from .model import Diagram
from .layout import LayoutResult, Box
from .routing import Route
from .icons import find_icon, icon_to_png
from .stencil import inspect_stencil, import_stencil_into_package, load_master_map, choose_master

V='http://schemas.microsoft.com/office/visio/2012/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
CT='http://schemas.openxmlformats.org/package/2006/content-types'
ET.register_namespace('',V);ET.register_namespace('r',R)
PX=96.0

def emit_vsdx(diagram:Diagram, layout:LayoutResult, routes:dict[int,Route], out_path:str|Path, *, template=None, stencil=None, master_map=None, aws_icons_dir=None):
    pkg=_load_pkg(template) if template else _new_pkg(layout.width/PX,layout.height/PX)
    if stencil:
        import_stencil_into_package(pkg,stencil)
    masters=_package_masters(pkg)
    mapping=load_master_map(master_map)
    page_name=_first_page_part(pkg)
    page=ET.fromstring(pkg[page_name])
    shapes=page.find(f'{{{V}}}Shapes')
    if shapes is None: shapes=ET.SubElement(page,f'{{{V}}}Shapes')
    connects=page.find(f'{{{V}}}Connects')
    if connects is None: connects=ET.SubElement(page,f'{{{V}}}Connects')
    maxid=max([int(s.get('ID','0')) for s in shapes.findall(f'{{{V}}}Shape')]+[0]); sid=maxid+1
    page_w,page_h=_page_size(pkg)
    transform=_fit_transform(diagram,layout,page_w,page_h,template is not None)
    relpart=_rels_name(page_name); relroot=ET.fromstring(pkg.get(relpart,_empty_rels()))
    next_rid=max([_ridnum(x.get('Id','')) for x in relroot]+[0])+1
    node_shape_ids={}
    # groups first
    group_by_id={g.id:g for g in diagram.groups}
    for g in diagram.groups:
        b=layout.group_boxes.get(g.id)
        if not b:continue
        x,y,w,h=_tb(b,transform)
        s=_rect_shape(sid,x,y,w,h,page_h,fill=_group_fill(g.type),stroke=_group_stroke(g.type),fill_trans=.90,rounding=.08); shapes.append(s); sid+=1
        # top-left label independent from group shape
        shapes.append(_text_shape(sid,x+.10,y+.06,max(1.2,w-.2),.30,page_h,g.label,9.0,bold=True,color=_group_stroke(g.type),halign=0)); sid+=1
    # nodes
    for n in diagram.nodes:
        b=layout.boxes[n.id]; x,y,w,h=_tb(b,transform)
        mid=choose_master(n.type,n.label,masters,mapping) if masters else None
        if mid is not None:
            s=_master_shape(sid,mid,x,y,w,h,page_h,n.label); shapes.append(s); node_shape_ids[n.id]=sid; sid+=1
        else:
            fill,stroke=_node_style(n.type)
            s=_rect_shape(sid,x,y,w,h,page_h,fill=fill,stroke=stroke,rounding=.08,text=""); shapes.append(s); node_shape_ids[n.id]=sid; sid+=1
            icon=find_icon(n.type,aws_icons_dir) if n.type.lower().startswith('aws.') else None
            png=icon_to_png(icon) if icon else None
            if png:
                fname=_unique_media(pkg,f'icon_{_slug(n.id)}.png'); pkg['visio/media/'+fname]=png
                rid=f'rId{next_rid}';next_rid+=1
                ET.SubElement(relroot,f'{{{REL}}}Relationship',{'Id':rid,'Type':R+'/image','Target':'../media/'+fname})
                iw=min(.46*w,.56*h); ih=iw
                shapes.append(_image_shape(sid,x+.10,y+(h-ih)/2,iw,ih,page_h,rid));sid+=1
                shapes.append(_text_shape(sid,x+iw+.20,y+.05,max(.4,w-iw-.30),h-.10,page_h,n.label,9.5,bold=False,halign=0));sid+=1
            else:
                shapes.append(_text_shape(sid,x+.08,y+.05,max(.3,w-.16),h-.10,page_h,n.label,9.5,bold=False));sid+=1
    # connectors and labels
    for idx,e in enumerate(diagram.edges):
        r=routes.get(idx)
        if not r or len(r.points)<2:continue
        pts=[_p(p,transform) for p in r.points]
        conn_id=sid; shapes.append(_connector_shape(conn_id,pts,page_h,e.style,e.bidirectional));sid+=1
        if e.source in node_shape_ids:
            ET.SubElement(connects,f'{{{V}}}Connect',{'FromSheet':str(conn_id),'FromCell':'BeginX','FromPart':'9','ToSheet':str(node_shape_ids[e.source]),'ToCell':'PinX','ToPart':'3'})
        if e.target in node_shape_ids:
            ET.SubElement(connects,f'{{{V}}}Connect',{'FromSheet':str(conn_id),'FromCell':'EndX','FromPart':'12','ToSheet':str(node_shape_ids[e.target]),'ToCell':'PinX','ToPart':'3'})
        if e.label:
            lx,ly=_label_point(pts); shapes.append(_text_shape(sid,lx-.50,ly-.16,1.0,.32,page_h,e.label,7.5,fill='#FFFFFF',fill_trans=.12));sid+=1
    # remove empty connects for neatness
    if len(connects)==0: page.remove(connects)
    pkg[page_name]=ET.tostring(page,encoding='utf-8',xml_declaration=True)
    pkg[relpart]=ET.tostring(relroot,encoding='utf-8',xml_declaration=True)
    _ensure_png_content_type(pkg)
    _write_pkg(pkg,out_path)

def _fit_transform(diagram,layout,page_w,page_h,has_template):
    # safeArea is top-left oriented inches: x,y,width,height
    safe=diagram.layout.get('safeArea') or diagram.layout.get('safe_area')
    if safe:
        ax=float(safe.get('x',.45)); ay=float(safe.get('y',.45)); aw=float(safe.get('width',page_w-ax-.45)); ah=float(safe.get('height',page_h-ay-.45))
    elif has_template:
        ax=ay=.45; aw=max(1,page_w-.90); ah=max(1,page_h-.90)
    else:
        ax=ay=.15; aw=max(1,page_w-.30); ah=max(1,page_h-.30)
    scale=min((aw*PX)/max(layout.width,1),(ah*PX)/max(layout.height,1),1.0 if not has_template else 99)
    usedw=layout.width*scale/PX; usedh=layout.height*scale/PX
    ox=ax+(aw-usedw)/2; oy=ay+(ah-usedh)/2
    return (scale,ox,oy)
def _tb(b,t):
    s,ox,oy=t;return ox+b.x*s/PX,oy+b.y*s/PX,b.w*s/PX,b.h*s/PX
def _p(p,t):
    s,ox,oy=t;return ox+p[0]*s/PX,oy+p[1]*s/PX

def _rect_shape(sid,x,top,w,h,page_h,*,fill='#FFFFFF',stroke='#5B6470',fill_trans=0,rounding=0,text=''):
    pinx=x+w/2;piny=page_h-(top+h/2)
    sh=ET.Element(f'{{{V}}}Shape',{'ID':str(sid),'Type':'Shape','LineStyle':'0','FillStyle':'0','TextStyle':'0'})
    _cell(sh,'PinX',pinx);_cell(sh,'PinY',piny);_cell(sh,'Width',w);_cell(sh,'Height',h);_cell(sh,'LocPinX',w/2);_cell(sh,'LocPinY',h/2);_cell(sh,'Angle',0)
    _cell(sh,'FillForegnd',fill);_cell(sh,'FillPattern',1);_cell(sh,'FillForegndTrans',fill_trans);_cell(sh,'LineColor',stroke);_cell(sh,'LineWeight',.012);_cell(sh,'Rounding',rounding)
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'});_geom_rect(sec)
    if text: ET.SubElement(sh,f'{{{V}}}Text').text=text
    return sh

def _master_shape(sid,mid,x,top,w,h,page_h,text):
    pinx=x+w/2;piny=page_h-(top+h/2); sh=ET.Element(f'{{{V}}}Shape',{'ID':str(sid),'Type':'Shape','Master':str(mid)})
    for n,v in [('PinX',pinx),('PinY',piny),('Width',w),('Height',h),('LocPinX',w/2),('LocPinY',h/2),('Angle',0)]:_cell(sh,n,v)
    ET.SubElement(sh,f'{{{V}}}Text').text=text;return sh

def _image_shape(sid,x,top,w,h,page_h,rid):
    sh=ET.Element(f'{{{V}}}Shape',{'ID':str(sid),'Type':'Foreign'});pinx=x+w/2;piny=page_h-(top+h/2)
    for n,v in [('PinX',pinx),('PinY',piny),('Width',w),('Height',h),('LocPinX',w/2),('LocPinY',h/2),('ImgOffsetX',0),('ImgOffsetY',0),('ImgWidth',w),('ImgHeight',h)]:_cell(sh,n,v)
    fd=ET.SubElement(sh,f'{{{V}}}ForeignData',{'ForeignType':'Bitmap'});ET.SubElement(fd,f'{{{V}}}Rel',{f'{{{R}}}id':rid});return sh

def _text_shape(sid,x,top,w,h,page_h,text,size,bold=False,color='#20262E',halign=1,fill=None,fill_trans=0):
    sh=_rect_shape(sid,x,top,w,h,page_h,fill=fill or '#FFFFFF',stroke='#FFFFFF',fill_trans=(1 if fill is None else fill_trans),text='')
    _cell(sh,'LinePattern',0); ET.SubElement(sh,f'{{{V}}}Text').text=text
    ch=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Character'});row=ET.SubElement(ch,f'{{{V}}}Row',{'IX':'0'});_cell(row,'Color',color);_cell(row,'Size',size/72);_cell(row,'Style',1 if bold else 0)
    pa=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Paragraph'});row=ET.SubElement(pa,f'{{{V}}}Row',{'IX':'0'});_cell(row,'HorzAlign',halign)
    return sh

def _connector_shape(sid,pts,page_h,style,bidirectional):
    x0,y0=pts[0];x1,y1=pts[-1]; minx=min(x for x,y in pts); miny=min(y for x,y in pts); maxx=max(x for x,y in pts); maxy=max(y for x,y in pts)
    w=max(maxx-minx,.001);h=max(maxy-miny,.001);pinx=minx;piny=page_h-miny
    sh=ET.Element(f'{{{V}}}Shape',{'ID':str(sid),'Type':'Shape','LineStyle':'0','FillStyle':'0','TextStyle':'0'})
    for n,v in [('PinX',pinx),('PinY',piny),('Width',w),('Height',h),('LocPinX',0),('LocPinY',0),('BeginX',x0),('BeginY',page_h-y0),('EndX',x1),('EndY',page_h-y1)]:_cell(sh,n,v)
    _cell(sh,'FillPattern',0);_cell(sh,'LineColor','#59636E');_cell(sh,'LineWeight',.012);_cell(sh,'LinePattern',2 if style=='dashed' else 1);_cell(sh,'BeginArrow',4 if bidirectional else 0);_cell(sh,'EndArrow',4);_cell(sh,'BeginArrowSize',2);_cell(sh,'EndArrowSize',2)
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'})
    for i,(x,y) in enumerate(pts):
        row=ET.SubElement(sec,f'{{{V}}}Row',{'T':'MoveTo' if i==0 else 'LineTo','IX':str(i+1)});_cell(row,'X',x-minx);_cell(row,'Y',(maxy-y))
    return sh

def _cell(parent,n,v):ET.SubElement(parent,f'{{{V}}}Cell',{'N':n,'V':_fmt(v)})
def _fmt(v):return str(v) if isinstance(v,str) else f'{float(v):.6f}'.rstrip('0').rstrip('.')
def _geom_rect(sec):
    for i,(t,x,y) in enumerate([('RelMoveTo',0,0),('RelLineTo',1,0),('RelLineTo',1,1),('RelLineTo',0,1),('RelLineTo',0,0)],1):
        r=ET.SubElement(sec,f'{{{V}}}Row',{'T':t,'IX':str(i)});_cell(r,'X',x);_cell(r,'Y',y)
def _label_point(pts):
    # midpoint of longest segment
    seg=max(zip(pts,pts[1:]),key=lambda ab:abs(ab[0][0]-ab[1][0])+abs(ab[0][1]-ab[1][1]));return ((seg[0][0]+seg[1][0])/2,(seg[0][1]+seg[1][1])/2)
def _node_style(t):
    s=t.lower()
    if s.startswith('aws.'):return '#FFF7EC','#D86613'
    if 'database' in s or s.endswith('.rds') or 'dynamo' in s:return '#F3F0FF','#5F48A8'
    if 'person' in s or 'actor' in s:return '#F4F6F8','#56616B'
    if 'external' in s:return '#F4F6F8','#77818A'
    return '#EEF5FB','#3C78A8'
def _group_fill(t):return '#F5F7F9'
def _group_stroke(t): return '#D86613' if 'aws' in t.lower() else '#8A949E'
def _slug(s):return re.sub(r'[^a-zA-Z0-9_-]+','_',s)

def _new_pkg(page_w,page_h):
    page_w=max(5.0,page_w);page_h=max(3.5,page_h)
    return {
      '[Content_Types].xml':_ct_xml(), '_rels/.rels':_root_rels(), 'visio/document.xml':_doc_xml(), 'visio/_rels/document.xml.rels':_doc_rels(),
      'visio/pages/pages.xml':_pages_xml(page_w,page_h), 'visio/pages/_rels/pages.xml.rels':_pages_rels(), 'visio/pages/page1.xml':_page_xml(),
      'docProps/app.xml':_app_xml(), 'docProps/core.xml':_core_xml()
    }
def _load_pkg(path):
    with zipfile.ZipFile(path) as z:return {n:z.read(n) for n in z.namelist()}
def _write_pkg(pkg,out):
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in pkg.items():z.writestr(n,b)
def _first_page_part(pkg):
    # Follow pages rel if possible; otherwise first page*.xml.
    return sorted([n for n in pkg if re.fullmatch(r'visio/pages/page\d+\.xml',n)])[0]
def _page_size(pkg):
    root=ET.fromstring(pkg['visio/pages/pages.xml']);p=root.find(f'{{{V}}}Page');ps=p.find(f'{{{V}}}PageSheet'); vals={c.get('N'):float(c.get('V')) for c in ps.findall(f'{{{V}}}Cell') if c.get('N') in {'PageWidth','PageHeight'}};return vals.get('PageWidth',11),vals.get('PageHeight',8.5)
def _package_masters(pkg):
    if 'visio/masters/masters.xml' not in pkg:return {}
    root=ET.fromstring(pkg['visio/masters/masters.xml']);return {m.get('NameU') or m.get('Name') or str(m.get('ID')):int(m.get('ID')) for m in root.findall(f'{{{V}}}Master')}
def _rels_name(page):
    p=Path(page);return str(p.parent/'_rels'/(p.name+'.rels')).replace('\\','/')
def _empty_rels():return b'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>'
def _ridnum(s):
    m=re.search(r'(\d+)$',s);return int(m.group(1)) if m else 0
def _unique_media(pkg,name):
    stem=Path(name).stem;suf=Path(name).suffix;out=name;i=2
    while 'visio/media/'+out in pkg:out=f'{stem}_{i}{suf}';i+=1
    return out

def _ensure_png_content_type(pkg):
    root=ET.fromstring(pkg['[Content_Types].xml']);existing={(x.get('Extension'),x.get('ContentType')) for x in root.findall(f'{{{CT}}}Default')}
    if any(n.lower().endswith('.png') for n in pkg) and ('png','image/png') not in existing:ET.SubElement(root,f'{{{CT}}}Default',{'Extension':'png','ContentType':'image/png'})
    pkg['[Content_Types].xml']=ET.tostring(root,encoding='utf-8',xml_declaration=True)
def _ct_xml():return f'''<?xml version="1.0" encoding="UTF-8"?><Types xmlns="{CT}"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/visio/document.xml" ContentType="application/vnd.ms-visio.drawing.main+xml"/><Override PartName="/visio/pages/pages.xml" ContentType="application/vnd.ms-visio.pages+xml"/><Override PartName="/visio/pages/page1.xml" ContentType="application/vnd.ms-visio.page+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>'''.encode()
def _root_rels():return f'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="{REL}"><Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/document" Target="visio/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>'''.encode()
def _doc_xml():return f'''<?xml version="1.0" encoding="UTF-8"?><VisioDocument xmlns="{V}" xmlns:r="{R}"><DocumentSettings DefaultTextStyle="0" DefaultLineStyle="0" DefaultFillStyle="0"><GlueSettings>9</GlueSettings><SnapSettings>65847</SnapSettings></DocumentSettings></VisioDocument>'''.encode()
def _doc_rels():return f'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="{REL}"><Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/pages" Target="pages/pages.xml"/></Relationships>'''.encode()
def _pages_xml(w,h):return f'''<?xml version="1.0" encoding="UTF-8"?><Pages xmlns="{V}" xmlns:r="{R}"><Page ID="0" Name="Generated Architecture" NameU="Generated Architecture"><PageSheet><Cell N="PageWidth" V="{w}"/><Cell N="PageHeight" V="{h}"/><Cell N="PageScale" V="1"/><Cell N="DrawingScale" V="1"/><Cell N="DrawingSizeType" V="3"/></PageSheet><Rel r:id="rId1"/></Page></Pages>'''.encode()
def _pages_rels():return f'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="{REL}"><Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/page" Target="page1.xml"/></Relationships>'''.encode()
def _page_xml():return f'''<?xml version="1.0" encoding="UTF-8"?><PageContents xmlns="{V}" xmlns:r="{R}"><Shapes/></PageContents>'''.encode()
def _app_xml():return b'''<?xml version="1.0" encoding="UTF-8"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Visio Architecture Renderer</Application></Properties>'''
def _core_xml():return b'''<?xml version="1.0" encoding="UTF-8"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:creator>Visio Architecture Renderer</dc:creator></cp:coreProperties>'''
