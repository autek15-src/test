# Third-party notices

This implementation was designed after reviewing several permissively licensed VSDX emitters. It does not bundle their repositories or AWS icon assets, but reuses general implementation techniques such as Open Packaging Convention structure, Visio coordinate transforms, native geometry cells, connector glue records, and media relationships.

## archdiagram
- Repository: https://github.com/bharathgnana/archdiagram
- License: MIT
- Copyright (c) 2026 Bharath Adapa

## svgtovisio
- Repository: https://github.com/McMarius11/svgtovisio
- License: MIT
- Copyright (c) 2026 McMarius11

## cytoscape-vsdx
- Repository: https://github.com/ShanteshSindgi/cytoscape-vsdx
- npm package declares license: MIT

## AWS Architecture Icons
AWS Architecture Icons are not included in this package. If the user supplies AWS icons, the renderer can embed them. Users are responsible for complying with AWS trademark/icon usage terms.


## OfficeIMO.Visio
- Repository: https://github.com/EvotecIT/OfficeIMO
- License: MIT
- Copyright (c) 2022 Evotec
- This package adapts the first-party OfficeIMO.Visio Architecture, Network, Infrastructure, Cloud, Security/Identity, Containers/Kubernetes, and Data Platform stencil taxonomy/aliases, in addition to Visio routing/polish concepts. The Python renderer emits its own VSDX geometry. The full MIT license is included in `third_party/OfficeIMO-LICENSE.txt`.

## Tabler Icons
- Repository: https://github.com/tabler/tabler-icons
- License: MIT
- Copyright (c) 2020-2026 Paweł Kuna
- A curated architecture-relevant subset of SVG icons and pre-rasterized PNG derivatives is redistributed in `visio_arch_renderer/assets/icons/tabler/`. v1.3.1 also includes a generated normalized-polyline derivative in `visio_arch_renderer/assets/icons/tabler_vectors.json` so those icons can be emitted as native Visio geometry. The full MIT license is included in `third_party/tabler-icons/LICENSE`.

## Routing libraries evaluated but not bundled
Adaptagrams/libavoid and @mr_mint/elkjs-libavoid were evaluated for obstacle-avoiding orthogonal routing. No libavoid/Adaptagrams source is copied or linked into this package; there is no LGPL runtime dependency.


## Interoperability references only (no copied code/assets)

The renderer's v1.2.4 dynamic-glue implementation was cross-checked against Microsoft ShapeSheet documentation and publicly available Visio outputs/exporters to identify the native `BegTrigger`/`EndTrigger`, `_WALKGLUE`, and `_XFTRIGGER` semantics. The historical Graphviz Visio exporter (EPL) and `ihordeyneka/json2visio` (GPL-3.0) were used only as interoperability references. No source code, templates, masters, icons, or other assets from those projects are copied, linked, or redistributed in this package.

## Native Visio automation references (no bundled source)

The optional v1.4.0 Windows backend uses Microsoft Visio's documented COM Automation object model through the separately installed `pywin32` package. The implementation was informed by public interoperability patterns in `visio-mcp`, `visio-mcp-sci`, `isiec9ai/MCP`, `iakov-gan/mcp-server-visio`, and `CloudDaddyZA/VisioIntegration`, plus Microsoft Learn documentation for `Cell.GlueTo`, `Selection.Group`, `Shape.Layout`, `ShapeRouteStyle`, `ConFixedCode`, and `Page.LayoutRoutePassive`. No source code or assets from those projects are bundled or copied into this package.

`pywin32` is an optional runtime dependency on Windows and is not redistributed in this ZIP. Microsoft Visio is proprietary software and is not included.
