from __future__ import annotations

"""Native Microsoft Visio connector finalization via COM/pywin32.

The deterministic portable emitter remains the source of truth for node/group
geometry, icons, labels, exact connection points, Shape Data and layout.  This
module is intentionally a *finalizer*: on Windows with desktop Visio installed,
it opens that already-complete VSDX and replaces only architecture connectors
with connectors created by Visio itself.

This hybrid design preserves the renderer's parsers, semantic/provider
recognition, grouping and obstacle-aware layout while delegating interactive
connector behavior (right-angle rerouting, endpoint dragging/regluing and
native ShapeSheet maintenance) to Microsoft Visio.
"""

import os
import re
import shutil
from pathlib import Path
from typing import Any

# Visio section constants used for Shape Data.  The named CellsU accessors are
# used everywhere else to avoid depending on generated COM constants.
VIS_SECTION_PROP = 243
VIS_SELECT = 2
VIS_DESELECT_ALL = 256


def _quote_formula(value: Any) -> str:
    """Return a universal ShapeSheet string formula, preserving line breaks."""
    text = "" if value is None else str(value)
    parts = re.split(r"\r\n|\r|\n", text)
    quoted = ['"' + part.replace('"', '""') + '"' for part in parts]
    return '&CHAR(10)&'.join(quoted)


def _safe_set_formula(shape: Any, cell: str, formula: str) -> bool:
    try:
        shape.CellsU(cell).FormulaU = formula
        return True
    except Exception:
        try:
            shape.Cells(cell).FormulaU = formula
            return True
        except Exception:
            return False


def _safe_cell_result(shape: Any, cell: str, default: str = "") -> str:
    try:
        return str(shape.CellsU(cell).ResultStrU(""))
    except Exception:
        try:
            return str(shape.Cells(cell).ResultStrU(""))
        except Exception:
            return default


def _shape_children(shape: Any):
    try:
        count = int(shape.Shapes.Count)
    except Exception:
        return
    for i in range(1, count + 1):
        try:
            yield shape.Shapes.Item(i)
        except Exception:
            continue


def _page_shapes(page: Any):
    try:
        count = int(page.Shapes.Count)
    except Exception:
        return
    for i in range(1, count + 1):
        try:
            yield page.Shapes.Item(i)
        except Exception:
            continue


def _walk_shapes(container: Any):
    for shape in _page_shapes(container) or ():
        yield shape
        for child in _walk_group(shape):
            yield child


def _walk_group(shape: Any):
    for child in _shape_children(shape) or ():
        yield child
        yield from _walk_group(child)


def _find_shape_by_id(page: Any, shape_id: int):
    wanted = int(shape_id)
    for shape in _walk_shapes(page):
        try:
            if int(shape.ID) == wanted:
                return shape
        except Exception:
            continue
    return None


def _edge_metadata(edge) -> dict:
    return edge.metadata or {}


def _property_row_name(label: str, used: set[str]) -> str:
    base = re.sub(r"[^A-Za-z0-9_]+", "_", str(label)).strip("_") or "Property"
    if base[0].isdigit():
        base = "P_" + base
    name = base
    i = 2
    while name in used:
        name = f"{base}_{i}"
        i += 1
    used.add(name)
    return name


def _humanize_property_name(name: str) -> str:
    text = re.sub(r"[_-]+", " ", str(name)).strip()
    if not text:
        return "Property"
    return " ".join(w if w.isupper() else w[:1].upper() + w[1:] for w in text.split())


def _shape_data_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _apply_connector_metadata(connector: Any, metadata: dict) -> None:
    metadata = metadata or {}
    tip = metadata.get("screenTip") or metadata.get("screentip") or metadata.get("tooltip")
    if tip is not None and str(tip) != "":
        _safe_set_formula(connector, "Comment", _quote_formula(tip))

    data = metadata.get("shapeData")
    if data is None:
        data = metadata.get("shape_data")
    if not isinstance(data, dict) or not data:
        return

    used: set[str] = set()
    for key, payload in data.items():
        value = payload
        label = _humanize_property_name(key)
        prompt = ""
        if isinstance(payload, dict):
            value = payload.get("value", payload.get("Value", ""))
            label = str(payload.get("label", payload.get("Label", label)))
            prompt = str(payload.get("prompt", payload.get("Prompt", "")))
        row = _property_row_name(str(key), used)
        try:
            if not bool(connector.CellExistsU(f"Prop.{row}", 0)):
                connector.AddNamedRow(VIS_SECTION_PROP, row, 0)
        except Exception:
            try:
                connector.AddNamedRow(VIS_SECTION_PROP, row, 0)
            except Exception:
                continue
        _safe_set_formula(connector, f"Prop.{row}", _quote_formula(_shape_data_text(value)))
        _safe_set_formula(connector, f"Prop.{row}.Label", _quote_formula(label))
        _safe_set_formula(connector, f"Prop.{row}.Type", "0")
        if prompt:
            _safe_set_formula(connector, f"Prop.{row}.Prompt", _quote_formula(prompt))


def _hex_rgb_formula(color: str | None, default: str = "#59636E") -> str:
    value = str(color or default).strip()
    m = re.fullmatch(r"#?([0-9A-Fa-f]{6})", value)
    if not m:
        return value
    raw = m.group(1)
    return f"RGB({int(raw[0:2],16)},{int(raw[2:4],16)},{int(raw[4:6],16)})"


def _configure_native_connector(connector: Any, edge, *, name: str) -> None:
    metadata = _edge_metadata(edge)
    try:
        connector.Name = name
    except Exception:
        pass
    try:
        connector.NameU = name
    except Exception:
        pass
    try:
        connector.Text = edge.label or ""
    except Exception:
        pass

    # Visio owns the interactive route.  Right-angle + freely-reroutable is the
    # key behavior the portable backend cannot guarantee after arbitrary user
    # drags.  Do not set ConFixedCode=2 here.
    _safe_set_formula(connector, "ShapeRouteStyle", "1")  # right-angle
    _safe_set_formula(connector, "ConFixedCode", "0")    # reroute freely
    _safe_set_formula(connector, "GlueType", "0")         # point glue
    _safe_set_formula(connector, "DynFeedback", "2")
    _safe_set_formula(connector, "LineWeight", "1.1 pt")
    _safe_set_formula(connector, "LineColor", _hex_rgb_formula(metadata.get("color")))
    if edge.style == "dashed":
        _safe_set_formula(connector, "LinePattern", "2")
    elif edge.style == "dotted":
        _safe_set_formula(connector, "LinePattern", "3")
    else:
        _safe_set_formula(connector, "LinePattern", "1")

    directed = bool(metadata.get("directed", True))
    if edge.bidirectional:
        _safe_set_formula(connector, "BeginArrow", "13")
        _safe_set_formula(connector, "BeginArrowSize", "2")
    else:
        _safe_set_formula(connector, "BeginArrow", "0")
    if directed:
        _safe_set_formula(connector, "EndArrow", "13")
        _safe_set_formula(connector, "EndArrowSize", "2")
    else:
        _safe_set_formula(connector, "EndArrow", "0")

    if edge.label:
        _safe_set_formula(connector, "Char.Size", "7.5 pt")
        # White text background keeps labels readable without a separate shape.
        _safe_set_formula(connector, "TextBkgnd", "RGB(255,255,255)")
    _apply_connector_metadata(connector, metadata)


def _glue_endpoint(connector: Any, endpoint: str, target_shape: Any, target_cell: str | None) -> str:
    cell = target_cell or "PinX"
    try:
        connector.CellsU(endpoint).GlueTo(target_shape.CellsU(cell))
        return cell
    except Exception:
        connector.Cells(endpoint).GlueTo(target_shape.Cells(cell))
        return cell


def _replace_connectors(app: Any, page: Any, diagram, manifest: dict) -> list[dict]:
    connectors = list(manifest.get("connectors") or [])
    result: list[dict] = []
    visible_edges = [e for e in diagram.edges if not (e.metadata or {}).get("hidden")]

    # Explicitly keep Visio's advanced routing enabled on this page.
    try:
        page.LayoutRoutePassive = False
    except Exception:
        pass
    try:
        page.PageSheet.CellsU("RouteStyle").FormulaU = "1"
    except Exception:
        pass

    if len(connectors) != len(visible_edges):
        raise RuntimeError(
            f"native connector finalization expected {len(visible_edges)} connectors, "
            f"portable manifest contains {len(connectors)}"
        )

    for index, (spec, edge) in enumerate(zip(connectors, visible_edges)):
        old_id = int(spec["shapeId"])
        old_connector = _find_shape_by_id(page, old_id)
        source = _find_shape_by_id(page, int(spec["sourceShapeId"])) if spec.get("sourceShapeId") is not None else None
        target = _find_shape_by_id(page, int(spec["targetShapeId"])) if spec.get("targetShapeId") is not None else None
        if source is None or target is None:
            raise RuntimeError(
                f"cannot finalize connector {index}: source/target shape missing "
                f"({spec.get('sourceShapeId')} -> {spec.get('targetShapeId')})"
            )
        if old_connector is not None:
            try:
                old_connector.Delete()
            except Exception as exc:
                raise RuntimeError(f"cannot delete portable connector shape {old_id}: {exc}") from exc

        connector = page.Drop(app.ConnectorToolDataObject, 0.0, 0.0)
        source_cell = _glue_endpoint(connector, "BeginX", source, spec.get("sourceConnectionCell"))
        target_cell = _glue_endpoint(connector, "EndX", target, spec.get("targetConnectionCell"))
        _configure_native_connector(connector, edge, name=f"ArchitectureConnector.{old_id}")

        # Ask Visio to calculate the connector route once after both exact point
        # glue operations.  Later user moves are handled natively because the
        # connector is freely reroutable and LayoutRoutePassive is False.
        try:
            connector.Layout()
        except Exception:
            pass

        result.append({
            "oldShapeId": old_id,
            "nativeShapeId": int(connector.ID),
            "sourceShapeId": int(source.ID),
            "targetShapeId": int(target.ID),
            "sourceConnectionCell": source_cell,
            "targetConnectionCell": target_cell,
            "routeStyle": "right-angle",
            "conFixedCode": 0,
        })
    return result


def _get_first_foreground_page(doc: Any):
    try:
        pages = doc.Pages
        for i in range(1, int(pages.Count) + 1):
            page = pages.Item(i)
            try:
                if not bool(page.Background):
                    return page
            except Exception:
                return page
    except Exception:
        pass
    try:
        return doc.Pages.Item(1)
    except Exception:
        return None


def finalize_vsdx_with_visio(
    portable_path: str | os.PathLike,
    output_path: str | os.PathLike,
    *,
    diagram,
    manifest: dict,
    visible: bool = False,
    app_factory=None,
) -> dict:
    """Open a portable render in desktop Visio and native-finalize connectors."""
    portable = Path(portable_path).resolve()
    output = Path(output_path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if not portable.exists():
        raise FileNotFoundError(portable)

    if app_factory is None:  # pragma: no cover - Windows/Visio integration
        if os.name != "nt":
            raise RuntimeError("native Visio finalization requires Windows")
        try:
            import pythoncom
            pythoncom.CoInitialize()
        except Exception:
            pythoncom = None
        import win32com.client
        app_factory = lambda: win32com.client.DispatchEx("Visio.Application")
    else:
        pythoncom = None

    app = app_factory()
    doc = None
    try:
        try:
            app.Visible = bool(visible)
        except Exception:
            pass
        try:
            app.AlertResponse = 6
        except Exception:
            pass

        doc = app.Documents.Open(str(portable))
        page = _get_first_foreground_page(doc)
        if page is None:
            raise RuntimeError("Visio opened the document but no foreground page was found")

        replacements = _replace_connectors(app, page, diagram, manifest)

        # SaveAs is intentionally used even when output==portable so Visio writes
        # the package through its native serializer and normalizes connector XML.
        if output != portable:
            try:
                if output.exists():
                    output.unlink()
            except Exception:
                pass
            doc.SaveAs(str(output))
        else:
            doc.Save()

        version = ""
        try:
            version = str(app.Version)
        except Exception:
            pass
        return {
            "backend": "visio",
            "engine": "Microsoft Visio COM",
            "visioVersion": version,
            "nativeConnectorCount": len(replacements),
            "connectors": replacements,
            "layoutRoutePassive": False,
            "connectorRouteStyle": 1,
            "connectorConFixedCode": 0,
        }
    finally:
        if doc is not None:
            try:
                doc.Close()
            except Exception:
                pass
        try:
            app.Quit()
        except Exception:
            pass
        if pythoncom is not None:
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass
