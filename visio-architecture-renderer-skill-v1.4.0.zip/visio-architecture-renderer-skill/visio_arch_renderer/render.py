from __future__ import annotations
import json, shutil, tempfile
from pathlib import Path
from .parsers import parse_diagram
from .layout import layout_diagram, autosize_nodes
from .routing import route_edges
from .quality import score_layout
from .emitter import emit_vsdx
from .backend import resolve_backend
from .native_visio import finalize_vsdx_with_visio


def render(input_path, output_path, *, template=None, stencil=None, master_map=None, aws_icons_dir=None, aws_icon_index=None, aws_aliases=None, refresh_aws_icon_index=False, layout_engine=None, report=None, backend='auto', visio_visible=False):
    d=parse_diagram(input_path)
    autosize_nodes(d)
    errors=d.validate()
    if errors: raise ValueError('; '.join(errors))
    requested=layout_engine or d.layout.get('engine','auto')
    congestion=float(d.layout.get('congestionPenalty', d.layout.get('congestion_penalty',12.0)))
    profiles=d.layout.get('profiles') or ['compact','balanced','spacious','dense-routing']
    candidates=[]
    # In auto mode, placement-engine choice is part of the optimization rather
    # than an environment-dependent preference.  Graphviz clusters are often
    # excellent for grouped architectures, while the internal layered placer
    # can produce fewer connector crossings on some dense service graphs.
    engines=['graphviz','layered'] if requested=='auto' else [requested]
    explicit = bool(d.nodes) and all(n.x is not None and n.y is not None for n in d.nodes)
    if explicit:
        engines=['auto']
    for engine in engines:
        for profile in profiles:
            try:
                # Fast screening pass. Full whole-page routing polish is reserved
                # for the strongest candidates so dense graphs do not multiply
                # an expensive optimization by every layout/profile combination.
                l=layout_diagram(d,profile,engine)
                r=route_edges(d,l.boxes,l.group_boxes,congestion_penalty=congestion,polish=False)
                score,metrics=score_layout(l,r,d)
                candidates.append((score,profile,l,r,metrics,engine))
            except Exception as e:
                candidates.append((1e18,profile,None,None,{'error':str(e),'engine':engine},engine))
    valid=[x for x in candidates if x[2] is not None]
    if not valid: raise RuntimeError('No layout candidate succeeded: '+json.dumps([x[4] for x in candidates]))

    # OfficeIMO/libavoid-inspired conflict-first polish on only the best three
    # screening layouts, accepting each candidate's improved whole-page route.
    finalist_ids={id(x[2]) for x in sorted(valid,key=lambda x:x[0])[:min(3,len(valid))]}
    polished=[]
    for item in candidates:
        score,profile0,l0,r0,metrics0,engine0=item
        if l0 is not None and id(l0) in finalist_ids:
            r0=route_edges(d,l0.boxes,l0.group_boxes,congestion_penalty=congestion,polish=True)
            score,metrics0=score_layout(l0,r0,d)
        polished.append((score,profile0,l0,r0,metrics0,engine0))
    candidates=polished
    valid=[x for x in candidates if x[2] is not None]
    best=min(valid,key=lambda x:x[0]);_,profile,l,r,metrics,_=best

    selected_backend, backend_probe = resolve_backend(backend)
    output_path=Path(output_path)
    output_path.parent.mkdir(parents=True,exist_ok=True)
    backend_report={**backend_probe,'selected':selected_backend}

    emitter_kwargs=dict(
        template=template,stencil=stencil,master_map=master_map,
        aws_icons_dir=aws_icons_dir,aws_icon_index=aws_icon_index,aws_aliases=aws_aliases,
        refresh_aws_icon_index=refresh_aws_icon_index,
    )

    if selected_backend=='vsdx':
        emit_rep=emit_vsdx(d,l,r,output_path,**emitter_kwargs)
        backend_report.update({'actual':'vsdx','engine':'pure-python VSDX/ShapeSheet'})
    else:
        # Native Visio mode intentionally uses the mature portable emitter as
        # the first stage so all semantics, groups, icons, labels and exact
        # connection points remain identical. Desktop Visio then replaces only
        # connector shapes with Visio-created dynamic connectors.
        with tempfile.TemporaryDirectory(prefix='arch2visio-native-') as td:
            portable=Path(td)/'portable.vsdx'
            emit_rep=emit_vsdx(d,l,r,portable,**emitter_kwargs)
            try:
                native_rep=finalize_vsdx_with_visio(
                    portable,output_path,diagram=d,
                    manifest=emit_rep.get('visioNativeManifest') or {},
                    visible=bool(visio_visible),
                )
                backend_report.update({'actual':'visio',**native_rep})
            except Exception as exc:
                # Auto mode must remain usable on partially configured Windows
                # workstations. An explicit --backend visio request is strict.
                if str(backend or 'auto').lower()!='auto':
                    raise
                shutil.copy2(portable,output_path)
                backend_report.update({
                    'actual':'vsdx','fallbackFrom':'visio',
                    'fallbackReason':str(exc),'engine':'pure-python VSDX/ShapeSheet',
                })

    rep={
        'input':str(input_path),'output':str(output_path),'selectedProfile':profile,
        'layoutEngine':l.engine,'metrics':metrics,
        'candidates':[{'profile':x[1],'requestedEngine':x[5],**x[4]} for x in candidates],
        'rendererBackend':backend_report,
        **emit_rep,
    }
    if report:Path(report).write_text(json.dumps(rep,indent=2),encoding='utf-8')
    return rep
