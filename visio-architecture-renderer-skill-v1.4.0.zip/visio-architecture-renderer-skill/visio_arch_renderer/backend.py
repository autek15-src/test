from __future__ import annotations

"""Renderer backend selection.

The portable ``vsdx`` backend writes the Open Packaging Convention/ShapeSheet
package directly and works on every supported OS.  The optional ``visio``
backend first builds that deterministic package and then asks desktop Microsoft
Visio to replace the generated connector shapes with connectors created by the
native Visio routing engine.
"""

import os
import sys

VALID_BACKENDS = ("auto", "vsdx", "visio")


def visio_backend_available() -> tuple[bool, str]:
    """Return whether native desktop Visio automation appears available.

    This deliberately does not launch Visio.  On Windows it verifies both the
    optional pywin32 dependency and the Visio.Application COM registration.
    """
    if os.name != "nt" and sys.platform != "win32":
        return False, "native Visio backend requires Windows"
    try:
        import win32com.client  # noqa: F401
    except Exception as exc:  # pragma: no cover - Windows-only branch
        return False, f"pywin32 is unavailable: {exc}"
    try:  # pragma: no cover - Windows-only branch
        import winreg
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, r"Visio.Application\CLSID") as key:
            value, _ = winreg.QueryValueEx(key, None)
            if value:
                return True, "Visio.Application COM registration found"
    except Exception as exc:
        return False, f"Microsoft Visio COM registration not found: {exc}"
    return False, "Microsoft Visio COM registration not found"


def resolve_backend(requested: str | None) -> tuple[str, dict]:
    requested = (requested or "auto").strip().lower()
    if requested not in VALID_BACKENDS:
        raise ValueError(f"unknown renderer backend {requested!r}; choose one of {', '.join(VALID_BACKENDS)}")
    available, reason = visio_backend_available()
    if requested == "visio":
        if not available:
            raise RuntimeError(
                "native Visio backend requested but unavailable. "
                f"{reason}. Install desktop Microsoft Visio and `pip install .[visio]`, "
                "or use --backend vsdx."
            )
        return "visio", {"requested": requested, "nativeVisioAvailable": True, "reason": reason}
    if requested == "vsdx":
        return "vsdx", {"requested": requested, "nativeVisioAvailable": available, "reason": reason}
    selected = "visio" if available else "vsdx"
    return selected, {"requested": requested, "nativeVisioAvailable": available, "reason": reason}
