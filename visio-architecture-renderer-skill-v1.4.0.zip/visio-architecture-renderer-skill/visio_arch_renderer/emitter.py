from __future__ import annotations
import html, io, math, re, zipfile, hashlib, uuid
from pathlib import Path
import xml.etree.ElementTree as ET
from .model import Diagram
from .layout import LayoutResult, Box
from .routing import Route, Port
from .icons import AwsIconCatalog, icon_to_png
from .stencil import inspect_stencil, import_stencil_into_package, load_master_map, choose_master
from .semantic import resolve_semantic, resolve_provider
from .builtin_icons import builtin_icon_bytes, builtin_icon_vectors

V='http://schemas.microsoft.com/office/visio/2012/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
CT='http://schemas.openxmlformats.org/package/2006/content-types'
ET.register_namespace('',V);ET.register_namespace('r',R)
PX=96.0


def emit_vsdx(diagram:Diagram, layout:LayoutResult, routes:dict[int,Route], out_path:str|Path, *, template=None, stencil=None, master_map=None, aws_icons_dir=None, aws_icon_index=None, aws_aliases=None, refresh_aws_icon_index=False):
    pkg=_load_pkg(template) if template else _new_pkg(layout.width/PX,layout.height/PX)
    if stencil:
        import_stencil_into_package(pkg,stencil)
    masters=_package_masters(pkg)
    mapping=load_master_map(master_map)
    icon_catalog = None
    icon_report = {'enabled': False, 'resolved': [], 'unresolved': [], 'warnings': []}
    if aws_icons_dir:
        try:
            icon_catalog = AwsIconCatalog.from_directory(
                aws_icons_dir, cache_path=aws_icon_index, force=refresh_aws_icon_index, aliases_path=aws_aliases
            )
            icon_report.update({'enabled': True, **icon_catalog.report(include_entries=False)})
        except Exception as exc:
            icon_report['warnings'].append(f'AWS icon catalog unavailable: {exc}')

    page_name=_first_page_part(pkg)
    page=ET.fromstring(pkg[page_name])
    shapes=page.find(f'{{{V}}}Shapes')
    if shapes is None: shapes=ET.SubElement(page,f'{{{V}}}Shapes')
    connects=page.find(f'{{{V}}}Connects')
    if connects is None: connects=ET.SubElement(page,f'{{{V}}}Connects')
    maxid=max([int(s.get('ID','0')) for s in page.findall(f'.//{{{V}}}Shape')]+[0]); sid=maxid+1
    page_w,page_h=_page_size(pkg)
    transform=_fit_transform(diagram,layout,page_w,page_h,template is not None)
    relpart=_rels_name(page_name); relroot=ET.fromstring(pkg.get(relpart,_empty_rels()))
    next_rid=max([_ridnum(x.get('Id','')) for x in relroot]+[0])+1

    # Standalone 1-D connectors retain inline geometry for broad renderer compatibility.
    # Endpoint and geometry formulas still use native Visio glue semantics so moves
    # of components/groups recalculate the connector endpoints.
    dynamic_master_id = None

    # Every connector endpoint gets a real ShapeSheet connection point.  The
    # mapping is prepared before shapes are emitted so connectors can glue to
    # Connections.Xn rather than the whole-shape PinX center.
    node_ports, port_rows = _collect_ports(diagram, routes)
    node_shape_ids={}
    group_shapes={}
    node_shapes={}
    native_manifest={'version':1,'page':1,'nodes':{},'groups':{},'connectors':[]}

    # Architecture zones/boundaries are emitted as true Visio group shapes.
    # IMPORTANT: the group parent itself must NOT carry filled rectangle geometry.
    # A filled geometry on the parent paints over its nested member shapes in desktop
    # Visio/LibreOffice. OfficeIMO follows the same rule and does not generate
    # geometry for group parents. We instead add a dedicated boundary subshape as
    # the first child, behind the member components. Selecting/dragging that visible
    # boundary selects the group in normal Visio interaction, so members move with it.
    group_boundary_specs={}
    for g in diagram.groups:
        b=layout.group_boxes.get(g.id)
        if not b:continue
        x,y,w,h=_tb(b,transform)
        gfill=g.metadata.get('fillColor') or _group_fill(g.type)
        gstroke=g.metadata.get('borderColor') or _group_stroke(g.type)
        pinx=x+w/2; piny=page_h-(y+h/2)
        s=ET.Element(f'{{{V}}}Shape',{'ID':str(sid),'Type':'Group','NameU':f'ArchitectureGroup.{sid}','LineStyle':'0','FillStyle':'0','TextStyle':'0'})
        _xform(s,pinx,piny,w,h)
        _cell(s,'ObjType',8)
        # First click selects/moves the whole group; a second click can still
        # select an individual member for local editing.
        _cell(s,'SelectMode',1)
        _cell(s,'FillPattern',0); _cell(s,'LinePattern',0)
        group_shapes[g.id]=s
        native_manifest['groups'][g.id]={'shapeId':sid,'label':g.label,'parent':g.parent}
        # Keep architecture-zone fills translucent even when PUML supplied an
        # explicit color. Desktop Visio may place native connectors beneath a
        # group object's child boundary during redraw/reroute; an opaque group
        # fill can therefore hide the short connector leg between a member node
        # and the group edge. The color remains visible while underlying
        # connectors stay legible.
        group_boundary_specs[g.id]=(g.label,gfill,gstroke,w,h,.72 if g.metadata.get('fillColor') else .88)
        sid+=1

    # Components.  Generic and master-backed nodes keep their text inside the
    # same Visio shape. AWS image-backed nodes are a single Foreign shape whose
    # image and text block share one XForm, so dragging the component keeps the
    # icon, label and glued connectors together.
    for n in diagram.nodes:
        b=layout.boxes[n.id]; x,y,w,h=_tb(b,transform)
        ports=node_ports.get(n.id,[])
        mid=choose_master(n.type,n.label,masters,mapping) if masters else None
        if mid is not None:
            s=_master_shape(sid,mid,x,y,w,h,page_h,n.label,ports)
            if n.metadata.get('fillColor'): _cell(s,'FillForegnd',n.metadata['fillColor']); _cell(s,'FillPattern',1)
            if n.metadata.get('borderColor'): _cell(s,'LineColor',n.metadata['borderColor'])
            node_shapes[n.id]=s;node_shape_ids[n.id]=sid;sid+=1
            continue

        # Resolve semantics/provider before choosing visual assets. v1.3.1 no
        # longer requires renderer-specific ``aws.*`` node types: labels such as
        # DynamoDB, APIGW, RDS, ALB, SFDC, Azure APIM and GCP Pub/Sub can drive
        # provider/service recognition.
        spec, tech_icon, semantic_reason = resolve_semantic(n.type, n.label, n.metadata)
        provider_match = resolve_provider(n.type, n.label, n.metadata)
        if provider_match:
            native_manifest['nodes'].setdefault(n.id,{})['provider']={
                'provider':provider_match.provider,'service':provider_match.service,
                'reason':provider_match.reason,'confidence':provider_match.confidence,
            }

        icon = None; icon_resolution = None; png=None; vectors=None; visual_source=None; visual_name=None
        if icon_catalog is not None and provider_match is not None and provider_match.confidence == 'high' and provider_match.provider == 'aws':
            aws_type='aws.'+provider_match.service if provider_match.service else n.type
            icon, icon_resolution = icon_catalog.resolve(aws_type, n.label, explain=True)
            png=icon_to_png(icon) if icon else None
            if icon and png is None and icon.suffix.lower() == '.svg':
                fallback, fallback_resolution = icon_catalog.resolve(
                    aws_type, n.label, explain=True, allowed_extensions={'.png', '.jpg', '.jpeg'}
                )
                if fallback:
                    fallback_png = icon_to_png(fallback)
                    if fallback_png is not None:
                        icon, png, icon_resolution = fallback, fallback_png, fallback_resolution
                        icon_resolution['fallbackFromSvg'] = True
            if png:
                visual_source='aws'; visual_name=provider_match.service
                icon_report['resolved'].append({'node': n.id, 'type': n.type, 'label': n.label, **(icon_resolution or {}), 'source': str(icon), 'recognizedService':provider_match.service})
            else:
                icon_report['unresolved'].append({'node': n.id, 'type': n.type, 'label': n.label, 'recognizedService':provider_match.service, 'resolution': icon_resolution})

        # Explicit icon metadata still wins over the automatic generic fallback
        # when no official AWS image was selected.
        requested_builtin = n.metadata.get('builtinIcon')
        meta_icon = n.metadata.get('icon')
        if not requested_builtin and isinstance(meta_icon,str) and meta_icon.lower().startswith('builtin:'):
            requested_builtin = meta_icon.split(':',1)[1]
        icon_mode=str(n.metadata.get('iconMode') or n.metadata.get('icon_mode') or 'auto').lower()
        if not png and icon_mode not in {'none','off','native-only','native_only'}:
            # Automatic bundled pictograms are now the default. Technology logos
            # are not bundled indiscriminately; semantic/provider icons are used
            # when no official/provider asset is available.
            auto_builtin = requested_builtin or (provider_match.icon if provider_match and provider_match.confidence == 'high' and provider_match.icon else spec.icon)
            if not requested_builtin and spec.key == 'actor':
                auto_builtin = None
            vectors = builtin_icon_vectors(str(auto_builtin)) if auto_builtin else None
            if vectors:
                visual_source='builtin'; visual_name=str(auto_builtin)
            else:
                builtin_asset = builtin_icon_bytes(str(auto_builtin)) if auto_builtin else None
                if builtin_asset and builtin_asset[1] == '.png':
                    png=builtin_asset[0]; visual_source='builtin'; visual_name=str(auto_builtin)

        if png or vectors:
            rid=None
            if png:
                prefix='icon' if visual_source=='aws' else 'builtin'
                fname=_unique_media(pkg,f'{prefix}_{_slug(n.id)}.png'); pkg['visio/media/'+fname]=png
                rid=f'rId{next_rid}';next_rid+=1
                ET.SubElement(relroot,f'{{{REL}}}Relationship',{'Id':rid,'Type':R+'/image','Target':'../media/'+fname})
            fill=n.metadata.get('fillColor') or spec.fill
            stroke=n.metadata.get('borderColor') or spec.stroke
            # Preserve the v1.3.1 professional body + dark pictogram + label
            # composition. Connector stability is handled independently below
            # with explicit Connections.Xn point glue, so the node can remain a
            # single selectable Visio group without walking-glue drift.
            s,next_sid=_icon_component_group(
                sid,x,y,w,h,page_h,rid,n.label,ports,fill=fill,stroke=stroke,
                semantic_key=spec.key,geometry=spec.geometry,icon_vectors=vectors,
            )
            node_shapes[n.id]=s;node_shape_ids[n.id]=sid
            native_manifest['nodes'].setdefault(n.id,{})['visualIcon']={
                'source':visual_source or 'builtin','name':visual_name or str(icon or ''),
                'automatic':not bool(requested_builtin) and visual_source!='aws',
            }
            if visual_source=='builtin':
                native_manifest['nodes'].setdefault(n.id,{})['builtinIcon']={'name':visual_name,'pack':'tabler','automatic':not bool(requested_builtin)}
            native_manifest['nodes'].setdefault(n.id,{})['semantic']={
                'key':spec.key,'geometry':spec.geometry,'reason':semantic_reason,'technologyIcon':tech_icon,
                'suggestedBuiltinIcon':spec.icon,
            }
            sid=next_sid
        else:
            fill=n.metadata.get('fillColor') or spec.fill
            stroke=n.metadata.get('borderColor') or spec.stroke
            s=_semantic_shape(
                sid,x,y,w,h,page_h,spec.geometry,n.label,ports,fill=fill,stroke=stroke,
                semantic_key=spec.key,technology_icon=tech_icon,
            )
            node_shapes[n.id]=s;node_shape_ids[n.id]=sid
            native_manifest['nodes'].setdefault(n.id,{})['semantic']={
                'key':spec.key,'geometry':spec.geometry,'reason':semantic_reason,'technologyIcon':tech_icon,
                'suggestedBuiltinIcon':spec.icon,
            }
            sid+=1

    for _nid,_sid in node_shape_ids.items():
        _node=next((x for x in diagram.nodes if x.id==_nid),None)
        native_manifest['nodes'].setdefault(_nid,{}).update({'shapeId':_sid,'label':_node.label if _node else _nid,'group':_node.group if _node else None})



    # Bind components and nested groups to their owning Visio group shapes.
    # This creates actual Shape Type=Group / nested Shapes XML rather than
    # passive boundary rectangles. Connectors remain page-level 1-D shapes and
    # glue directly to globally unique nested component IDs.
    groups_by_id={g.id:g for g in diagram.groups}
    child_groups={g.id:[] for g in diagram.groups}
    for g in diagram.groups:
        if g.parent and g.parent in child_groups:
            child_groups[g.parent].append(g.id)

    nodes_by_group={g.id:[] for g in diagram.groups}
    ungrouped=[]
    for n in diagram.nodes:
        if n.group and n.group in nodes_by_group:
            nodes_by_group[n.group].append(n.id)
        else:
            ungrouped.append(n.id)

    def bind_group(gid):
        nonlocal sid
        gshape=group_shapes[gid]
        sub=ET.SubElement(gshape,f'{{{V}}}Shapes')
        # Visible boundary is a normal child shape behind all member shapes. The
        # group parent remains geometry-free, which prevents it from obscuring
        # components while retaining true Visio group move semantics.
        label,gfill,gstroke,gw,gh,gtrans=group_boundary_specs[gid]
        boundary=_rect_shape(
            sid,0,0,gw,gh,gh,fill=gfill,stroke=gstroke,fill_trans=gtrans,
            rounding=.08,text=label,font_size=9.0,bold=True,halign=0,valign=0,text_margin=.08,
        )
        boundary.set('NameU',f'ArchitectureGroupBoundary.{sid}')
        # _rect_shape used a top-left/page-height helper; reset its XForm directly
        # into the owning group's local coordinate system.
        _set_cell_num(boundary,'PinX',gw/2); _set_cell_num(boundary,'PinY',gh/2)
        _set_cell_num(boundary,'Width',gw); _set_cell_num(boundary,'Height',gh)
        _set_cell_num(boundary,'LocPinX',gw/2); _set_cell_num(boundary,'LocPinY',gh/2)
        sub.append(boundary); sid+=1
        for nid in nodes_by_group.get(gid,[]):
            child=node_shapes[nid]
            _localize_child_to_group(child,gshape)
            sub.append(child)
        for cgid in child_groups.get(gid,[]):
            child=bind_group(cgid)
            _localize_child_to_group(child,gshape)
            sub.append(child)
        return gshape

    for g in diagram.groups:
        if not g.parent or g.parent not in group_shapes:
            shapes.append(bind_group(g.id))
    for nid in ungrouped:
        shapes.append(node_shapes[nid])

    # Track the Visio group ancestry of every component. Dynamic connector
    # trigger formulas depend on these ancestors as well as the component itself,
    # so moving an enclosing group forces Visio to recalculate the walking glue.
    group_parent={g.id:g.parent for g in diagram.groups}
    node_group_ancestors={}
    for n in diagram.nodes:
        ids=[]; gid=n.group; seen=set()
        while gid and gid in group_shapes and gid not in seen:
            seen.add(gid); ids.append(int(group_shapes[gid].get('ID'))); gid=group_parent.get(gid)
        node_group_ancestors[n.id]=ids

    # Native one-dimensional connectors. Their endpoints use exact generated
    # connection points and their Geometry includes formula-driven terminal
    # adapters. Connector labels live on the connector itself, not as independent
    # text boxes.
    for idx,e in enumerate(diagram.edges):
        if e.metadata.get('hidden'): continue
        r=routes.get(idx)
        if not r or len(r.points)<2:continue
        pts=[_p(p,transform) for p in r.points]
        conn_id=sid
        conn=_connector_shape(
            conn_id,pts,page_h,e.style,e.bidirectional,e.metadata.get('color'),e.label,
            directed=e.metadata.get('directed',True),dynamic_master_id=dynamic_master_id,
            source_side=(r.source_port.side if r.source_port else None),
            target_side=(r.target_port.side if r.target_port else None),
        )
        # Glue to the exact perimeter ports chosen by the router.  Walking glue
        # (PinX) is intentionally NOT used here: on desktop Visio it can choose
        # a different perimeter location when the document opens, while the
        # connector's precomputed multi-bend Geometry still reflects the old
        # route.  That mismatch is what made v1.3.1 connectors appear detached.
        # LOCTOPAR converts nested/group-local connection points to page
        # coordinates and continues to track component/group moves.
        source_row=None; target_row=None
        if e.source in node_shape_ids and r.source_port is not None:
            source_row=port_rows.get(e.source,{}).get(_port_key(r.source_port))
            if source_row is not None:
                _fixed_point_glue(conn,'begin',node_shape_ids[e.source],source_row)
        if e.target in node_shape_ids and r.target_port is not None:
            target_row=port_rows.get(e.target,{}).get(_port_key(r.target_port))
            if target_row is not None:
                _fixed_point_glue(conn,'end',node_shape_ids[e.target],target_row)
        # Bind the visible Geometry endpoints to Begin/End cells as well. This
        # prevents a live formula update from leaving the drawn polyline behind.
        _bind_connector_geometry_endpoints(conn)
        # Optional authoring metadata. Conversion parsers normally leave these
        # fields absent, so source connector labels remain untouched. Newly
        # authored canonical JSON can keep a short semantic visible label while
        # carrying full endpoint details in native Visio ScreenTips/Shape Data.
        _apply_connector_metadata(conn,e.metadata)
        shapes.append(conn)
        native_manifest['connectors'].append({
            'shapeId':conn_id,'source':e.source,'target':e.target,
            'sourceShapeId':node_shape_ids.get(e.source),'targetShapeId':node_shape_ids.get(e.target),
            'sourceConnectionCell':(f'Connections.X{source_row+1}' if source_row is not None else None),
            'targetConnectionCell':(f'Connections.X{target_row+1}' if target_row is not None else None),
            'sourceSide':(r.source_port.side if r.source_port else None),
            'targetSide':(r.target_port.side if r.target_port else None),
            'label':e.label or '', 'color':e.metadata.get('color') or '#59636E',
            'style':e.style or 'solid','directed':bool(e.metadata.get('directed',True)),
            'bidirectional':bool(e.bidirectional)
        })
        sid+=1

        if e.source in node_shape_ids and source_row is not None:
            ET.SubElement(connects,f'{{{V}}}Connect',{
                'FromSheet':str(conn_id),'FromCell':'BeginX','FromPart':'9',
                'ToSheet':str(node_shape_ids[e.source]),
                'ToCell':f'Connections.X{source_row+1}','ToPart':str(100+source_row)
            })
        if e.target in node_shape_ids and target_row is not None:
            ET.SubElement(connects,f'{{{V}}}Connect',{
                'FromSheet':str(conn_id),'FromCell':'EndX','FromPart':'12',
                'ToSheet':str(node_shape_ids[e.target]),
                'ToCell':f'Connections.X{target_row+1}','ToPart':str(100+target_row)
            })

    if len(connects)==0: page.remove(connects)
    pkg[page_name]=ET.tostring(page,encoding='utf-8',xml_declaration=True)
    pkg[relpart]=ET.tostring(relroot,encoding='utf-8',xml_declaration=True)
    _ensure_png_content_type(pkg)
    _write_pkg(pkg,out_path)
    return {'awsIcons': icon_report, 'nativeConnectionPoints': sum(len(v) for v in node_ports.values()), 'visioNativeManifest': native_manifest}


def _fixed_point_glue(connector, endpoint, target_shape_id, connection_row):
    """Glue one connector endpoint to an exact generated connection point.

    The router assigns deterministic perimeter ports.  The endpoint formulas use
    LOCTOPAR so a connection point remains valid even when its component is a
    subshape of one or more native Visio groups.  Static point glue is deliberate:
    unlike walking glue it cannot silently choose a different side when Visio
    recalculates the ShapeSheet on open.
    """
    endpoint=endpoint.lower()
    xcell,ycell=('BeginX','BeginY') if endpoint=='begin' else ('EndX','EndY')
    ix=int(connection_row)+1
    sid=int(target_shape_id)
    point=(f'LOCTOPAR(PNT(Sheet.{sid}!Connections.X{ix},Sheet.{sid}!Connections.Y{ix}),'
           f'Sheet.{sid}!Width,ThePage!PageWidth)')
    formulas={xcell:f'PNTX({point})', ycell:f'PNTY({point})'}
    for name,formula in formulas.items():
        c=_direct_cell(connector,name)
        if c is None:
            c=ET.SubElement(connector,f'{{{V}}}Cell',{'N':name,'V':'0'})
        c.set('F',formula)
    # Point-to-point/static glue. Microsoft Visio also infers static glue from a
    # non-PinX target, but making the GlueType explicit avoids walking behavior.
    glue=_direct_cell(connector,'GlueType')
    if glue is None:
        glue=ET.SubElement(connector,f'{{{V}}}Cell',{'N':'GlueType','V':'0'})
    else:
        glue.set('V','0'); glue.attrib.pop('F',None)


def _property_row_name(label,used):
    base=re.sub(r'[^A-Za-z0-9_]+','_',str(label)).strip('_') or 'Property'
    if base[0].isdigit(): base='P_'+base
    name=base; i=2
    while name in used:
        name=f'{base}_{i}'; i+=1
    used.add(name)
    return name


def _humanize_property_name(name):
    text=re.sub(r'[_-]+',' ',str(name)).strip()
    if not text:return 'Property'
    # Preserve familiar all-caps acronyms supplied by the author while making
    # machine-style keys readable in the Shape Data pane.
    return ' '.join(w if w.isupper() else w[:1].upper()+w[1:] for w in text.split())


def _shape_data_text(value):
    if value is None:return ''
    if isinstance(value,bool):return 'true' if value else 'false'
    return str(value)


def _insert_shapesheet_child_before_extensions(shape,child):
    """Insert Cell/Section content before Text/ForeignData/Shapes extensions.

    Visio's Sheet_Type schema requires all ShapeSheet Cell/Trigger/Section
    elements to precede extension content such as Text.  Metadata is applied
    after connector geometry/text construction, so appending a Comment Cell or
    Property Section would create XML that tolerant readers accept but desktop
    Visio may reject.
    """
    base={'Cell','Trigger','Section'}
    children=list(shape)
    for ix,existing in enumerate(children):
        if existing.tag.rsplit('}',1)[-1] not in base:
            shape.insert(ix,child)
            return child
    shape.append(child)
    return child


def _apply_connector_metadata(connector,metadata):
    """Apply optional native Visio ScreenTip and Shape Data to a connector.

    Expected authoring metadata keys are ``screenTip`` (or ``screentip`` /
    ``tooltip``) and ``shapeData`` (or ``shape_data``). Shape Data string values
    deliberately use U="STR" and no ``F="No Formula"``: desktop Visio otherwise
    renders many text values as numeric 0 or blank.  Metadata ShapeSheet content
    is inserted before connector Text so the package remains valid for desktop
    Visio's stricter XML ordering rules.
    """
    metadata=metadata or {}
    tip=metadata.get('screenTip') or metadata.get('screentip') or metadata.get('tooltip')
    if tip is not None and str(tip)!='':
        c=_direct_cell(connector,'Comment')
        if c is None:
            c=ET.Element(f'{{{V}}}Cell',{'N':'Comment','V':str(tip)})
            _insert_shapesheet_child_before_extensions(connector,c)
        else:
            c.set('V',str(tip)); c.attrib.pop('F',None)

    data=metadata.get('shapeData')
    if data is None:data=metadata.get('shape_data')
    if not isinstance(data,dict) or not data:return

    sec=next((x for x in connector.findall(f'{{{V}}}Section') if x.get('N')=='Property'),None)
    if sec is None:
        sec=ET.Element(f'{{{V}}}Section',{'N':'Property'})
        _insert_shapesheet_child_before_extensions(connector,sec)
    used={r.get('N') for r in sec.findall(f'{{{V}}}Row') if r.get('N')}
    for pos,(key,payload) in enumerate(data.items(),1):
        label=_humanize_property_name(key); prompt=''; value=payload
        if isinstance(payload,dict):
            value=payload.get('value',payload.get('Value',''))
            label=str(payload.get('label',payload.get('Label',label)))
            prompt=str(payload.get('prompt',payload.get('Prompt','')))
        row=ET.SubElement(sec,f'{{{V}}}Row',{'N':_property_row_name(key,used)})
        _cell(row,'Label',label); _cell(row,'Type',0)
        ET.SubElement(row,f'{{{V}}}Cell',{'N':'Value','V':_shape_data_text(value),'U':'STR'})
        if prompt:_cell(row,'Prompt',prompt)
        _cell(row,'SortKey',f'{pos:02d}'); _cell(row,'Invisible',0)


def _bind_connector_geometry_endpoints(connector):
    """Formula-bind first/last Geometry vertices to the live connector endpoints."""
    sec=next((x for x in connector.findall(f'{{{V}}}Section') if x.get('N')=='Geometry'),None)
    if sec is None:
        return
    rows=sec.findall(f'{{{V}}}Row')
    if not rows:
        return
    for row,prefix in ((rows[0],'Begin'),(rows[-1],'End')):
        xc=next((c for c in row.findall(f'{{{V}}}Cell') if c.get('N')=='X'),None)
        yc=next((c for c in row.findall(f'{{{V}}}Cell') if c.get('N')=='Y'),None)
        if xc is not None:
            xc.set('F',f'{prefix}X-PinX+LocPinX')
        if yc is not None:
            yc.set('F',f'{prefix}Y-PinY+LocPinY')


def _dynamic_glue_trigger(connector, endpoint, target_shape_id, ancestor_group_ids=()):
    """Attach an endpoint using the exact walking-glue trigger Visio 2019 saves.

    The known-good Visio-authored sample uses only the target subshape's
    EventXFMod trigger.  Moving an enclosing native group changes the subshape
    transform and Visio maintains the connection without an explicit group
    DEPENDSON() term, so do not add synthetic ancestor dependencies here.
    """
    endpoint=endpoint.lower()
    if endpoint=='begin':
        trigger='BegTrigger'; xcell='BeginX'; ycell='BeginY'
        walk='_WALKGLUE(BegTrigger,EndTrigger,WalkPreference)'
    else:
        trigger='EndTrigger'; xcell='EndX'; ycell='EndY'
        walk='_WALKGLUE(EndTrigger,BegTrigger,WalkPreference)'
    tc=_direct_cell(connector,trigger)
    if tc is None:
        tc=ET.SubElement(connector,f'{{{V}}}Cell',{'N':trigger,'V':'2'})
    tc.set('F',f'_XFTRIGGER(Sheet.{int(target_shape_id)}!EventXFMod)')
    for name in (xcell,ycell):
        c=_direct_cell(connector,name)
        if c is None:
            c=ET.SubElement(connector,f'{{{V}}}Cell',{'N':name,'V':'0'})
        c.set('F',walk)

def _direct_cell(shape,name):
    return next((c for c in shape.findall(f'{{{V}}}Cell') if c.get('N')==name),None)

def _cell_num(shape,name,default=0.0):
    c=_direct_cell(shape,name)
    try:return float(c.get('V')) if c is not None else float(default)
    except Exception:return float(default)

def _set_cell_num(shape,name,value):
    c=_direct_cell(shape,name)
    if c is None:
        _cell(shape,name,value)
    else:
        c.set('V',_fmt(value)); c.attrib.pop('F',None)

def _localize_child_to_group(child,group):
    """Convert an absolute page XForm into coordinates local to a group."""
    group_left=_cell_num(group,'PinX')-_cell_num(group,'LocPinX')
    group_bottom=_cell_num(group,'PinY')-_cell_num(group,'LocPinY')
    _set_cell_num(child,'PinX',_cell_num(child,'PinX')-group_left)
    _set_cell_num(child,'PinY',_cell_num(child,'PinY')-group_bottom)
    return child


def _collect_ports(diagram, routes):
    per={n.id:[('L',.5),('R',.5),('T',.5),('B',.5)] for n in diagram.nodes}
    for idx,r in routes.items():
        e=diagram.edges[idx]
        if r.source_port: per[e.source].append((r.source_port.side,r.source_port.fraction))
        if r.target_port: per[e.target].append((r.target_port.side,r.target_port.fraction))
    rows={}; out={}
    side_order={'L':0,'R':1,'T':2,'B':3}
    for nid,vals in per.items():
        uniq={ (s,round(float(f),6)) for s,f in vals }
        ordered=sorted(uniq,key=lambda x:(side_order.get(x[0],9),x[1]))
        out[nid]=ordered
        rows[nid]={k:i for i,k in enumerate(ordered)}
    return out,rows


def _port_key(p:Port): return (p.side,round(float(p.fraction),6))


def _fit_transform(diagram,layout,page_w,page_h,has_template):
    safe=diagram.layout.get('safeArea') or diagram.layout.get('safe_area')
    if safe:
        ax=float(safe.get('x',.45)); ay=float(safe.get('y',.45)); aw=float(safe.get('width',page_w-ax-.45)); ah=float(safe.get('height',page_h-ay-.45))
    elif has_template:
        ax=ay=.45; aw=max(1,page_w-.90); ah=max(1,page_h-.90)
    else:
        ax=ay=.15; aw=max(1,page_w-.30); ah=max(1,page_h-.30)
    scale=min((aw*PX)/max(layout.width,1),(ah*PX)/max(layout.height,1),1.0 if not has_template else 99)
    usedw=layout.width*scale/PX; usedh=layout.height*scale/PX
    ox=ax+(aw-usedw)/2; oy=ay+(ah-usedh)/2
    return (scale,ox,oy)
def _tb(b,t):
    s,ox,oy=t;return ox+b.x*s/PX,oy+b.y*s/PX,b.w*s/PX,b.h*s/PX
def _p(p,t):
    s,ox,oy=t;return ox+p[0]*s/PX,oy+p[1]*s/PX


def _rect_shape(sid,x,top,w,h,page_h,*,fill='#FFFFFF',stroke='#5B6470',fill_trans=0,rounding=0,text='',font_size=9.2,bold=False,color='#20262E',halign=1,valign=1,text_margin=.08,ports=None):
    pinx=x+w/2;piny=page_h-(top+h/2)
    sh=ET.Element(f'{{{V}}}Shape',{'ID':str(sid),'Type':'Shape','LineStyle':'0','FillStyle':'0','TextStyle':'0'})
    _xform(sh,pinx,piny,w,h)
    _cell(sh,'ObjType',1)
    _cell(sh,'FillForegnd',fill);_cell(sh,'FillPattern',1);_cell(sh,'FillForegndTrans',fill_trans)
    _cell(sh,'LineColor',stroke);_cell(sh,'LineWeight',.012);_cell(sh,'LinePattern',1);_cell(sh,'Rounding',rounding)
    _cell(sh,'VerticalAlign',valign);_cell(sh,'LeftMargin',text_margin);_cell(sh,'RightMargin',text_margin);_cell(sh,'TopMargin',text_margin);_cell(sh,'BottomMargin',text_margin)
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'});_geom_rect(sec)
    if ports:_add_connection_points(sh,ports,w,h)
    if text:
        _add_text_sections(sh,font_size,bold,color,halign)
        ET.SubElement(sh,f'{{{V}}}Text').text=text
    return sh




def _icon_component_group(sid,x,top,w,h,page_h,rid,text,ports,*,fill='#F7F9FB',stroke='#59636E',semantic_key='service',geometry='service',icon_vectors=None):
    """Create a single selectable Visio component with body + real pictogram.

    The node is a native Visio group.  The group parent owns the connection
    points, while child shapes provide the semantic body, bitmap icon and text.
    This preserves move/glue/group behavior and avoids the v1.3.0 hand-drawn
    ``><`` / three-line pseudo-icons.
    """
    pinx=x+w/2; piny=page_h-(top+h/2)
    parent=ET.Element(f'{{{V}}}Shape',{
        'ID':str(sid),'Type':'Group','NameU':f'SemanticIcon.{_slug(semantic_key)}.{sid}',
        'LineStyle':'0','FillStyle':'0','TextStyle':'0'
    })
    _xform(parent,pinx,piny,w,h); _cell(parent,'ObjType',8); _cell(parent,'SelectMode',1)
    _cell(parent,'FillPattern',0); _cell(parent,'LinePattern',0)
    if ports:_add_connection_points(parent,ports,w,h)
    sub=ET.SubElement(parent,f'{{{V}}}Shapes')

    body_id=sid+1; icon_id=sid+2; text_id=sid+3
    body=_icon_semantic_body(body_id,w,h,fill,stroke,semantic_key,geometry)
    sub.append(body)

    # Reserve a stable left visual rail for the pictogram. Larger nodes use up
    # to 24% of their width, but the icon is capped by node height.
    iw=max(.28,min(w*.22,h*.58)); ih=iw
    ix=max(.07,w*.055); iy=(h-ih)/2
    if icon_vectors:
        image=_vector_icon_shape(icon_id,ix,h-(iy+ih),iw,ih,h,icon_vectors,stroke='#303A44')
    else:
        image=_foreign_image_shape(icon_id,ix,h-(iy+ih),iw,ih,h,rid)
    sub.append(image)

    tx=ix+iw+max(.08,w*.035); tw=max(.35,w-tx-max(.08,w*.05))
    label=_text_only_shape(text_id,tx,0,tw,h,h,text,font_size=8.8,color='#20262E',fill=fill)
    sub.append(label)
    return parent,sid+4


def _icon_semantic_body(sid,w,h,fill,stroke,semantic_key,geometry):
    """Minimal semantic container behind a professional icon."""
    g=(geometry or 'service').lower()
    # Shapes with meaningful outer silhouettes retain those silhouettes. Inner
    # hand-drawn decoration is intentionally avoided because the icon now carries
    # the visual semantics.
    if g in {'database','storage','cache','object_storage'}:
        return _cylinder_shape(sid,0,0,w,h,h,'',None,fill=fill,stroke=stroke,compact=(g=='cache'))
    if g in {'gateway','function','pod'}:
        return _polygon_component_shape(sid,0,0,w,h,h,'',None,_hex_points(),fill,stroke,semantic_key)
    if g=='external':
        return _external_shape(sid,0,0,w,h,h,'',None,fill=fill,stroke=stroke)
    # Consistent clean architecture card for all other icon-backed semantics.
    body=_rect_shape(sid,0,0,w,h,h,fill=fill,stroke=stroke,rounding=.08,text='')
    body.set('NameU',f'SemanticBody.{_slug(semantic_key)}.{sid}')
    return body



def _vector_icon_shape(sid,x,top,w,h,page_h,polylines,*,stroke='#303A44'):
    """Render a precompiled Tabler pictogram as native Visio geometry."""
    pinx=x+w/2;piny=page_h-(top+h/2)
    sh=ET.Element(f'{{{V}}}Shape',{'ID':str(sid),'Type':'Shape','LineStyle':'0','FillStyle':'0','TextStyle':'0','NameU':f'ArchitectureVectorIcon.{sid}'})
    _xform(sh,pinx,piny,w,h); _cell(sh,'ObjType',1)
    _cell(sh,'FillPattern',0); _cell(sh,'LinePattern',1); _cell(sh,'LineColor',stroke); _cell(sh,'LineWeight',.018)
    for sec_ix,poly in enumerate(polylines):
        if not poly or len(poly)<2:continue
        sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':str(sec_ix)})
        _cell(sec,'NoFill',1); _cell(sec,'NoLine',0)
        for row_ix,(nx,ny) in enumerate(poly):
            typ='MoveTo' if row_ix==0 else 'LineTo'
            row=ET.SubElement(sec,f'{{{V}}}Row',{'T':typ,'IX':str(row_ix+1)})
            _cell(row,'X',float(nx)*w); _cell(row,'Y',(1.0-float(ny))*h)
    return sh

def _foreign_image_shape(sid,x,top,w,h,page_h,rid):
    pinx=x+w/2;piny=page_h-(top+h/2)
    sh=ET.Element(f'{{{V}}}Shape',{'ID':str(sid),'Type':'Foreign','LineStyle':'0','FillStyle':'0','TextStyle':'0','NameU':f'ArchitectureIcon.{sid}'})
    _xform(sh,pinx,piny,w,h); _cell(sh,'ObjType',1)
    _cell(sh,'FillPattern',0);_cell(sh,'LinePattern',0)
    _cell(sh,'ImgOffsetX',0);_cell(sh,'ImgOffsetY',0);_cell(sh,'ImgWidth',w);_cell(sh,'ImgHeight',h)
    fd=ET.SubElement(sh,f'{{{V}}}ForeignData',{'ForeignType':'Bitmap','CompressionType':'PNG'})
    ET.SubElement(fd,f'{{{V}}}Rel',{f'{{{R}}}id':rid})
    return sh


def _text_only_shape(sid,x,top,w,h,page_h,text,*,font_size=8.8,color='#20262E',fill='#FFFFFF'):
    sh=_rect_shape(sid,x,top,w,h,page_h,fill=fill,stroke=fill,fill_trans=1,rounding=0,text=text,font_size=font_size,color=color,halign=1,valign=1,text_margin=.025)
    _set_cell_num(sh,'FillPattern',0); _set_cell_num(sh,'LinePattern',0)
    sh.set('NameU',f'ArchitectureLabel.{sid}')
    return sh

def _semantic_shape(sid,x,top,w,h,page_h,geometry,text,ports,*,fill='#F7F9FB',stroke='#59636E',semantic_key='service',technology_icon=None):
    """Create an editable native Visio architecture shape.

    The semantic taxonomy is adapted from the MIT-licensed OfficeIMO.Visio
    first-party stencil catalogs. Geometry stays dependency-free/native so it
    remains editable even when vendor icon packs are unavailable.
    """
    g=(geometry or 'service').lower()
    if g=='actor':
        return _actor_shape(sid,x,top,w,h,page_h,text,ports,stroke=stroke,text_color='#20262E')
    if g in {'database','storage','cache','object_storage'}:
        return _cylinder_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke,compact=(g=='cache'))
    if g in {'gateway','function','pod'}:
        return _polygon_component_shape(sid,x,top,w,h,page_h,text,ports,_hex_points(),fill,stroke,semantic_key)
    if g=='load_balancer':
        return _load_balancer_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke)
    if g in {'security','firewall','secret','router'}:
        return _polygon_component_shape(sid,x,top,w,h,page_h,text,ports,_diamond_points(),fill,stroke,semantic_key)
    if g=='external':
        return _external_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke)
    if g=='folder':
        return _folder_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke)
    if g=='document':
        return _document_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke)
    if g=='browser':
        return _browser_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke)
    if g=='mobile':
        return _mobile_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke)
    if g=='server':
        return _server_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke)
    if g in {'queue','event_bus','stream'}:
        return _queue_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke,mode=g)
    if g=='network':
        return _network_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke)
    if g=='internet':
        return _internet_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke)
    if g=='container':
        return _container_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke)
    if g=='cluster':
        return _cluster_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke)
    if g in {'monitoring','logging','notification','email','identity','workflow','cloud','api','service'}:
        # These semantics intentionally use restrained professional cards. Their
        # semantic identity is reinforced by the small native glyph, not by a
        # vendor-specific logo.
        return _glyph_card_shape(sid,x,top,w,h,page_h,text,ports,fill=fill,stroke=stroke,glyph=g)
    return _rect_shape(sid,x,top,w,h,page_h,fill=fill,stroke=stroke,rounding=.08,text=text,font_size=9.2,ports=ports)


def _base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text='',font_size=9.0,rounding=0.0,halign=1,valign=1,text_margin=.08,nameu=None):
    pinx=x+w/2; piny=page_h-(top+h/2)
    attrs={'ID':str(sid),'Type':'Shape','LineStyle':'0','FillStyle':'0','TextStyle':'0'}
    if nameu: attrs['NameU']=nameu
    sh=ET.Element(f'{{{V}}}Shape',attrs)
    _xform(sh,pinx,piny,w,h); _cell(sh,'ObjType',1)
    _cell(sh,'FillForegnd',fill); _cell(sh,'FillPattern',1)
    _cell(sh,'LineColor',stroke); _cell(sh,'LineWeight',.012); _cell(sh,'LinePattern',1)
    if rounding: _cell(sh,'Rounding',rounding)
    _cell(sh,'VerticalAlign',valign); _cell(sh,'LeftMargin',text_margin); _cell(sh,'RightMargin',text_margin); _cell(sh,'TopMargin',text_margin); _cell(sh,'BottomMargin',text_margin)
    if ports:_add_connection_points(sh,ports,w,h)
    if text:
        _add_text_sections(sh,font_size,False,'#20262E',halign)
    return sh


def _append_shape_text(sh,text):
    if text:
        ET.SubElement(sh,f'{{{V}}}Text').text=text
    return sh


def _geom_poly(sec, points, close=True):
    pts=list(points)
    if close and pts and pts[-1]!=pts[0]: pts.append(pts[0])
    for i,(x,y) in enumerate(pts,1):
        row=ET.SubElement(sec,f'{{{V}}}Row',{'T':'RelMoveTo' if i==1 else 'RelLineTo','IX':str(i)})
        _cell(row,'X',x); _cell(row,'Y',y)


def _hex_points(): return [(0.18,0),(0.82,0),(1,0.5),(0.82,1),(0.18,1),(0,0.5)]
def _diamond_points(): return [(0.5,0),(1,0.5),(0.5,1),(0,0.5)]


def _polygon_component_shape(sid,x,top,w,h,page_h,text,ports,points,fill,stroke,semantic_key):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.9,text_margin=.07,nameu=f'Semantic.{semantic_key}.{sid}')
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_poly(sec,points)
    return _append_shape_text(sh,text)


def _cylinder_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke,compact=False):
    """Standard architecture database/storage cylinder as native vector geometry."""
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=9.0,text_margin=.08,nameu=f'Semantic.Database.{sid}')
    # Keep text clear of the top ellipse.
    _cell(sh,'TxtPinX',w/2); _cell(sh,'TxtPinY',h*.47); _cell(sh,'TxtWidth',max(.3,w*.82)); _cell(sh,'TxtHeight',max(.22,h*.55)); _cell(sh,'TxtLocPinX',max(.3,w*.82)/2); _cell(sh,'TxtLocPinY',max(.22,h*.55)/2); _cell(sh,'TxtAngle',0)
    eh=max(.12,min(h*(.24 if compact else .30),w*.22))
    ry=eh/2; cy_top=h-ry; cy_bot=ry
    # Filled outer body with smooth-ish elliptical top/bottom halves.
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'})
    pts=[]
    steps=10
    # top half: left -> top -> right
    for i in range(steps+1):
        a=math.pi - math.pi*i/steps
        pts.append((w/2+(w/2)*math.cos(a),cy_top+ry*math.sin(a)))
    pts.append((w,cy_bot))
    # bottom half: right -> bottom -> left
    for i in range(steps+1):
        a=math.pi*i/steps
        pts.append((w/2+(w/2)*math.cos(a),cy_bot-ry*math.sin(a)))
    pts.append((0,cy_top))
    for i,(px,py) in enumerate(pts,1):
        r=ET.SubElement(sec,f'{{{V}}}Row',{'T':'MoveTo' if i==1 else 'LineTo','IX':str(i)}); _cell(r,'X',px); _cell(r,'Y',py)
    r=ET.SubElement(sec,f'{{{V}}}Row',{'T':'LineTo','IX':str(len(pts)+1)}); _cell(r,'X',pts[0][0]); _cell(r,'Y',pts[0][1])
    # Top ellipse rim.
    rim=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(rim,'NoFill',1); _cell(rim,'NoLine',0)
    er=ET.SubElement(rim,f'{{{V}}}Row',{'T':'Ellipse','IX':'1'}); _cell(er,'X',w/2); _cell(er,'Y',cy_top); _cell(er,'A',w); _cell(er,'B',cy_top); _cell(er,'C',w/2); _cell(er,'D',cy_top+ry)
    return _append_shape_text(sh,text)


def _server_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.9,rounding=.04,text_margin=.07,nameu=f'Semantic.Server.{sid}')
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_rect(sec)
    # Rack/server fascia lines kept to the left so labels remain readable.
    deco=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(deco,'NoFill',1)
    for j,yy in enumerate((.27,.50,.73),1):
        for k,(typ,xx) in enumerate((('MoveTo',.06),('LineTo',.23)),1):
            r=ET.SubElement(deco,f'{{{V}}}Row',{'T':typ,'IX':str((j-1)*2+k)}); _cell(r,'X',xx*w); _cell(r,'Y',yy*h)
    _cell(sh,'TxtPinX',w*.61); _cell(sh,'TxtPinY',h/2); _cell(sh,'TxtWidth',w*.68); _cell(sh,'TxtHeight',h*.78); _cell(sh,'TxtLocPinX',w*.34); _cell(sh,'TxtLocPinY',h*.39); _cell(sh,'TxtAngle',0)
    return _append_shape_text(sh,text)


def _queue_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke,mode='queue'):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.8,rounding=.08,text_margin=.06,nameu=f'Semantic.{mode}.{sid}')
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_rect(sec)
    deco=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(deco,'NoFill',1)
    if mode=='event_bus':
        # central bus + ingress/egress branches
        seq=[('MoveTo',.20,.20),('LineTo',.20,.80),('MoveTo',.20,.30),('LineTo',.38,.30),('MoveTo',.20,.50),('LineTo',.38,.50),('MoveTo',.20,.70),('LineTo',.38,.70)]
    elif mode=='stream':
        seq=[('MoveTo',.06,.32),('LineTo',.28,.32),('MoveTo',.10,.50),('LineTo',.32,.50),('MoveTo',.06,.68),('LineTo',.28,.68)]
    else:
        seq=[('MoveTo',.07,.28),('LineTo',.28,.28),('MoveTo',.07,.50),('LineTo',.28,.50),('MoveTo',.07,.72),('LineTo',.28,.72)]
    for i,(typ,xx,yy) in enumerate(seq,1):
        r=ET.SubElement(deco,f'{{{V}}}Row',{'T':typ,'IX':str(i)}); _cell(r,'X',xx*w); _cell(r,'Y',yy*h)
    _cell(sh,'TxtPinX',w*.64); _cell(sh,'TxtPinY',h/2); _cell(sh,'TxtWidth',w*.62); _cell(sh,'TxtHeight',h*.78); _cell(sh,'TxtLocPinX',w*.31); _cell(sh,'TxtLocPinY',h*.39); _cell(sh,'TxtAngle',0)
    return _append_shape_text(sh,text)


def _load_balancer_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.9,text_margin=.07,nameu=f'Semantic.LoadBalancer.{sid}')
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_poly(sec,_hex_points())
    deco=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(deco,'NoFill',1)
    seq=[('MoveTo',.25,.50),('LineTo',.47,.50),('MoveTo',.47,.50),('LineTo',.67,.25),('MoveTo',.47,.50),('LineTo',.67,.50),('MoveTo',.47,.50),('LineTo',.67,.75)]
    for i,(typ,xx,yy) in enumerate(seq,1):
        r=ET.SubElement(deco,f'{{{V}}}Row',{'T':typ,'IX':str(i)}); _cell(r,'X',xx*w); _cell(r,'Y',yy*h)
    return _append_shape_text(sh,text)


def _external_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=9.0,rounding=.03,nameu=f'Semantic.External.{sid}')
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_rect(sec)
    inner=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(inner,'NoFill',1)
    _geom_poly(inner,[(.035,.06),(.965,.06),(.965,.94),(.035,.94)],close=True)
    return _append_shape_text(sh,text)


def _folder_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.9,text_margin=.08,nameu=f'Semantic.Folder.{sid}')
    pts=[(0,.12),(.34,.12),(.43,0),(.72,0),(.79,.12),(1,.12),(1,1),(0,1)]
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_poly(sec,pts)
    return _append_shape_text(sh,text)


def _document_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.8,text_margin=.07,nameu=f'Semantic.Document.{sid}')
    pts=[(0,0),(1,0),(1,.82),(.86,.96),(.70,.82),(.54,.96),(.38,.82),(.22,.96),(0,.82)]
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_poly(sec,pts)
    return _append_shape_text(sh,text)


def _browser_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.8,rounding=.05,text_margin=.06,nameu=f'Semantic.Browser.{sid}')
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_rect(sec)
    deco=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(deco,'NoFill',1)
    seq=[('MoveTo',0,.78),('LineTo',w,.78),('MoveTo',.08,.88),('LineTo',.13,.88),('MoveTo',.17,.88),('LineTo',.22,.88)]
    for i,(typ,xx,yy) in enumerate(seq,1):
        r=ET.SubElement(deco,f'{{{V}}}Row',{'T':typ,'IX':str(i)}); _cell(r,'X',xx if xx>1 else xx*w); _cell(r,'Y',yy if yy>1 else yy*h)
    _cell(sh,'TxtPinX',w*.58); _cell(sh,'TxtPinY',h*.40); _cell(sh,'TxtWidth',w*.74); _cell(sh,'TxtHeight',h*.62); _cell(sh,'TxtLocPinX',w*.37); _cell(sh,'TxtLocPinY',h*.31); _cell(sh,'TxtAngle',0)
    return _append_shape_text(sh,text)


def _mobile_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke):
    # Maintain the layout box but draw a phone outline in its left third.
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.8,rounding=.08,text_margin=.06,nameu=f'Semantic.Mobile.{sid}')
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_rect(sec)
    deco=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(deco,'NoFill',1)
    _geom_poly(deco,[(.06,.12),(.28,.12),(.28,.88),(.06,.88)],close=True)
    _cell(sh,'TxtPinX',w*.64); _cell(sh,'TxtWidth',w*.62); _cell(sh,'TxtLocPinX',w*.31)
    return _append_shape_text(sh,text)


def _network_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.8,rounding=.05,text_margin=.06,nameu=f'Semantic.Network.{sid}')
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_rect(sec)
    deco=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(deco,'NoFill',1)
    # Three connected nodes on the left.
    seq=[('MoveTo',.13,.25),('LineTo',.25,.50),('LineTo',.13,.75),('MoveTo',.25,.50),('LineTo',.35,.50)]
    for i,(typ,xx,yy) in enumerate(seq,1):
        r=ET.SubElement(deco,f'{{{V}}}Row',{'T':typ,'IX':str(i)}); _cell(r,'X',xx*w); _cell(r,'Y',yy*h)
    _cell(sh,'TxtPinX',w*.67); _cell(sh,'TxtWidth',w*.60); _cell(sh,'TxtLocPinX',w*.30)
    return _append_shape_text(sh,text)


def _internet_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.7,text_margin=.05,nameu=f'Semantic.Internet.{sid}')
    # Ellipse body, a standard network/internet notation.
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'})
    er=ET.SubElement(sec,f'{{{V}}}Row',{'T':'Ellipse','IX':'1'}); _cell(er,'X',w/2); _cell(er,'Y',h/2); _cell(er,'A',w); _cell(er,'B',h/2); _cell(er,'C',w/2); _cell(er,'D',h)
    return _append_shape_text(sh,text)


def _container_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.8,rounding=.03,text_margin=.06,nameu=f'Semantic.Container.{sid}')
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_rect(sec)
    deco=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(deco,'NoFill',1)
    for i,xx in enumerate((.10,.19,.28),1):
        r=ET.SubElement(deco,f'{{{V}}}Row',{'T':'MoveTo','IX':str(i*2-1)}); _cell(r,'X',xx*w); _cell(r,'Y',.28*h)
        r=ET.SubElement(deco,f'{{{V}}}Row',{'T':'LineTo','IX':str(i*2)}); _cell(r,'X',xx*w); _cell(r,'Y',.72*h)
    _cell(sh,'TxtPinX',w*.67); _cell(sh,'TxtWidth',w*.60); _cell(sh,'TxtLocPinX',w*.30)
    return _append_shape_text(sh,text)


def _cluster_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.8,rounding=.05,text_margin=.06,nameu=f'Semantic.Cluster.{sid}')
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_rect(sec)
    deco=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(deco,'NoFill',1)
    # compact 2x2 cluster tiles
    for j,(xx,yy) in enumerate(((.08,.58),(.20,.58),(.08,.34),(.20,.34)),1):
        r=ET.SubElement(deco,f'{{{V}}}Row',{'T':'MoveTo','IX':str(j*2-1)}); _cell(r,'X',xx*w); _cell(r,'Y',yy*h)
        r=ET.SubElement(deco,f'{{{V}}}Row',{'T':'LineTo','IX':str(j*2)}); _cell(r,'X',(xx+.07)*w); _cell(r,'Y',yy*h)
    _cell(sh,'TxtPinX',w*.65); _cell(sh,'TxtWidth',w*.62); _cell(sh,'TxtLocPinX',w*.31)
    return _append_shape_text(sh,text)


def _glyph_card_shape(sid,x,top,w,h,page_h,text,ports,*,fill,stroke,glyph='service'):
    sh=_base_native_shape(sid,x,top,w,h,page_h,fill,stroke,ports,text=text,font_size=8.8,rounding=.08,text_margin=.06,nameu=f'Semantic.{glyph}.{sid}')
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'}); _geom_rect(sec)
    # Small dependency-free native glyph on the left. These are deliberately
    # restrained so the label remains the primary architecture information.
    deco=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(deco,'NoFill',1)
    if glyph=='api': seq=[('MoveTo',.07,.38),('LineTo',.15,.50),('LineTo',.07,.62),('MoveTo',.29,.38),('LineTo',.21,.50),('LineTo',.29,.62)]
    elif glyph in {'security','identity'}: seq=[('MoveTo',.10,.66),('LineTo',.18,.76),('LineTo',.26,.66),('LineTo',.24,.42),('LineTo',.18,.28),('LineTo',.12,.42),('LineTo',.10,.66)]
    elif glyph=='workflow': seq=[('MoveTo',.08,.66),('LineTo',.18,.50),('LineTo',.08,.34),('MoveTo',.18,.50),('LineTo',.29,.50)]
    elif glyph in {'monitoring','logging'}: seq=[('MoveTo',.07,.45),('LineTo',.12,.45),('LineTo',.16,.65),('LineTo',.21,.30),('LineTo',.25,.55),('LineTo',.30,.55)]
    elif glyph=='email': seq=[('MoveTo',.06,.65),('LineTo',.18,.48),('LineTo',.30,.65),('MoveTo',.06,.35),('LineTo',.18,.52),('LineTo',.30,.35)]
    elif glyph=='cloud': seq=[('MoveTo',.06,.44),('LineTo',.30,.44),('MoveTo',.10,.44),('LineTo',.12,.62),('LineTo',.19,.70),('LineTo',.26,.60),('LineTo',.28,.44)]
    else: seq=[('MoveTo',.07,.35),('LineTo',.30,.35),('MoveTo',.07,.50),('LineTo',.30,.50),('MoveTo',.07,.65),('LineTo',.30,.65)]
    for i,(typ,xx,yy) in enumerate(seq,1):
        r=ET.SubElement(deco,f'{{{V}}}Row',{'T':typ,'IX':str(i)}); _cell(r,'X',xx*w); _cell(r,'Y',yy*h)
    _cell(sh,'TxtPinX',w*.65); _cell(sh,'TxtPinY',h/2); _cell(sh,'TxtWidth',w*.62); _cell(sh,'TxtHeight',h*.78); _cell(sh,'TxtLocPinX',w*.31); _cell(sh,'TxtLocPinY',h*.39); _cell(sh,'TxtAngle',0)
    return _append_shape_text(sh,text)

def _master_shape(sid,mid,x,top,w,h,page_h,text,ports):
    pinx=x+w/2;piny=page_h-(top+h/2)
    sh=ET.Element(f'{{{V}}}Shape',{'ID':str(sid),'Type':'Shape','Master':str(mid)})
    _xform(sh,pinx,piny,w,h)
    _cell(sh,'ObjType',1)
    if ports:_add_connection_points(sh,ports,w,h)
    _add_text_sections(sh,9.2,False,'#20262E',1)
    ET.SubElement(sh,f'{{{V}}}Text').text=text
    return sh


def _foreign_component_shape(sid,x,top,w,h,page_h,rid,text,ports):
    pinx=x+w/2;piny=page_h-(top+h/2)
    sh=ET.Element(f'{{{V}}}Shape',{'ID':str(sid),'Type':'Foreign','LineStyle':'0','FillStyle':'0','TextStyle':'0'})
    _xform(sh,pinx,piny,w,h)
    _cell(sh,'ObjType',1)
    _cell(sh,'FillPattern',0);_cell(sh,'LinePattern',0)
    # Image occupies the left portion of the component shape; the label uses a
    # text block on the right. Both remain part of this single Visio object.
    iw=min(.42*w,.64*h);ih=iw;ix=.10;iy=(h-ih)/2
    _cell(sh,'ImgOffsetX',ix);_cell(sh,'ImgOffsetY',iy);_cell(sh,'ImgWidth',iw);_cell(sh,'ImgHeight',ih)
    tw=max(.35,w-iw-.28);th=max(.28,h-.12)
    _cell(sh,'TxtPinX',iw+.18+tw/2);_cell(sh,'TxtPinY',h/2);_cell(sh,'TxtWidth',tw);_cell(sh,'TxtHeight',th);_cell(sh,'TxtLocPinX',tw/2);_cell(sh,'TxtLocPinY',th/2);_cell(sh,'TxtAngle',0)
    if ports:_add_connection_points(sh,ports,w,h)
    _add_text_sections(sh,9.0,False,'#20262E',0)
    ET.SubElement(sh,f'{{{V}}}Text').text=text
    fd=ET.SubElement(sh,f'{{{V}}}ForeignData',{'ForeignType':'Bitmap','CompressionType':'PNG'})
    ET.SubElement(fd,f'{{{V}}}Rel',{f'{{{R}}}id':rid})
    return sh


def _actor_shape(sid,x,top,w,h,page_h,text,ports,stroke='#56616B',text_color='#20262E'):
    """Native single-shape stick-figure actor with an attached text block."""
    pinx=x+w/2; piny=page_h-(top+h/2)
    sh=ET.Element(f'{{{V}}}Shape',{'ID':str(sid),'Type':'Shape','LineStyle':'0','FillStyle':'0','TextStyle':'0','NameU':f'Actor.{sid}'})
    _xform(sh,pinx,piny,w,h)
    _cell(sh,'ObjType',1)
    _cell(sh,'FillPattern',0); _cell(sh,'LineColor',stroke); _cell(sh,'LineWeight',.014); _cell(sh,'LinePattern',1)
    # Reserve the lower third for the label and draw the actor in the upper area.
    label_h=max(.28,h*.32); fig_bottom=label_h+.05; fig_top=h-.08
    fig_h=max(.30,fig_top-fig_bottom); cx=w/2
    head_r=min(w*.10,fig_h*.13)
    head_cy=fig_top-head_r
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'})
    _cell(sec,'NoFill',1); _cell(sec,'NoLine',0)
    er=ET.SubElement(sec,f'{{{V}}}Row',{'T':'Ellipse','IX':'1'})
    _cell(er,'X',cx); _cell(er,'Y',head_cy); _cell(er,'A',cx+head_r); _cell(er,'B',head_cy); _cell(er,'C',cx); _cell(er,'D',head_cy+head_r)
    body_top=head_cy-head_r; shoulder=body_top-fig_h*.12; hip=fig_bottom+fig_h*.25
    arm_y=body_top-fig_h*.20; arm_dx=min(w*.25,fig_h*.22); leg_dx=min(w*.18,fig_h*.16)
    sec2=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'1'}); _cell(sec2,'NoFill',1); _cell(sec2,'NoLine',0)
    pts=[('MoveTo',cx,body_top),('LineTo',cx,hip),('MoveTo',cx-arm_dx,arm_y),('LineTo',cx+arm_dx,arm_y),('MoveTo',cx,hip),('LineTo',cx-leg_dx,fig_bottom),('MoveTo',cx,hip),('LineTo',cx+leg_dx,fig_bottom)]
    for ixr,(typ,px,py) in enumerate(pts,1):
        rr=ET.SubElement(sec2,f'{{{V}}}Row',{'T':typ,'IX':str(ixr)}); _cell(rr,'X',px); _cell(rr,'Y',py)
    _cell(sh,'TxtPinX',w/2); _cell(sh,'TxtPinY',label_h/2); _cell(sh,'TxtWidth',max(.4,w-.12)); _cell(sh,'TxtHeight',label_h); _cell(sh,'TxtLocPinX',max(.4,w-.12)/2); _cell(sh,'TxtLocPinY',label_h/2); _cell(sh,'TxtAngle',0)
    _cell(sh,'VerticalAlign',1); _cell(sh,'LeftMargin',.02); _cell(sh,'RightMargin',.02); _cell(sh,'TopMargin',.01); _cell(sh,'BottomMargin',.01)
    if ports: _add_connection_points(sh,ports,w,h)
    _add_text_sections(sh,8.8,False,text_color,1); ET.SubElement(sh,f'{{{V}}}Text').text=text
    return sh


def _xform(sh,pinx,piny,w,h):
    for n,v in [('PinX',pinx),('PinY',piny),('Width',w),('Height',h),('LocPinX',w/2),('LocPinY',h/2),('Angle',0),('FlipX',0),('FlipY',0),('ResizeMode',0)]:_cell(sh,n,v)


def _add_connection_points(sh,ports,w,h):
    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Connection'})
    for ix,(side,f) in enumerate(ports):
        row=ET.SubElement(sec,f'{{{V}}}Row',{'T':'Connection','IX':str(ix)})
        f=float(f)
        if side=='L': x=0.0;y=1-f;dx=1;dy=0
        elif side=='R': x=1.0;y=1-f;dx=-1;dy=0
        elif side=='T': x=f;y=1.0;dx=0;dy=-1
        else: x=f;y=0.0;dx=0;dy=1
        _cell_f(row,'X',x*w,f'Width*{x:.6f}')
        _cell_f(row,'Y',y*h,f'Height*{y:.6f}')
        _cell(row,'DirX',dx);_cell(row,'DirY',dy);_cell(row,'Type',0);_cell(row,'AutoGen',0)
        ET.SubElement(row,f'{{{V}}}Cell',{'N':'Prompt','V':'','F':'No Formula'})


def _cell_f(parent,n,v,formula):
    ET.SubElement(parent,f'{{{V}}}Cell',{'N':n,'V':_fmt(v),'F':formula})


def _add_text_sections(sh,size,bold,color,halign):
    ch=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Character'})
    row=ET.SubElement(ch,f'{{{V}}}Row',{'IX':'0'});_cell(row,'Font','Calibri');_cell(row,'Color',color);_cell(row,'Size',size/72);_cell(row,'Style',1 if bold else 0)
    pa=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Paragraph'})
    row=ET.SubElement(pa,f'{{{V}}}Row',{'IX':'0'});_cell(row,'HorzAlign',halign)
    tabs=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Tabs'});ET.SubElement(tabs,f'{{{V}}}Row',{'IX':'0'})


def _connector_shape(sid,pts,page_h,style,bidirectional,line_color=None,label='',directed=True,dynamic_master_id=None,source_side=None,target_side=None):
    """Emit a standalone Visio-native orthogonal connector shape.

    v1.3.3 keeps exact point glue but stops relying on Visio to preserve the
    precomputed terminal geometry after shapes are dragged.  The full middle
    route is pinned to its original page coordinates, while a small formula-
    driven Manhattan "terminal adapter" is built at each endpoint.  This gives
    every connector three important interactive guarantees:

    * the first/last leg always leaves/enters the component perpendicular to the
      selected connection-point side, so arrowheads cannot rotate sideways;
    * a turn immediately before an arrowhead is kept at least TERMINAL_STUB away
      from the component instead of collapsing onto the arrow;
    * moving some unrelated shape cannot cause Visio's automatic router to
      rewrite a connector that was already valid.

    Connection-point DirX/DirY remains authoritative metadata for Visio and the
    emitted geometry independently enforces the same orientation.  This is more
    deterministic than the v1.3.2 combination of static point glue plus a
    mostly-static local polyline.
    """
    vis_pts=[(float(x), float(page_h-y)) for x,y in pts]
    x0,y0=vis_pts[0]; x1,y1=vis_pts[-1]
    dx=x1-x0; dy=y1-y0
    width=max(abs(dx),0.25)
    height=max(abs(dy),0.25)
    pinx=(x0+x1)/2.0; piny=(y0+y1)/2.0
    locx=width/2.0; locy=height/2.0
    origin_x=pinx-locx; origin_y=piny-locy
    color=(line_color or '#59636E').lower()

    attrs={
        'ID':str(sid),
        'NameU':f'ArchitectureConnector.{sid}', 'IsCustomNameU':'1',
        'Name':f'ArchitectureConnector.{sid}', 'IsCustomName':'1',
        'Type':'Shape','LineStyle':'0','FillStyle':'0','TextStyle':'0'
    }
    sh=ET.Element(f'{{{V}}}Shape',attrs)

    def cf(name,value,formula=None,unit=None):
        a={'N':name,'V':_fmt(value)}
        if formula is not None:a['F']=formula
        if unit is not None:a['U']=unit
        ET.SubElement(sh,f'{{{V}}}Cell',a)

    cf('PinX',pinx,'GUARD((BeginX+EndX)/2)')
    cf('PinY',piny,'GUARD((BeginY+EndY)/2)')
    if abs(dx)<1e-9:
        cf('Width',width,'GUARD(0.25DL)')
    elif dx>0:
        cf('Width',width,'GUARD(EndX-BeginX)')
    else:
        cf('Width',width,'GUARD(BeginX-EndX)')
    if abs(dy)<1e-9:
        cf('Height',height,'GUARD(0.25DL)')
    elif dy>0:
        cf('Height',height,'GUARD(EndY-BeginY)')
    else:
        cf('Height',height,'GUARD(BeginY-EndY)')
    cf('LocPinX',locx,'GUARD(Width*0.5)')
    cf('LocPinY',locy,'GUARD(Height*0.5)')
    cf('Angle',0,'GUARD(0DA)'); cf('FlipX',0,'GUARD(FALSE)'); cf('FlipY',0,'GUARD(FALSE)'); cf('ResizeMode',0)

    # These are overwritten with exact group-safe connection-point formulas by
    # _fixed_point_glue().  Initial values are still the router-selected points.
    walk_b='_WALKGLUE(BegTrigger,EndTrigger,WalkPreference)'
    walk_e='_WALKGLUE(EndTrigger,BegTrigger,WalkPreference)'
    cf('BeginX',x0,walk_b); cf('BeginY',y0,walk_b)
    cf('EndX',x1,walk_e); cf('EndY',y1,walk_e)
    cf('TextBkgnd','#ffffff','THEMEGUARD(THEMEVAL("BackgroundColor")+1)')
    cf('NoAlignBox',1); cf('DynFeedback',2); cf('GlueType',0)
    cf('BegTrigger',2); cf('EndTrigger',2); cf('ObjType',2)
    cf('QuickStyleLineMatrix',1); cf('QuickStyleFillMatrix',1); cf('QuickStyleEffectsMatrix',1); cf('QuickStyleFontMatrix',1)

    if label:
        lx,ly_screen=_label_point(pts); ly=page_h-ly_screen
        llocal_x=lx-origin_x; llocal_y=ly-origin_y
        label_lines=label.splitlines() or [label]
        longest=max(len(x) for x in label_lines)
        tw=max(.55,min(2.8,.30+longest*.052))
        visual=max(1,len(label_lines)); th=max(.25,min(1.25,.11+visual*.14))
        cf('TxtPinX',llocal_x); cf('TxtPinY',llocal_y)
        cf('TxtWidth',tw); cf('TxtHeight',th)
        cf('TxtLocPinX',tw/2,'TxtWidth*0.5'); cf('TxtLocPinY',th/2,'TxtHeight*0.5'); cf('TxtAngle',0)

    cf('ShapeRouteStyle',1)
    # v1.3.2 preserved the native sample's undocumented value 6.  In interactive
    # diagrams that lets desktop Visio unexpectedly rewrite a route when another
    # shape moves.  Microsoft documents value 2 as "Never reroute".  Our endpoint
    # adapters already provide deterministic move behavior, so auto-rerouting is
    # deliberately disabled rather than allowing unrelated shapes to alter arrows.
    cf('ConFixedCode',2)
    cf('ConLineRouteExt',1)
    cf('LineWeight',0.01527777777777778,unit='PT')
    cf('LineColor',color)
    if style=='dashed': cf('LinePattern',2)
    if bidirectional: cf('BeginArrow',13)
    if directed: cf('EndArrow',13)
    if not bidirectional: cf('BeginArrowSize',0)

    sec=ET.SubElement(sh,f'{{{V}}}Section',{'N':'Geometry','IX':'0'})
    _cell(sec,'NoFill',1); _cell(sec,'NoLine',0); _cell(sec,'NoShow',0); _cell(sec,'NoSnap',0); _cell(sec,'NoQuickDrag',0)
    _emit_interactive_connector_geometry(
        sec, vis_pts, origin_x, origin_y,
        source_side=source_side, target_side=target_side,
        stub=0.25,
    )
    if label:
        ET.SubElement(sh,f'{{{V}}}Text').text=label+'\n'
    return sh


def _emit_interactive_connector_geometry(sec, vis_pts, origin_x, origin_y, *, source_side, target_side, stub=.25):
    """Write orthogonal Geometry that remains well-formed when endpoints move.

    Middle route vertices are page-pinned constants.  Endpoint adapters are
    ShapeSheet formulas derived from BeginX/BeginY/EndX/EndY and the selected
    connection-point side.  The adapters are Manhattan paths, so arbitrary
    endpoint movement cannot make the terminal segment diagonal or rotate an
    arrowhead away from its component.
    """
    if len(vis_pts)<2:
        return
    begin=vis_pts[0]; end=vis_pts[-1]
    middle=list(vis_pts[1:-1])
    if not middle:
        middle=[((begin[0]+end[0])/2.0,(begin[1]+end[1])/2.0)]
    sa=middle[0]; ta=middle[-1]

    def outward_expr(prefix, side):
        side=(side or '').upper()
        if side=='L': return (f'{prefix}X-{_fmt(stub)}', f'{prefix}Y')
        if side=='R': return (f'{prefix}X+{_fmt(stub)}', f'{prefix}Y')
        if side=='T': return (f'{prefix}X', f'{prefix}Y+{_fmt(stub)}')
        if side=='B': return (f'{prefix}X', f'{prefix}Y-{_fmt(stub)}')
        return (f'{prefix}X', f'{prefix}Y')

    def eval_outward(p,side):
        x,y=p; side=(side or '').upper()
        if side=='L': return (x-stub,y)
        if side=='R': return (x+stub,y)
        if side=='T': return (x,y+stub)
        if side=='B': return (x,y-stub)
        return p

    ss=eval_outward(begin,source_side); ts=eval_outward(end,target_side)
    sx,sy=outward_expr('Begin',source_side)
    tx,ty=outward_expr('End',target_side)
    shoriz=(source_side or '').upper() in {'L','R'}
    thoriz=(target_side or '').upper() in {'L','R'}
    sb=(ss[0],sa[1]) if shoriz else (sa[0],ss[1])
    tb=(ts[0],ta[1]) if thoriz else (ta[0],ts[1])
    sbx,sby=(sx,_fmt(sa[1])) if shoriz else (_fmt(sa[0]),sy)
    tbx,tby=(tx,_fmt(ta[1])) if thoriz else (_fmt(ta[0]),ty)

    rows=[]
    rows.append((begin, 'BeginX','BeginY'))
    rows.append((ss, sx,sy))
    rows.append((sb, sbx,sby))
    for p in middle:
        rows.append((p,_fmt(p[0]),_fmt(p[1])))
    rows.append((tb,tbx,tby))
    rows.append((ts,tx,ty))
    rows.append((end,'EndX','EndY'))

    def local_formula(expr,axis):
        return f'GUARD(({expr})-Pin{axis}+LocPin{axis})'

    for i,(p,xexpr,yexpr) in enumerate(rows):
        row=ET.SubElement(sec,f'{{{V}}}Row',{'T':'MoveTo' if i==0 else 'LineTo','IX':str(i+1)})
        xc=ET.SubElement(row,f'{{{V}}}Cell',{'N':'X','V':_fmt(p[0]-origin_x),'F':local_formula(xexpr,'X')})
        yc=ET.SubElement(row,f'{{{V}}}Cell',{'N':'Y','V':_fmt(p[1]-origin_y),'F':local_formula(yexpr,'Y')})


def _cell(parent,n,v):ET.SubElement(parent,f'{{{V}}}Cell',{'N':n,'V':_fmt(v)})
def _fmt(v):
    if isinstance(v,str): return v
    x=float(v)
    if abs(x)<5e-12: x=0.0
    return f'{x:.6f}'.rstrip('0').rstrip('.')

def _signed(delta):
    d=float(delta)
    if abs(d)<1e-9:return '+0'
    return f'{d:+.6f}'.rstrip('0').rstrip('.')

def _geom_rect(sec):
    for i,(t,x,y) in enumerate([('RelMoveTo',0,0),('RelLineTo',1,0),('RelLineTo',1,1),('RelLineTo',0,1),('RelLineTo',0,0)],1):
        r=ET.SubElement(sec,f'{{{V}}}Row',{'T':t,'IX':str(i)});_cell(r,'X',x);_cell(r,'Y',y)
def _label_point(pts):
    # midpoint of longest segment
    seg=max(zip(pts,pts[1:]),key=lambda ab:abs(ab[0][0]-ab[1][0])+abs(ab[0][1]-ab[1][1]));return ((seg[0][0]+seg[1][0])/2,(seg[0][1]+seg[1][1])/2)
def _node_style(t):
    s=t.lower()
    if s.startswith('aws.'):return '#FFF7EC','#D86613'
    if 'database' in s or s.endswith('.rds') or 'dynamo' in s:return '#F3F0FF','#5F48A8'
    if 'person' in s or 'actor' in s:return '#F4F6F8','#56616B'
    if 'external' in s:return '#F4F6F8','#77818A'
    return '#EEF5FB','#3C78A8'
def _group_fill(t):return '#F5F7F9'
def _group_stroke(t): return '#D86613' if 'aws' in t.lower() else '#8A949E'
def _slug(s):return re.sub(r'[^a-zA-Z0-9_-]+','_',s)


def _det_guid(*segments):
    payload='|'.join(str(x) for x in segments).encode('utf-8')
    return '{'+str(uuid.UUID(bytes=hashlib.md5(payload).digest())).upper()+'}'


def _ensure_dynamic_connector_master(pkg):
    """Ensure a native-style Dynamic connector master exists in the package.

    This is adapted from the MIT-licensed OfficeIMO.Visio built-in Dynamic
    Connector writer. It gives desktop Visio a genuine connector master so
    glue/reroute behavior is owned by Visio rather than by static path XML.
    Returns ``(master_id, master_part_path)``.
    """
    masters_name='visio/masters/masters.xml'
    master_rels_name='visio/masters/_rels/masters.xml.rels'
    # Reuse an existing Dynamic connector master from a template/stencil.
    if masters_name in pkg:
        root=ET.fromstring(pkg[masters_name])
        rels=ET.fromstring(pkg.get(master_rels_name,_empty_rels()))
        rel_by_id={r.get('Id'):r.get('Target') for r in rels}
        for m in root.findall(f'{{{V}}}Master'):
            name=(m.get('NameU') or m.get('Name') or '').strip().lower()
            if name=='dynamic connector':
                rel=m.find(f'{{{V}}}Rel')
                rid=rel.get(f'{{{R}}}id') if rel is not None else None
                target=rel_by_id.get(rid)
                if target:
                    return int(m.get('ID')), 'visio/masters/'+Path(target).name

    if masters_name in pkg:
        mroot=ET.fromstring(pkg[masters_name])
        mrroot=ET.fromstring(pkg.get(master_rels_name,_empty_rels()))
    else:
        mroot=ET.Element(f'{{{V}}}Masters')
        mrroot=ET.Element(f'{{{REL}}}Relationships')

    max_id=max([int(m.get('ID','0')) for m in mroot.findall(f'{{{V}}}Master')]+[0])
    max_part=max([int(m.group(1)) for n in pkg for m in [re.match(r'visio/masters/master(\d+)\.xml$',n)] if m]+[0])
    max_rid=max([_ridnum(r.get('Id','')) for r in mrroot]+[0])
    master_id=max_id+1
    part_num=max_part+1
    rid=f'rId{max_rid+1}'
    part=f'visio/masters/master{part_num}.xml'

    master=ET.SubElement(mroot,f'{{{V}}}Master',{
        'ID':str(master_id),
        'Name':'Dynamic connector','NameU':'Dynamic connector',
        'IsCustomNameU':'1','IsCustomName':'1',
        'Prompt':'This connector automatically routes between the shapes it connects.',
        'IconSize':'1','AlignName':'2','MatchByName':'1','IconUpdate':'0',
        'UniqueID':_det_guid('Unique','Dynamic connector','6'),
        'BaseID':_det_guid('Base','Dynamic connector'),
        'PatternFlags':'0','Hidden':'0','MasterType':'0',
    })
    ps=ET.SubElement(master,f'{{{V}}}PageSheet',{'LineStyle':'0','FillStyle':'0','TextStyle':'0'})
    for n,v in [
        ('PageWidth',3.937007874015748),('PageHeight',3.937007874015748),
        ('ShdwOffsetX',0.1181102362204724),('ShdwOffsetY',-0.1181102362204724),
        ('PageScale',0.03937007874015748),('DrawingScale',0.03937007874015748),
        ('DrawingSizeType',4),('DrawingScaleType',0),('InhibitSnap',0),
        ('PageLockReplace',0),('PageLockDuplicate',0),('UIVisibility',0),
        ('ShdwType',0),('ShdwObliqueAngle',0),('ShdwScaleFactor',1),('DrawingResizeType',0),
    ]:_cell(ps,n,v)
    layer=ET.SubElement(ps,f'{{{V}}}Section',{'N':'Layer'})
    row=ET.SubElement(layer,f'{{{V}}}Row',{'IX':'1'})
    for n,v in [('Name','Connector'),('Color',255),('Status',0),('Visible',1),('Print',1),('Active',0),('Lock',0),('Snap',1),('Glue',1),('NameUniv','Connector'),('ColorTrans',0)]:_cell(row,n,v)
    rel=ET.SubElement(master,f'{{{V}}}Rel'); rel.set(f'{{{R}}}id',rid)
    ET.SubElement(mrroot,f'{{{REL}}}Relationship',{
        'Id':rid,'Type':'http://schemas.microsoft.com/visio/2010/relationships/master','Target':Path(part).name,
    })

    # OfficeIMO-style generated Dynamic Connector master content.
    mc=ET.Element(f'{{{V}}}MasterContents'); mc.set(f'xmlns:r',R); mc.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
    shapes=ET.SubElement(mc,f'{{{V}}}Shapes')
    s=ET.SubElement(shapes,f'{{{V}}}Shape',{'ID':'1','Name':'Dynamic connector','NameU':'Dynamic connector','Type':'Shape','LineStyle':'0','FillStyle':'0','TextStyle':'0'})
    for n,v in [('BeginX',0),('BeginY',0),('EndX',1),('EndY',0)]:_cell(s,n,v)
    for n,v in [
        ('OneD',1),('ObjType',2),('LineWeight',0.0138889),('LinePattern',1),('LineColor','#000000'),
        ('FillPattern',0),('FillForegnd','#FFFFFF'),('LockHeight',1),('LockCalcWH',1),
        ('GlueType',2),('NoAlignBox',1),('DynFeedback',2),('ShapeSplittable',1),('LayerMember',0),
        ('ShapeSplit',1),('QuickStyleType',2),
    ]:_cell(s,n,v)
    control=ET.SubElement(s,f'{{{V}}}Section',{'N':'Control'})
    crow=ET.SubElement(control,f'{{{V}}}Row',{'N':'TextPosition'})
    _cell(crow,'X',0); _cell_f(crow,'Y',-1,'Controls.TextPosition.Y'); _cell_f(crow,'XDyn',0,'Controls.TextPosition'); _cell_f(crow,'YDyn',-1,'Controls.TextPosition.Y')
    _cell(crow,'XCon',5); _cell(crow,'YCon',0); _cell(crow,'CanGlue',0); _cell(crow,'Prompt','Reposition Text')
    user=ET.SubElement(s,f'{{{V}}}Section',{'N':'User'}); urow=ET.SubElement(user,f'{{{V}}}Row',{'N':'visVersion'}); _cell(urow,'Value',15)
    ch=ET.SubElement(s,f'{{{V}}}Section',{'N':'Character'}); chrow=ET.SubElement(ch,f'{{{V}}}Row',{'IX':'0'}); _cell(chrow,'Size',0.1388888888888889)

    pkg[masters_name]=ET.tostring(mroot,encoding='utf-8',xml_declaration=True)
    pkg[master_rels_name]=ET.tostring(mrroot,encoding='utf-8',xml_declaration=True)
    pkg[part]=ET.tostring(mc,encoding='utf-8',xml_declaration=True)

    # Document -> masters list relationship.
    drel_name='visio/_rels/document.xml.rels'; droot=ET.fromstring(pkg.get(drel_name,_empty_rels()))
    if not any(r.get('Type','').endswith('/masters') for r in droot):
        drid=max([_ridnum(r.get('Id','')) for r in droot]+[0])+1
        ET.SubElement(droot,f'{{{REL}}}Relationship',{
            'Id':f'rId{drid}','Type':'http://schemas.microsoft.com/visio/2010/relationships/masters','Target':'masters/masters.xml',
        })
    pkg[drel_name]=ET.tostring(droot,encoding='utf-8',xml_declaration=True)

    # Content-type overrides.
    ct=ET.fromstring(pkg['[Content_Types].xml']); existing={x.get('PartName') for x in ct.findall(f'{{{CT}}}Override')}
    for pn,ctype in [
        ('/visio/masters/masters.xml','application/vnd.ms-visio.masters+xml'),
        ('/'+part,'application/vnd.ms-visio.master+xml'),
    ]:
        if pn not in existing:ET.SubElement(ct,f'{{{CT}}}Override',{'PartName':pn,'ContentType':ctype})
    pkg['[Content_Types].xml']=ET.tostring(ct,encoding='utf-8',xml_declaration=True)
    return master_id,part

def _new_pkg(page_w,page_h):
    page_w=max(5.0,page_w);page_h=max(3.5,page_h)
    return {
      '[Content_Types].xml':_ct_xml(), '_rels/.rels':_root_rels(), 'visio/document.xml':_doc_xml(), 'visio/_rels/document.xml.rels':_doc_rels(),
      'visio/windows.xml':_windows_xml(page_w,page_h),
      'visio/pages/pages.xml':_pages_xml(page_w,page_h), 'visio/pages/_rels/pages.xml.rels':_pages_rels(), 'visio/pages/page1.xml':_page_xml(),
      'docProps/app.xml':_app_xml(), 'docProps/core.xml':_core_xml()
    }
def _load_pkg(path):
    with zipfile.ZipFile(path) as z:return {n:z.read(n) for n in z.namelist()}
def _write_pkg(pkg,out):
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in pkg.items():z.writestr(n,b)
def _first_page_part(pkg):
    # Follow pages rel if possible; otherwise first page*.xml.
    return sorted([n for n in pkg if re.fullmatch(r'visio/pages/page\d+\.xml',n)])[0]
def _page_size(pkg):
    root=ET.fromstring(pkg['visio/pages/pages.xml']);p=root.find(f'{{{V}}}Page');ps=p.find(f'{{{V}}}PageSheet'); vals={c.get('N'):float(c.get('V')) for c in ps.findall(f'{{{V}}}Cell') if c.get('N') in {'PageWidth','PageHeight'}};return vals.get('PageWidth',11),vals.get('PageHeight',8.5)
def _package_masters(pkg):
    if 'visio/masters/masters.xml' not in pkg:return {}
    root=ET.fromstring(pkg['visio/masters/masters.xml']);return {m.get('NameU') or m.get('Name') or str(m.get('ID')):int(m.get('ID')) for m in root.findall(f'{{{V}}}Master')}
def _rels_name(page):
    p=Path(page);return str(p.parent/'_rels'/(p.name+'.rels')).replace('\\','/')
def _empty_rels():return b'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>'
def _ridnum(s):
    m=re.search(r'(\d+)$',s);return int(m.group(1)) if m else 0
def _unique_media(pkg,name):
    stem=Path(name).stem;suf=Path(name).suffix;out=name;i=2
    while 'visio/media/'+out in pkg:out=f'{stem}_{i}{suf}';i+=1
    return out

def _ensure_png_content_type(pkg):
    root=ET.fromstring(pkg['[Content_Types].xml']);existing={(x.get('Extension'),x.get('ContentType')) for x in root.findall(f'{{{CT}}}Default')}
    if any(n.lower().endswith('.png') for n in pkg) and ('png','image/png') not in existing:ET.SubElement(root,f'{{{CT}}}Default',{'Extension':'png','ContentType':'image/png'})
    pkg['[Content_Types].xml']=ET.tostring(root,encoding='utf-8',xml_declaration=True)
def _ct_xml():return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="{CT}"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/visio/document.xml" ContentType="application/vnd.ms-visio.drawing.main+xml"/><Override PartName="/visio/windows.xml" ContentType="application/vnd.ms-visio.windows+xml"/><Override PartName="/visio/pages/pages.xml" ContentType="application/vnd.ms-visio.pages+xml"/><Override PartName="/visio/pages/page1.xml" ContentType="application/vnd.ms-visio.page+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>'''.encode()
def _root_rels():return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="{REL}"><Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/document" Target="visio/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>'''.encode()
def _doc_xml():return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<VisioDocument xmlns="{V}" xmlns:r="{R}" xml:space="preserve">
  <DocumentSettings TopPage="0" DefaultTextStyle="0" DefaultLineStyle="0" DefaultFillStyle="0" DefaultGuideStyle="0">
    <GlueSettings>9</GlueSettings><SnapSettings>295</SnapSettings><SnapExtensions>34</SnapExtensions><SnapAngles/><DynamicGridEnabled>1</DynamicGridEnabled><ProtectStyles>0</ProtectStyles><ProtectShapes>0</ProtectShapes><ProtectMasters>0</ProtectMasters><ProtectBkgnds>0</ProtectBkgnds>
  </DocumentSettings>
  <Colors/>
  <FaceNames><FaceName NameU="Calibri"/></FaceNames>
  <StyleSheets>
    <StyleSheet ID="0" Name="No Style" NameU="No Style">
      <Cell N="EnableLineProps" V="1"/><Cell N="EnableFillProps" V="1"/><Cell N="EnableTextProps" V="1"/>
      <Cell N="LineWeight" V="0.01041666666666667"/><Cell N="LineColor" V="#000000"/><Cell N="LinePattern" V="1"/>
      <Cell N="FillForegnd" V="#FFFFFF"/><Cell N="FillPattern" V="1"/><Cell N="VerticalAlign" V="1"/>
      <Section N="Character"><Row IX="0"><Cell N="Font" V="Calibri"/><Cell N="Color" V="#000000"/><Cell N="Size" V="0.1388888889"/></Row></Section>
      <Section N="Paragraph"><Row IX="0"><Cell N="HorzAlign" V="1"/></Row></Section>
      <Section N="Tabs"><Row IX="0"/></Section>
    </StyleSheet>
  </StyleSheets>
  <DocumentSheet NameU="TheDoc" Name="TheDoc" LineStyle="0" FillStyle="0" TextStyle="0"><Cell N="DocLangID" V="1033"/></DocumentSheet>
</VisioDocument>'''.encode()
def _doc_rels():return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="{REL}"><Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/pages" Target="pages/pages.xml"/><Relationship Id="rId2" Type="http://schemas.microsoft.com/visio/2010/relationships/windows" Target="windows.xml"/></Relationships>'''.encode()
def _windows_xml(w,h):
    # Window dimensions are display units, not drawing inches. Keep them integer/schema-safe.
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Windows xmlns="{V}" ClientWidth="1024" ClientHeight="768"><Window ID="1" WindowType="Drawing" WindowState="0" ContainerType="Page" Container="0" Page="0" ViewScale="1" ViewCenterX="{w/2:.6f}" ViewCenterY="{h/2:.6f}" WindowWidth="1024" WindowHeight="768" WindowLeft="0" WindowTop="0"/></Windows>'''.encode()
def _pages_xml(w,h):return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Pages xmlns="{V}" xmlns:r="{R}" xml:space="preserve"><Page ID="0" Name="Generated Architecture" NameU="Generated Architecture" ViewScale="1" ViewCenterX="{w/2}" ViewCenterY="{h/2}"><PageSheet LineStyle="0" FillStyle="0" TextStyle="0"><Cell N="PageWidth" V="{w}"/><Cell N="PageHeight" V="{h}"/><Cell N="PageScale" V="1"/><Cell N="DrawingScale" V="1"/><Cell N="DrawingSizeType" V="3"/><Cell N="DrawingScaleType" V="0"/><Cell N="RouteStyle" V="1"/><Cell N="LineJumpCode" V="1"/></PageSheet><Rel r:id="rId1"/></Page></Pages>'''.encode()
def _pages_rels():return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="{REL}"><Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/page" Target="page1.xml"/></Relationships>'''.encode()
def _page_xml():return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><PageContents xmlns="{V}" xmlns:r="{R}" xml:space="preserve"><Shapes/></PageContents>'''.encode()
def _app_xml():return b'''<?xml version="1.0" encoding="UTF-8"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Visio Architecture Renderer</Application></Properties>'''
def _core_xml():return b'''<?xml version="1.0" encoding="UTF-8"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:creator>Visio Architecture Renderer</dc:creator></cp:coreProperties>'''
