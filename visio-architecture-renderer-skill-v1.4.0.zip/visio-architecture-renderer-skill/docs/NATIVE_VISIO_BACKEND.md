# Native Microsoft Visio backend

Version 1.4.0 adds a dual-renderer architecture.

## Backends

`--backend vsdx`

- Pure Python.
- Works on Linux, macOS, Windows, containers and CI.
- Writes the editable VSDX/ShapeSheet package directly.
- Keeps the deterministic renderer-planned orthogonal route.
- Does not require Microsoft Visio.

`--backend visio`

- Windows only.
- Requires desktop Microsoft Visio plus `pywin32`.
- First produces the same portable VSDX as the `vsdx` backend.
- Opens that file through `Visio.Application` COM automation.
- Preserves all generated nodes, groups, provider icons, labels, connection points, ScreenTips and Shape Data.
- Replaces only architecture connector shapes with connectors created by Microsoft Visio itself.
- Glues the connector endpoints to the exact `Connections.Xn` rows selected by the renderer.
- Sets `ShapeRouteStyle=1` (Right Angle), `ConFixedCode=0` (Reroute freely), `GlueType=0` (point glue), and leaves advanced page routing enabled (`LayoutRoutePassive=False`).
- Saves the result through Visio's native serializer.

`--backend auto` is the default. It selects `visio` only when running on Windows with `pywin32` installed and `Visio.Application` registered; otherwise it selects `vsdx`. If an auto-selected native finalization fails, the command falls back to the already-rendered portable VSDX and records the reason in `rendererBackend` in the report. An explicit `--backend visio` request is strict and fails instead of silently falling back.

## Install

Portable only:

```bash
pip install .
```

Windows native backend:

```bash
pip install .[visio]
arch2visio backend-info
```

Example:

```bash
arch2visio render architecture.puml -o architecture.vsdx --backend visio --report architecture.report.json
```

Use `--visio-visible` during development if you want to see the desktop Visio instance while finalization runs.

## Why the native backend is connector-only

The portable renderer already contains the more mature architecture-specific intelligence: PlantUML/Mermaid parsing, provider/service recognition, cloud icon resolution, semantic shapes, nested groups, deterministic component placement, exact perimeter-port assignment, connector-label policy, ScreenTips and Shape Data.

The difficult remaining problem is interactive connector behavior after a human edits the drawing in Visio. Hand-authored ShapeSheet geometry can preserve an excellent initial route but is difficult to make behave exactly like a connector that Visio created itself after arbitrary drag/reglue operations.

Therefore v1.4.0 does not duplicate the full renderer in COM. It uses the existing renderer as the planning/materialization stage and delegates only native connector ownership to Visio.

## Connector behavior

The native finalizer uses the exact router-selected connection point rather than whole-shape walking glue. This preserves deterministic source/target ports and ensures the terminal direction metadata on those connection points is retained.

Unlike the portable backend's fixed route, the native connector is freely reroutable. When a connected component moves, Visio is allowed to recalculate the right-angle route. The endpoint remains editable by the user and can be detached or re-glued in Visio.

The tradeoff is that Visio can choose a different middle route from the portable planner. The report therefore retains the renderer's planned quality metrics and separately records the selected/actual backend and the connector IDs created by Visio.

## Metadata and labels

The existing policy is unchanged:

- Conversion from PUML/Mermaid/etc. preserves the source-visible connector label.
- New diagrams authored from requirements use semantic visible labels and put detailed endpoint/operation information in ScreenTips and Shape Data.

The COM finalizer re-applies connector labels, ScreenTips and Shape Data from the canonical model when it creates the native connector.

## Templates, stencils and icons

These continue to be handled by the portable stage, including imported user stencils/masters and official AWS icons. Because the native stage opens the already-rendered VSDX, it does not need to reconstruct those assets through COM.

## Validation

On non-Windows systems, normal structural validation and LibreOffice smoke rendering remain available.

On Windows with Visio, additionally run the desktop open/glue checks in `scripts/validate_with_visio.ps1` and `scripts/validate_glue_with_visio.ps1`.
