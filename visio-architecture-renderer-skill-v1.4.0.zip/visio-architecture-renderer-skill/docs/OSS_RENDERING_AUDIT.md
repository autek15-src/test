# Open-source rendering audit

This renderer deliberately adopts third-party ideas/code only when they improve the architecture-to-Visio result or desktop compatibility.

## Adopted: OfficeIMO.Visio

Repository: https://github.com/EvotecIT/OfficeIMO  
License: MIT

Useful items incorporated/adapted:

- Visio-native triangle arrowhead mapping (`EndArrow.Triangle = 13`).
- Conflict-first, whole-page rerouting strategy: route the page, identify the most conflicted connectors, and accept reroutes only when the page-level interaction score improves.
- Connector quality concepts including orthogonal routing, explicit connection points, obstacle avoidance, crossing-aware scoring, and page-level polish.

The Python implementation in this package is native to this package rather than a .NET dependency. See `third_party/OfficeIMO-LICENSE.txt`.

## Evaluated but not bundled: Adaptagrams / libavoid

Repository: https://github.com/mjwybrow/adaptagrams  
License: LGPL-2.1-or-later

libavoid is a mature object-avoiding orthogonal connector router. Its design strongly validates the renderer's use of hard rectangular obstacles, directed connection pins, shape-buffer distance, bend penalties, crossing penalties, and post-routing nudging/polish. No Adaptagrams/libavoid source code is copied into this package, so the package does not acquire an LGPL runtime dependency.

## Evaluated but not bundled: @mr_mint/elkjs-libavoid

Repository: https://github.com/MrMint/elkjs-libavoid  
NPM: `@mr_mint/elkjs-libavoid`

This project combines ELK JSON graphs with libavoid and supports hierarchical/compound graphs, ports, and orthogonal obstacle-avoiding routes. It is technically a strong optional alternative, but making it mandatory would add Node.js plus WASM/runtime packaging. The current Python renderer passes the stricter real-world gates (zero component intersections, zero group overlaps, zero diagonal segments) and performs better than v1.1.4 on the supplied fixture, so this dependency is not introduced.

## Evaluated but not additionally reused

- `bharathgnana/archdiagram`: useful VSDX packaging/icon ideas already reflected in earlier releases; its layout/routing is simpler than the current renderer.
- `McMarius11/svgtovisio`: useful OPC/VSDX geometry and glue patterns already reflected in earlier releases; no stronger whole-page architecture routing was found.
- `ShanteshSindgi/cytoscape-vsdx`: good exporter when Cytoscape already owns layout; no improvement over the current architecture-specific routing/editability model.
- Eclipse ELK / elkjs: excellent layered/compound layout system, but adding a JavaScript/Java layout dependency is not justified while Graphviz + the internal grouped placement + native router satisfy the release gates.

## Acceptance principle

An OSS technique is retained only if it improves one or more measured release metrics without regressing Visio editability or adding disproportionate runtime complexity. The real-world fixture `examples/uml-test-realworld.puml` is the primary regression case for these decisions.


## Dynamic glue interoperability references (not reused)

For v1.2.4, Microsoft ShapeSheet documentation was the normative basis for dynamic connector behavior: `BegTrigger`/`EndTrigger` reference a target shape's `EventXFMod`, and endpoint formulas use Visio's walking-glue mechanism so a 1-D connector remains attached when the target moves. Historical Graphviz Visio output (EPL) and `ihordeyneka/json2visio` (GPL-3.0) were inspected only to confirm how those documented cells commonly appear in serialized Visio files. Their code and assets are not included or adapted into this MIT package.

## v1.4.0 native Visio automation audit

The dual backend work reviewed multiple public COM/MCP implementations as interoperability references, including `visio-mcp`, `visio-mcp-sci`, `isiec9ai/MCP`, `iakov-gan/mcp-server-visio`, and `CloudDaddyZA/VisioIntegration`, plus Microsoft Learn Automation documentation.

The reusable pattern is consistent across these projects: create a connector with `Page.Drop(Application.ConnectorToolDataObject, ...)` and glue `BeginX` / `EndX` with `Cell.GlueTo`. Several projects use whole-shape `PinX` glue; this skill deliberately does not. The v1.4.0 native finalizer uses the exact `Connections.Xn` cells selected by the existing routing engine, preserving deterministic fan-in/fan-out anchors.

No third-party MCP/COM source is copied into this package. The implemented COM layer is small and original: open the portable VSDX, recursively resolve shape IDs, delete each portable connector, create a Visio connector, glue it to the manifest-selected point cells, set right-angle/free-reroute behavior, reapply label/ScreenTip/Shape Data/style, ask Visio to lay out the connector, and save through Visio.

The architecture intentionally does not replace the portable renderer with a generic MCP implementation because the existing renderer is materially stronger at PUML/Mermaid parsing, provider/service inference, exact port assignment, grouping, icons, deterministic layout, source-label fidelity, and headless generation.
