# 1.4.0 - Dual Portable/Native Visio Backend

- Adds `--backend auto|vsdx|visio`. `auto` prefers desktop Microsoft Visio only when Windows, `pywin32`, and `Visio.Application` COM registration are available; otherwise it uses the existing portable VSDX backend.
- Adds a native Microsoft Visio COM finalization stage without duplicating the mature parser/layout/icon/group implementation. The portable emitter remains the source of truth for nodes, groups, icons, labels, metadata and exact connection points.
- Native finalization replaces only architecture connector shapes with connectors created by `Visio.Application.ConnectorToolDataObject`, then saves the package through Visio's native serializer.
- Native connectors glue to the exact renderer-selected `Connections.Xn` cells, preserve conversion labels and authored ScreenTips/Shape Data, and use `ShapeRouteStyle=1`, `ConFixedCode=0`, `GlueType=0`, plus `Page.LayoutRoutePassive=False` for right-angle interactive rerouting.
- Adds `arch2visio backend-info` and optional dependency group `pip install .[visio]`.
- Extends the portable connector manifest with exact source/target connection-cell names so the COM finalizer does not fall back to whole-shape `PinX` glue.
- Adds Windows-native architecture documentation and offline mock regression coverage for exact point glue, metadata, right-angle route settings, freely-reroutable connectors, and nested-shape lookup.
- `auto` mode falls back to the already-rendered portable VSDX if a native finalization attempt fails; explicit `--backend visio` remains strict. The report records requested, selected and actual backend plus any fallback reason.

# 1.3.4 - Connector Metadata, Labeling Policy, and Editable Endpoint Glue

- Added mandatory connector-label mode distinction: source conversions preserve source-visible labels; newly authored diagrams use concise semantic labels with technical detail in ScreenTips and Shape Data.
- Added reusable conversion examples for PlantUML and Mermaid plus a rich from-scratch JSON example covering REST, Salesforce, SQS, and PostgreSQL interactions.
- Documented the desktop-Visio Shape Data string requirement (`U="STR"`, no `F="No Formula"` on text Value cells).
- Added canonical JSON `screenTip` and `shapeData` fields.
- Emits connector ScreenTip/Shape Data ShapeSheet elements before `Text`/other extension content, preserving the strict VSDX element ordering required by desktop Microsoft Visio.
- Recorded the confirmed interactive endpoint-editability rule: exact point-glue formulas on Begin/End cells must remain unguarded so users can detach/reglue endpoints.

# 1.3.3 - Direction-Locked Terminal Legs and Drag-Stable Connectors

- Fixes interactive Visio cases where dragging a component could leave the final connector leg approaching a component from the wrong direction, causing an arrowhead to point up/down/sideways instead of into the attached component.
- Adds formula-driven terminal adapters at both ends of every connector. The endpoint leg is always perpendicular to the selected `Connections.Xn` side and maintains a 0.25-inch minimum terminal standoff before the final arrow.
- Pins the middle route vertices to page coordinates so endpoint movement does not distort unrelated bends through connector XForm resizing.
- Uses the existing connection-point `DirX` / `DirY` vectors and independently enforces the same direction in Geometry formulas.
- Changes `ConFixedCode` from the undocumented native-sample value `6` to documented value `2` (Never reroute). This prevents moving an unrelated component from causing desktop Visio to rewrite a previously valid connector.
- Keeps exact connection-point glue, nested-group tracking, orthogonal routing, professional icons, and provider recognition from v1.3.2.

# 1.3.2 - Deterministic Connector Anchoring and Group-Visibility Fix

- Fixes the v1.3.1 real-world Visio regression where connectors could appear detached after Microsoft Visio recalculated walking glue on open. The router had chosen exact perimeter ports, but whole-shape `PinX` walking glue was free to choose a different side while the precomputed multi-bend Geometry still described the original route.
- Restores deterministic point-to-point glue to the exact generated `Connections.Xn` row selected by the router. Every `<Connect>` now targets the concrete connection point with the matching `ToPart=100+row` value.
- Uses group-safe `LOCTOPAR(PNT(...), Sheet.<id>!Width, ThePage!PageWidth)` formulas for `BeginX/BeginY/EndX/EndY`, so endpoints remain attached to nested components when a component or enclosing native Visio group moves.
- Formula-binds the first and last connector Geometry vertices to the live `Begin*`/`End*` cells, preventing the visible polyline from being left behind when Visio recalculates endpoint formulas.
- Uses static point glue (`GlueType=0`) instead of walking glue for generated routes. This preserves the renderer's chosen side/port and avoids open-time route drift.
- Keeps the v1.3.1 professional Tabler-derived pictograms and provider recognition unchanged.
- Makes architecture-zone fills translucent even when the source PUML specifies a fill color. This keeps connector legs legible if a desktop renderer places a group boundary above a connector during redraw.
- Adds regression tests for explicit connection-point glue, group-safe endpoint formulas, Geometry endpoint binding, and the standalone connector package model.

# 1.3.1 - Professional Native Icons and Provider-Aware Recognition

- Replaces the v1.3.0 hand-drawn API/service pseudo-glyphs with automatic professional pictograms from the bundled MIT-licensed Tabler set. The generic icons are precompiled into native Visio polyline geometry, so they remain visible, selectable and editable without bitmap support or optional runtime dependencies.
- Keeps semantic container geometry behind the pictogram where it adds meaning. Databases retain a cylinder body, gateways/functions retain a hexagonal body, external systems retain external-system notation, and other components use a clean architecture card.
- Makes generic icon use automatic by default rather than opt-in. Use `iconMode: "none"` / `icon_mode: "none"` when a native semantic shape without a pictogram is preferred. Explicit `builtinIcon` and `icon: "builtin:<name>"` overrides remain supported.
- Adds provider/service recognition from ordinary labels, partial names and architecture acronyms rather than requiring renderer-specific `aws.*` types. Examples include APIGW/API GW, DDB, RDS, Aurora, SQS, SNS, SFN, TGW, ALB/NLB/ELB, EKS/ECS/EC2, EventBridge, CloudWatch, Azure APIM/AKS/AAD/Cosmos DB, GCP GKE/GCE/GCS/BigQuery/PubSub, Salesforce/SFDC, Okta, HashiCorp Vault, Splunk, MuleSoft/Anypoint, SAP and Snowflake.
- When a user-supplied AWS Architecture Icons catalog is present, a generically declared PlantUML/JSON node such as `component "DDB Orders"` can now resolve the official DynamoDB icon from its inferred AWS service identity.
- Distinguishes primary component identity from contextual deployment/integration mentions. For example, `Angular 18 (ECS Fargate)` remains an application/service and `pmp-gateway-api [Okta JWT]` remains an API gateway; Fargate/Okta are reported as context and do not hijack the shape/icon.
- Adds `provider-recognition.puml` regression coverage and provider/semantic inference tests.
- Preserves the v1.2.7-v1.3.0 connector, grouping, routing, PUML color, arrowhead, Visio 2019 and quality-gate behavior.

# 1.3.0 - Built-in semantic architecture stencil layer

- Adds an offline professional semantic shape catalog adapted from the MIT-licensed OfficeIMO.Visio first-party Architecture, Network, Infrastructure, Cloud, Security/Identity, Containers/Kubernetes, and Data Platform stencil families.
- Replaces generic rectangle fallbacks with native editable Visio architecture notation, including database/cache/storage cylinders, API/gateway shapes, load balancers, queues/event buses/streams, servers, security/network shapes, clients, containers/clusters, external systems, and actors.
- Adds deterministic inference so generic PUML components labelled PostgreSQL/MySQL/MongoDB become databases, Redis becomes cache, Kafka becomes stream, and common AWS services map to appropriate native semantics when official AWS icons are unavailable.
- Preserves explicit PUML colors over the built-in semantic palette.
- Bundles a curated 25-icon subset of MIT-licensed Tabler Icons as SVG plus pre-rasterized PNG derivatives; explicit `builtinIcon`/`icon: builtin:<name>` overrides require no runtime SVG dependency.
- Adds `arch2visio list-shapes` and `arch2visio list-icons`.
- Adds semantic gallery and built-in icon examples plus regression tests.
- Retains the v1.2.7 pure-Python standalone connector representation reverse-engineered from a working Visio Standard 2019 save.

# Release Notes

## 1.2.7 - Pure-Python Visio-2019 Connector Interoperability

- Replaces the failed hand-authored Dynamic Connector master approach with the exact **standalone connector ShapeSheet pattern** reverse-engineered from a user-provided VSDX that Microsoft Visio Standard 2019 created and that was verified interactively to remain attached when components/groups move.
- The Python emitter now writes guarded `PinX`, `PinY`, `Width`, `Height`, `LocPinX`, and `LocPinY` cells plus walking-glue `BeginX/BeginY/EndX/EndY` formulas, `_XFTRIGGER(...EventXFMod)` triggers, `ObjType=2`, `GlueType=2`, `DynFeedback=2`, `ShapeRouteStyle=1`, and Visio-saved `ConFixedCode=6`.
- Uses whole-shape `<Connect>` glue to `PinX` (`ToPart=3`) exactly as the working Visio-generated sample.
- Removes synthetic ancestor-group `DEPENDSON(...)` trigger terms; the working Visio file showed that the nested component `EventXFMod` trigger is sufficient when its native parent group moves.
- Emits connector Geometry in the standalone connector's **local coordinate system**, preserving strictly orthogonal initial routes.
- Does not serialize an explicit `OneD` cell, matching the Visio-authored file; desktop Visio infers the 1-D connector interaction model from the connector XForm/glue representation.
- Removes the Microsoft-Visio finalizer from the production package. Generation is Python-only and self-contained; Visio COM remains optional only for interactive compatibility validation.
- Adds regression checks for the Visio-2019 golden connector pattern and retains structural/LibreOffice rendering gates.

## 1.2.4 - Native Visio Walking Glue and Drag-Safe Connectors

- Replaces the v1.2.3 coordinate-reference endpoint formulas with Visio's native dynamic/walking-glue model used by dynamic connectors.
- Generated connector endpoints now use `_WALKGLUE(BegTrigger,EndTrigger,WalkPreference)` / `_WALKGLUE(EndTrigger,BegTrigger,WalkPreference)`.
- Adds `BegTrigger`/`EndTrigger` formulas using `_XFTRIGGER(Sheet.<target>!EventXFMod)`, which is the Visio mechanism that causes 1-D connector endpoints to recalculate when an attached shape moves.
- Adds `DEPENDSON(...)` references to ancestor group `EventXFMod` cells so dragging an enclosing generated Visio group also invalidates/recalculates the connector endpoint.
- Changes generated `<Connect>` records from fixed connection-point glue (`Connections.Xn`) to native dynamic whole-shape glue (`PinX`, `ToPart=3`), allowing Visio to walk the endpoint around the component boundary and reroute after a drag.
- Keeps the renderer's obstacle-free orthogonal route as the initial route while formula-binding the first/last geometry vertices to the live connector endpoints.
- Retains standard medium triangle arrowheads and right-angle routing with `ConFixedCode=0` (reroute freely).
- Strengthens package validation to require walking-glue formulas, trigger-to-target consistency, and group-trigger dependencies for grouped components.
- Adds `scripts/validate_glue_with_visio.ps1`, a native Microsoft Visio COM smoke test that moves a connected component and, when applicable, its enclosing group and verifies that the connector endpoint actually changes.
- Graphviz's historical Visio exporter and GPL `json2visio` were used only as interoperability references for Visio-generated ShapeSheet patterns; no code/assets from those non-permissive projects are included.

## 1.2.3 - Standard Arrowheads and True Interactive Glue

- Reduces directed connector arrowheads from Visio size 6 (Colossal) to size 2 (Medium), preserving triangle direction markers without visually overwhelming the diagram.
- Adds ShapeSheet endpoint glue formulas to `BeginX`, `BeginY`, `EndX`, and `EndY`; `<Connect>` metadata alone is no longer considered sufficient.
- Uses `LOCTOPAR(PNT(...), ..., ThePage!PageWidth)` so connection-point references remain valid for components nested inside one or more Visio groups.
- Sets `ConFixedCode=0` (reroute freely) on generated connectors so Visio can recalculate a right-angle route after connected components/groups are moved.
- Marks generated components as placeable (`ObjType=1`) and generated group parents as containing placeable/routable shapes (`ObjType=8`) to cooperate with Visio layout/rerouting behavior.
- Strengthens VSDX validation: every explicit connection-point `<Connect>` must have a matching group-safe endpoint formula and matching X/Y endpoint formulas.
- Adds regression tests for formula glue, standard arrow size, rerouting cells, and grouped component behavior.

## 1.2.2 - Visible Group Members and Native XForm1D Arrowheads

- Fixes v1.2.1 regression where a filled rectangle geometry on the `Type="Group"` parent painted over nested component shapes, making member component boxes disappear in Visio/PDF export.
- Follows the native Visio/OfficeIMO group model: the group parent is geometry-free and a dedicated boundary rectangle is emitted as the first child behind all member components. The boundary remains part of the true Visio group, so moving the group moves the boundary and all members together.
- Rewrites connectors to native XForm1D semantics: only `BeginX/BeginY/EndX/EndY` endpoint cells are emitted, without a synthetic 2-D `PinX/PinY/Width/Height` transform.
- Writes connector Geometry rows in absolute page coordinates, matching native/OfficeIMO Visio connector serialization. This fixes the case where `EndArrow=13` existed in the ShapeSheet but desktop/office renderers did not visibly draw the arrowhead.
- Keeps filled triangle arrowheads (`EndArrow=13`, size 6) and increases connector line weight slightly for high-density architecture pages.
- Adds regression tests requiring geometry-free group parents, a visible boundary child, renderable nested members, and native XForm1D connector structure whose final geometry vertex matches `EndX/EndY`.
- Visually regression-tested against the supplied real-world PlantUML fixture after LibreOffice VSDX-to-PDF conversion: component boxes and directional arrowheads are visible again.

## 1.2.1 - Visible Direction Arrows and Native Movable Groups

- Increases directed connector arrowheads to Visio filled triangle style 13 at size 6 (Colossal) and raises connector line weight so direction remains visually obvious even on very large architecture pages.
- Converts architecture zone rectangles from passive shapes into native Visio `Type="Group"` shapes with nested component subshapes. Dragging a generated group in Visio therefore moves its member components with it.
- Preserves nested group hierarchies recursively and converts child XForms from page coordinates into parent-group local coordinates.
- Keeps connectors page-level and glued to explicit connection points on the nested component IDs so endpoint glue follows grouped components.
- Adds VSDX regression tests for visible arrowhead settings, native group structure, nested component membership, local child coordinates, and connector glue to grouped members.


## 1.2.0 - PUML Fidelity, Hard Obstacle Routing, and Zone Separation

- Preserves PlantUML `skinparam` component/database/rectangle fill and border colors plus explicit per-node/per-zone colors such as `#FFF0CC`, `#FFDACC`, `#D6EED6`, and `#F0F0F0`.
- Renders PlantUML `actor` as a native single-shape stick figure with attached label and connection points rather than a generic rectangle.
- Uses Visio triangle arrowhead value 13 for visible directed connectors; reverse-only PlantUML arrows are normalized to the correct source/target direction, and headless associations remain headless.
- Treats source and target components as hard obstacles for the connector middle route. Only the first escape segment and last ingress segment may contact endpoint shapes, preventing connector re-entry through its own endpoints.
- Strengthens the `nodeIntersections` metric so endpoint re-entry can no longer be hidden by ignoring source/target boxes.
- Adds sibling-zone/group de-overlap. Complete group subtrees are translated together and boundaries are recomputed, producing `groupOverlaps = 0` on the supplied real-world fixture.
- Adds an OfficeIMO/libavoid-inspired whole-page routing polish pass. Worst connectors are revisited and reroutes are accepted only when crossing/overlap/bend cost improves while remaining obstacle-free.
- Uses a two-stage layout evaluation so all placement candidates are screened cheaply and only the strongest finalists receive expensive routing polish.
- On `uml-test-realworld.puml`, improves connector crossings from 12 in v1.1.4 to 7 while keeping `nodeIntersections = 0`, `groupOverlaps = 0`, and `diagonalSegments = 0`.
- Adds VSDX regression tests for PUML colors, native actor geometry, visible arrowheads, reverse/headless direction semantics, hard component avoidance, and group-overlap elimination.
- Adds `docs/OSS_RENDERING_AUDIT.md` and OfficeIMO MIT attribution/license.

## 1.1.4 - Real-world Regression Fixture

- Adds `examples/uml-test-realworld.puml`, a real-world PlantUML regression fixture derived from the user-provided architecture diagram scenario.
- Extends validation coverage to render and validate the real-world fixture alongside the smoke and dense-routing fixtures.
- Confirms the renderer produces a structurally valid Visio 2019 / LibreOffice-openable VSDX for the fixture.

## 1.1.3 - Native Anchors, Bound Labels, and Orthogonal Routing

- Fixes the visual/editability failures seen in dense Visio output where labels were detached from components, connectors were glued to whole shapes, and routes could become diagonal or run over components.
- Stores each component label on its owning Visio shape. AWS icon-backed components use one Foreign shape containing both image placement and label text.
- Stores edge labels on their connector shape rather than as independent floating text objects, with a light text background for readability.
- Adds explicit Visio Connection Points rows around component perimeters and maps each routed port to a concrete `Connections.Xn` anchor.
- Glues connector endpoints to those anchors using connection-point `ToPart` semantics rather than whole-shape `PinX` glue.
- Sets generated connector `ShapeRouteStyle=1` (Right Angle). The previous value 16 represented center-to-center routing.
- Fixes connector local Y-coordinate serialization that could distort multi-segment routes after conversion to Visio coordinates.
- Replaces endpoint grid snapping with exact perpendicular escape legs and a rectilinear visibility-graph router. Every emitted route segment is horizontal or vertical.
- Treats unrelated component boxes as hard routing obstacles and adds `nodeIntersections` to the quality report and completion gate.
- Strongly increases crossing and shared-corridor penalties so a longer clean path is preferred over a short crossing.
- Auto mode now evaluates both Graphviz and the internal layered placement engine across all layout profiles.
- Uses nested Graphviz clusters as placement constraints for PlantUML/C4/AWS groups and fixes parent group bounds that could be finalized before child groups.
- Auto-sizes default components from realistic multi-line labels and decodes PlantUML `\n`, `\l`, and `\r` escapes.
- Adds a dense architecture regression fixture, explicit-anchor/orthogonal-geometry tests, group-containment tests, and completion-gate checks requiring zero diagonal segments and zero component intersections.

## 1.1.2 - PlantUML Architecture Parser Fixes

- Parses styled/colored PlantUML links such as `A -[#0066CC]-> B`, `-[#green,dashed]->`, direction hints, and `[hidden]` links instead of silently dropping those edges.
- Preserves hex arrow colors as edge metadata and uses them for native Visio connector line colors.
- Treats PlantUML `rectangle { ... }`, `package { ... }`, `frame { ... }`, `folder { ... }`, `cloud { ... }`, and `node { ... }` blocks as nested architecture groups rather than leaf nodes.
- Supports aliased and unaliased zone/container blocks, with deterministic IDs for unaliased quoted group labels.
- Preserves parent/child nesting such as AWS Cloud -> VPC -> availability zone/subnet/zone.
- Treats PlantUML `[hidden]` relationships as layout constraints but omits them from rendered Visio connectors.
- Expands standard PlantUML node declarations to include actors and common deployment-diagram element kinds.
- Adds parser and renderer regression fixtures for colored links, dashed links, hidden links, and nested rectangle zones.
- Adds the styled/nested PlantUML fixture to the package completion validator.

## 1.1.1 - Visio Desktop Compatibility Fix

- Fixes Microsoft Visio Standard/Professional 2019 open failure reported as **Error 271 during Open File** for freshly generated VSDX packages.
- Corrects ShapeSheet XML child ordering so Character/Paragraph/Tabs sections precede the `<Text>` element as required by the Visio schema.
- Defines StyleSheet ID 0 and DocumentSheet in fresh `document.xml` instead of referencing an undefined default style.
- Adds desktop-oriented `visio/windows.xml`, its document relationship, and content type.
- Marks generated connectors as native 1-D connector shapes (`OneD=1`, `ObjType=2`, `GlueType=2`).
- Adds PNG `CompressionType` metadata on embedded bitmap ForeignData.
- Expands VSDX validation with desktop compatibility checks for style references, ShapeSheet ordering, connector semantics, image relationships, and Windows metadata.
- Adds regression tests specifically covering these failures.
- Adds `scripts/validate_with_visio.ps1` for an optional native Microsoft Visio COM open test on Windows.

## 1.1.0 - AWS Icon Catalog/Indexer

## AWS icon catalog/indexer
- recursively indexes every user-supplied AWS SVG/PNG/JPEG icon instead of scanning filenames independently for every node
- caches the index outside the AWS asset directory and reuses it on subsequent renders
- adds deterministic scoring using normalized official names, service aliases, acronyms, token overlap, service/resource semantics, format, and image size
- adds a broad built-in AWS service/abbreviation alias catalog while still supporting newly released services directly from official filenames
- prefers SVG when available and automatically falls back to PNG/JPEG if SVG conversion is unavailable
- adds custom alias extension files via `--aws-aliases`
- adds `arch2visio index-aws-icons` and `arch2visio resolve-aws-icon`
- adds explicit `--aws-icon-index` and `--refresh-aws-icon-index` controls
- includes icon resolution details and cache status in the JSON render quality report
- adds AWS index/resolution/render tests, including unknown future-service filename matching

## Existing v1.0 capabilities retained
- canonical architecture JSON schema
- Mermaid parser
- PlantUML/C4/common AWS macro parser
- automatic Graphviz-or-layered placement
- multiple layout profiles with score-based selection
- obstacle-aware orthogonal routing with congestion penalty
- native editable VSDX shapes, text, polyline connectors, and connector glue records
- optional VSDX template preservation and safe drawing area
- optional VSSX stencil master import and master mapping
- structural VSDX validation and optional LibreOffice open/render smoke test
- Codex/Claude-style `SKILL.md`, CLI/scripts, examples, tests, and completion validator
