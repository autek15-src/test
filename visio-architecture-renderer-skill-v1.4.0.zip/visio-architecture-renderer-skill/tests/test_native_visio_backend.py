from __future__ import annotations

import os
import pytest

from visio_arch_renderer.backend import resolve_backend
from visio_arch_renderer.model import Diagram, Edge
from visio_arch_renderer.native_visio import _replace_connectors


class FakeCell:
    def __init__(self, name):
        self.name=name
        self.FormulaU=''
        self.glued_to=None
    def GlueTo(self, other):
        self.glued_to=other
    def ResultStrU(self, _unit):
        return self.FormulaU


class FakeShapes:
    def __init__(self, items=None):
        self.items=list(items or [])
    @property
    def Count(self): return len(self.items)
    def Item(self, i): return self.items[i-1]


class FakeShape:
    def __init__(self, sid, children=None):
        self.ID=sid
        self.Shapes=FakeShapes(children)
        self._cells={}
        self.Text=''
        self.Name=''
        self.NameU=''
        self.deleted=False
        self.layout_called=False
    def CellsU(self, name):
        return self._cells.setdefault(name,FakeCell(name))
    def Cells(self, name):
        return self.CellsU(name)
    def CellExistsU(self, name, _flags):
        return name in self._cells
    def AddNamedRow(self, _section, row, _tag):
        self.CellsU(f'Prop.{row}')
        self.CellsU(f'Prop.{row}.Label')
        self.CellsU(f'Prop.{row}.Type')
        self.CellsU(f'Prop.{row}.Prompt')
    def Delete(self): self.deleted=True
    def Layout(self): self.layout_called=True


class FakeSheet:
    def __init__(self): self._cells={}
    def CellsU(self,name): return self._cells.setdefault(name,FakeCell(name))


class FakePage:
    def __init__(self, shapes):
        self.Shapes=FakeShapes(shapes)
        self.PageSheet=FakeSheet()
        self.LayoutRoutePassive=True
        self.next_id=500
        self.dropped=[]
    def Drop(self, _obj, _x, _y):
        sh=FakeShape(self.next_id); self.next_id+=1
        self.Shapes.items.append(sh); self.dropped.append(sh)
        return sh


class FakeApp:
    ConnectorToolDataObject=object()


def test_auto_backend_is_portable_on_non_windows():
    if os.name=='nt':
        pytest.skip('non-Windows behavior test')
    selected, detail=resolve_backend('auto')
    assert selected=='vsdx'
    assert detail['nativeVisioAvailable'] is False


def test_explicit_native_backend_errors_when_unavailable():
    if os.name=='nt':
        pytest.skip('non-Windows behavior test')
    with pytest.raises(RuntimeError):
        resolve_backend('visio')


def test_native_finalizer_replaces_connector_with_exact_point_glue_and_dynamic_routing():
    source=FakeShape(10); target=FakeShape(20); old=FakeShape(30)
    source_cp=source.CellsU('Connections.X1')
    target_cp=target.CellsU('Connections.X2')
    group=FakeShape(40,[source,target])
    page=FakePage([group,old])
    edge=Edge('a','b','Load profile',metadata={
        'color':'#112233','screenTip':'GET /profiles/{id}\nHTTPS/REST',
        'shapeData':{'HTTP Method':'GET','REST Path':'/profiles/{id}'}
    })
    diagram=Diagram(nodes=[],groups=[],edges=[edge])
    manifest={'connectors':[{
        'shapeId':30,'sourceShapeId':10,'targetShapeId':20,
        'sourceConnectionCell':'Connections.X1','targetConnectionCell':'Connections.X2'
    }]}
    result=_replace_connectors(FakeApp(),page,diagram,manifest)
    assert old.deleted
    new=page.dropped[0]
    assert new.CellsU('BeginX').glued_to is source_cp
    assert new.CellsU('EndX').glued_to is target_cp
    assert new.CellsU('ShapeRouteStyle').FormulaU=='1'
    assert new.CellsU('ConFixedCode').FormulaU=='0'
    assert new.CellsU('GlueType').FormulaU=='0'
    assert page.LayoutRoutePassive is False
    assert page.PageSheet.CellsU('RouteStyle').FormulaU=='1'
    assert new.layout_called is True
    assert new.Text=='Load profile'
    assert new.CellsU('Comment').FormulaU=='"GET /profiles/{id}"&CHAR(10)&"HTTPS/REST"'
    assert new.CellsU('Prop.HTTP_Method').FormulaU=='"GET"'
    assert new.CellsU('Prop.REST_Path').FormulaU=='"/profiles/{id}"'
    assert result[0]['sourceConnectionCell']=='Connections.X1'
    assert result[0]['targetConnectionCell']=='Connections.X2'


def test_portable_manifest_exposes_exact_connection_cells(tmp_path):
    import json
    from visio_arch_renderer.render import render
    src=tmp_path/'x.json'; out=tmp_path/'x.vsdx'
    src.write_text(json.dumps({
        'nodes':[{'id':'a','label':'A'},{'id':'b','label':'B'}],
        'edges':[{'source':'a','target':'b','label':'Call B'}]
    }),encoding='utf-8')
    rep=render(src,out,backend='vsdx')
    conn=rep['visioNativeManifest']['connectors'][0]
    assert conn['sourceConnectionCell'].startswith('Connections.X')
    assert conn['targetConnectionCell'].startswith('Connections.X')
    assert conn['sourceSide'] in {'L','R','T','B'}
    assert conn['targetSide'] in {'L','R','T','B'}
