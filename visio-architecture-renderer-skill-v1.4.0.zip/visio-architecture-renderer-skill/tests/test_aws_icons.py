from __future__ import annotations
import base64
from pathlib import Path
from visio_arch_renderer.icons import AwsIconCatalog, index_aws_icons
from visio_arch_renderer.render import render
from visio_arch_renderer.validate import validate_vsdx

PNG_1X1 = base64.b64decode(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9ZlJ8AAAAASUVORK5CYII='
)
SVG = b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64"/></svg>'


def _write(root: Path, rel: str, data: bytes):
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    return p


def _fake_icons(root: Path):
    _write(root, 'Architecture-Service-Icons/Arch_Compute/Arch_AWS-Lambda_64.png', PNG_1X1)
    _write(root, 'Architecture-Service-Icons/Arch_Compute/Arch_AWS-Lambda.svg', SVG)
    _write(root, 'Architecture-Service-Icons/Arch_Networking-Content-Delivery/Arch_Amazon-API-Gateway_64.png', PNG_1X1)
    _write(root, 'Architecture-Service-Icons/Arch_Database/Arch_Amazon-RDS_64.png', PNG_1X1)
    _write(root, 'Architecture-Service-Icons/Arch_Networking-Content-Delivery/Arch_Elastic-Load-Balancing_64.png', PNG_1X1)
    _write(root, 'Resource-Icons/Res_Networking/Res_Elastic-Load-Balancing_Application-Load-Balancer_48.png', PNG_1X1)


def test_catalog_indexes_and_prefers_svg(tmp_path):
    icons = tmp_path / 'aws-icons'; _fake_icons(icons)
    cache = tmp_path / 'index.json'
    cat = AwsIconCatalog.from_directory(icons, cache_path=cache)
    assert len(cat.records) == 6
    assert cache.exists()
    assert cat.resolve('aws.lambda').suffix == '.svg'
    assert 'API-Gateway' in cat.resolve('aws.api_gateway').name
    assert 'Application-Load-Balancer' in cat.resolve('aws.application_load_balancer').name
    cat2 = AwsIconCatalog.from_directory(icons, cache_path=cache)
    assert cat2.cache_hit is True


def test_custom_alias_extends_builtin(tmp_path):
    icons = tmp_path / 'aws-icons'; _fake_icons(icons)
    aliases = tmp_path / 'aliases.json'
    aliases.write_text('{"lambda":["corp function"]}', encoding='utf-8')
    cat = AwsIconCatalog.from_directory(icons, cache_path=tmp_path/'i.json', aliases_path=aliases)
    assert 'Lambda' in cat.resolve('aws.corp_function').name


def test_index_report(tmp_path):
    icons = tmp_path / 'aws-icons'; _fake_icons(icons)
    rep = index_aws_icons(icons, cache_path=tmp_path/'index.json')
    assert rep['iconCount'] == 6
    assert rep['formats']['.png'] == 5
    assert rep['formats']['.svg'] == 1
    assert rep['aliasGroups'] > 50



def test_unknown_future_service_resolves_from_official_filename(tmp_path):
    icons = tmp_path / 'aws-icons'
    _write(icons, 'Architecture-Service-Icons/Arch_New/Arch_Amazon-Nova-Service_64.png', PNG_1X1)
    cat = AwsIconCatalog.from_directory(icons, cache_path=tmp_path/'future.json')
    match = cat.resolve('aws.nova_service')
    assert match is not None and 'Nova-Service' in match.name


def test_render_embeds_indexed_png_icons(tmp_path):
    icons = tmp_path / 'aws-icons'
    _write(icons, 'Architecture-Service-Icons/Arch_Compute/Arch_AWS-Lambda_64.png', PNG_1X1)
    _write(icons, 'Architecture-Service-Icons/Arch_Networking/Arch_Amazon-API-Gateway_64.png', PNG_1X1)
    _write(icons, 'Architecture-Service-Icons/Arch_Database/Arch_Amazon-RDS_64.png', PNG_1X1)
    root = Path(__file__).resolve().parents[1]
    out = tmp_path / 'aws.vsdx'
    rep = render(root/'examples'/'aws-target.json', out, aws_icons_dir=icons, aws_icon_index=tmp_path/'index.json', backend='vsdx')
    assert validate_vsdx(out)['ok']
    assert rep['awsIcons']['enabled'] is True
    resolved = {x['node'] for x in rep['awsIcons']['resolved']}
    assert {'apigw','lambda','rds'} <= resolved


def test_render_resolves_official_aws_icon_from_generic_label(tmp_path):
    icons=tmp_path/'aws-icons'
    _write(icons,'Architecture-Service-Icons/Arch_Database/Arch_Amazon-DynamoDB_64.png',PNG_1X1)
    src=tmp_path/'generic.json'
    src.write_text('{"title":"label inference","nodes":[{"id":"db","label":"DDB Orders","type":"component"}],"edges":[]}',encoding='utf-8')
    out=tmp_path/'generic.vsdx'
    rep=render(src,out,aws_icons_dir=icons,aws_icon_index=tmp_path/'index.json',backend='vsdx')
    assert validate_vsdx(out)['ok']
    assert rep['visioNativeManifest']['nodes']['db']['provider']['provider']=='aws'
    assert rep['visioNativeManifest']['nodes']['db']['provider']['service']=='dynamodb'
    resolved={x['node']:x for x in rep['awsIcons']['resolved']}
    assert 'db' in resolved and resolved['db']['recognizedService']=='dynamodb'
