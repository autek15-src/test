#!/usr/bin/env python3
"""Windows-only smoke test for the optional native Microsoft Visio backend."""
from __future__ import annotations
import json, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from visio_arch_renderer.backend import visio_backend_available
from visio_arch_renderer.render import render
from visio_arch_renderer.validate import validate_vsdx


def main():
    available, reason=visio_backend_available()
    if not available:
        print(json.dumps({'ok':False,'nativeVisioAvailable':False,'reason':reason},indent=2))
        return 2
    with tempfile.TemporaryDirectory(prefix='arch2visio-native-smoke-') as td:
        out=Path(td)/'connector-smoke-native.vsdx'
        report=Path(td)/'connector-smoke-native.report.json'
        rep=render(ROOT/'examples'/'connector-smoke.puml',out,backend='visio',report=report)
        val=validate_vsdx(out)
        backend=rep.get('rendererBackend',{})
        ok=val.get('ok') is True and backend.get('actual')=='visio' and backend.get('nativeConnectorCount',0)>0
        print(json.dumps({'ok':ok,'backend':backend,'validation':val},indent=2))
        return 0 if ok else 1


if __name__=='__main__':
    raise SystemExit(main())
