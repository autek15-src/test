# Customization guide

Everything visual routes through `scripts/deck_theme.py`. The slide builders
and the matplotlib Gantt both read `PALETTE` and `FONTS`, so a re-brand is a
single edit — never hard-code colors in slide code.

## Re-branding the palette

Replace hex values, keep the semantic keys:

- `bg`, `card`, `card_hi`, `line` — background layers, darkest to lightest
  (or lightest to darkest in a light theme).
- `text`, `muted`, `faint` — three text emphasis levels. Keep contrast vs
  `bg` and `card` at WCAG-ish levels: `text` should be clearly readable at
  10pt on `card`.
- `accent`..`accent4` — brand accents; also the Gantt phase-bar cycle
  (`GANTT_PHASE_COLORS` picks which keys, in what order).
- `green` / `amber` / `red` + `*_bg` chip tints — RAG semantics. Keep these
  recognizably green/amber/red even under a brand palette; executives read
  RAG by color before they read any text.

## A tested light-theme variant

```python
PALETTE.update({
    "bg": "FFFFFF", "card": "F1F5F9", "card_hi": "E2E8F0", "line": "CBD5E1",
    "text": "0F172A", "muted": "475569", "faint": "94A3B8",
    "accent": "0284C7", "accent2": "4F46E5", "accent3": "0D9488",
    "accent4": "7C3AED",
    "green": "15803D", "amber": "B45309", "red": "B91C1C",
    "green_bg": "DCFCE7", "amber_bg": "FEF3C7", "red_bg": "FEE2E2",
})
```

Two things to check after any palette change: the Gantt in-bar phase labels
are drawn in `bg` color (they assume bars are darker than text would be —
on a light theme with pale accents, switch that to `text` in
`gantt_chart.py`), and the % complete overlay is white at 35% alpha (invert
to black on light bars).

## Fonts

`FONTS["display"]` (titles, big numbers) and `FONTS["body"]`. Stick to fonts
that ship with Office AND render true-to-width in LibreOffice QA: Arial,
Calibri, Cambria, Times New Roman, Courier New. If the user demands a brand
font outside that list, use it but leave ~10% extra room in text boxes and
don't fully trust the QA render's text fit.

## Adding slides

Pattern for a new content slide in `build_deck.py`:

```python
def slide_next_steps(prs, data, page_no):
    s = blank_slide(prs)
    add_slide_header(s, "Looking ahead", "Next Steps")
    # ... cards / text via add_rect, add_text, add_chip ...
    footer(s, data, page_no)
```

Then call it in `build_deck()` in the right order and pass a page number.
Layout conventions the existing slides follow (keep them for a coherent deck):
0.6" margins all around; content starts at y≈1.5–1.75 below the header;
cards use `fill="card"` with `radius≈0.11–0.13`; 0.3" gaps between cards;
kickers/labels are 9–12pt bold `display` font in `accent` or `faint`;
body text 10–14pt `body` font; nothing centered except values in table-like
cells and chips. Avoid decorative accent bars, lines under titles, and
text-only slides — the theme's motif is rounded cards, pill chips, and
status dots.

## Gantt tweaks

In `gantt_chart.py`: `ROW_H`/`BAR_H`/`BAND_PAD` control density; `width_in`/
`height_in` args control the render size (the deck passes 12.13 × 5.15 in at
200 dpi — keep the aspect ratio if you resize the slide placement); the
month locator can be swapped for `WeekdayLocator` on short projects
(< ~3 months) or `MonthLocator(interval=2)` on multi-year ones.

## Paginating big programmes

More than ~6 applications or ~5 risks won't fit their slides. Split the data
into multiple JSON files (e.g. by workstream) and build one deck per group,
or generate extra slides: call `slide_key_dates`/`slide_risks` more than once
with a sliced copy of the data dict.
