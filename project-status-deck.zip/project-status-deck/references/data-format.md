# Project JSON data format

One JSON file drives the whole deck. Top-level keys: `project`, `applications`,
`risks`. All dates are ISO `YYYY-MM-DD`; they are rendered as "15 Aug 26".

## `project` (object, required)

| Field | Req | Notes |
|---|---|---|
| `name` | yes | Programme/project name (title slide + footers). Keep ≤ ~45 chars so the 44pt title fits on one line. |
| `subtitle` | no | One line under the title. |
| `period` | no | Reporting period label, e.g. `"September 2026"`. |
| `as_of` | no | Reporting date; drives the Gantt TODAY line and defaults milestone coloring context. Defaults to today. |
| `presenter` | no | Shown as a chip on the title slide. |
| `overall_status` | no | `"green"` \| `"amber"` \| `"red"`. Default `"green"`. |
| `summary` | no | 2–3 sentence executive narrative (≤ ~340 chars fits the reserved two lines). |

## `applications` (array, required, 1–6 items)

Each application:

| Field | Req | Notes |
|---|---|---|
| `name` | yes | Application/workstream name. |
| `status` | no | RAG: `"green"` \| `"amber"` \| `"red"`. |
| `phase` | no | Current phase label shown on the status card, e.g. `"UAT"`. |
| `percent_complete` | no | Integer 0–100; big number on the card. |
| `note` | no | One-liner (≤ ~90 chars) on the card. |
| `milestones` | yes* | Drives the Key Dates matrix and the Gantt diamonds. |
| `gantt` | yes* | Drives the Gantt phase bars. |

\* Technically optional, but the key-dates slide and Gantt only show what you
provide.

### `milestones[]`

```json
{ "label": "SIT Exit", "date": "2026-10-02", "status": "at_risk" }
```

- `label`: use the SAME label strings across applications — the key-dates
  matrix columns are the ordered union of labels (first-seen order). A typo
  like "Go Live" vs "Go-Live" creates a duplicate column.
- `status`: `"done"` (green ✓), `"upcoming"` (default, white), `"at_risk"`
  (amber bold), `"late"` (red bold). Also colors the Gantt diamond.

### `gantt[]` (phases, in display order top→bottom)

```json
{ "task": "SIT", "start": "2026-08-10", "end": "2026-10-02", "percent": 40 }
```

- `task`: short phase name (≤ ~18 chars; long labels get clipped or crowd the
  chart).
- `percent`: optional 0–100 completion; draws the thin bright overlay.
- `color`: optional palette key (`accent`, `accent2`, `accent3`, `accent4`,
  `green`, ...) to override the default per-phase color cycle.
- 3–5 phases per application read best; the chart scales rows automatically.

## `risks` (array, optional, ≤ 5 per slide)

```json
{
  "title": "UAT tester availability during quarter close",
  "severity": "medium",
  "impact": "Billing UAT cycle 3 may slip up to one week.",
  "mitigation": "Backfill agreed with Finance; weekend slots pre-approved.",
  "owner": "J. Reyes",
  "due": "2026-09-12"
}
```

- `severity`: `"high"` \| `"medium"` \| `"low"` — rows are auto-sorted
  high→low and chip-colored red/amber/green.
- `title` ≤ ~70 chars; `impact` and `mitigation` 1–2 short sentences each.
- An empty/missing `risks` array skips the slide entirely.

## Minimal valid example

```json
{
  "project": { "name": "Atlas Upgrade", "period": "Q3 2026", "as_of": "2026-09-01" },
  "applications": [
    {
      "name": "Payments Service",
      "status": "green",
      "phase": "Build",
      "percent_complete": 60,
      "milestones": [
        { "label": "Dev Complete", "date": "2026-10-01" },
        { "label": "Go-Live", "date": "2026-12-01" }
      ],
      "gantt": [
        { "task": "Build", "start": "2026-07-01", "end": "2026-10-01", "percent": 60 },
        { "task": "Test", "start": "2026-10-01", "end": "2026-11-15" }
      ]
    }
  ],
  "risks": []
}
```

See `assets/example_project.json` for a full 4-application example that
exercises every field.
