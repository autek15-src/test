---
name: project-status-deck
description: Generate beautiful, professional PowerPoint (.pptx) software project status decks with a modern dark tech theme — title slide, executive summary with per-application RAG status cards, a key-dates matrix showing every relevant date for each application in scope, a theme-matched matplotlib Gantt chart, and a risks & issues slide. Use this skill whenever the user asks for a project status deck, status report presentation, steering committee (SteerCo) pack, programme/portfolio update, delivery status slides, RAG report, milestone review, or any PowerPoint that reports progress, timelines, key dates, or risks for one or more software applications or workstreams — even if they don't say "PowerPoint" explicitly but want a status deck or status pack.
---

# Software Project Status Deck

Build an executive-ready status deck from structured project data. The heavy
lifting is scripted: you describe the project in one JSON file, and the bundled
Python scripts (python-pptx + matplotlib) render a consistent, branded deck.
Your job is to gather accurate status content, fill the JSON well, run the
builder, and QA the render — not to hand-craft slides.

## The deck it produces

1. **Title** — programme name, subtitle, reporting period, presenter, overall
   RAG status, with a mini-gantt visual motif.
2. **Executive Summary** — narrative summary, overall status chip, and one
   status card per application (RAG dot, phase, % complete, one-line note).
3. **Key Dates by Application** — a matrix of every milestone date per
   application, color-coded: done ✓ (green), upcoming (white), at-risk
   (amber, bold), late (red, bold).
4. **Plan & Progress — Gantt** — a matplotlib Gantt matched to the deck theme:
   one band per application, phase bars with % complete overlays, milestone
   diamonds on each application's header line, month grid, and a TODAY line.
5. **Risks & Issues** — severity-sorted rows with severity chips, impact,
   mitigation, owner and due date. (Omitted automatically if `risks` is empty.)

## Workflow

### 1. Gather the content first

The deck is only as good as its data. Before writing any JSON, collect from
the user (or their documents/tools): the applications in scope, each one's
RAG status, current phase and % complete, milestone dates with their statuses,
phase start/end dates for the timeline, top risks/issues with owners, and the
overall narrative. If something important is missing, ask — don't invent
status facts. Placeholder data is fine only when the user explicitly wants a
demo/template deck.

### 2. Write the project JSON

Create `project.json` following `references/data-format.md` (read it — field
names and status vocabularies matter). A complete worked example lives at
`assets/example_project.json`; copying it and replacing values is the fastest
route. Content guidance that keeps slides clean:

- Keep per-app `note` to ~90 characters and risk texts to 1–2 short sentences
  — the layouts reserve tight boxes and long text will overflow.
- Use a consistent milestone vocabulary across applications (e.g. "Dev
  Complete", "SIT Exit", "UAT Exit", "Go-Live") so the key-dates matrix lines
  up; the column set is the ordered union of labels across apps. Aim for ≤ 6
  milestone labels and ≤ 6 applications per deck; beyond that, split into
  multiple decks or ask the user how to group.
- Set `project.as_of` to the reporting date — it drives the TODAY line.
- 3–5 risks fit on one slide; if there are more, keep the top 5 by severity
  and note the rest in the summary, or add a second risks slide (see below).

### 3. Build

```bash
cd <skill>/scripts
pip install python-pptx matplotlib --break-system-packages  # only if missing
python build_deck.py /path/to/project.json -o /path/to/status_deck.pptx
```

`gantt_chart.py` can also be run standalone to produce just the chart PNG
(useful when the user wants the Gantt for another document):

```bash
python gantt_chart.py project.json -o gantt.png
```

### 4. Visual QA (required)

Render and actually look at every slide before delivering:

```bash
soffice --headless --convert-to pdf status_deck.pptx
pdftoppm -jpeg -r 110 status_deck.pdf slide
```

Check for text overflowing its card or the slide edge (most common — shorten
the JSON text rather than resizing shapes), Gantt labels clipped at the chart
edge, milestone columns misaligned because of inconsistent labels, and any
empty-looking slide. Fix the data (or, rarely, the script) and rebuild.

### 5. Deliver

Send the `.pptx`. If the user wants tweaks like "make Data Migration red" or
"move UAT Exit to Nov 20", edit the JSON and rebuild — that's the whole point
of the pipeline.

## Customizing

- **Colors, fonts, re-branding**: edit `PALETTE` / `FONTS` in
  `scripts/deck_theme.py`. Both the slides and the Gantt read from it, so one
  edit re-skins everything. See `references/customization.md` for a tested
  light-theme variant and guidance on picking accessible values.
- **Extra slides** (accomplishments, next steps, budget, decisions needed):
  add a `slide_*` function in `build_deck.py` using the helpers in
  `deck_theme.py` (`blank_slide`, `add_slide_header`, `add_rect`, `add_text`,
  `add_chip`, `footer`). Follow the existing slides' pattern — 0.6" margins,
  cards on `card` fill, Arial display headers, Calibri body.
- **Design rules baked into the theme** (keep them when extending): dark
  background throughout, rounded cards and pill chips as the motif, no
  decorative accent bars or lines under titles, left-aligned body text,
  titles 30pt+, body 10–14pt, RAG colors reserved for status meaning only.

## Files

- `scripts/build_deck.py` — main entry point, one function per slide
- `scripts/gantt_chart.py` — standalone Gantt PNG renderer
- `scripts/deck_theme.py` — palette, fonts, shape/text helpers (edit to brand)
- `references/data-format.md` — full JSON schema with examples
- `references/customization.md` — re-branding, light theme, extending slides
- `assets/example_project.json` — complete realistic example (4 apps, 4 risks)
