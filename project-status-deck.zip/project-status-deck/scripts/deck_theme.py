"""
Shared theme + drawing helpers for the project-status-deck skill.

One place defines the entire look: colors, fonts, and the small set of
shape helpers every slide builder uses. To re-brand a deck, edit the
PALETTE and FONTS dicts here and everything (slides AND the matplotlib
Gantt chart) follows.
"""

from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn

# ---------------------------------------------------------------- palette --
# Modern-tech dark theme. Keys are semantic so swapping brands is safe.
PALETTE = {
    "bg":        "0B1220",  # slide background (near-black navy)
    "card":      "16202F",  # card / panel background
    "card_hi":   "1C2A3D",  # slightly lifted card (headers, hero chips)
    "line":      "2A3A52",  # hairlines, table grid
    "text":      "F1F5F9",  # primary text
    "muted":     "8CA0B8",  # secondary text
    "faint":     "5B6C82",  # tertiary text / captions
    "accent":    "38BDF8",  # electric cyan — the brand accent
    "accent2":   "818CF8",  # indigo — supporting accent
    "accent3":   "2DD4BF",  # teal — supporting accent
    "accent4":   "A78BFA",  # violet — supporting accent
    "green":     "34D399",  # on track / done
    "amber":     "FBBF24",  # at risk
    "red":       "F87171",  # off track / blocked
    "green_bg":  "12311F",  # tinted chip backgrounds
    "amber_bg":  "3A2E10",
    "red_bg":    "3A1D1D",
}

FONTS = {
    "display": "Arial",    # titles & big numbers (safe font, bold weights)
    "body":    "Calibri",  # everything else (safe font)
}

# Colors for Gantt phase bars, cycled in order per application.
GANTT_PHASE_COLORS = ["accent", "accent2", "accent3", "accent4"]

STATUS_LABELS = {"green": "ON TRACK", "amber": "AT RISK", "red": "OFF TRACK"}

# Slide geometry (16:9)
SLIDE_W_IN = 13.333
SLIDE_H_IN = 7.5
MARGIN_IN = 0.6


def rgb(key_or_hex):
    """Accept a palette key or a raw 6-digit hex string."""
    return RGBColor.from_string(PALETTE.get(key_or_hex, key_or_hex))


def status_color(status):
    return {"green": "green", "amber": "amber", "red": "red"}.get(status, "muted")


def status_bg(status):
    return {"green": "green_bg", "amber": "amber_bg", "red": "red_bg"}.get(status, "card_hi")


# ---------------------------------------------------------------- shapes ---

def paint_background(slide, color="bg"):
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = rgb(color)


def add_rect(slide, x, y, w, h, fill="card", line=None, line_w=0.75, radius=None):
    """Rounded rectangle (the deck's core motif). Sizes in inches.
    radius: corner radius in inches (approx), None = python-pptx default."""
    shp = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    if radius is not None:
        try:  # adjustment is a fraction of the shorter side
            shp.adjustments[0] = max(0.0, min(0.5, radius / min(w, h)))
        except Exception:
            pass
    if fill is None:
        shp.fill.background()
    else:
        shp.fill.solid()
        shp.fill.fore_color.rgb = rgb(fill)
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = rgb(line)
        shp.line.width = Pt(line_w)
    shp.shadow.inherit = False
    return shp


def add_dot(slide, x, y, d, fill):
    shp = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y), Inches(d), Inches(d))
    shp.fill.solid()
    shp.fill.fore_color.rgb = rgb(fill)
    shp.line.fill.background()
    shp.shadow.inherit = False
    return shp


def add_text(slide, x, y, w, h, runs, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP,
             space_after=0, line_spacing=1.0, wrap=True, autosize_off=True):
    """Add a text box. `runs` is a list of paragraphs; each paragraph is a
    list of (text, opts) tuples. opts keys: size, bold, italic, color, font.
    A paragraph may also be a single (text, opts) tuple for convenience."""
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = wrap
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    if autosize_off:
        from pptx.enum.text import MSO_AUTO_SIZE
        tf.auto_size = MSO_AUTO_SIZE.NONE
    first = True
    for para in runs:
        if isinstance(para, tuple):
            para = [para]
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = align
        p.line_spacing = line_spacing
        if space_after:
            p.space_after = Pt(space_after)
        for text, opts in para:
            r = p.add_run()
            r.text = text
            f = r.font
            f.size = Pt(opts.get("size", 14))
            f.bold = opts.get("bold", False)
            f.italic = opts.get("italic", False)
            f.name = FONTS[opts.get("font", "body")]
            f.color.rgb = rgb(opts.get("color", "text"))
    return tb


def add_chip(slide, x, y, w, h, label, fg, bg, size=10, bold=True):
    """Small rounded pill with centered label — used for statuses, dates,
    severities. Returns the shape."""
    shp = add_rect(slide, x, y, w, h, fill=bg, radius=h / 2)
    tf = shp.text_frame
    tf.word_wrap = False
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    r = p.add_run()
    r.text = label
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.name = FONTS["body"]
    r.font.color.rgb = rgb(fg)
    return shp


def add_slide_header(slide, kicker, title):
    """Standard content-slide header: small accent kicker + big title."""
    add_text(slide, MARGIN_IN, 0.42, SLIDE_W_IN - 2 * MARGIN_IN, 0.3,
             [(kicker.upper(), {"size": 12, "bold": True, "color": "accent",
                                "font": "display"})])
    add_text(slide, MARGIN_IN, 0.72, SLIDE_W_IN - 2 * MARGIN_IN, 0.62,
             [(title, {"size": 30, "bold": True, "color": "text",
                       "font": "display"})])


def blank_slide(prs, color="bg"):
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank layout
    paint_background(slide, color)
    return slide
