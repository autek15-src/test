"""
Build a professional software project status deck (.pptx) from project JSON.

Usage:
    python build_deck.py project.json -o status_deck.pptx

Slides produced:
    1. Title
    2. Executive summary (overall + per-application status cards)
    3. Key dates by application (milestone date matrix)
    4. Delivery timeline (matplotlib Gantt chart, theme-matched)
    5. Risks & issues

Data format: see references/data-format.md. Theme: deck_theme.py.
"""

import argparse
import json
import os
import tempfile
from datetime import datetime, date

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

from deck_theme import (
    STATUS_LABELS, SLIDE_W_IN, SLIDE_H_IN, MARGIN_IN,
    status_color, status_bg, add_rect, add_dot, add_text, add_chip,
    add_slide_header, blank_slide,
)
from gantt_chart import build_gantt

CONTENT_W = SLIDE_W_IN - 2 * MARGIN_IN


def _d(s):
    return datetime.strptime(s, "%Y-%m-%d").date()


def fmt_date(s):
    return _d(s).strftime("%d %b %y").lstrip("0")


def footer(slide, data, page_no):
    proj = data["project"]
    add_text(slide, MARGIN_IN, SLIDE_H_IN - 0.38, 8.0, 0.25,
             [(f"{proj['name']}  ·  {proj.get('period', '')}",
               {"size": 9, "color": "faint"})])
    add_text(slide, SLIDE_W_IN - MARGIN_IN - 1.0, SLIDE_H_IN - 0.38, 1.0, 0.25,
             [(str(page_no), {"size": 9, "color": "faint"})],
             align=PP_ALIGN.RIGHT)


# ------------------------------------------------------------------ slides --

def slide_title(prs, data):
    proj = data["project"]
    s = blank_slide(prs)

    # Decorative mini-gantt motif, top-right — abstract, on-topic.
    bars = [(9.0, 1.1, 2.6, "accent2"), (9.9, 1.62, 2.83, "accent"),
            (9.45, 2.14, 2.0, "accent3"), (10.4, 2.66, 2.33, "accent4")]
    for x, y, w, c in bars:
        add_rect(s, x, y, w, 0.28, fill=c, radius=0.14)

    add_text(s, MARGIN_IN, 2.55, 9.5, 0.35,
             [("SOFTWARE PROJECT STATUS",
               {"size": 14, "bold": True, "color": "accent", "font": "display"})])
    add_text(s, MARGIN_IN, 2.95, 11.5, 1.0,
             [(proj["name"],
               {"size": 44, "bold": True, "color": "text", "font": "display"})])
    if proj.get("subtitle"):
        add_text(s, MARGIN_IN, 3.85, 11.0, 0.45,
                 [(proj["subtitle"], {"size": 18, "color": "muted"})])

    # Info chips: reporting period, as-of date, presenter
    chips = []
    if proj.get("period"):
        chips.append(proj["period"])
    if proj.get("as_of"):
        chips.append("As of " + fmt_date(proj["as_of"]))
    if proj.get("presenter"):
        chips.append(proj["presenter"])
    x = MARGIN_IN
    for label in chips:
        w = 0.32 + 0.082 * len(label)
        add_chip(s, x, 4.6, w, 0.42, label, "text", "card_hi", size=11, bold=False)
        x += w + 0.22

    # Overall status, anchored bottom-left
    overall = proj.get("overall_status", "green")
    add_dot(s, MARGIN_IN, 6.28, 0.2, status_color(overall))
    add_text(s, MARGIN_IN + 0.32, 6.22, 6.0, 0.35,
             [[("Overall status:  ", {"size": 13, "color": "muted"}),
               (STATUS_LABELS.get(overall, overall.upper()),
                {"size": 13, "bold": True, "color": status_color(overall),
                 "font": "display"})]])


def slide_summary(prs, data, page_no):
    proj = data["project"]
    apps = data["applications"]
    s = blank_slide(prs)
    add_slide_header(s, f"Status report · {proj.get('period', '')}",
                     "Executive Summary")

    overall = proj.get("overall_status", "green")
    add_chip(s, SLIDE_W_IN - MARGIN_IN - 2.1, 0.55, 2.1, 0.44,
             "●  " + STATUS_LABELS.get(overall, overall.upper()),
             status_color(overall), status_bg(overall), size=11)

    if proj.get("summary"):
        add_text(s, MARGIN_IN, 1.5, CONTENT_W, 0.75,
                 [(proj["summary"], {"size": 13.5, "color": "muted"})],
                 line_spacing=1.15)

    # Application cards
    n = len(apps)
    cols = min(4, n)
    rows = (n + cols - 1) // cols
    gap = 0.3
    top = 2.45
    grid_h = SLIDE_H_IN - top - 0.55
    card_w = (CONTENT_W - gap * (cols - 1)) / cols
    card_h = min(2.3, (grid_h - gap * (rows - 1)) / rows)

    for i, app in enumerate(apps):
        r, c = divmod(i, cols)
        x = MARGIN_IN + c * (card_w + gap)
        y = top + r * (card_h + gap)
        add_rect(s, x, y, card_w, card_h, fill="card", radius=0.13)
        pad = 0.22
        st = app.get("status", "green")
        add_dot(s, x + pad, y + pad + 0.03, 0.14, status_color(st))
        add_text(s, x + pad + 0.24, y + pad - 0.035, card_w - 2 * pad - 0.24, 0.28,
                 [(app.get("phase", "").upper(),
                   {"size": 10, "bold": True, "color": status_color(st),
                    "font": "display"})])
        add_text(s, x + pad, y + pad + 0.28, card_w - 2 * pad, 0.55,
                 [(app["name"],
                   {"size": 15.5, "bold": True, "color": "text", "font": "display"})],
                 line_spacing=0.95)
        pct = app.get("percent_complete")
        if pct is not None:
            add_text(s, x + pad, y + card_h - 1.13, card_w - 2 * pad, 0.55,
                     [[(f"{pct}", {"size": 30, "bold": True, "color": "text",
                                   "font": "display"}),
                       ("%  complete", {"size": 11, "color": "faint"})]],
                     anchor=MSO_ANCHOR.BOTTOM)
        if app.get("note"):
            add_text(s, x + pad, y + card_h - 0.52, card_w - 2 * pad, 0.42,
                     [(app["note"], {"size": 9.5, "color": "muted"})],
                     line_spacing=1.0)
    footer(s, data, page_no)


def slide_key_dates(prs, data, page_no):
    apps = data["applications"]
    s = blank_slide(prs)
    add_slide_header(s, "Plan on a page", "Key Dates by Application")

    # Ordered union of milestone labels across applications
    labels = []
    for app in apps:
        for ms in app.get("milestones", []):
            if ms["label"] not in labels:
                labels.append(ms["label"])

    name_w = 2.35
    col_w = (CONTENT_W - name_w) / max(1, len(labels))
    top = 1.75
    header_h = 0.5
    row_h = min(0.82, (SLIDE_H_IN - top - header_h - 1.05) / max(1, len(apps)))
    date_size = 12 if len(labels) <= 6 else 10.5

    # Column headers
    for j, lab in enumerate(labels):
        add_text(s, MARGIN_IN + name_w + j * col_w, top + 0.12, col_w - 0.1, 0.35,
                 [(lab.upper(), {"size": 9.5, "bold": True, "color": "faint",
                                 "font": "display"})],
                 align=PP_ALIGN.CENTER, wrap=True)

    y = top + header_h
    for i, app in enumerate(apps):
        if i % 2 == 0:  # alternating row band
            add_rect(s, MARGIN_IN - 0.12, y + 0.03, CONTENT_W + 0.24, row_h - 0.06,
                     fill="card", radius=0.09)
        st = app.get("status", "green")
        add_dot(s, MARGIN_IN + 0.08, y + row_h / 2 - 0.055, 0.11, status_color(st))
        add_text(s, MARGIN_IN + 0.3, y, name_w - 0.3, row_h,
                 [(app["name"], {"size": 12.5, "bold": True, "color": "text",
                                 "font": "display"})],
                 anchor=MSO_ANCHOR.MIDDLE, line_spacing=0.95)
        by_label = {m["label"]: m for m in app.get("milestones", [])}
        for j, lab in enumerate(labels):
            ms = by_label.get(lab)
            cx = MARGIN_IN + name_w + j * col_w
            if not ms:
                add_text(s, cx, y, col_w - 0.1, row_h,
                         [("—", {"size": date_size, "color": "faint"})],
                         align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
                continue
            mst = ms.get("status", "upcoming")
            color = {"done": "green", "at_risk": "amber", "late": "red",
                     "upcoming": "text"}.get(mst, "text")
            prefix = "✓ " if mst == "done" else ""
            add_text(s, cx, y, col_w - 0.1, row_h,
                     [(prefix + fmt_date(ms["date"]),
                       {"size": date_size, "color": color,
                        "bold": mst in ("at_risk", "late")})],
                     align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        y += row_h

    # Legend
    ly = SLIDE_H_IN - 0.78
    legend = [("✓ Done", "green"), ("Upcoming", "text"),
              ("At risk", "amber"), ("Late", "red")]
    lx = MARGIN_IN
    for lab, col in legend:
        add_text(s, lx, ly, 1.5, 0.28, [(lab, {"size": 10, "color": col,
                                               "bold": col in ("amber", "red")})])
        lx += 1.1
    footer(s, data, page_no)


def slide_gantt(prs, data, gantt_png, page_no):
    s = blank_slide(prs)
    add_slide_header(s, "Delivery timeline", "Plan & Progress — Gantt")
    s.shapes.add_picture(gantt_png, Inches(MARGIN_IN), Inches(1.62),
                         width=Inches(CONTENT_W))
    footer(s, data, page_no)


def slide_risks(prs, data, page_no):
    risks = data.get("risks", [])
    s = blank_slide(prs)
    add_slide_header(s, "Watch list", "Risks & Issues")

    sev_rank = {"high": 0, "medium": 1, "low": 2}
    risks = sorted(risks, key=lambda r: sev_rank.get(r.get("severity"), 3))
    sev_style = {"high": ("red", "red_bg"), "medium": ("amber", "amber_bg"),
                 "low": ("green", "green_bg")}

    top = 1.62
    gap = 0.16
    avail = SLIDE_H_IN - top - 0.55
    row_h = min(1.15, (avail - gap * (len(risks) - 1)) / max(1, len(risks)))

    # Column guides
    x_sev, w_sev = MARGIN_IN + 0.2, 1.15
    x_risk = x_sev + w_sev + 0.3
    w_risk = 4.7
    x_mit = x_risk + w_risk + 0.3
    w_mit = 3.9
    x_own = x_mit + w_mit + 0.3
    w_own = 1.55
    add_text(s, x_risk, top - 0.3, w_risk, 0.25,
             [("RISK / ISSUE", {"size": 9, "bold": True, "color": "faint",
                                "font": "display"})])
    add_text(s, x_mit, top - 0.3, w_mit, 0.25,
             [("MITIGATION / NEXT STEP", {"size": 9, "bold": True,
                                          "color": "faint", "font": "display"})])
    add_text(s, x_own, top - 0.3, w_own, 0.25,
             [("OWNER · DUE", {"size": 9, "bold": True, "color": "faint",
                               "font": "display"})])

    y = top
    for r in risks:
        add_rect(s, MARGIN_IN, y, CONTENT_W, row_h, fill="card", radius=0.11)
        fg, bg = sev_style.get(r.get("severity", "medium"), ("amber", "amber_bg"))
        add_chip(s, x_sev, y + row_h / 2 - 0.17, w_sev, 0.34,
                 r.get("severity", "medium").upper(), fg, bg, size=9.5)
        body = [[(r["title"], {"size": 12.5, "bold": True, "color": "text",
                               "font": "display"})]]
        if r.get("impact"):
            body.append([(r["impact"], {"size": 10, "color": "muted"})])
        add_text(s, x_risk, y + 0.14, w_risk, row_h - 0.28, body,
                 line_spacing=1.02, space_after=2)
        add_text(s, x_mit, y + 0.14, w_mit, row_h - 0.28,
                 [(r.get("mitigation", ""), {"size": 10.5, "color": "text"})],
                 line_spacing=1.05, anchor=MSO_ANCHOR.MIDDLE)
        own = [[(r.get("owner", ""), {"size": 10.5, "bold": True,
                                      "color": "text"})]]
        if r.get("due"):
            own.append([(fmt_date(r["due"]), {"size": 10, "color": "muted"})])
        add_text(s, x_own, y + 0.14, w_own, row_h - 0.28, own,
                 line_spacing=1.05, anchor=MSO_ANCHOR.MIDDLE, space_after=2)
        y += row_h + gap
    footer(s, data, page_no)


# -------------------------------------------------------------------- main --

def build_deck(data, out_pptx, gantt_png=None):
    prs = Presentation()
    prs.slide_width = Inches(SLIDE_W_IN)
    prs.slide_height = Inches(SLIDE_H_IN)

    if gantt_png is None:
        gantt_png = os.path.join(tempfile.gettempdir(), "psd_gantt.png")
        build_gantt(data, gantt_png, width_in=CONTENT_W, height_in=5.15)

    slide_title(prs, data)
    slide_summary(prs, data, 2)
    slide_key_dates(prs, data, 3)
    slide_gantt(prs, data, gantt_png, 4)
    if data.get("risks"):
        slide_risks(prs, data, 5)

    prs.save(out_pptx)
    return out_pptx


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("project_json")
    ap.add_argument("-o", "--out", default="status_deck.pptx")
    ap.add_argument("--gantt-png", default=None,
                    help="Use a pre-rendered Gantt PNG instead of generating one")
    args = ap.parse_args()
    with open(args.project_json) as f:
        data = json.load(f)
    print(build_deck(data, args.out, args.gantt_png))


if __name__ == "__main__":
    main()
