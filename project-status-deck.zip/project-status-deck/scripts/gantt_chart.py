"""
Render a professional, deck-matched Gantt chart PNG with matplotlib.

Usage:
    python gantt_chart.py project.json -o gantt.png

Reads the same project JSON the deck builder uses (see
references/data-format.md). One row per phase, grouped by application,
with alternating application bands, month gridlines, milestone diamonds,
completion overlays, and a "today" line. Colors come from deck_theme so
the chart always matches the slides.
"""

import argparse
import json
from datetime import datetime, date

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import FancyBboxPatch, BoxStyle
from matplotlib.lines import Line2D

from deck_theme import PALETTE, GANTT_PHASE_COLORS


def _c(key):
    return "#" + PALETTE[key]


def _d(s):
    return datetime.strptime(s, "%Y-%m-%d").date()


ROW_H = 1.0          # y units per phase row
BAND_PAD = 0.55      # padding rows between application bands
BAR_H = 0.58         # bar thickness within a row


def build_gantt(data, out_png, width_in=12.13, height_in=5.15, dpi=200):
    apps = data["applications"]
    today = _d(data["project"].get("as_of", date.today().isoformat()))

    # ---- lay out rows top-to-bottom -------------------------------------
    rows = []          # (y_center, phase dict, color)
    bands = []         # (app, y_top, y_bottom)
    milestones = []    # (date, y_of_band_bottom, status)
    y = 0.0
    for app in apps:
        band_top = y
        for i, ph in enumerate(app.get("gantt", [])):
            y += ROW_H
            color_key = ph.get("color") or GANTT_PHASE_COLORS[i % len(GANTT_PHASE_COLORS)]
            rows.append((y - ROW_H / 2, ph, _c(color_key)))
        band_bottom = y
        for ms in app.get("milestones", []):
            milestones.append((_d(ms["date"]), band_top,
                              ms.get("status", "upcoming")))
        bands.append((app, band_top, band_bottom))
        y += BAND_PAD

    total_h = y - BAND_PAD
    starts = [_d(ph["start"]) for _, ph, _ in rows]
    ends = [_d(ph["end"]) for _, ph, _ in rows]
    ms_dates = [m[0] for m in milestones]
    t0 = min(starts + ms_dates + [today])
    t1 = max(ends + ms_dates + [today])
    span = (t1 - t0).days
    pad_l, pad_r = span * 0.02, span * 0.06

    fig, ax = plt.subplots(figsize=(width_in, height_in), dpi=dpi)
    fig.patch.set_facecolor(_c("bg"))
    ax.set_facecolor(_c("bg"))

    x0 = mdates.date2num(t0) - pad_l
    x1 = mdates.date2num(t1) + pad_r
    ax.set_xlim(x0, x1)
    ax.set_ylim(total_h + 0.15, -0.9)  # inverted: first app on top

    # ---- alternating application bands + labels -------------------------
    for idx, (app, top, bot) in enumerate(bands):
        if idx % 2 == 0:
            ax.axhspan(top - BAND_PAD * 0.45, bot + BAND_PAD * 0.45,
                       color=_c("card"), zorder=0)
        ax.text(x0 + span * 0.012, top - 0.12, app["name"],
                color=_c("text"), fontsize=10.5, fontweight="bold",
                va="bottom", ha="left", zorder=6)

    # ---- month grid ------------------------------------------------------
    months = mdates.MonthLocator()
    ax.xaxis.set_major_locator(months)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %y"))
    ax.grid(axis="x", color=_c("line"), linewidth=0.7, alpha=0.55, zorder=1)
    ax.tick_params(axis="x", colors=_c("muted"), labelsize=9, length=0)
    ax.xaxis.set_ticks_position("top")
    ax.tick_params(axis="y", left=False, labelleft=False)
    for spine in ax.spines.values():
        spine.set_visible(False)

    # ---- phase bars ------------------------------------------------------
    for yc, ph, color in rows:
        s, e = mdates.date2num(_d(ph["start"])), mdates.date2num(_d(ph["end"]))
        bar = FancyBboxPatch(
            (s, yc - BAR_H / 2), e - s, BAR_H,
            boxstyle=BoxStyle("Round", pad=0, rounding_size=0.16),
            mutation_aspect=(x1 - x0) / 40.0,
            facecolor=color, edgecolor="none", zorder=3)
        ax.add_patch(bar)
        pct = ph.get("percent")
        if pct:  # completion overlay: a brighter inner bar
            done_w = (e - s) * min(pct, 100) / 100.0
            inner = FancyBboxPatch(
                (s, yc - BAR_H / 6), done_w, BAR_H / 3,
                boxstyle=BoxStyle("Round", pad=0, rounding_size=0.05),
                mutation_aspect=(x1 - x0) / 40.0,
                facecolor="#FFFFFF", alpha=0.35, edgecolor="none", zorder=4)
            ax.add_patch(inner)
        # phase label: inside the bar if it fits; else beside it, flipped to
        # the left when it would run off the right edge of the chart
        label = ph["task"]
        bar_days = e - s
        est_w = len(label) * span * 0.0078  # rough text width in day units
        if bar_days > span * 0.14:
            ax.text(s + bar_days / 2, yc, label, color=_c("bg"),
                    fontsize=8.5, fontweight="bold", ha="center", va="center",
                    zorder=5)
        elif e + span * 0.008 + est_w > x1:
            ax.text(s - span * 0.008, yc, label, color=_c("muted"),
                    fontsize=8.5, ha="right", va="center", zorder=5)
        else:
            ax.text(e + span * 0.008, yc, label, color=_c("muted"),
                    fontsize=8.5, ha="left", va="center", zorder=5)

    # ---- milestones ------------------------------------------------------
    ms_face = {"done": _c("green"), "at_risk": _c("amber"),
               "late": _c("red"), "upcoming": "#FFFFFF"}
    for dt, top, status in milestones:
        xn = mdates.date2num(dt)
        # on the app's header line, next to the application name
        ax.plot([xn], [top - 0.26], marker="D", markersize=6.5,
                markerfacecolor=ms_face.get(status, "#FFFFFF"),
                markeredgecolor=_c("bg"), markeredgewidth=1.0, zorder=6,
                clip_on=False)

    # ---- today line ------------------------------------------------------
    tn = mdates.date2num(today)
    ax.axvline(tn, color=_c("accent"), linewidth=1.4, linestyle=(0, (5, 3)),
               zorder=7)
    ax.text(tn, -0.72, " TODAY", color=_c("accent"), fontsize=8.5,
            fontweight="bold", ha="left", va="bottom", zorder=7)

    # ---- legend ----------------------------------------------------------
    handles = [
        Line2D([], [], marker="D", linestyle="none", markersize=6,
               markerfacecolor="#FFFFFF", markeredgecolor=_c("bg"),
               label="Milestone"),
        Line2D([], [], marker="D", linestyle="none", markersize=6,
               markerfacecolor=_c("green"), markeredgecolor=_c("bg"),
               label="Milestone done"),
        Line2D([], [], color="#FFFFFF", alpha=0.5, linewidth=3,
               label="% complete"),
    ]
    leg = ax.legend(handles=handles, loc="upper right", frameon=False,
                    fontsize=8.5, ncol=3, bbox_to_anchor=(1.0, -0.015),
                    handletextpad=0.5, columnspacing=1.2)
    for t in leg.get_texts():
        t.set_color(_c("muted"))

    fig.subplots_adjust(left=0.01, right=0.99, top=0.93, bottom=0.075)
    fig.savefig(out_png, facecolor=_c("bg"))
    plt.close(fig)
    return out_png


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("project_json")
    ap.add_argument("-o", "--out", default="gantt.png")
    args = ap.parse_args()
    with open(args.project_json) as f:
        data = json.load(f)
    print(build_gantt(data, args.out))


if __name__ == "__main__":
    main()
